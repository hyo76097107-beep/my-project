import fs from 'fs';
import path from 'path';

export type SmsVerificationStatus = 'pending' | 'verified' | 'expired' | 'failed';
export type SmsProviderType =
  | 'CoolSMS'
  | 'Aligo'
  | 'Twilio'
  | 'NaverSENS'
  | 'Custom'
  | 'DirectSMS'
  | 'Manual_Admin_Input'
  | 'Sandbox';

export interface SmsDbRecord {
  id: string; // e.g. "sms_rec_1727581234567_abc1"
  phoneNumber: string; // raw digits "01012345678"
  displayPhone: string; // formatted "010-1234-5678"
  code: string; // 6-digit numeric verification code
  status: SmsVerificationStatus;
  attempts: number;
  provider: SmsProviderType;
  smsText: string;
  isRealSmsSent: boolean;
  createdAt: string; // ISO string
  createdTimestamp: number;
  expiresAt: string; // ISO string
  expiresTimestamp: number;
  verifiedAt?: string | null;
  verifiedTimestamp?: number | null;
  userId?: string | null;
  userHandle?: string | null;
  ipAddress?: string | null;
  notes?: string | null;
}

export interface SmsDbStats {
  total: number;
  verified: number;
  pending: number;
  expired: number;
  failed: number;
  todayCount: number;
  successRate: number;
}

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'sms_verification_db.json');

// Memory cache of DB records for rapid reads
let cachedRecords: SmsDbRecord[] = [];
let isInitialized = false;

/**
 * Format phone digits to standard Korean format
 */
export function formatKoreanPhone(digits: string): string {
  const clean = digits.replace(/\D/g, '');
  if (clean.length === 11) {
    return `${clean.slice(0, 3)}-${clean.slice(3, 7)}-${clean.slice(7, 11)}`;
  } else if (clean.length === 10) {
    return `${clean.slice(0, 3)}-${clean.slice(3, 6)}-${clean.slice(6, 10)}`;
  }
  return clean;
}

/**
 * Seed initial sample records if DB is newly created
 */
function getInitialSeedData(): SmsDbRecord[] {
  const now = Date.now();
  return [
    {
      id: `sms_rec_${now - 3600000 * 2}_seed1`,
      phoneNumber: '01012345678',
      displayPhone: '010-1234-5678',
      code: '839201',
      status: 'verified',
      attempts: 1,
      provider: 'CoolSMS',
      smsText: '[마음(Maeum)] 본인확인 인증번호 [839201]를 3분 이내에 입력해주세요.',
      isRealSmsSent: true,
      createdAt: new Date(now - 3600000 * 2).toISOString(),
      createdTimestamp: now - 3600000 * 2,
      expiresAt: new Date(now - 3600000 * 2 + 180000).toISOString(),
      expiresTimestamp: now - 3600000 * 2 + 180000,
      verifiedAt: new Date(now - 3600000 * 2 + 35000).toISOString(),
      verifiedTimestamp: now - 3600000 * 2 + 35000,
      userId: 'user_1',
      userHandle: 'minwoo_kim',
      notes: '회원가입 본인인증 성공 (시스템 시드 데이터)',
    },
    {
      id: `sms_rec_${now - 1800000}_seed2`,
      phoneNumber: '01098765432',
      displayPhone: '010-9876-5432',
      code: '472910',
      status: 'verified',
      attempts: 1,
      provider: 'Twilio',
      smsText: '[마음(Maeum)] 본인확인 인증번호 [472910]를 3분 이내에 입력해주세요.',
      isRealSmsSent: true,
      createdAt: new Date(now - 1800000).toISOString(),
      createdTimestamp: now - 1800000,
      expiresAt: new Date(now - 1800000 + 180000).toISOString(),
      expiresTimestamp: now - 1800000 + 180000,
      verifiedAt: new Date(now - 1800000 + 42000).toISOString(),
      verifiedTimestamp: now - 1800000 + 42000,
      userId: 'user_2',
      userHandle: 'seo_jin',
      notes: '휴대폰 본인인증 완료',
    },
  ];
}

/**
 * Initialize DB from disk or create file
 */
export function initSmsDb(): void {
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      const fileData = fs.readFileSync(DB_FILE, 'utf-8');
      try {
        const parsed = JSON.parse(fileData);
        if (Array.isArray(parsed)) {
          cachedRecords = parsed;
        } else {
          cachedRecords = getInitialSeedData();
          saveDbToDisk();
        }
      } catch (err) {
        console.error('[SMS DB] Corrupted DB file, resetting with seed data:', err);
        cachedRecords = getInitialSeedData();
        saveDbToDisk();
      }
    } else {
      cachedRecords = getInitialSeedData();
      saveDbToDisk();
      console.log('[SMS DB] Created new SMS verification database file at:', DB_FILE);
    }

    isInitialized = true;
  } catch (err) {
    console.error('[SMS DB] Failed to initialize SMS DB:', err);
    cachedRecords = getInitialSeedData();
  }
}

/**
 * Persist cached records to disk atomically
 */
function saveDbToDisk(): void {
  try {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
    fs.writeFileSync(tempFile, JSON.stringify(cachedRecords, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  } catch (err) {
    console.error('[SMS DB] Error saving to disk:', err);
  }
}

function ensureInitialized() {
  if (!isInitialized) {
    initSmsDb();
  }
}

/**
 * Insert a new SMS verification record into the DB
 */
export function insertSmsVerificationRecord(data: {
  phoneNumber: string;
  code: string;
  provider: SmsProviderType;
  smsText: string;
  isRealSmsSent: boolean;
  expiresInMinutes?: number;
  ipAddress?: string;
  notes?: string;
  status?: SmsVerificationStatus;
}): SmsDbRecord {
  ensureInitialized();

  const now = Date.now();
  const cleanDigits = data.phoneNumber.replace(/\D/g, '');
  const expiresInMs = (data.expiresInMinutes || 3) * 60 * 1000;
  const expiresTimestamp = now + expiresInMs;
  const id = `sms_rec_${now}_${Math.random().toString(36).substring(2, 7)}`;

  const newRecord: SmsDbRecord = {
    id,
    phoneNumber: cleanDigits,
    displayPhone: formatKoreanPhone(cleanDigits),
    code: data.code,
    status: data.status || 'pending',
    attempts: 0,
    provider: data.provider,
    smsText: data.smsText,
    isRealSmsSent: data.isRealSmsSent,
    createdAt: new Date(now).toISOString(),
    createdTimestamp: now,
    expiresAt: new Date(expiresTimestamp).toISOString(),
    expiresTimestamp,
    verifiedAt: data.status === 'verified' ? new Date(now).toISOString() : null,
    verifiedTimestamp: data.status === 'verified' ? now : null,
    ipAddress: data.ipAddress || null,
    notes: data.notes || (data.status === 'verified' ? '관리자 직접 입력 (즉시 인증)' : '발송 후 인증 대기중'),
  };

  // Add to top of list
  cachedRecords.unshift(newRecord);

  // Keep max 500 records to maintain speed
  if (cachedRecords.length > 500) {
    cachedRecords = cachedRecords.slice(0, 500);
  }

  saveDbToDisk();
  console.log(`[SMS DB] Inserted record ${newRecord.id} for phone ${newRecord.displayPhone} (code: ${newRecord.code})`);

  return newRecord;
}

/**
 * Find the latest active verification record for a phone number
 */
export function findLatestSmsRecord(phoneNumber: string): SmsDbRecord | undefined {
  ensureInitialized();
  const cleanDigits = phoneNumber.replace(/\D/g, '');
  return cachedRecords.find((rec) => rec.phoneNumber === cleanDigits);
}

/**
 * Find record by record ID
 */
export function findSmsRecordById(id: string): SmsDbRecord | undefined {
  ensureInitialized();
  return cachedRecords.find((rec) => rec.id === id);
}

/**
 * Increment attempt count for a record
 */
export function incrementSmsAttempt(id: string): SmsDbRecord | undefined {
  ensureInitialized();
  const record = cachedRecords.find((r) => r.id === id);
  if (!record) return undefined;

  record.attempts += 1;
  if (record.attempts > 5 && record.status === 'pending') {
    record.status = 'failed';
    record.notes = '최대 입력 시도(5회) 초과로 실패 처리';
  }
  saveDbToDisk();
  return record;
}

/**
 * Mark record as verified in DB
 */
export function markSmsRecordVerified(
  id: string,
  extra?: { userId?: string; userHandle?: string; notes?: string }
): SmsDbRecord | undefined {
  ensureInitialized();
  const record = cachedRecords.find((r) => r.id === id);
  if (!record) return undefined;

  const now = Date.now();
  record.status = 'verified';
  record.verifiedAt = new Date(now).toISOString();
  record.verifiedTimestamp = now;
  if (extra?.userId) record.userId = extra.userId;
  if (extra?.userHandle) record.userHandle = extra.userHandle;
  if (extra?.notes) record.notes = extra.notes;

  saveDbToDisk();
  console.log(`[SMS DB] Successfully verified record ${record.id} for phone ${record.displayPhone}`);
  return record;
}

/**
 * Link user to verified record in DB
 */
export function linkUserToSmsRecord(phoneNumber: string, userId: string, userHandle: string): boolean {
  ensureInitialized();
  const cleanDigits = phoneNumber.replace(/\D/g, '');
  const record = cachedRecords.find(
    (r) => r.phoneNumber === cleanDigits && r.status === 'verified'
  );
  if (record) {
    record.userId = userId;
    record.userHandle = userHandle;
    saveDbToDisk();
    return true;
  }
  return false;
}

/**
 * Delete record by ID
 */
export function deleteSmsRecord(id: string): boolean {
  ensureInitialized();
  const initialLen = cachedRecords.length;
  cachedRecords = cachedRecords.filter((r) => r.id !== id);
  if (cachedRecords.length !== initialLen) {
    saveDbToDisk();
    return true;
  }
  return false;
}

/**
 * Clear all records except seed data
 */
export function clearAllSmsRecords(): void {
  ensureInitialized();
  cachedRecords = getInitialSeedData();
  saveDbToDisk();
}

/**
 * Get all records with pagination and optional search filter
 */
export function getAllSmsRecords(query?: {
  search?: string;
  status?: string;
  limit?: number;
}): SmsDbRecord[] {
  ensureInitialized();
  let results = [...cachedRecords];

  const now = Date.now();
  // Automatically mark unverified records as expired if past expiresTimestamp
  let updatedAny = false;
  results.forEach((rec) => {
    if (rec.status === 'pending' && now > rec.expiresTimestamp) {
      rec.status = 'expired';
      updatedAny = true;
    }
  });
  if (updatedAny) {
    saveDbToDisk();
  }

  if (query?.status && query.status !== 'all') {
    results = results.filter((r) => r.status === query.status);
  }

  if (query?.search && query.search.trim()) {
    const s = query.search.trim().toLowerCase();
    results = results.filter(
      (r) =>
        r.phoneNumber.includes(s) ||
        r.displayPhone.includes(s) ||
        r.code.includes(s) ||
        (r.userId && r.userId.toLowerCase().includes(s)) ||
        (r.userHandle && r.userHandle.toLowerCase().includes(s)) ||
        (r.notes && r.notes.toLowerCase().includes(s))
    );
  }

  const limit = query?.limit || 100;
  return results.slice(0, limit);
}

/**
 * Compute statistics for SMS verification database
 */
export function getSmsDbStats(): SmsDbStats {
  ensureInitialized();
  const now = Date.now();
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const todayStartTimestamp = todayStart.getTime();

  let verified = 0;
  let pending = 0;
  let expired = 0;
  let failed = 0;
  let todayCount = 0;

  cachedRecords.forEach((r) => {
    let currentStatus = r.status;
    if (currentStatus === 'pending' && now > r.expiresTimestamp) {
      currentStatus = 'expired';
    }

    if (currentStatus === 'verified') verified++;
    else if (currentStatus === 'pending') pending++;
    else if (currentStatus === 'expired') expired++;
    else if (currentStatus === 'failed') failed++;

    if (r.createdTimestamp >= todayStartTimestamp) {
      todayCount++;
    }
  });

  const total = cachedRecords.length;
  const successRate = total > 0 ? Math.round((verified / total) * 100) : 0;

  return {
    total,
    verified,
    pending,
    expired,
    failed,
    todayCount,
    successRate,
  };
}
