import crypto from 'crypto';
import nodemailer from 'nodemailer';

export interface EmailVerificationRecord {
  code: string;
  expiresAt: number;
  attempts: number;
  verified: boolean;
  lastSentAt: number;
  sentCount: number;
  purpose?: string;
}

// In-memory verification store: lowercase email -> EmailVerificationRecord
const emailVerificationStore = new Map<string, EmailVerificationRecord>();

/**
 * Validate email address syntax
 */
export function isValidEmailFormat(email: string): boolean {
  if (!email || typeof email !== 'string') return false;
  const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return re.test(email.trim());
}

/**
 * Generate a beautifully styled HTML email template for 6-digit code
 */
export function generateVerificationEmailHtml(code: string, purpose: string = '본인확인'): string {
  return `
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>마음(Maeum) 이메일 인증코드</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1f2937;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f4f4f7; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table role="presentation" width="100%" style="max-width: 520px; background-color: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05); border: 1px solid #e5e7eb;">
          
          <!-- Header Banner -->
          <tr>
            <td style="background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%); padding: 36px 30px; text-align: center;">
              <div style="display: inline-block; background-color: rgba(255, 255, 255, 0.2); border-radius: 12px; padding: 8px 14px; margin-bottom: 12px;">
                <span style="font-size: 20px; font-weight: 800; color: #ffffff; letter-spacing: -0.5px;">마음 (Maeum)</span>
              </div>
              <h1 style="margin: 0; color: #ffffff; font-size: 22px; font-weight: 700; line-height: 1.3;">이메일 ${purpose} 인증번호</h1>
              <p style="margin: 8px 0 0 0; color: rgba(255, 255, 255, 0.85); font-size: 13px;">안전하고 신뢰할 수 있는 소셜 라이프의 시작</p>
            </td>
          </tr>

          <!-- Main Content -->
          <tr>
            <td style="padding: 36px 32px;">
              <p style="margin: 0 0 18px 0; font-size: 15px; line-height: 1.6; color: #374151;">
                안녕하세요! 마음(Maeum) 소셜 네트워크를 이용해 주셔서 감사합니다.<br>
                아래 <strong>숫자 6자리 인증번호</strong>를 화면에 입력하여 인증을 완료해주세요.
              </p>

              <!-- 6-digit Code Box -->
              <div style="background: #f8fafc; border: 2px dashed #6366f1; border-radius: 16px; padding: 24px; text-align: center; margin: 26px 0;">
                <div style="font-size: 12px; font-weight: 600; text-transform: uppercase; color: #6366f1; letter-spacing: 1px; margin-bottom: 8px;">
                  본인확인 인증코드 (6자리)
                </div>
                <div style="font-size: 38px; font-weight: 800; letter-spacing: 10px; color: #1e1b4b; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace; padding-left: 10px;">
                  ${code}
                </div>
                <div style="margin-top: 10px; font-size: 12px; color: #ef4444; font-weight: 600;">
                  ⏱️ 유효시간: 발송 후 5분 이내
                </div>
              </div>

              <!-- Security Information -->
              <div style="background-color: #f9fafb; border-radius: 12px; padding: 14px 18px; border-left: 4px solid #6366f1; margin-top: 20px;">
                <p style="margin: 0; font-size: 12px; line-height: 1.6; color: #6b7280;">
                  • 본 인증번호는 회원가입 및 본인확인을 위한 일회용 코드입니다.<br>
                  • 타인에게 인증번호를 절대 노출하거나 공유하지 마세요.<br>
                  • 본인이 요청하지 않은 경우, 이 메일을 무시하셔도 안전합니다.
                </p>
              </div>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color: #f9fafb; padding: 20px 32px; border-top: 1px solid #f3f4f6; text-align: center;">
              <p style="margin: 0; font-size: 11px; color: #9ca3af; line-height: 1.5;">
                본 메일은 발신 전용이며 회신되지 않습니다.<br>
                © ${new Date().getFullYear()} 마음(Maeum) 소셜 네트워크. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();
}

/**
 * Dispatch real email using SMTP or Resend if configured
 */
export async function dispatchRealEmail(
  toEmail: string,
  subject: string,
  htmlContent: string
): Promise<{ success: boolean; provider: string; error?: string }> {
  // 1. Try Resend API if RESEND_API_KEY is configured
  const resendApiKey = process.env.RESEND_API_KEY?.trim();
  const fromEmail = process.env.EMAIL_FROM || process.env.SMTP_FROM || 'Maeum <onboarding@resend.dev>';

  if (resendApiKey) {
    try {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromEmail,
          to: [toEmail],
          subject: subject,
          html: htmlContent,
        }),
      });

      const data: any = await res.json().catch(() => ({}));
      if (res.ok && data.id) {
        console.log(`[Resend] Email sent successfully to ${toEmail}, id=${data.id}`);
        return { success: true, provider: 'Resend' };
      } else {
        console.error('[Resend] Error response:', data);
        return {
          success: false,
          provider: 'Resend',
          error: data.message || 'Resend 이메일 발송에 실패했습니다.',
        };
      }
    } catch (err: any) {
      console.error('[Resend] Exception:', err);
      return { success: false, provider: 'Resend', error: err.message };
    }
  }

  // 2. Try Nodemailer with SMTP (e.g. Gmail App Password, Naver, or custom SMTP)
  const smtpHost = process.env.SMTP_HOST?.trim();
  const smtpPort = parseInt(process.env.SMTP_PORT || '587', 10);
  const smtpUser = (process.env.SMTP_USER || process.env.GMAIL_USER)?.trim();
  const smtpPass = (process.env.SMTP_PASS || process.env.GMAIL_APP_PASSWORD)?.trim();
  const smtpSender = process.env.SMTP_FROM || smtpUser || 'no-reply@maeum.io';

  if (smtpUser && smtpPass) {
    try {
      const transporter = nodemailer.createTransport(
        smtpHost
          ? {
              host: smtpHost,
              port: smtpPort,
              secure: smtpPort === 465,
              auth: {
                user: smtpUser,
                pass: smtpPass,
              },
            }
          : {
              service: 'gmail',
              auth: {
                user: smtpUser,
                pass: smtpPass,
              },
            }
      );

      const info = await transporter.sendMail({
        from: `"마음(Maeum)" <${smtpSender}>`,
        to: toEmail,
        subject: subject,
        html: htmlContent,
      });

      console.log(`[SMTP] Email sent successfully to ${toEmail}, messageId=${info.messageId}`);
      return { success: true, provider: smtpHost ? 'Custom SMTP' : 'Gmail SMTP' };
    } catch (err: any) {
      console.error('[SMTP] Exception during email send:', err);
      return { success: false, provider: 'SMTP', error: err.message };
    }
  }

  // No real email gateway configured
  return {
    success: false,
    provider: 'none',
    error: 'NO_EMAIL_GATEWAY_CONFIGURED',
  };
}

/**
 * Generate 6-digit verification code and dispatch via Email
 */
export async function requestEmailVerification(
  email: string,
  purpose: string = '본인확인'
): Promise<{
  success: boolean;
  isRealEmailSent: boolean;
  provider: string;
  expiresAt: number;
  emailSubject: string;
  emailHtml: string;
  simulatedCode?: string;
  message: string;
  error?: string;
}> {
  const cleanEmail = (email || '').trim().toLowerCase();

  if (!cleanEmail) {
    return {
      success: false,
      isRealEmailSent: false,
      provider: 'none',
      expiresAt: 0,
      emailSubject: '',
      emailHtml: '',
      message: '이메일 주소를 입력해주세요.',
      error: '이메일 주소를 입력해주세요.',
    };
  }

  if (!isValidEmailFormat(cleanEmail)) {
    return {
      success: false,
      isRealEmailSent: false,
      provider: 'none',
      expiresAt: 0,
      emailSubject: '',
      emailHtml: '',
      message: '올바른 이메일 주소 형식(예: user@example.com)을 입력해주세요.',
      error: '올바른 이메일 주소 형식(예: user@example.com)을 입력해주세요.',
    };
  }

  const existing = emailVerificationStore.get(cleanEmail);
  const now = Date.now();

  // Rate limiting: 20 seconds cooldown
  if (existing && now - existing.lastSentAt < 20 * 1000) {
    const waitSec = Math.ceil((20 * 1000 - (now - existing.lastSentAt)) / 1000);
    return {
      success: false,
      isRealEmailSent: false,
      provider: 'none',
      expiresAt: existing.expiresAt,
      emailSubject: '',
      emailHtml: '',
      message: `인증코드를 너무 빠르게 요청하셨습니다. ${waitSec}초 후에 다시 시도해주세요.`,
      error: `인증코드를 너무 빠르게 요청하셨습니다. ${waitSec}초 후에 다시 시도해주세요.`,
    };
  }

  // Rate limiting: Max 10 sends per hour per email
  if (existing && existing.sentCount >= 10 && now - existing.lastSentAt < 60 * 60 * 1000) {
    return {
      success: false,
      isRealEmailSent: false,
      provider: 'none',
      expiresAt: existing.expiresAt,
      emailSubject: '',
      emailHtml: '',
      message: '시간당 최대 인증 요청 횟수(10회)를 초과했습니다. 1시간 후 다시 시도해주세요.',
      error: '시간당 최대 인증 요청 횟수(10회)를 초과했습니다. 1시간 후 다시 시도해주세요.',
    };
  }

  // Generate 6-digit numeric verification code
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = now + 5 * 60 * 1000; // 5 minutes expiration
  const emailSubject = `[마음(Maeum)] ${purpose} 인증번호는 [${code}] 입니다.`;
  const emailHtml = generateVerificationEmailHtml(code, purpose);

  // Save to verification store
  emailVerificationStore.set(cleanEmail, {
    code,
    expiresAt,
    attempts: 0,
    verified: false,
    lastSentAt: now,
    sentCount: existing ? existing.sentCount + 1 : 1,
    purpose,
  });

  // Attempt real email dispatch
  const emailResult = await dispatchRealEmail(cleanEmail, emailSubject, emailHtml);

  if (emailResult.success) {
    return {
      success: true,
      isRealEmailSent: true,
      provider: emailResult.provider,
      expiresAt,
      emailSubject,
      emailHtml,
      message: `${cleanEmail} 주소로 6자리 인증번호가 실제 발송되었습니다. 수신함을 확인해주세요.`,
    };
  } else {
    // If real email gateway is not configured or failed:
    return {
      success: true,
      isRealEmailSent: false,
      provider: emailResult.provider,
      expiresAt,
      emailSubject,
      emailHtml,
      simulatedCode: code, // Provided for instant testing in demo/preview
      message:
        emailResult.error === 'NO_EMAIL_GATEWAY_CONFIGURED'
          ? `${cleanEmail} 주소로 인증번호(6자리)가 발급되었습니다. (실제 메일 발송은 .env의 SMTP 또는 RESEND 설정 시 전송됩니다)`
          : `이메일 발송 연동(${emailResult.provider}) 오류: ${emailResult.error}. 테스트 인증번호로 진행할 수 있습니다.`,
    };
  }
}

/**
 * Verify submitted 6-digit email code
 */
export function verifyEmailCode(
  email: string,
  inputCode: string
): { success: boolean; message: string; error?: string } {
  const cleanEmail = (email || '').trim().toLowerCase();
  const record = emailVerificationStore.get(cleanEmail);

  if (!record) {
    return {
      success: false,
      message: '인증번호를 먼저 요청해주세요.',
      error: '인증번호를 먼저 요청해주세요.',
    };
  }

  const now = Date.now();
  if (now > record.expiresAt) {
    return {
      success: false,
      message: '인증번호 유효시간(5분)이 만료되었습니다. 인증번호를 다시 요청해주세요.',
      error: '인증번호 유효시간(5분)이 만료되었습니다. 인증번호를 다시 요청해주세요.',
    };
  }

  record.attempts += 1;
  if (record.attempts > 5) {
    emailVerificationStore.delete(cleanEmail);
    return {
      success: false,
      message: '인증번호 입력 시도 횟수(5회)를 초과하였습니다. 인증번호를 다시 발급받아주세요.',
      error: '인증번호 입력 시도 횟수(5회)를 초과하였습니다. 인증번호를 다시 발급받아주세요.',
    };
  }

  const cleanInput = (inputCode || '').trim();
  if (record.code !== cleanInput) {
    return {
      success: false,
      message: `인증번호가 일치하지 않습니다. (오류 횟수: ${record.attempts}/5회)`,
      error: `인증번호가 일치하지 않습니다. (오류 횟수: ${record.attempts}/5회)`,
    };
  }

  // Successfully verified
  record.verified = true;
  return {
    success: true,
    message: '이메일 주소 본인인증이 성공적으로 완료되었습니다.',
  };
}

/**
 * Check if the email has been verified recently
 */
export function isEmailVerified(email: string): boolean {
  const cleanEmail = (email || '').trim().toLowerCase();
  const record = emailVerificationStore.get(cleanEmail);
  return !!record && record.verified && Date.now() < record.expiresAt + 60 * 60 * 1000;
}
