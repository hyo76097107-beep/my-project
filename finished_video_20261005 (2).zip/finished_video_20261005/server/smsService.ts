import crypto from 'crypto';
import {
  insertSmsVerificationRecord,
  findLatestSmsRecord,
  incrementSmsAttempt,
  markSmsRecordVerified,
  SmsDbRecord,
} from './smsDb';
import {
  getRawSmsApiConfig,
  getMaskedSmsApiConfig,
  SmsApiConfig,
  SmsProviderType,
} from './smsConfig';

/**
 * Dispatch real SMS using the configured provider in sms_api_config.json (or process.env fallback)
 */
export async function dispatchRealSms(
  toPhoneNumber: string,
  messageText: string
): Promise<{ success: boolean; provider: SmsProviderType; error?: string; detail?: any }> {
  const config = getRawSmsApiConfig();
  const toDigits = toPhoneNumber.replace(/\D/g, '');

  // If SMS service is disabled or in test mode, return Sandbox simulation
  if (!config.enabled || config.testMode) {
    return {
      success: false,
      provider: 'Sandbox',
      error: 'TEST_MODE_ACTIVE',
    };
  }

  const senderDigits = config.senderNumber.replace(/\D/g, '');

  // 1. CoolSMS (Solapi) - Standard Korean Telco SMS Gateway
  if (config.provider === 'CoolSMS') {
    const apiKey = config.coolsmsApiKey || process.env.COOLSMS_API_KEY || '';
    const apiSecret = config.coolsmsApiSecret || process.env.COOLSMS_API_SECRET || '';
    const sender = senderDigits || process.env.COOLSMS_SENDER_NUMBER?.replace(/\D/g, '') || '';

    if (!apiKey || !apiSecret || !sender) {
      return {
        success: false,
        provider: 'CoolSMS',
        error: 'CoolSMS API Key, Secret 또는 발신번호가 설정되지 않았습니다.',
      };
    }

    try {
      const date = new Date().toISOString();
      const salt = crypto.randomBytes(16).toString('hex');
      const hmac = crypto.createHmac('sha256', apiSecret);
      hmac.update(date + salt);
      const signature = hmac.digest('hex');
      const authHeader = `HMAC-SHA256 apiKey=${apiKey}, date=${date}, salt=${salt}, signature=${signature}`;

      const response = await fetch('https://api.coolsms.co.kr/messages/v4/send', {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: {
            to: toDigits,
            from: sender,
            text: messageText,
            type: messageText.length > 90 ? 'LMS' : 'SMS',
          },
        }),
      });

      const responseData: any = await response.json().catch(() => ({}));
      if (response.ok) {
        console.log(`[CoolSMS] SMS sent successfully to ${toDigits}`);
        return { success: true, provider: 'CoolSMS', detail: responseData };
      } else {
        console.error('[CoolSMS] Error response:', responseData);
        return {
          success: false,
          provider: 'CoolSMS',
          error: responseData.message || responseData.errorMessage || 'CoolSMS 발송 실패',
          detail: responseData,
        };
      }
    } catch (err: any) {
      console.error('[CoolSMS] Exception during SMS dispatch:', err);
      return { success: false, provider: 'CoolSMS', error: err.message };
    }
  }

  // 2. Aligo (알리고 문자 API)
  if (config.provider === 'Aligo') {
    const key = config.aligoApiKey || '';
    const userId = config.aligoUserId || '';
    const sender = senderDigits;

    if (!key || !userId || !sender) {
      return {
        success: false,
        provider: 'Aligo',
        error: '알리고 API Key, 사용자 아이디(user_id) 또는 발신번호가 누락되었습니다.',
      };
    }

    try {
      const params = new URLSearchParams();
      params.append('key', key);
      params.append('user_id', userId);
      params.append('sender', sender);
      params.append('receiver', toDigits);
      params.append('msg', messageText);
      params.append('msg_type', messageText.length > 90 ? 'LMS' : 'SMS');

      const response = await fetch('https://apis.aligo.in/send/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: params.toString(),
      });

      const responseData: any = await response.json().catch(() => ({}));
      if (response.ok && responseData.result_code === '1') {
        console.log(`[Aligo] SMS sent successfully to ${toDigits}`);
        return { success: true, provider: 'Aligo', detail: responseData };
      } else {
        return {
          success: false,
          provider: 'Aligo',
          error: responseData.message || `알리고 발송 실패 (코드: ${responseData.result_code})`,
          detail: responseData,
        };
      }
    } catch (err: any) {
      console.error('[Aligo] Exception during SMS dispatch:', err);
      return { success: false, provider: 'Aligo', error: err.message };
    }
  }

  // 3. Twilio (Global SMS API)
  if (config.provider === 'Twilio') {
    const twilioSid = config.twilioAccountSid || process.env.TWILIO_ACCOUNT_SID || '';
    const twilioAuth = config.twilioAuthToken || process.env.TWILIO_AUTH_TOKEN || '';
    const twilioFrom = config.senderNumber || process.env.TWILIO_PHONE_NUMBER || '';

    if (!twilioSid || !twilioAuth || !twilioFrom) {
      return {
        success: false,
        provider: 'Twilio',
        error: 'Twilio Account SID, Auth Token 또는 발신번호가 누락되었습니다.',
      };
    }

    try {
      let e164To = toDigits;
      if (e164To.startsWith('010')) {
        e164To = '+8210' + e164To.slice(3);
      } else if (!e164To.startsWith('+')) {
        e164To = '+82' + (e164To.startsWith('0') ? e164To.slice(1) : e164To);
      }

      const params = new URLSearchParams();
      params.append('To', e164To);
      params.append('From', twilioFrom);
      params.append('Body', messageText);

      const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${twilioSid}/Messages.json`;
      const auth = Buffer.from(`${twilioSid}:${twilioAuth}`).toString('base64');

      const response = await fetch(twilioUrl, {
        method: 'POST',
        headers: {
          Authorization: `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: params.toString(),
      });

      const responseData: any = await response.json().catch(() => ({}));
      if (response.ok) {
        console.log(`[Twilio] SMS sent successfully to ${e164To}`);
        return { success: true, provider: 'Twilio', detail: responseData };
      } else {
        return {
          success: false,
          provider: 'Twilio',
          error: responseData.message || 'Twilio 발송 실패',
          detail: responseData,
        };
      }
    } catch (err: any) {
      console.error('[Twilio] Exception during SMS dispatch:', err);
      return { success: false, provider: 'Twilio', error: err.message };
    }
  }

  // 4. Naver Cloud SENS API
  if (config.provider === 'NaverSENS') {
    const accessKey = config.naverAccessKey || '';
    const secretKey = config.naverSecretKey || '';
    const serviceId = config.naverServiceId || '';
    const callingNumber = senderDigits;

    if (!accessKey || !secretKey || !serviceId || !callingNumber) {
      return {
        success: false,
        provider: 'NaverSENS',
        error: '네이버 클라우드 SENS Access Key, Secret Key, Service ID, 발신번호가 필요합니다.',
      };
    }

    try {
      const timestamp = Date.now().toString();
      const method = 'POST';
      const uri = `/sms/v2/services/${serviceId}/messages`;
      const space = ' ';
      const newLine = '\n';

      const hmac = crypto.createHmac('sha256', secretKey);
      hmac.update(method);
      hmac.update(space);
      hmac.update(uri);
      hmac.update(newLine);
      hmac.update(timestamp);
      hmac.update(newLine);
      hmac.update(accessKey);
      const signature = hmac.digest('base64');

      const response = await fetch(`https://sens.apigw.ntruss.com${uri}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'x-ncp-apigw-timestamp': timestamp,
          'x-ncp-iam-access-key': accessKey,
          'x-ncp-apigw-signature-v2': signature,
        },
        body: JSON.stringify({
          type: messageText.length > 80 ? 'LMS' : 'SMS',
          contentType: 'COMM',
          countryCode: '82',
          from: callingNumber,
          content: messageText,
          messages: [{ to: toDigits }],
        }),
      });

      const responseData: any = await response.json().catch(() => ({}));
      if (response.ok && (responseData.statusCode === '202' || responseData.statusName === 'success')) {
        return { success: true, provider: 'NaverSENS', detail: responseData };
      } else {
        return {
          success: false,
          provider: 'NaverSENS',
          error: responseData.errorMessage || '네이버 SENS SMS 발송 실패',
          detail: responseData,
        };
      }
    } catch (err: any) {
      console.error('[NaverSENS] Exception during SMS dispatch:', err);
      return { success: false, provider: 'NaverSENS', error: err.message };
    }
  }

  // 5. Custom HTTP / Webhook API
  if (config.provider === 'Custom') {
    if (!config.customApiUrl) {
      return {
        success: false,
        provider: 'Custom',
        error: '사용자 지정 SMS API URL이 설정되지 않았습니다.',
      };
    }

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (config.customAuthHeader) {
        headers['Authorization'] = config.customAuthHeader;
      }

      const response = await fetch(config.customApiUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          to: toDigits,
          from: senderDigits,
          text: messageText,
        }),
      });

      const responseData: any = await response.json().catch(() => ({}));
      if (response.ok) {
        return { success: true, provider: 'Custom', detail: responseData };
      } else {
        return {
          success: false,
          provider: 'Custom',
          error: responseData.message || 'Custom API 응답 에러',
          detail: responseData,
        };
      }
    } catch (err: any) {
      console.error('[Custom SMS] Exception:', err);
      return { success: false, provider: 'Custom', error: err.message };
    }
  }

  // Fallback to Sandbox
  return {
    success: false,
    provider: 'Sandbox',
    error: 'NO_GATEWAY_CONFIGURED',
  };
}

/**
 * Generate 6-digit verification code, record in Database, and dispatch via SMS
 */
export async function requestSmsVerification(
  phoneNumber: string,
  ipAddress?: string
): Promise<{
  success: boolean;
  isRealSmsSent: boolean;
  provider: string;
  expiresAt: number;
  message: string;
  simulatedCode?: string;
  smsText: string;
  dbRecordId?: string;
  error?: string;
}> {
  const digits = phoneNumber.replace(/\D/g, '');

  if (!digits) {
    return {
      success: false,
      isRealSmsSent: false,
      provider: 'Sandbox',
      expiresAt: 0,
      smsText: '',
      message: '휴대폰 번호를 입력해주세요.',
      error: '휴대폰 번호를 입력해주세요.',
    };
  }

  if (!/^01[016789]\d{7,8}$/.test(digits)) {
    return {
      success: false,
      isRealSmsSent: false,
      provider: 'Sandbox',
      expiresAt: 0,
      smsText: '',
      message: '유효한 한국 휴대폰 번호(010-XXXX-XXXX)를 입력해주세요.',
      error: '유효한 한국 휴대폰 번호(010-XXXX-XXXX)를 입력해주세요.',
    };
  }

  const existing = findLatestSmsRecord(digits);
  const now = Date.now();

  // Rate limiting: Can only re-send after 20 seconds
  if (existing && now - existing.createdTimestamp < 20 * 1000) {
    const waitSec = Math.ceil((20 * 1000 - (now - existing.createdTimestamp)) / 1000);
    return {
      success: false,
      isRealSmsSent: false,
      provider: existing.provider,
      expiresAt: existing.expiresTimestamp,
      smsText: existing.smsText,
      message: `인증번호를 너무 빠르게 요청하셨습니다. ${waitSec}초 후에 다시 시도해주세요.`,
      error: `인증번호를 너무 빠르게 요청하셨습니다. ${waitSec}초 후에 다시 시도해주세요.`,
    };
  }

  const config = getRawSmsApiConfig();

  // Generate 6-digit numeric verification code
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = now + (config.codeExpirationMinutes || 3) * 60 * 1000;
  
  // Format template with {code}
  let smsText = config.smsTemplate || '[마음(Maeum)] 본인확인 인증번호 [{code}]를 3분 이내에 입력해주세요. (타인 노출 금지)';
  if (smsText.includes('{code}')) {
    smsText = smsText.replace('{code}', code);
  } else {
    smsText = `${smsText} [${code}]`;
  }

  // Attempt real SMS dispatch
  const smsResult = await dispatchRealSms(digits, smsText);

  // Record in Database
  const dbRecord = insertSmsVerificationRecord({
    phoneNumber: digits,
    code,
    provider: smsResult.provider,
    smsText,
    isRealSmsSent: smsResult.success,
    expiresInMinutes: config.codeExpirationMinutes || 3,
    ipAddress,
    notes: smsResult.success
      ? `${smsResult.provider} 통신사 게이트웨이 발송 성공`
      : `샌드박스 가상 발송 (게이트웨이 미연동/테스트 모드: ${smsResult.error || '정상'})`,
  });

  if (smsResult.success) {
    return {
      success: true,
      isRealSmsSent: true,
      provider: smsResult.provider,
      expiresAt,
      smsText,
      dbRecordId: dbRecord.id,
      message: `${phoneNumber} 번호로 SMS 인증 문자가 실제 발송되었습니다. 수신된 문자메시지의 인증번호 6자리를 입력해주세요. (DB 등록 완료: ${dbRecord.id})`,
    };
  } else {
    return {
      success: true,
      isRealSmsSent: false,
      provider: smsResult.provider,
      expiresAt,
      smsText,
      simulatedCode: code,
      dbRecordId: dbRecord.id,
      message:
        smsResult.error === 'TEST_MODE_ACTIVE'
          ? `${phoneNumber} 번호로 테스트 모드 SMS 발송이 처리되어 DB에 안전하게 등록되었습니다.`
          : smsResult.error === 'NO_GATEWAY_CONFIGURED'
          ? `${phoneNumber} 번호로 인증번호 문자 발송이 요청되어 데이터베이스(DB)에 안전하게 등록되었습니다.`
          : `SMS 발송 연동(${smsResult.provider}) 응답: ${smsResult.error}. DB 등록 코드로 인증 진행 가능합니다.`,
    };
  }
}

/**
 * Verify submitted SMS code against Database record
 */
export function verifySmsCode(
  phoneNumber: string,
  inputCode: string,
  extra?: { userId?: string; userHandle?: string }
): { success: boolean; message: string; dbRecord?: SmsDbRecord; error?: string } {
  const digits = phoneNumber.replace(/\D/g, '');
  const record = findLatestSmsRecord(digits);

  if (!record) {
    return {
      success: false,
      message: '해당 휴대폰 번호의 인증 요청 데이터베이스(DB) 기록이 없습니다. 인증번호를 먼저 요청해주세요.',
      error: '인증번호를 먼저 요청해주세요.',
    };
  }

  const now = Date.now();
  if (now > record.expiresTimestamp) {
    return {
      success: false,
      message: '인증번호 유효시간이 만료되었습니다. 데이터베이스 기록이 만료되어 재발급이 필요합니다.',
      error: '인증번호 유효시간이 만료되었습니다. 인증번호를 다시 요청해주세요.',
    };
  }

  const config = getRawSmsApiConfig();
  const maxAttempts = config.maxAttempts || 5;

  const updatedRecord = incrementSmsAttempt(record.id);
  if (!updatedRecord || updatedRecord.attempts > maxAttempts) {
    return {
      success: false,
      message: `인증번호 입력 시도 횟수(${maxAttempts}회)를 초과하여 DB 레코드가 실패 처리되었습니다. 인증번호를 다시 요청해주세요.`,
      error: `인증번호 입력 시도 횟수(${maxAttempts}회)를 초과하였습니다. 인증번호를 다시 발급받아주세요.`,
    };
  }

  const cleanInput = (inputCode || '').trim();
  if (record.code !== cleanInput) {
    return {
      success: false,
      message: `인증번호가 일치하지 않습니다. (입력 오류 ${updatedRecord.attempts}/${maxAttempts}회, DB 저장 코드와 불일치)`,
      error: `인증번호가 일치하지 않습니다. (입력 오류 ${updatedRecord.attempts}/${maxAttempts}회)`,
    };
  }

  // Verification succeeded -> mark verified in DB
  const verifiedRecord = markSmsRecordVerified(record.id, {
    userId: extra?.userId,
    userHandle: extra?.userHandle,
    notes: '본인확인 6자리 인증번호 일치 및 DB 인증 완료',
  });

  return {
    success: true,
    message: '휴대폰 번호 본인인증이 성공적으로 완료되었으며 데이터베이스(DB)에 승인 기록되었습니다.',
    dbRecord: verifiedRecord,
  };
}

/**
 * Check if the phone number has been verified in the Database
 */
export function isPhoneVerifiedInDb(phoneNumber: string): boolean {
  const digits = phoneNumber.replace(/\D/g, '');
  const record = findLatestSmsRecord(digits);
  return !!record && record.status === 'verified';
}
