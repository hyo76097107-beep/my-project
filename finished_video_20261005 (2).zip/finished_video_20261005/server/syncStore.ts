import fs from 'fs';
import path from 'path';
import { Response } from 'express';
import type { WebSocket } from 'ws';
import {
  INITIAL_POSTS,
  INITIAL_USERS,
  INITIAL_COMMENTS,
  INITIAL_STORIES,
  INITIAL_MESSAGES,
  INITIAL_NOTIFICATIONS,
} from '../src/data/mockData';

export interface SyncData {
  posts: any[];
  comments: any[];
  messages: any[];
  stories: any[];
  users: any[];
  notifications?: any[];
  deletedPostIds?: string[];
  kickedUsers?: any[];
  version: number;
  lastUpdated: string;
}

const DB_FILE_PATH = path.join(process.cwd(), 'data', 'social_db.json');

// In-memory active database cache
let db: SyncData = {
  posts: [],
  comments: [],
  messages: [],
  stories: [],
  users: [],
  notifications: [],
  deletedPostIds: [],
  kickedUsers: [],
  version: 1,
  lastUpdated: new Date().toISOString(),
};

// Connected Server-Sent Events (SSE) and WebSocket clients for cross-platform real-time sync
const sseClients = new Set<Response>();
const wsClients = new Set<WebSocket>();

/**
 * Persists current in-memory database to disk safely
 */
function saveDbToDisk(): void {
  try {
    const dir = path.dirname(DB_FILE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    // Strict guard: ensure kicked users NEVER exist in db.users
    if (Array.isArray(db.kickedUsers) && db.kickedUsers.length > 0) {
      const kickedIds = new Set(db.kickedUsers.map((k: any) => k.id));
      const kickedHandles = new Set(db.kickedUsers.map((k: any) => (k.handle || '').toLowerCase().replace(/^@/, '')));
      db.users = db.users.filter((u: any) => !kickedIds.has(u.id) && !kickedHandles.has((u.handle || '').toLowerCase().replace(/^@/, '')));
    }
    db.lastUpdated = new Date().toISOString();
    db.version += 1;
    fs.writeFileSync(DB_FILE_PATH, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to save social_db.json to disk:', err);
  }
}

/**
 * Deduplicates notifications by ID and semantic uniqueness
 * (e.g. at most 1 follow notification per actor/recipient pair, at most 1 like notification per actor/post pair)
 */
export function deduplicateNotifications(notifs: any[]): any[] {
  if (!Array.isArray(notifs) || notifs.length === 0) return [];
  const seenIds = new Set<string>();
  const seenSemanticKeys = new Set<string>();
  const result: any[] = [];

  for (const n of notifs) {
    if (!n || !n.id) continue;
    if (seenIds.has(n.id)) continue;

    let semanticKey = '';
    if (n.type === 'like') {
      semanticKey = `${n.recipientId}_${n.actorId}_like_${n.postId || ''}`;
    } else if (n.type === 'follow') {
      semanticKey = `${n.recipientId}_${n.actorId}_follow`;
    } else if (n.type === 'comment') {
      if (n.commentId) {
        semanticKey = `${n.recipientId}_${n.actorId}_comment_${n.postId || ''}_${n.commentId}`;
      } else {
        const timeBucket = Math.floor(new Date(n.createdAt || Date.now()).getTime() / 60000);
        semanticKey = `${n.recipientId}_${n.actorId}_comment_${n.postId || ''}_${(n.content || '').slice(0, 30)}_${timeBucket}`;
      }
    } else {
      const timeBucket = Math.floor(new Date(n.createdAt || Date.now()).getTime() / 30000);
      semanticKey = `${n.recipientId}_${n.actorId}_${n.type}_${n.content || ''}_${timeBucket}`;
    }

    if (seenSemanticKeys.has(semanticKey)) continue;

    seenIds.add(n.id);
    seenSemanticKeys.add(semanticKey);
    result.push(n);
  }
  return result;
}

/**
 * Normalizes any media/video URL to a clean relative path (/uploads/... or /videos/...)
 * if it points to server storage, removing external IP or dev domain prefixes.
 */
export function normalizeMediaUrl(url: string | undefined): string | undefined {
  if (!url || typeof url !== 'string') return undefined;
  const trimmed = url.trim();
  if (!trimmed) return undefined;

  if (trimmed.startsWith('content://') || trimmed.startsWith('file://')) {
    return '/videos/sample_nature.mp4';
  }
  if (trimmed.includes('uploads/')) {
    const idx = trimmed.indexOf('uploads/');
    return `/${trimmed.substring(idx)}`;
  }
  if (trimmed.includes('videos/')) {
    const idx = trimmed.indexOf('videos/');
    return `/${trimmed.substring(idx)}`;
  }
  if (trimmed.includes(':3000')) {
    const p = trimmed.substring(trimmed.indexOf(':3000') + 5);
    return p.startsWith('/') ? p : `/${p}`;
  }
  if (trimmed.includes('commondatastorage.googleapis.com')) {
    if (trimmed.includes('tokyo') || trimmed.includes('Escapes')) return '/videos/sample_tokyo.mp4';
    return '/videos/sample_fitness.mp4';
  }
  return trimmed;
}

/**
 * Ensures a post has all video/photo fields synchronized:
 * - video: primary video URL
 * - videoUrls: full array of all attached videos
 * - mediaItems: comprehensive carousel items for both Web & Android
 */
export function normalizePostMedia(post: any): any {
  if (!post || typeof post !== 'object') return post;

  const rawVideo = normalizeMediaUrl(post.video || post.videoUrl);
  const rawVideoUrls: string[] = Array.isArray(post.videoUrls)
    ? post.videoUrls.map((u: string) => normalizeMediaUrl(u)).filter(Boolean) as string[]
    : [];

  const rawPhotos: string[] = Array.isArray(post.photos)
    ? post.photos.map((u: string) => normalizeMediaUrl(u)).filter(Boolean) as string[]
    : (Array.isArray(post.images)
    ? post.images.map((u: string) => normalizeMediaUrl(u)).filter(Boolean) as string[]
    : []);

  // Merge video URLs
  const videoUrlsSet = new Set<string>();
  if (rawVideo) videoUrlsSet.add(rawVideo);
  rawVideoUrls.forEach((u) => videoUrlsSet.add(u));

  if (Array.isArray(post.mediaItems)) {
    post.mediaItems.forEach((m: any) => {
      if (m && m.type === 'video' && m.url) {
        const norm = normalizeMediaUrl(m.url);
        if (norm) videoUrlsSet.add(norm);
      }
    });
  }

  const normalizedVideoUrls = Array.from(videoUrlsSet);
  const normalizedPrimaryVideo = normalizedVideoUrls[0] || rawVideo || undefined;

  // Build mediaItems if missing or sanitize existing
  let normalizedMediaItems: any[] = [];
  if (Array.isArray(post.mediaItems) && post.mediaItems.length > 0) {
    normalizedMediaItems = post.mediaItems.map((m: any, idx: number) => ({
      ...m,
      id: m.id || `media_${post.id || 'item'}_${idx}`,
      type: m.type || (m.url && (m.url.includes('/videos/') || m.url.includes('.mp4')) ? 'video' : 'image'),
      url: normalizeMediaUrl(m.url) || m.url,
      thumbnail: normalizeMediaUrl(m.thumbnail) || m.thumbnail,
    }));
  } else {
    normalizedVideoUrls.forEach((vUrl, idx) => {
      normalizedMediaItems.push({
        id: `media_vid_${post.id || 'post'}_${idx}`,
        type: 'video',
        url: vUrl,
        thumbnail: idx === 0 ? normalizeMediaUrl(post.videoThumbnail) : undefined,
      });
    });
    rawPhotos.forEach((pUrl, idx) => {
      normalizedMediaItems.push({
        id: `media_img_${post.id || 'post'}_${idx}`,
        type: 'image',
        url: pUrl,
      });
    });
  }

  return {
    ...post,
    video: normalizedPrimaryVideo,
    videoUrl: normalizedPrimaryVideo,
    videoUrls: normalizedVideoUrls,
    videoThumbnail: normalizeMediaUrl(post.videoThumbnail) || post.videoThumbnail,
    photos: rawPhotos,
    images: rawPhotos,
    mediaItems: normalizedMediaItems,
  };
}

/**
 * Initializes the social sync database with real pre-seeded data
 */
export function initSyncStore(initialData?: {
  posts?: any[];
  comments?: any[];
  messages?: any[];
  stories?: any[];
  users?: any[];
}): void {
  try {
    if (fs.existsSync(DB_FILE_PATH)) {
      const content = fs.readFileSync(DB_FILE_PATH, 'utf-8');
      const parsed = JSON.parse(content);
      
      const loadedDeletedIds: string[] = Array.isArray(parsed.deletedPostIds) ? parsed.deletedPostIds : [];
      const loadedPosts = (Array.isArray(parsed.posts) && parsed.posts.length > 0 
        ? parsed.posts 
        : (initialData?.posts && initialData.posts.length > 0 ? initialData.posts : INITIAL_POSTS))
        .filter((p: any) => !loadedDeletedIds.includes(p.id))
        .map((p: any) => normalizePostMedia(p));

      const loadedKickedUsers = Array.isArray(parsed.kickedUsers) ? parsed.kickedUsers : [];
      const kickedIds = new Set(loadedKickedUsers.map((k: any) => k.id));
      const kickedHandles = new Set(loadedKickedUsers.map((k: any) => (k.handle || '').toLowerCase()));

      const rawParsedUsers = Array.isArray(parsed.users) ? parsed.users : [];
      const existingUserIds = new Set(rawParsedUsers.map((u: any) => u.id));
      const mergedUsers = [...rawParsedUsers];
      for (const initU of INITIAL_USERS) {
        if (!existingUserIds.has(initU.id) && !kickedIds.has(initU.id) && !kickedHandles.has(initU.handle.toLowerCase())) {
          mergedUsers.push(initU);
          existingUserIds.add(initU.id);
        }
      }
      // CRITICAL: Ensure kicked users NEVER appear in loadedUsers
      const loadedUsers = (mergedUsers.length > 0 ? mergedUsers : INITIAL_USERS)
        .filter((u: any) => !kickedIds.has(u.id) && !kickedHandles.has((u.handle || '').toLowerCase()))
        .map((u: any) => {
          if (!u.signupIp) {
            const matchInit = INITIAL_USERS.find((init) => init.id === u.id || init.handle === u.handle);
            return { ...u, signupIp: matchInit?.signupIp || '211.234.120.45' };
          }
          return u;
        });

      const sanitizedKickedUsers = loadedKickedUsers.map((k: any) => {
        if (!k.signupIp) {
          const matchInit = INITIAL_USERS.find((init) => init.id === k.id || init.handle === k.handle);
          return { ...k, signupIp: matchInit?.signupIp || '175.197.88.12' };
        }
        return k;
      });

      const loadedComments = Array.isArray(parsed.comments) && parsed.comments.length > 0 
        ? parsed.comments 
        : (initialData?.comments && initialData.comments.length > 0 ? initialData.comments : INITIAL_COMMENTS);

      const loadedMessages = Array.isArray(parsed.messages) && parsed.messages.length > 0 
        ? parsed.messages 
        : (initialData?.messages && initialData.messages.length > 0 ? initialData.messages : INITIAL_MESSAGES);

      const rawStories = Array.isArray(parsed.stories) && parsed.stories.length > 0 
        ? parsed.stories 
        : (initialData?.stories && initialData.stories.length > 0 ? initialData.stories : INITIAL_STORIES);

      // Deduplicate story items by ID to avoid React key collisions
      const loadedStories = rawStories.map((userStory: any) => {
        if (!userStory || !Array.isArray(userStory.items)) return userStory;
        const seenIds = new Set<string>();
        const uniqueItems: any[] = [];
        for (const item of userStory.items) {
          if (item && item.id && !seenIds.has(item.id)) {
            seenIds.add(item.id);
            uniqueItems.push(item);
          }
        }
        return { ...userStory, items: uniqueItems };
      });

      const loadedNotifications = deduplicateNotifications(
        Array.isArray(parsed.notifications) && parsed.notifications.length > 0
          ? parsed.notifications
          : INITIAL_NOTIFICATIONS
      );

      db = {
        posts: loadedPosts,
        comments: loadedComments,
        messages: loadedMessages,
        stories: loadedStories,
        users: loadedUsers,
        notifications: loadedNotifications,
        deletedPostIds: loadedDeletedIds,
        kickedUsers: sanitizedKickedUsers,
        version: typeof parsed.version === 'number' ? parsed.version : 1,
        lastUpdated: parsed.lastUpdated || new Date().toISOString(),
      };
      saveDbToDisk();
      console.log(`[SyncStore] Loaded DB with ${db.posts.length} posts, ${db.users.length} users, ${db.comments.length} comments.`);
    } else {
      db = {
        posts: (initialData?.posts && initialData.posts.length > 0) ? initialData.posts : INITIAL_POSTS,
        comments: (initialData?.comments && initialData.comments.length > 0) ? initialData.comments : INITIAL_COMMENTS,
        messages: (initialData?.messages && initialData.messages.length > 0) ? initialData.messages : INITIAL_MESSAGES,
        stories: (initialData?.stories && initialData.stories.length > 0) ? initialData.stories : INITIAL_STORIES,
        users: (initialData?.users && initialData.users.length > 0) ? initialData.users : INITIAL_USERS,
        notifications: INITIAL_NOTIFICATIONS,
        version: 1,
        lastUpdated: new Date().toISOString(),
      };
      saveDbToDisk();
      console.log(`[SyncStore] Initialized new DB with ${db.posts.length} posts, ${db.users.length} users at ${DB_FILE_PATH}`);
    }
  } catch (err) {
    console.error('[SyncStore] Error loading DB file, using fallback initial data:', err);
    db = {
      posts: INITIAL_POSTS,
      comments: INITIAL_COMMENTS,
      messages: INITIAL_MESSAGES,
      stories: INITIAL_STORIES,
      users: INITIAL_USERS,
      notifications: INITIAL_NOTIFICATIONS,
      version: 1,
      lastUpdated: new Date().toISOString(),
    };
    saveDbToDisk();
  }
}

/**
 * Registers an active Server-Sent Events client
 */
export function registerSseClient(res: Response): void {
  sseClients.add(res);

  // Send initial connected state
  res.write(`event: connected\ndata: ${JSON.stringify({ timestamp: new Date().toISOString(), clientCount: sseClients.size + wsClients.size })}\n\n`);

  res.on('close', () => {
    sseClients.delete(res);
  });
}

/**
 * Registers an active WebSocket client (Android & Web apps for instantaneous media & video sync)
 */
export function registerWsClient(ws: WebSocket): void {
  wsClients.add(ws);

  // Send welcome confirmation
  try {
    ws.send(JSON.stringify({
      type: 'CONNECTED',
      payload: {
        timestamp: new Date().toISOString(),
        clientCount: sseClients.size + wsClients.size,
        version: db.version
      }
    }));
  } catch {}

  ws.on('message', (data: any) => {
    try {
      const text = data.toString();
      const parsed = JSON.parse(text);
      if (parsed && parsed.type) {
        handleWsMessage(ws, parsed.type, parsed.payload);
      }
    } catch (err) {
      console.warn('[WS] Failed to parse message:', err);
    }
  });

  ws.on('close', () => {
    wsClients.delete(ws);
  });

  ws.on('error', () => {
    wsClients.delete(ws);
  });
}

/**
 * Handles incoming WebSocket sync messages from Android or Web
 */
export function handleWsMessage(senderWs: WebSocket | null, type: string, payload: any): void {
  if (type === 'VIDEO_PLAYBACK_SYNC') {
    // Relay video playback state (videoId, positionMs, isPlaying, senderId) to all other devices
    broadcastEvent('VIDEO_PLAYBACK_SYNC', payload);
  } else if (type === 'MEDIA_SYNC') {
    const { postId, videoUrls, thumbnailUrl, authorId } = payload || {};
    if (postId && Array.isArray(videoUrls)) {
      syncMediaPost(postId, videoUrls, thumbnailUrl, authorId);
    }
  } else if (type === 'PING') {
    try {
      senderWs?.send(JSON.stringify({ type: 'PONG', timestamp: Date.now() }));
    } catch {}
  }
}

/**
 * Broadcasts an event to all connected devices (mobile phones & desktops via SSE and WebSocket)
 */
export function broadcastEvent(eventType: string, payload: any): void {
  const data = JSON.stringify({
    type: eventType,
    payload,
    timestamp: new Date().toISOString(),
    version: db.version,
  });

  // Broadcast to SSE clients
  for (const client of sseClients) {
    try {
      client.write(`event: sync\ndata: ${data}\n\n`);
    } catch (err) {
      sseClients.delete(client);
    }
  }

  // Broadcast to WebSocket clients (e.g. Android MediaSyncService & Web)
  for (const ws of wsClients) {
    try {
      if (ws.readyState === 1 /* OPEN */) {
        ws.send(data);
      }
    } catch (err) {
      wsClients.delete(ws);
    }
  }
}

/**
 * Updates a post's media URLs and broadcasts immediate availability to all devices
 */
export function syncMediaPost(postId: string, videoUrls: string[], videoThumbnail?: string, authorId?: string): any {
  let targetPost = db.posts.find((p) => p.id === postId);
  if (!targetPost) {
    targetPost = {
      id: postId,
      authorId: authorId || 'user_current',
      authorName: '회원',
      authorHandle: 'user',
      authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200',
      content: '',
      video: videoUrls[0],
      videoUrls: videoUrls,
      videoThumbnail: videoThumbnail,
      likes: [],
      commentsCount: 0,
      createdAt: new Date().toISOString()
    };
    targetPost = normalizePostMedia(targetPost);
    db.posts = [targetPost, ...db.posts];
  } else {
    targetPost.video = videoUrls[0] || targetPost.video;
    targetPost.videoUrls = videoUrls;
    if (videoThumbnail) targetPost.videoThumbnail = videoThumbnail;
    targetPost = normalizePostMedia(targetPost);
    db.posts = db.posts.map((p) => (p.id === postId ? targetPost : p));
  }
  saveDbToDisk();
  broadcastEvent('MEDIA_SYNC', { postId, post: targetPost, videoUrls: targetPost.videoUrls, videoThumbnail: targetPost.videoThumbnail, posts: db.posts });
  broadcastEvent('POST_UPDATED', { post: targetPost, posts: db.posts });
  return targetPost;
}

/**
 * Heartbeat ticker to keep mobile carrier & websocket connections alive
 */
setInterval(() => {
  for (const client of sseClients) {
    try {
      client.write(`: heartbeat\n\n`);
    } catch {
      sseClients.delete(client);
    }
  }
  for (const ws of wsClients) {
    try {
      if (ws.readyState === 1 /* OPEN */) {
        ws.ping();
      }
    } catch {
      wsClients.delete(ws);
    }
  }
}, 15000);

export function getSyncState(): SyncData {
  if (Array.isArray(db.kickedUsers) && db.kickedUsers.length > 0) {
    const kickedIds = new Set(db.kickedUsers.map((k: any) => k.id));
    const kickedHandles = new Set(db.kickedUsers.map((k: any) => (k.handle || '').toLowerCase().replace(/^@/, '')));
    db.users = db.users.filter((u: any) => !kickedIds.has(u.id) && !kickedHandles.has((u.handle || '').toLowerCase().replace(/^@/, '')));
  }
  return db;
}

export function syncCreatePost(newPost: any): any {
  const normalizedPost = normalizePostMedia(newPost);
  // If post was previously deleted, un-delete it
  if (db.deletedPostIds && db.deletedPostIds.includes(normalizedPost.id)) {
    db.deletedPostIds = db.deletedPostIds.filter((id) => id !== normalizedPost.id);
  }
  // Prevent duplicate id
  const existingIdx = db.posts.findIndex((p) => p.id === normalizedPost.id);
  if (existingIdx !== -1) {
    db.posts[existingIdx] = normalizedPost;
  } else {
    db.posts = [normalizedPost, ...db.posts];
  }
  saveDbToDisk();
  broadcastEvent('POST_CREATED', { post: normalizedPost, posts: db.posts });
  return normalizedPost;
}

export function syncUpdatePost(postId: string, updatedFields: any): any {
  let updatedPost: any = null;
  db.posts = db.posts.map((post) => {
    if (post.id === postId) {
      updatedPost = normalizePostMedia({ ...post, ...updatedFields });
      return updatedPost;
    }
    return post;
  });
  if (updatedPost) {
    saveDbToDisk();
    broadcastEvent('POST_UPDATED', { post: updatedPost, posts: db.posts });
  }
  return updatedPost;
}

export function syncDeletePost(postId: string): boolean {
  if (!db.deletedPostIds) {
    db.deletedPostIds = [];
  }
  if (!db.deletedPostIds.includes(postId)) {
    db.deletedPostIds.push(postId);
  }

  const initialLength = db.posts.length;
  db.posts = db.posts.filter((p) => p.id !== postId);
  // Also remove associated comments
  db.comments = db.comments.filter((c) => c.postId !== postId);

  saveDbToDisk();
  broadcastEvent('POST_DELETED', { 
    postId, 
    posts: db.posts, 
    comments: db.comments,
    deletedPostIds: db.deletedPostIds 
  });
  return true;
}

export function syncToggleLike(postId: string, userId: string, userName?: string, userAvatar?: string): any {
  const existingPost = db.posts.find((p) => p.id === postId);
  if (!existingPost) return null;

  // Prevent self-like abuse (자신의 게시물 가짜 좋아요 방지)
  if (existingPost.authorId === userId) return null;

  // Check if actor is banned or kicked
  const user = db.users.find((u) => u.id === userId);
  if (user?.isBanned) return null;
  const isKicked = db.kickedUsers?.some((k) => k.id === userId);
  if (isKicked) return null;

  let targetPost: any = null;
  let isLikedNow = false;
  db.posts = db.posts.map((post) => {
    if (post.id === postId) {
      const likes: string[] = post.likes || [];
      const hasLiked = likes.includes(userId);
      isLikedNow = !hasLiked;
      const updatedLikes = hasLiked ? likes.filter((id) => id !== userId) : [...likes, userId];
      targetPost = {
        ...post,
        likes: updatedLikes,
        likesCount: updatedLikes.length,
      };
      return targetPost;
    }
    return post;
  });
  if (targetPost) {
    let newNotif: any = null;
    if (isLikedNow && targetPost.authorId !== userId) {
      const actor = db.users.find((u: any) => u.id === userId) || {
        id: userId,
        name: userName || '회원',
        avatar: userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
      };
      const finalActorName = userName || actor.name || '회원';
      const finalActorAvatar = userAvatar || actor.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80';

      if (!Array.isArray(db.notifications)) {
        db.notifications = [];
      }

      // Deduplicate: check if a like notification from this actor for this post already exists
      const existingIdx = db.notifications.findIndex(
        (n: any) => n.type === 'like' && n.recipientId === targetPost.authorId && n.actorId === actor.id && n.postId === targetPost.id
      );

      if (existingIdx !== -1) {
        db.notifications[existingIdx] = {
          ...db.notifications[existingIdx],
          actorName: finalActorName,
          actorAvatar: finalActorAvatar,
          content: `회원님의 게시물을 좋아합니다: "${(targetPost.content || '').slice(0, 24)}..."`,
          createdAt: new Date().toISOString(),
          isRead: false,
        };
        newNotif = db.notifications[existingIdx];
      } else {
        newNotif = {
          id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          recipientId: targetPost.authorId,
          actorId: actor.id,
          actorName: finalActorName,
          actorAvatar: finalActorAvatar,
          type: 'like',
          postId: targetPost.id,
          content: `회원님의 게시물을 좋아합니다: "${(targetPost.content || '').slice(0, 24)}..."`,
          createdAt: new Date().toISOString(),
          isRead: false,
        };
        db.notifications = [newNotif, ...db.notifications];
      }
      db.notifications = deduplicateNotifications(db.notifications);
    }
    saveDbToDisk();
    broadcastEvent('POST_LIKED', {
      post: targetPost,
      postId,
      userId,
      posts: db.posts,
      notification: newNotif,
      notifications: db.notifications,
    });
  }
  return targetPost;
}

export function syncToggleBookmark(postId: string, userId: string): any {
  let targetPost: any = null;
  db.posts = db.posts.map((post) => {
    if (post.id === postId) {
      const bookmarks: string[] = post.bookmarks || [];
      const hasBookmarked = bookmarks.includes(userId);
      const updatedBookmarks = hasBookmarked ? bookmarks.filter((id) => id !== userId) : [...bookmarks, userId];
      targetPost = {
        ...post,
        bookmarks: updatedBookmarks,
      };
      return targetPost;
    }
    return post;
  });
  if (targetPost) {
    saveDbToDisk();
    broadcastEvent('POST_BOOKMARKED', { post: targetPost, postId, userId, posts: db.posts });
  }
  return targetPost;
}

export function syncClearBookmarks(userId: string): any {
  db.posts = db.posts.map((post) => {
    const bookmarks: string[] = post.bookmarks || [];
    if (bookmarks.includes(userId)) {
      return {
        ...post,
        bookmarks: bookmarks.filter((id) => id !== userId),
      };
    }
    return post;
  });
  saveDbToDisk();
  broadcastEvent('POSTS_SYNC', { posts: db.posts });
  return db.posts;
}

export function syncAddComment(newComment: any): any {
  const existingIdx = db.comments.findIndex((c) => c.id === newComment.id);
  if (existingIdx !== -1) {
    db.comments[existingIdx] = newComment;
  } else {
    db.comments = [...db.comments, newComment];
  }

  // Update comments count on target post
  let targetPost: any = null;
  db.posts = db.posts.map((post) => {
    if (post.id === newComment.postId) {
      const count = db.comments.filter((c) => c.postId === post.id).length;
      targetPost = { ...post, commentsCount: count };
      return targetPost;
    }
    return post;
  });

  if (!targetPost) {
    targetPost = db.posts.find((p: any) => p.id === newComment.postId) || null;
  }

  // Authoritative Notifications generation for comment & reply
  const actor = db.users.find((u: any) => u.id === newComment.authorId) || {
    id: newComment.authorId,
    name: newComment.authorName || '회원',
    avatar: newComment.authorAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200',
  };

  const createdNotifs: any[] = [];
  const commentText = (newComment.content || '').trim();
  const summaryText = newComment.audioUrl
    ? `음성 댓글을 남겼습니다 (${Math.round(newComment.audioDuration || 0)}초)`
    : `회원님의 게시물에 댓글을 남겼습니다: "${commentText.slice(0, 30)}${commentText.length > 30 ? '...' : ''}"`;

  // 1. Post author notification (when someone else comments)
  let postAuthorNotif: any = null;
  if (targetPost && targetPost.authorId && targetPost.authorId !== newComment.authorId) {
    postAuthorNotif = {
      id: `notif_${Date.now()}_comm_${Math.random().toString(36).substring(2, 7)}`,
      recipientId: targetPost.authorId,
      actorId: actor.id,
      actorName: actor.name,
      actorAvatar: actor.avatar,
      type: 'comment',
      postId: targetPost.id,
      commentId: newComment.id,
      content: summaryText,
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    createdNotifs.push(postAuthorNotif);
  } else if (targetPost && targetPost.authorId === newComment.authorId && !newComment.parentId) {
    // Activity record when author writes comment on own post
    const selfNotif = {
      id: `notif_${Date.now()}_selfcomm_${Math.random().toString(36).substring(2, 7)}`,
      recipientId: targetPost.authorId,
      actorId: actor.id,
      actorName: actor.name,
      actorAvatar: actor.avatar,
      type: 'comment',
      postId: targetPost.id,
      commentId: newComment.id,
      content: newComment.audioUrl
        ? `내 게시물에 음성 댓글을 등록했습니다 (${Math.round(newComment.audioDuration || 0)}초)`
        : `내 게시물에 새 댓글을 등록했습니다: "${commentText.slice(0, 30)}${commentText.length > 30 ? '...' : ''}"`,
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    createdNotifs.push(selfNotif);
  }

  // 2. Parent comment author notification (when replying)
  let replyAuthorNotif: any = null;
  if (newComment.parentId) {
    const parentComment = db.comments.find((c: any) => c.id === newComment.parentId);
    if (
      parentComment &&
      parentComment.authorId &&
      parentComment.authorId !== newComment.authorId &&
      parentComment.authorId !== targetPost?.authorId
    ) {
      const replySummary = newComment.audioUrl
        ? `회원님의 댓글에 음성 답글을 남겼습니다 (${Math.round(newComment.audioDuration || 0)}초)`
        : `회원님의 댓글에 답글을 남겼습니다: "${commentText.slice(0, 30)}${commentText.length > 30 ? '...' : ''}"`;
      replyAuthorNotif = {
        id: `notif_${Date.now()}_reply_${Math.random().toString(36).substring(2, 7)}`,
        recipientId: parentComment.authorId,
        actorId: actor.id,
        actorName: actor.name,
        actorAvatar: actor.avatar,
        type: 'comment',
        postId: targetPost?.id || newComment.postId,
        commentId: newComment.id,
        content: replySummary,
        createdAt: new Date().toISOString(),
        isRead: false,
      };
      createdNotifs.push(replyAuthorNotif);
    }
  }

  if (!Array.isArray(db.notifications)) {
    db.notifications = [];
  }
  if (createdNotifs.length > 0) {
    db.notifications = [...createdNotifs, ...db.notifications];
    db.notifications = deduplicateNotifications(db.notifications);
  }

  saveDbToDisk();
  broadcastEvent('COMMENT_ADDED', {
    comment: newComment,
    comments: db.comments,
    post: targetPost,
    posts: db.posts,
    notification: postAuthorNotif || replyAuthorNotif || createdNotifs[0] || null,
    notifications: db.notifications,
  });
  return newComment;
}

export function syncToggleCommentLike(commentId: string, userId: string): any {
  let targetComment: any = null;
  let isLikedNow = false;
  db.comments = db.comments.map((comment) => {
    if (comment.id === commentId) {
      const likes: string[] = comment.likes || [];
      const hasLiked = likes.includes(userId);
      isLikedNow = !hasLiked;
      const updatedLikes = hasLiked ? likes.filter((id) => id !== userId) : [...likes, userId];
      targetComment = {
        ...comment,
        likes: updatedLikes,
      };
      return targetComment;
    }
    return comment;
  });
  if (targetComment) {
    let newNotif: any = null;
    if (isLikedNow && targetComment.authorId !== userId) {
      const actor = db.users.find((u: any) => u.id === userId) || {
        id: userId,
        name: '회원',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
      };
      if (!Array.isArray(db.notifications)) {
        db.notifications = [];
      }
      const existingIdx = db.notifications.findIndex(
        (n: any) => n.type === 'like' && n.recipientId === targetComment.authorId && n.actorId === actor.id && n.postId === targetComment.postId
      );
      if (existingIdx !== -1) {
        db.notifications[existingIdx] = {
          ...db.notifications[existingIdx],
          createdAt: new Date().toISOString(),
          isRead: false,
        };
        newNotif = db.notifications[existingIdx];
      } else {
        newNotif = {
          id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          recipientId: targetComment.authorId,
          actorId: actor.id,
          actorName: actor.name,
          actorAvatar: actor.avatar,
          type: 'like',
          postId: targetComment.postId,
          content: `회원님의 댓글을 좋아합니다: "${(targetComment.content || '').slice(0, 24)}..."`,
          createdAt: new Date().toISOString(),
          isRead: false,
        };
        db.notifications = [newNotif, ...db.notifications];
      }
      db.notifications = deduplicateNotifications(db.notifications);
    }
    saveDbToDisk();
    broadcastEvent('COMMENT_LIKED', {
      comment: targetComment,
      commentId,
      comments: db.comments,
      notification: newNotif,
      notifications: db.notifications,
    });
  }
  return targetComment;
}

export function syncAddNotification(notification: any): any {
  if (!notification || !notification.id) return null;
  if (!Array.isArray(db.notifications)) {
    db.notifications = [];
  }
  const existingIdx = db.notifications.findIndex((n: any) => {
    if (n.id === notification.id) return true;
    if (notification.type === 'like' || notification.type === 'follow') {
      return (
        n.recipientId === notification.recipientId &&
        n.actorId === notification.actorId &&
        n.type === notification.type &&
        (n.postId || '') === (notification.postId || '')
      );
    }
    if (notification.type === 'comment') {
      if (notification.commentId && n.commentId) {
        return n.commentId === notification.commentId;
      }
      return (
        n.recipientId === notification.recipientId &&
        n.actorId === notification.actorId &&
        n.type === notification.type &&
        n.content === notification.content &&
        Math.abs(new Date(n.createdAt).getTime() - new Date(notification.createdAt).getTime()) < 10000
      );
    }
    return false;
  });
  if (existingIdx !== -1) {
    db.notifications[existingIdx] = {
      ...db.notifications[existingIdx],
      ...notification,
      id: db.notifications[existingIdx].id,
      createdAt: new Date().toISOString(),
      isRead: false,
    };
    notification = db.notifications[existingIdx];
  } else {
    db.notifications = [notification, ...db.notifications];
  }
  db.notifications = deduplicateNotifications(db.notifications);
  saveDbToDisk();
  broadcastEvent('NOTIFICATION_ADDED', { notification, notifications: db.notifications });
  return notification;
}

export function syncSendMessage(newMsg: any): any {
  if (!newMsg || (!newMsg.content && !newMsg.mediaUrl)) {
    return null;
  }
  // Prevent fake self-messages (가짜 메시지 및 자가 발송 방지)
  if (newMsg.senderId && newMsg.receiverId && newMsg.senderId === newMsg.receiverId) {
    return null;
  }
  const existingIdx = db.messages.findIndex((m) => m.id === newMsg.id);
  if (existingIdx !== -1) {
    db.messages[existingIdx] = newMsg;
  } else {
    db.messages = [...db.messages, newMsg];
  }
  saveDbToDisk();
  broadcastEvent('MESSAGE_SENT', { message: newMsg, messages: db.messages });
  return newMsg;
}

export function syncMarkConversationAsRead(partnerId: string, userId?: string): { readCount: number; messages: any[] } {
  let readCount = 0;
  const now = new Date().toISOString();
  db.messages = db.messages.map((m) => {
    const matchesReceiver = userId ? m.receiverId === userId : true;
    if (m.senderId === partnerId && matchesReceiver && !m.isRead) {
      readCount++;
      return { ...m, isRead: true, readAt: now };
    }
    return m;
  });

  if (readCount > 0) {
    saveDbToDisk();
    broadcastEvent('MESSAGES_READ', { partnerId, userId, readCount, messages: db.messages });
  }

  return { readCount, messages: db.messages };
}

export function syncMarkMessageAsRead(messageId: string, userId?: string): { success: boolean; message?: any; messages: any[] } {
  let updatedMsg: any = null;
  const now = new Date().toISOString();
  db.messages = db.messages.map((m) => {
    if (m.id === messageId) {
      if (!m.isRead) {
        updatedMsg = { ...m, isRead: true, readAt: now };
        return updatedMsg;
      }
      updatedMsg = m;
    }
    return m;
  });

  if (updatedMsg) {
    saveDbToDisk();
    broadcastEvent('MESSAGE_READ', { messageId, message: updatedMsg, messages: db.messages });
    return { success: true, message: updatedMsg, messages: db.messages };
  }
  return { success: false, messages: db.messages };
}

export function syncMarkAllMessagesAsRead(userId: string): { readCount: number; messages: any[] } {
  let readCount = 0;
  const now = new Date().toISOString();
  db.messages = db.messages.map((m) => {
    if (m.receiverId === userId && !m.isRead) {
      readCount++;
      return { ...m, isRead: true, readAt: now };
    }
    return m;
  });

  if (readCount > 0) {
    saveDbToDisk();
    broadcastEvent('ALL_MESSAGES_READ', { userId, readCount, messages: db.messages });
  }

  return { readCount, messages: db.messages };
}

export function syncToggleStarMessage(messageId: string): { success: boolean; isStarred: boolean; message?: any; messages: any[] } {
  let updatedMsg: any = null;
  const now = new Date().toISOString();
  db.messages = db.messages.map((m) => {
    if (m.id === messageId) {
      const nextStarred = !m.isStarred;
      updatedMsg = { ...m, isStarred: nextStarred, starredAt: nextStarred ? now : undefined };
      return updatedMsg;
    }
    return m;
  });

  if (updatedMsg) {
    saveDbToDisk();
    broadcastEvent('MESSAGE_STARRED', { messageId, isStarred: updatedMsg.isStarred, message: updatedMsg, messages: db.messages });
    return { success: true, isStarred: updatedMsg.isStarred, message: updatedMsg, messages: db.messages };
  }

  return { success: false, isStarred: false, messages: db.messages };
}

export function syncCreateStory(newStory: any): any {
  const existingIdx = db.stories.findIndex((s) => s.userId === newStory.userId);
  if (existingIdx !== -1) {
    const existingStory = db.stories[existingIdx];
    // Deduplicate items by ID, preserving order (newest items first)
    const seenIds = new Set<string>();
    const uniqueItems: any[] = [];
    for (const item of newStory.items || []) {
      if (item && item.id && !seenIds.has(item.id)) {
        seenIds.add(item.id);
        uniqueItems.push(item);
      }
    }
    for (const item of existingStory.items || []) {
      if (item && item.id && !seenIds.has(item.id)) {
        seenIds.add(item.id);
        uniqueItems.push(item);
      }
    }
    db.stories[existingIdx] = { ...existingStory, ...newStory, items: uniqueItems };
  } else {
    const seenIds = new Set<string>();
    const uniqueItems: any[] = [];
    for (const item of newStory.items || []) {
      if (item && item.id && !seenIds.has(item.id)) {
        seenIds.add(item.id);
        uniqueItems.push(item);
      }
    }
    db.stories = [{ ...newStory, items: uniqueItems }, ...db.stories];
  }
  saveDbToDisk();
  broadcastEvent('STORY_CREATED', { story: newStory, stories: db.stories });
  return db.stories[existingIdx !== -1 ? existingIdx : 0];
}

export function syncUpdateUser(userId: string, updatedFields: any): any {
  let targetUser: any = null;
  db.users = db.users.map((user) => {
    if (user.id === userId) {
      targetUser = { ...user, ...updatedFields };
      return targetUser;
    }
    return user;
  });
  if (targetUser) {
    saveDbToDisk();
    broadcastEvent('USER_UPDATED', { user: targetUser, users: db.users });
  }
  return targetUser;
}

export function syncAddUser(newUser: any): any {
  const existingIdx = db.users.findIndex((u) => u.id === newUser.id || u.handle === newUser.handle);
  if (existingIdx !== -1) {
    db.users[existingIdx] = { ...db.users[existingIdx], ...newUser };
  } else {
    db.users = [newUser, ...db.users];
  }
  saveDbToDisk();
  broadcastEvent('USER_REGISTERED', { user: newUser, users: db.users });
  return newUser;
}

export function syncKickUser(
  userId: string,
  reason: string = '운영 정책 위반',
  adminName: string = '최고 관리자',
  incomingUserData?: any,
  incomingUserPosts?: any[]
): any {
  let targetUser = db.users.find((u) => u.id === userId);
  if (!targetUser && incomingUserData) {
    targetUser = incomingUserData;
  }
  if (!targetUser) return null;

  // Add to kickedUsers history
  if (!db.kickedUsers) {
    db.kickedUsers = [];
  }

  const existingPosts = db.posts.filter((p) => p.authorId === userId);
  const userPosts = Array.isArray(incomingUserPosts) && incomingUserPosts.length > 0 ? incomingUserPosts : existingPosts;

  const kickRecord = {
    id: targetUser.id,
    name: targetUser.name,
    handle: targetUser.handle,
    email: targetUser.email,
    phoneNumber: targetUser.phoneNumber,
    signupIp: targetUser.signupIp || '211.234.120.45',
    kickedAt: new Date().toISOString(),
    reason,
    kickedBy: adminName,
    userData: targetUser,
    userPosts: userPosts,
  };
  db.kickedUsers = [kickRecord, ...db.kickedUsers.filter((k) => k.id !== userId && k.handle !== targetUser.handle)];

  // Remove user completely from active users list
  db.users = db.users.filter((u) => u.id !== userId && u.handle.toLowerCase() !== targetUser.handle.toLowerCase());

  // Remove user's posts, comments, stories
  const userPostIds = userPosts.map((p: any) => p.id);
  if (!db.deletedPostIds) db.deletedPostIds = [];
  userPostIds.forEach((pid: string) => {
    if (!db.deletedPostIds!.includes(pid)) db.deletedPostIds!.push(pid);
  });
  db.posts = db.posts.filter((p) => p.authorId !== userId);
  db.comments = db.comments.filter((c) => c.authorId !== userId && !userPostIds.includes(c.postId));
  db.stories = db.stories.filter((s) => s.userId !== userId);

  saveDbToDisk();
  broadcastEvent('USER_KICKED', {
    userId,
    kickedRecord: kickRecord,
    users: db.users,
    posts: db.posts,
    deletedPostIds: db.deletedPostIds,
    kickedUsers: db.kickedUsers,
  });

  return kickRecord;
}

export function syncRestoreUser(
  userId: string,
  incomingRestoredUser?: any,
  incomingUserPosts?: any[]
): {
  success: boolean;
  restoredUser: any;
  users: any[];
  kickedUsers: any[];
  posts?: any[];
  deletedPostIds?: string[];
  error?: string;
} {
  const kickIdx = Array.isArray(db.kickedUsers) ? db.kickedUsers.findIndex((k) => k.id === userId) : -1;
  const kickedRecord = kickIdx !== -1 ? db.kickedUsers[kickIdx] : null;

  if (kickIdx !== -1) {
    db.kickedUsers = db.kickedUsers.filter((_, idx) => idx !== kickIdx);
  }

  // Reconstitute restored user
  let restoredUser: any = kickedRecord?.userData || incomingRestoredUser;
  if (!restoredUser) {
    const initialMatch = INITIAL_USERS.find(
      (u) => u.id === userId || (kickedRecord && u.handle.toLowerCase() === (kickedRecord.handle || '').toLowerCase())
    );
    if (initialMatch) {
      restoredUser = { ...initialMatch, isBanned: false };
    } else if (kickedRecord) {
      restoredUser = {
        id: kickedRecord.id,
        name: kickedRecord.name,
        handle: kickedRecord.handle,
        email: kickedRecord.email || `${kickedRecord.handle}@maeum.io`,
        phoneNumber: kickedRecord.phoneNumber,
        signupIp: kickedRecord.signupIp || (kickedRecord.userData && kickedRecord.userData.signupIp) || '211.234.120.45',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
        banner: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
        bio: '관리자에 의해 정상 복원된 계정입니다.',
        role: '일반 회원',
        location: '대한민국',
        isVerified: false,
        isAdmin: false,
        isBanned: false,
        followersCount: 0,
        followingCount: 0,
        followingIds: [],
        followerIds: [],
        createdAt: kickedRecord.kickedAt || new Date().toISOString(),
      };
    }
  }

  if (!restoredUser) {
    return { success: false, restoredUser: null, users: db.users, kickedUsers: db.kickedUsers || [], error: '해당 회원의 강퇴 기록을 찾을 수 없습니다.' };
  }

  restoredUser.isBanned = false;
  // Prepend restored user to users list
  db.users = [
    restoredUser,
    ...db.users.filter((u) => u.id !== userId && u.handle.toLowerCase() !== (restoredUser.handle || '').toLowerCase()),
  ];

  // Restore user's posts and unblock deleted post IDs
  const postsToRestore: any[] = (kickedRecord && Array.isArray(kickedRecord.userPosts) && kickedRecord.userPosts.length > 0)
    ? kickedRecord.userPosts
    : (Array.isArray(incomingUserPosts) ? incomingUserPosts : []);

  if (postsToRestore.length > 0) {
    const postIdsToRestore = new Set(postsToRestore.map((p) => p.id));
    if (Array.isArray(db.deletedPostIds)) {
      db.deletedPostIds = db.deletedPostIds.filter((pid) => !postIdsToRestore.has(pid));
    }
    const existingPostIds = new Set(db.posts.map((p) => p.id));
    const newPosts = postsToRestore.filter((p) => !existingPostIds.has(p.id));
    db.posts = [...newPosts, ...db.posts];
  }

  saveDbToDisk();
  broadcastEvent('USER_RESTORED', {
    userId,
    restoredUser,
    users: db.users,
    kickedUsers: db.kickedUsers,
    posts: db.posts,
    deletedPostIds: db.deletedPostIds,
  });

  return {
    success: true,
    restoredUser,
    users: db.users,
    kickedUsers: db.kickedUsers,
    posts: db.posts,
    deletedPostIds: db.deletedPostIds,
  };
}

export function syncToggleBanUser(userId: string, reason: string = '운영 정책 위반'): any {
  let targetUser: any = null;
  db.users = db.users.map((u) => {
    if (u.id === userId) {
      const isNowBanned = !u.isBanned;
      targetUser = {
        ...u,
        isBanned: isNowBanned,
        bannedAt: isNowBanned ? new Date().toISOString() : undefined,
        banReason: isNowBanned ? reason : undefined,
      };
      return targetUser;
    }
    return u;
  });

  if (targetUser) {
    saveDbToDisk();
    broadcastEvent('USER_BAN_TOGGLED', { user: targetUser, users: db.users });
  }

  return targetUser;
}

export function syncToggleFollow(
  currentUserId: string,
  targetUserId: string,
  currentUserObj?: any,
  targetName?: string,
  targetHandle?: string
): {
  success: boolean;
  isFollowing: boolean;
  currentUser: any;
  targetUser: any;
  users: any[];
  notification?: any;
} {
  let isFollowing = false;
  let updatedMe: any = null;
  let updatedTarget: any = null;

  // Prevent self-follow (자기 자신 팔로우 금지)
  if (currentUserId === targetUserId) {
    return { success: false, isFollowing: false, currentUser: null, targetUser: null, users: db.users };
  }

  // Prevent banned or kicked actor
  const isKickedMe = db.kickedUsers?.some((k) => k.id === currentUserId);
  if (isKickedMe) return { success: false, isFollowing: false, currentUser: null, targetUser: null, users: db.users };

  // Prevent following kicked target
  const isKickedTarget = db.kickedUsers?.some((k) => k.id === targetUserId);
  if (isKickedTarget) return { success: false, isFollowing: false, currentUser: null, targetUser: null, users: db.users };

  let me = db.users.find((u) => u.id === currentUserId);
  if (!me && currentUserObj) {
    db.users.push(currentUserObj);
    me = currentUserObj;
  }
  if (!me) return { success: false, isFollowing: false, currentUser: null, targetUser: null, users: db.users };

  let target = db.users.find((u) => u.id === targetUserId);
  if (!target) {
    const initTarget = INITIAL_USERS.find((u) => u.id === targetUserId);
    if (initTarget) {
      db.users.push(initTarget);
      target = initTarget;
    }
  }

  // Look in db.posts for author info if target is still missing
  const matchPost = db.posts.find((p) => p.authorId === targetUserId);

  if (!target) {
    const resolvedName =
      (targetName && targetName.trim() !== '회원' ? targetName.trim() : '') ||
      (matchPost?.authorName && matchPost.authorName.trim() !== '회원' ? matchPost.authorName.trim() : '') ||
      (targetHandle ? `@${targetHandle.replace(/^@/, '')}` : '') ||
      (matchPost?.authorHandle ? `@${matchPost.authorHandle.replace(/^@/, '')}` : '') ||
      '회원';

    const resolvedHandle = targetHandle?.replace(/^@/, '') || matchPost?.authorHandle || targetUserId;

    target = {
      id: targetUserId,
      name: resolvedName,
      handle: resolvedHandle,
      avatar: matchPost?.authorAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      banner: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
      bio: '마음 회원입니다 ✨',
      joinedDate: '2024년 1월',
      followersCount: 0,
      followingCount: 0,
      followingIds: [],
      followerIds: [],
      isBanned: false,
    };
    db.users.push(target);
  } else {
    // If target has generic or empty name, enhance with matchPost or targetName
    if ((!target.name || target.name.trim() === '회원') && matchPost?.authorName && matchPost.authorName.trim() !== '회원') {
      target.name = matchPost.authorName.trim();
    } else if ((!target.name || target.name.trim() === '회원') && targetName && targetName.trim() !== '회원') {
      target.name = targetName.trim();
    }
  }

  const currentFollowing: string[] = Array.isArray(me.followingIds) ? me.followingIds : [];
  isFollowing = currentFollowing.includes(targetUserId);

  const nextFollowing = isFollowing
    ? currentFollowing.filter((id) => id !== targetUserId)
    : Array.from(new Set([...currentFollowing, targetUserId]));

  db.users = db.users.map((u) => {
    if (u.id === currentUserId) {
      updatedMe = {
        ...u,
        followingIds: nextFollowing,
        followingCount: nextFollowing.length,
      };
      return updatedMe;
    }
    if (u.id === targetUserId) {
      const currentFollowers: string[] = Array.isArray(u.followerIds) ? u.followerIds : [];
      const nextFollowers = isFollowing
        ? currentFollowers.filter((id) => id !== currentUserId)
        : Array.from(new Set([...currentFollowers, currentUserId]));

      const curCount = typeof u.followersCount === 'number' ? u.followersCount : 0;
      const nextCount = isFollowing ? Math.max(0, curCount - 1) : curCount + 1;

      updatedTarget = {
        ...u,
        followerIds: nextFollowers,
        followersCount: nextCount,
      };
      return updatedTarget;
    }
    return u;
  });

  let newNotif: any = null;
  if (!isFollowing && targetUserId !== currentUserId) {
    if (!Array.isArray(db.notifications)) {
      db.notifications = [];
    }

    const finalActorName = updatedMe?.name || '회원';
    const finalActorAvatar = updatedMe?.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80';

    const existingIdx = db.notifications.findIndex(
      (n: any) => n.type === 'follow' && n.recipientId === targetUserId && n.actorId === currentUserId
    );

    if (existingIdx !== -1) {
      db.notifications[existingIdx] = {
        ...db.notifications[existingIdx],
        actorName: finalActorName,
        actorAvatar: finalActorAvatar,
        content: '회원님을 팔로우하기 시작했습니다.',
        createdAt: new Date().toISOString(),
        isRead: false,
      };
      newNotif = db.notifications[existingIdx];
    } else {
      newNotif = {
        id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        recipientId: targetUserId,
        actorId: currentUserId,
        actorName: finalActorName,
        actorAvatar: finalActorAvatar,
        type: 'follow',
        content: '회원님을 팔로우하기 시작했습니다.',
        createdAt: new Date().toISOString(),
        isRead: false,
      };
      db.notifications = [newNotif, ...db.notifications];
    }
    db.notifications = deduplicateNotifications(db.notifications);
  }

  saveDbToDisk();
  broadcastEvent('USER_FOLLOW_TOGGLED', {
    currentUserId,
    targetUserId,
    isFollowing: !isFollowing,
    currentUser: updatedMe,
    targetUser: updatedTarget,
    users: db.users,
    notification: newNotif,
    notifications: db.notifications,
  });

  return {
    success: true,
    isFollowing: !isFollowing,
    currentUser: updatedMe,
    targetUser: updatedTarget,
    users: db.users,
    notification: newNotif,
  };
}
