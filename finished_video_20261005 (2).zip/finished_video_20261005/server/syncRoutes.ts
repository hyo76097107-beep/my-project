import { Router, Request, Response } from 'express';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import {
  getSyncState,
  registerSseClient,
  syncCreatePost,
  syncUpdatePost,
  syncDeletePost,
  syncToggleLike,
  syncToggleBookmark,
  syncClearBookmarks,
  syncAddComment,
  syncToggleCommentLike,
  syncSendMessage,
  syncMarkConversationAsRead,
  syncMarkMessageAsRead,
  syncMarkAllMessagesAsRead,
  syncToggleStarMessage,
  syncCreateStory,
  syncUpdateUser,
  syncAddUser,
  syncKickUser,
  syncRestoreUser,
  syncToggleBanUser,
  syncAddNotification,
  syncToggleFollow,
  syncMediaPost,
  initSyncStore,
} from './syncStore';

const router = Router();

// Configure local uploads directory for persistent cross-device video & photo storage
const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const rawExt = path.extname(file.originalname);
    const safeExt = rawExt
      ? rawExt.toLowerCase()
      : file.mimetype.includes('webm')
      ? '.webm'
      : file.mimetype.includes('quicktime')
      ? '.mov'
      : '.mp4';
    const uniqueName = `media_${Date.now()}_${Math.random().toString(36).substring(2, 8)}${safeExt}`;
    cb(null, uniqueName);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 300 * 1024 * 1024 }, // 300MB per video file
});

// 1. Real-time Server-Sent Events (SSE) Stream
router.get('/stream', (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no'); // Disable buffering for Nginx / Cloud Run proxies
  res.flushHeaders?.();

  registerSseClient(res);
});

// 2. Get authoritative state
router.get('/state', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: getSyncState(),
  });
});

// 3. Seed / bootstrap data from client on first load if server is empty
router.post('/seed', (req: Request, res: Response) => {
  try {
    const { posts, comments, messages, stories, users } = req.body;
    const currentState = getSyncState();
    const deletedIds = currentState.deletedPostIds || [];
    
    // Only seed if empty, and make sure deleted posts are never seeded
    if (currentState.posts.length === 0 && Array.isArray(posts) && posts.length > 0) {
      const filteredPosts = posts.filter((p: any) => !deletedIds.includes(p.id));
      initSyncStore({ posts: filteredPosts, comments, messages, stories, users });
    }
    res.json({ success: true, data: getSyncState() });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3.5. Get Posts (Direct REST endpoint for Android and Web)
router.get('/posts', (req: Request, res: Response) => {
  try {
    const currentState = getSyncState();
    res.json({ success: true, posts: currentState.posts });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Create Post
router.post('/posts', (req: Request, res: Response) => {
  try {
    const post = req.body;
    const authorId = post.authorId || post.author?.id;
    if (!post || !post.id || !authorId) {
      res.status(400).json({ success: false, error: '유효한 게시물 데이터가 필요합니다.' });
      return;
    }
    const normalizedPost = {
      ...post,
      authorId: authorId,
      authorName: post.authorName || post.author?.name || '회원',
      authorHandle: post.authorHandle || post.author?.handle || 'user',
      authorAvatar: post.authorAvatar || post.author?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200',
      authorVerified: post.authorVerified ?? post.author?.isVerified ?? false,
      likes: Array.isArray(post.likes) ? post.likes : [],
      commentsCount: post.commentsCount ?? 0,
      createdAt: post.createdAt || new Date().toISOString()
    };
    const created = syncCreatePost(normalizedPost);
    res.json({ success: true, post: created });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. Update Post
router.put('/posts/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const updated = syncUpdatePost(id, req.body);
    if (!updated) {
      res.status(404).json({ success: false, error: '게시물을 찾을 수 없습니다.' });
      return;
    }
    res.json({ success: true, post: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 6. Delete Post
router.delete('/posts/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const deleted = syncDeletePost(id);
    res.json({ success: deleted });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 7. Toggle Like on Post
router.put('/posts/:id/like', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId, userName, userAvatar } = req.body || {};
    if (!userId) {
      res.status(400).json({ success: false, error: 'userId가 필요합니다.' });
      return;
    }
    const post = syncToggleLike(id, userId, userName, userAvatar);
    res.json({ success: true, post });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 7-1. Toggle Bookmark
router.put('/posts/:id/bookmark', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;
    if (!userId) {
      res.status(400).json({ success: false, error: 'userId가 필요합니다.' });
      return;
    }
    const post = syncToggleBookmark(id, userId);
    res.json({ success: true, post });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 7-2. Clear all bookmarks for user
router.post('/bookmarks/clear', (req: Request, res: Response) => {
  try {
    const { userId } = req.body;
    if (!userId) {
      res.status(400).json({ success: false, error: 'userId가 필요합니다.' });
      return;
    }
    const posts = syncClearBookmarks(userId);
    res.json({ success: true, posts });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 8. Add Comment / Reply / Voice Comment
router.post('/posts/:id/comments', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const comment = req.body;
    const authorId = comment.authorId || comment.author?.id;
    if (!comment || !comment.id || !authorId) {
      res.status(400).json({ success: false, error: '댓글 작성자 정보가 필요합니다.' });
      return;
    }
    const normalizedComment = {
      ...comment,
      postId: id,
      authorId: authorId,
      authorName: comment.authorName || comment.author?.name || '회원',
      authorHandle: comment.authorHandle || comment.author?.handle || 'user',
      authorAvatar: comment.authorAvatar || comment.author?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200',
      likes: Array.isArray(comment.likes) ? comment.likes : [],
      createdAt: comment.createdAt || '방금 전'
    };
    const created = syncAddComment(normalizedComment);
    res.json({ success: true, comment: created });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 9. Toggle Comment Like
router.put('/comments/:id/like', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;
    if (!userId) {
      res.status(400).json({ success: false, error: 'userId가 필요합니다.' });
      return;
    }
    const comment = syncToggleCommentLike(id, userId);
    res.json({ success: true, comment });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 10. Send Direct Message
router.post('/messages', (req: Request, res: Response) => {
  try {
    const msg = req.body;
    if (!msg || !msg.id || !msg.senderId || !msg.receiverId) {
      res.status(400).json({ success: false, error: '유효한 메시지 정보가 필요합니다.' });
      return;
    }
    const sent = syncSendMessage(msg);
    res.json({ success: true, message: sent });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 10-1. Mark Messages as Read (Conversation or Specific Message)
router.post('/messages/read', (req: Request, res: Response) => {
  try {
    const { partnerId, userId, messageId } = req.body;
    if (messageId) {
      const result = syncMarkMessageAsRead(messageId, userId);
      res.json({ success: true, ...result });
      return;
    }
    if (!partnerId) {
      res.status(400).json({ success: false, error: 'partnerId 또는 messageId가 필요합니다.' });
      return;
    }
    const result = syncMarkConversationAsRead(partnerId, userId);
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 10-2. Mark Specific Message as Read (PUT)
router.put('/messages/:id/read', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { userId } = req.body || {};
    const result = syncMarkMessageAsRead(id, userId);
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 10-3. Mark All Messages as Read for User
router.post('/messages/read-all', (req: Request, res: Response) => {
  try {
    const { userId } = req.body;
    if (!userId) {
      res.status(400).json({ success: false, error: 'userId가 필요합니다.' });
      return;
    }
    const result = syncMarkAllMessagesAsRead(userId);
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 10-4. Toggle Star on Message
router.post('/messages/:id/star', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const result = syncToggleStarMessage(id);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 11. Create Story
router.post('/stories', (req: Request, res: Response) => {
  try {
    const story = req.body;
    if (!story || !story.userId) {
      res.status(400).json({ success: false, error: '스토리 정보가 필요합니다.' });
      return;
    }
    const created = syncCreateStory(story);
    res.json({ success: true, story: created });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 12. Update User Profile
router.put('/users/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const updated = syncUpdateUser(id, req.body);
    res.json({ success: true, user: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

function getClientIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  let ip = '';
  if (typeof forwarded === 'string') {
    ip = forwarded.split(',')[0].trim();
  } else if (Array.isArray(forwarded) && forwarded.length > 0) {
    ip = forwarded[0].trim();
  }
  if (!ip) {
    ip = (req.headers['x-real-ip'] as string) || req.socket?.remoteAddress || req.ip || '';
  }
  if (ip.startsWith('::ffff:')) {
    ip = ip.replace('::ffff:', '');
  }
  if (ip === '::1' || ip === '127.0.0.1') {
    ip = '127.0.0.1';
  }
  return ip || '127.0.0.1';
}

// 12.5 Get Client IP
router.get('/client-ip', (req: Request, res: Response) => {
  res.json({ success: true, ip: getClientIp(req) });
});

// 13. Register User
router.post('/users/signup', (req: Request, res: Response) => {
  try {
    const user = req.body;
    if (!user || !user.handle) {
      res.status(400).json({ success: false, error: '사용자 정보가 필요합니다.' });
      return;
    }
    const detectedIp = getClientIp(req);
    user.signupIp = user.signupIp || detectedIp;
    const created = syncAddUser(user);
    res.json({ success: true, user: created, detectedIp });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 14. Kick User (Force Delete & Record Reason)
router.post('/users/:id/kick', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { reason, adminName, userData, userPosts } = req.body || {};
    const result = syncKickUser(id, reason, adminName, userData, userPosts);
    if (!result) {
      res.status(404).json({ success: false, error: '해당 회원을 찾을 수 없습니다.' });
      return;
    }
    res.json({ success: true, kickedRecord: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 14.5. Restore Kicked User
router.post('/users/:id/restore', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { restoredUser, userPosts } = req.body || {};
    const result = syncRestoreUser(id, restoredUser, userPosts);
    if (!result.success) {
      res.status(404).json(result);
      return;
    }
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 15. Toggle Ban User
router.post('/users/:id/ban', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    const user = syncToggleBanUser(id, reason);
    if (!user) {
      res.status(404).json({ success: false, error: '해당 회원을 찾을 수 없습니다.' });
      return;
    }
    res.json({ success: true, user });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 16. Add Notification
router.post('/notifications', (req: Request, res: Response) => {
  try {
    const notif = req.body;
    if (!notif || !notif.recipientId) {
      res.status(400).json({ success: false, error: '알림 정보가 올바르지 않습니다.' });
      return;
    }
    const created = syncAddNotification(notif);
    res.json({ success: true, notification: created });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 17. Toggle Follow User
router.post('/users/:id/follow', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { currentUserId, currentUser, targetName, targetHandle } = req.body || {};
    if (!id || !currentUserId) {
      res.status(400).json({ success: false, error: 'targetUserId와 currentUserId가 필요합니다.' });
      return;
    }
    const result = syncToggleFollow(currentUserId, id, currentUser, targetName, targetHandle);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 17.5. Media Sync Endpoint (Instant cross-device video availability)
router.post('/media-sync', (req: Request, res: Response) => {
  try {
    const { postId, videoUrls, thumbnailUrl, authorId } = req.body;
    if (!postId || !Array.isArray(videoUrls) || videoUrls.length === 0) {
      res.status(400).json({ success: false, error: 'postId와 videoUrls 배열이 필요합니다.' });
      return;
    }
    const updated = syncMediaPost(postId, videoUrls, thumbnailUrl, authorId);
    res.json({ success: true, post: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 18. Multi-Device Media Upload Endpoint (Multipart FormData)
router.post('/upload', upload.array('files', 10), async (req: Request, res: Response) => {
  try {
    const files = req.files as Express.Multer.File[];
    if (!files || files.length === 0) {
      res.status(400).json({ success: false, error: '업로드할 파일이 없습니다.' });
      return;
    }

    const processedFiles: any[] = [];
    const urls: string[] = [];

    for (const f of files) {
      const p = path.join(uploadsDir, f.filename);
      const isVideo = /\.(mp4|mov|m4v|webm|mkv|avi|3gp)$/i.test(f.filename) || (f.mimetype && f.mimetype.startsWith('video/'));

      if (isVideo) {
        const opt = await optimizeVideoForStreaming(p);
        const stat = fs.existsSync(opt.filePath) ? fs.statSync(opt.filePath) : null;
        const fileUrl = `/uploads/${opt.filename}`;
        const thumbUrl = opt.thumbnail ? `/uploads/${opt.thumbnail}` : undefined;
        urls.push(fileUrl);
        processedFiles.push({
          url: fileUrl,
          thumbnail: thumbUrl,
          filename: opt.filename,
          size: stat ? stat.size : f.size,
          mimetype: 'video/mp4',
        });
      } else {
        const fileUrl = `/uploads/${f.filename}`;
        urls.push(fileUrl);
        processedFiles.push({
          url: fileUrl,
          filename: f.filename,
          size: f.size,
          mimetype: f.mimetype,
        });
      }
    }

    res.json({
      success: true,
      urls,
      files: processedFiles,
    });
  } catch (err: any) {
    console.error('[UploadError]', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

export interface VideoOptimizationResult {
  filePath: string;
  filename: string;
  thumbnail?: string;
  duration?: number;
}

/**
 * Optimizes, faststarts, and standardizes video files for 100% universal Web & Android playback.
 * 1. Probes video codec and audio stream with ffprobe.
 * 2. If already H.264 + AAC (yuv420p), applies faststart (+faststart) without re-encoding in ~100ms.
 * 3. If HEVC/H.265 (common in modern iPhone/Android 4K), VP9, ProRes, or non-yuv420p profile,
 *    transcodes with libx264 (yuv420p) + aac so that it plays smoothly on all browsers without stalling.
 * 4. Extracts a crisp, lightweight JPG video thumbnail at 1.0s.
 * 5. Supports videos of ANY length (10s, 30s, 60s+) and large file sizes without 10s timeout failure.
 */
function optimizeVideoForStreaming(filePath: string): Promise<VideoOptimizationResult> {
  const filename = path.basename(filePath);
  const defaultResult: VideoOptimizationResult = { filePath, filename };

  return new Promise((resolve) => {
    try {
      if (!fs.existsSync(filePath)) {
        resolve(defaultResult);
        return;
      }

      const ext = path.extname(filePath).toLowerCase();
      const isVideo = ['.mp4', '.mov', '.m4v', '.webm', '.mkv', '.avi', '.3gp'].includes(ext);
      if (!isVideo) {
        resolve(defaultResult);
        return;
      }

      // Check probe with ffprobe (timeout 15s, buffer 10MB)
      exec(
        `ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,pix_fmt,duration,width,height -of json "${filePath}"`,
        { timeout: 15000, maxBuffer: 10 * 1024 * 1024 },
        (probeErr, stdout) => {
          let needsTranscode = false;
          let duration = 0;

          if (!probeErr && stdout) {
            try {
              const probeData = JSON.parse(stdout);
              const vStream = probeData.streams?.[0];
              if (vStream) {
                const codec = (vStream.codec_name || '').toLowerCase();
                const pixFmt = (vStream.pix_fmt || '').toLowerCase();
                duration = parseFloat(vStream.duration) || 0;

                // Needs transcode if not standard H.264 or not standard 8-bit yuv420p
                if (codec !== 'h264' || !pixFmt.startsWith('yuv420p')) {
                  needsTranscode = true;
                }
              }
            } catch {
              needsTranscode = true;
            }
          } else {
            if (ext !== '.mp4') {
              needsTranscode = true;
            }
          }

          const baseNameWithoutExt = filename.replace(/\.[^/.]+$/, '');
          const finalFilename = `${baseNameWithoutExt}.mp4`;
          const finalFilePath = path.join(uploadsDir, finalFilename);
          const tempPath = path.join(uploadsDir, `${baseNameWithoutExt}_opt.tmp.mp4`);
          const thumbFilename = `thumb_${baseNameWithoutExt}.jpg`;
          const thumbPath = path.join(uploadsDir, thumbFilename);

          const generateThumbnail = () => {
            const actualPath =
              fs.existsSync(finalFilePath) && fs.statSync(finalFilePath).size > 0
                ? finalFilePath
                : fs.existsSync(filePath) && fs.statSync(filePath).size > 0
                ? filePath
                : null;

            const actualFilename = actualPath ? path.basename(actualPath) : finalFilename;

            if (!actualPath) {
              resolve(defaultResult);
              return;
            }

            try {
              if (!fs.existsSync(thumbPath)) {
                exec(
                  `ffmpeg -y -ss 00:00:00.500 -i "${actualPath}" -vframes 1 -q:v 2 "${thumbPath}"`,
                  { timeout: 15000, maxBuffer: 10 * 1024 * 1024 },
                  () => {
                    const hasThumb = fs.existsSync(thumbPath) && fs.statSync(thumbPath).size > 0;
                    resolve({
                      filePath: actualPath,
                      filename: actualFilename,
                      thumbnail: hasThumb ? thumbFilename : undefined,
                      duration: duration || undefined,
                    });
                  }
                );
                return;
              }
            } catch {}
            const hasThumb = fs.existsSync(thumbPath) && fs.statSync(thumbPath).size > 0;
            resolve({
              filePath: actualPath,
              filename: actualFilename,
              thumbnail: hasThumb ? thumbFilename : undefined,
              duration: duration || undefined,
            });
          };

          const runTranscode = () => {
            // High compatibility H.264 (yuv420p) + AAC with faststart, ultrafast preset, CRF 23, 3-min timeout, 50MB maxBuffer
            const cmd = `ffmpeg -y -i "${filePath}" -c:v libx264 -preset ultrafast -crf 23 -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart "${tempPath}"`;
            exec(cmd, { timeout: 180000, maxBuffer: 50 * 1024 * 1024 }, (transcodeErr) => {
              if (!transcodeErr && fs.existsSync(tempPath) && fs.statSync(tempPath).size > 0) {
                try {
                  if (fs.existsSync(finalFilePath) && finalFilePath !== filePath) {
                    fs.unlinkSync(finalFilePath);
                  }
                  fs.renameSync(tempPath, finalFilePath);
                  if (finalFilePath !== filePath && fs.existsSync(filePath)) {
                    try { fs.unlinkSync(filePath); } catch {}
                  }
                } catch {}
              } else {
                try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch {}
              }
              generateThumbnail();
            });
          };

          if (needsTranscode) {
            runTranscode();
          } else {
            // Fast remux: Copy stream and relocate moov atom to beginning (+faststart)
            const fastCmd = `ffmpeg -y -i "${filePath}" -c copy -movflags +faststart "${tempPath}"`;
            exec(fastCmd, { timeout: 60000, maxBuffer: 20 * 1024 * 1024 }, (remuxErr) => {
              if (!remuxErr && fs.existsSync(tempPath) && fs.statSync(tempPath).size > 0) {
                try {
                  if (fs.existsSync(finalFilePath) && finalFilePath !== filePath) {
                    fs.unlinkSync(finalFilePath);
                  }
                  fs.renameSync(tempPath, finalFilePath);
                  if (finalFilePath !== filePath && fs.existsSync(filePath)) {
                    try { fs.unlinkSync(filePath); } catch {}
                  }
                  generateThumbnail();
                } catch {
                  runTranscode();
                }
              } else {
                try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch {}
                // If fast copy failed, fallback to transcode
                runTranscode();
              }
            });
          }
        }
      );
    } catch {
      resolve(defaultResult);
    }
  });
}

// 19. Multi-Device Media Upload Endpoint (Base64 Fallback)
router.post('/upload-base64', async (req: Request, res: Response) => {
  try {
    const { name, type, data } = req.body;
    if (!data) {
      res.status(400).json({ success: false, error: '업로드할 데이터가 없습니다.' });
      return;
    }

    const rawExt = path.extname(name || '');
    const safeExt = rawExt
      ? rawExt.toLowerCase()
      : type?.includes('webm')
      ? '.webm'
      : type?.includes('quicktime')
      ? '.mov'
      : '.mp4';
    const filename = `media_${Date.now()}_${Math.random().toString(36).substring(2, 8)}${safeExt}`;
    const targetPath = path.join(uploadsDir, filename);

    const base64Data = data.replace(/^data:[^;]+;base64,/, '');
    fs.writeFileSync(targetPath, Buffer.from(base64Data, 'base64'));

    // Optimize video faststart & universal codec for instant streaming
    const optResult = await optimizeVideoForStreaming(targetPath);

    res.json({
      success: true,
      url: `/uploads/${optResult.filename}`,
      thumbnail: optResult.thumbnail ? `/uploads/${optResult.thumbnail}` : undefined,
      filename: optResult.filename,
    });
  } catch (err: any) {
    console.error('[UploadBase64Error]', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 20. Resumable Chunked Video/Media Upload Endpoint (Supports Sequential Chunks from Android Native)
router.post('/upload-chunk', upload.single('chunk'), async (req: Request, res: Response) => {
  try {
    const uploadId = (req.body.uploadId || '').replace(/[^a-zA-Z0-9_-]/g, '');
    const chunkIndex = parseInt(req.body.chunkIndex, 10);
    const totalChunks = parseInt(req.body.totalChunks, 10);
    const fileName = req.body.fileName || 'video.mp4';
    const chunkFile = req.file;
    const chunkBase64 = req.body.chunkBase64;

    if (!uploadId || isNaN(chunkIndex) || isNaN(totalChunks)) {
      res.status(400).json({ success: false, error: 'uploadId, chunkIndex, totalChunks가 올바르지 않습니다.' });
      return;
    }

    const tempDir = path.join(uploadsDir, 'temp', uploadId);
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }

    const chunkPath = path.join(tempDir, `chunk_${chunkIndex}`);

    if (chunkFile && fs.existsSync(chunkFile.path)) {
      try {
        fs.renameSync(chunkFile.path, chunkPath);
      } catch {
        fs.copyFileSync(chunkFile.path, chunkPath);
        try { fs.unlinkSync(chunkFile.path); } catch {}
      }
    } else if (chunkBase64) {
      const cleanBase64 = chunkBase64.replace(/^data:[^;]+;base64,/, '');
      fs.writeFileSync(chunkPath, Buffer.from(cleanBase64, 'base64'));
    } else {
      res.status(400).json({ success: false, error: '청크 데이터가 전달되지 않았습니다.' });
      return;
    }

    // Check if all chunks (0 to totalChunks - 1) have arrived
    let allChunksPresent = true;
    for (let i = 0; i < totalChunks; i++) {
      if (!fs.existsSync(path.join(tempDir, `chunk_${i}`))) {
        allChunksPresent = false;
        break;
      }
    }

    if (!allChunksPresent) {
      res.json({
        success: true,
        completed: false,
        uploadId,
        receivedChunk: chunkIndex,
        totalChunks,
      });
      return;
    }

    // All chunks present: assemble them synchronously to avoid memory buffer exhaustion on large files
    const ext = path.extname(fileName) || '.mp4';
    const finalFilename = `video_${Date.now()}_${Math.random().toString(36).substring(2, 8)}${ext.toLowerCase()}`;
    const finalPath = path.join(uploadsDir, finalFilename);

    try {
      if (fs.existsSync(finalPath)) {
        fs.unlinkSync(finalPath);
      }
      for (let i = 0; i < totalChunks; i++) {
        const p = path.join(tempDir, `chunk_${i}`);
        if (fs.existsSync(p)) {
          const chunkBuf = fs.readFileSync(p);
          fs.appendFileSync(finalPath, chunkBuf);
        }
      }
    } catch (assembleErr: any) {
      console.error('[ChunkAssembleError]', assembleErr);
      res.status(500).json({ success: false, error: '동영상 청크 병합 중 오류가 발생했습니다.' });
      return;
    }

    // Clean up temporary chunks
    try {
      for (let i = 0; i < totalChunks; i++) {
        const p = path.join(tempDir, `chunk_${i}`);
        if (fs.existsSync(p)) fs.unlinkSync(p);
      }
      fs.rmdirSync(tempDir);
    } catch (cleanupErr) {
      console.warn('[ChunkCleanupWarn]', cleanupErr);
    }

    // Optimize assembled video with faststart & universal codec
    const optResult = await optimizeVideoForStreaming(finalPath);

    res.json({
      success: true,
      completed: true,
      uploadId,
      url: `/uploads/${optResult.filename}`,
      thumbnail: optResult.thumbnail ? `/uploads/${optResult.thumbnail}` : undefined,
      filename: optResult.filename,
    });
  } catch (err: any) {
    console.error('[UploadChunkError]', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
