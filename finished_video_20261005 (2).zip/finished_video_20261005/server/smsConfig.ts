import fs from 'fs';
import path from 'path';

export type SmsProviderType =
  | 'CoolSMS'
  | 'Aligo'
  | 'Twilio'
  | 'NaverSENS'
  | 'Custom'
  | 'DirectSMS'
  | 'Manual_Admin_Input'
  | 'Sandbox';

export interface SmsApiConfig {
  provider: SmsProviderType;
  enabled: boolean;
  senderNumber: string;
  // CoolSMS (Solapi)
  coolsmsApiKey?: string;
  coolsmsApiSecret?: string;
  // Aligo (알리고)
  aligoApiKey?: string;
  aligoUserId?: string;
  // Twilio
  twilioAccountSid?: string;
  twilioAuthToken?: string;
  // Naver Cloud SENS
  naverAccessKey?: string;
  naverSecretKey?: string;
  naverServiceId?: string;
  // Custom API
  customApiUrl?: string;
  customAuthHeader?: string;
  // SMS Template & Security
  smsTemplate: string;
  codeExpirationMinutes: number;
  maxAttempts: number;
  testMode: boolean;
  updatedAt?: string;
  updatedBy?: string;
}

const CONFIG_DIR = path.resolve(process.cwd(), 'data');
const CONFIG_FILE = path.join(CONFIG_DIR, 'sms_api_config.json');

const DEFAULT_SMS_CONFIG: SmsApiConfig = {
  provider: (process.env.COOLSMS_API_KEY ? 'CoolSMS' : process.env.TWILIO_ACCOUNT_SID ? 'Twilio' : 'CoolSMS') as SmsProviderType,
  enabled: true,
  senderNumber: process.env.COOLSMS_SENDER_NUMBER || process.env.TWILIO_PHONE_NUMBER || '010-1234-5678',
  coolsmsApiKey: process.env.COOLSMS_API_KEY || '',
  coolsmsApiSecret: process.env.COOLSMS_API_SECRET || '',
  aligoApiKey: '',
  aligoUserId: '',
  twilioAccountSid: process.env.TWILIO_ACCOUNT_SID || '',
  twilioAuthToken: process.env.TWILIO_AUTH_TOKEN || '',
  naverAccessKey: '',
  naverSecretKey: '',
  naverServiceId: '',
  customApiUrl: '',
  customAuthHeader: '',
  smsTemplate: '[마음(Maeum)] 본인확인 인증번호 [{code}]를 3분 이내에 입력해주세요. (타인 노출 금지)',
  codeExpirationMinutes: 3,
  maxAttempts: 5,
  testMode: !(process.env.COOLSMS_API_KEY || process.env.TWILIO_ACCOUNT_SID),
  updatedAt: new Date().toISOString(),
  updatedBy: '시스템 관리자',
};

let inMemoryConfig: SmsApiConfig = { ...DEFAULT_SMS_CONFIG };
let lastConfigFileMtime = 0;

/**
 * Initialize SMS API Config from file or create if missing
 */
export function initSmsApiConfig(): SmsApiConfig {
  try {
    if (!fs.existsSync(CONFIG_DIR)) {
      fs.mkdirSync(CONFIG_DIR, { recursive: true });
    }

    if (fs.existsSync(CONFIG_FILE)) {
      const stats = fs.statSync(CONFIG_FILE);
      lastConfigFileMtime = stats.mtimeMs;
      const data = fs.readFileSync(CONFIG_FILE, 'utf-8');
      const parsed = JSON.parse(data);
      inMemoryConfig = { ...DEFAULT_SMS_CONFIG, ...parsed };
    } else {
      inMemoryConfig = { ...DEFAULT_SMS_CONFIG };
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(inMemoryConfig, null, 2), 'utf-8');
      const stats = fs.statSync(CONFIG_FILE);
      lastConfigFileMtime = stats.mtimeMs;
    }
  } catch (err) {
    console.error('Failed to load sms_api_config.json:', err);
    inMemoryConfig = { ...DEFAULT_SMS_CONFIG };
  }
  return inMemoryConfig;
}

/**
 * Get raw unmasked SMS API config for server dispatch
 */
export function getRawSmsApiConfig(): SmsApiConfig {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const stats = fs.statSync(CONFIG_FILE);
      if (stats.mtimeMs !== lastConfigFileMtime) {
        lastConfigFileMtime = stats.mtimeMs;
        const data = fs.readFileSync(CONFIG_FILE, 'utf-8');
        const parsed = JSON.parse(data);
        inMemoryConfig = { ...DEFAULT_SMS_CONFIG, ...parsed };
      }
    } else {
      initSmsApiConfig();
    }
  } catch {
    // fallback to current in-memory config
  }
  return inMemoryConfig;
}

/**
 * Mask a secret string, leaving first 2 and last 2 characters visible
 */
function maskSecret(val?: string): string {
  if (!val || val.length === 0) return '';
  if (val.length <= 4) return '••••';
  return `${val.slice(0, 2)}${'•'.repeat(Math.min(8, val.length - 4))}${val.slice(-2)}`;
}

/**
 * Get masked SMS API config safe for admin UI
 */
export function getMaskedSmsApiConfig(): SmsApiConfig & { hasCredentials: boolean } {
  const raw = getRawSmsApiConfig();
  const hasCreds = Boolean(
    (raw.provider === 'CoolSMS' && raw.coolsmsApiKey && raw.coolsmsApiSecret) ||
    (raw.provider === 'Aligo' && raw.aligoApiKey && raw.aligoUserId) ||
    (raw.provider === 'Twilio' && raw.twilioAccountSid && raw.twilioAuthToken) ||
    (raw.provider === 'NaverSENS' && raw.naverAccessKey && raw.naverSecretKey && raw.naverServiceId) ||
    (raw.provider === 'Custom' && raw.customApiUrl) ||
    raw.provider === 'Sandbox'
  );

  return {
    ...raw,
    coolsmsApiSecret: raw.coolsmsApiSecret ? maskSecret(raw.coolsmsApiSecret) : '',
    aligoApiKey: raw.aligoApiKey ? maskSecret(raw.aligoApiKey) : '',
    twilioAuthToken: raw.twilioAuthToken ? maskSecret(raw.twilioAuthToken) : '',
    naverSecretKey: raw.naverSecretKey ? maskSecret(raw.naverSecretKey) : '',
    customAuthHeader: raw.customAuthHeader ? maskSecret(raw.customAuthHeader) : '',
    hasCredentials: hasCreds,
  };
}

/**
 * Save updated SMS API config to persistent file
 */
export function updateSmsApiConfig(newValues: Partial<SmsApiConfig>, updatedBy = '관리자'): SmsApiConfig {
  const current = getRawSmsApiConfig();

  // If a masked secret (starts with • or contains bullets) was sent back, retain existing secret
  const preserveIfMasked = (incoming?: string, original?: string): string => {
    if (incoming === undefined) return original || '';
    if (incoming.includes('•')) return original || '';
    return incoming.trim();
  };

  const updated: SmsApiConfig = {
    ...current,
    ...newValues,
    coolsmsApiKey: newValues.coolsmsApiKey !== undefined ? newValues.coolsmsApiKey.trim() : current.coolsmsApiKey,
    coolsmsApiSecret: preserveIfMasked(newValues.coolsmsApiSecret, current.coolsmsApiSecret),
    aligoApiKey: preserveIfMasked(newValues.aligoApiKey, current.aligoApiKey),
    aligoUserId: newValues.aligoUserId !== undefined ? newValues.aligoUserId.trim() : current.aligoUserId,
    twilioAccountSid: newValues.twilioAccountSid !== undefined ? newValues.twilioAccountSid.trim() : current.twilioAccountSid,
    twilioAuthToken: preserveIfMasked(newValues.twilioAuthToken, current.twilioAuthToken),
    naverAccessKey: newValues.naverAccessKey !== undefined ? newValues.naverAccessKey.trim() : current.naverAccessKey,
    naverSecretKey: preserveIfMasked(newValues.naverSecretKey, current.naverSecretKey),
    naverServiceId: newValues.naverServiceId !== undefined ? newValues.naverServiceId.trim() : current.naverServiceId,
    customApiUrl: newValues.customApiUrl !== undefined ? newValues.customApiUrl.trim() : current.customApiUrl,
    customAuthHeader: preserveIfMasked(newValues.customAuthHeader, current.customAuthHeader),
    senderNumber: newValues.senderNumber !== undefined ? newValues.senderNumber.trim() : current.senderNumber,
    smsTemplate: newValues.smsTemplate || current.smsTemplate,
    codeExpirationMinutes: Number(newValues.codeExpirationMinutes) || current.codeExpirationMinutes,
    maxAttempts: Number(newValues.maxAttempts) || current.maxAttempts,
    testMode: newValues.testMode !== undefined ? Boolean(newValues.testMode) : current.testMode,
    updatedAt: new Date().toISOString(),
    updatedBy: updatedBy || current.updatedBy,
  };

  inMemoryConfig = updated;

  try {
    if (!fs.existsSync(CONFIG_DIR)) {
      fs.mkdirSync(CONFIG_DIR, { recursive: true });
    }
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(inMemoryConfig, null, 2), 'utf-8');
    console.log(`[SMS Config] Configuration updated by ${updatedBy} (Provider: ${updated.provider})`);
  } catch (err) {
    console.error('Failed to write sms_api_config.json:', err);
  }

  return inMemoryConfig;
}

/**
 * Reset SMS API config back to defaults
 */
export function resetSmsApiConfig(): SmsApiConfig {
  inMemoryConfig = {
    ...DEFAULT_SMS_CONFIG,
    updatedAt: new Date().toISOString(),
    updatedBy: '시스템 관리자 (초기화)',
  };

  try {
    if (!fs.existsSync(CONFIG_DIR)) {
      fs.mkdirSync(CONFIG_DIR, { recursive: true });
    }
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(inMemoryConfig, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to reset sms_api_config.json:', err);
  }

  return inMemoryConfig;
}
