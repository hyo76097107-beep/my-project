#!/bin/bash
set -e

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
if [ -z "$JAVA_HOME" ] || [ ! -x "$JAVA_HOME/bin/java" ]; then
  if [ -x "/usr/bin/java" ]; then
    export JAVA_HOME="/usr"
  fi
fi
export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-/opt/android-sdk}"

echo "🚀 [마음 소셜] Android 디버그 APK (테스트 설치용) 빌드를 시작합니다..."
chmod +x ./gradlew
./gradlew clean --no-daemon --console=plain
./gradlew assembleDebug --stacktrace --no-daemon --console=plain

echo "✅ 디버그 APK 빌드가 성공적으로 완료되었습니다!"
echo "📦 생성 위치: app/build/outputs/apk/debug/app-debug.apk"
echo "📲 연결된 디바이스나 에뮬레이터에 설치하려면:"
echo "   adb install -r app/build/outputs/apk/debug/app-debug.apk"
