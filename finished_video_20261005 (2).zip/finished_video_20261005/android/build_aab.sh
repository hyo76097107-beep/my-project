#!/bin/bash
set -e

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
if [ -d "/usr/lib/jvm/java-17-openjdk-amd64" ]; then
  export JAVA_HOME="/usr/lib/jvm/java-17-openjdk-amd64"
elif [ -z "$JAVA_HOME" ] || [ ! -x "$JAVA_HOME/bin/java" ]; then
  if [ -x "/usr/bin/java" ]; then
    export JAVA_HOME="/usr"
  fi
fi
export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-/opt/android-sdk}"

echo "🚀 [마음 소셜] Google Play 배포용 AAB (Android App Bundle) 빌드를 시작합니다..."
chmod +x ./gradlew
./gradlew clean --no-daemon --console=plain
./gradlew bundleRelease --stacktrace --no-daemon --console=plain

echo "✅ AAB 빌드가 성공적으로 완료되었습니다!"
echo "📦 생성 위치: app/build/outputs/bundle/release/app-release.aab"
