package com.maeum.social.data

import com.maeum.social.model.Comment
import com.maeum.social.model.DirectMessage
import com.maeum.social.model.Conversation
import com.maeum.social.model.Post
import com.maeum.social.model.RegionalScope
import com.maeum.social.model.Story
import com.maeum.social.model.User

object MockData {
    const val DEFAULT_SILHOUETTE_AVATAR =
        "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80"

    val ALL_INTERESTS = listOf(
        "인공지능", "모바일", "가전", "프로그래밍", "과학 이슈",
        "영화", "드라마", "방송", "음악/K-POP", "웹툰/만화",
        "책/독서", "요리/맛집", "반려동물", "여행/캠핑", "인테리어/반셀프",
        "반려식물", "트렌드 패션", "화장품", "스킨케어", "쇼핑 할인 혜택",
        "주식", "부동산", "가상화폐", "금융/저축", "창업/부업",
        "축구", "야구", "골프", "헬스/피트니스", "등산",
        "러닝/마라톤", "격투", "미술", "사진", "악기",
        "공예", "공연/전시", "외국어", "직무 역량", "자격증", "취업/이직"
    )

    val currentUser = User(
        id = "user_me",
        name = "김마음",
        handle = "maeum_kim",
        avatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
        bio = "일상의 따뜻한 순간들과 기술 이야기를 공유합니다 ✨",
        location = "서울 강남구 역삼동",
        role = "프론트엔드 & 안드로이드 엔지니어",
        interests = listOf("인공지능", "모바일", "프로그래밍", "여행/캠핑")
    )

    val adminUser = User(
        id = "user_admin",
        name = "마음 관리자",
        handle = "admin_master",
        avatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80",
        bio = "마음 소셜 네트워크 시스템 관리자 계정입니다 🛡️",
        location = "서울 중구 태평로",
        role = "시스템 총괄 관리자",
        isAdmin = true,
        interests = listOf("인공지능", "모바일", "가상화폐")
    )

    val users = listOf(
        currentUser,
        User(
            id = "user_1",
            name = "이지은",
            handle = "jieun_film",
            avatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80",
            bio = "필름 사진 작가 📷 골목길의 햇살을 담습니다.",
            location = "서울 마포구 연남동",
            role = "포토그래퍼",
            interests = listOf("사진", "공연/전시", "책/독서")
        ),
        User(
            id = "user_2",
            name = "박서준",
            handle = "seojun_dev",
            avatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
            bio = "새로운 스타트업 창업 준비 중 🚀 커피와 코딩",
            location = "경기 성남시 판교동",
            role = "서비스 기획자",
            interests = listOf("창업/부업", "프로그래밍", "인공지능")
        ),
        adminUser
    )

    val PRESET_BGMS = listOf(
        com.maeum.social.model.StoryBgm(
            id = "bgm_lofi",
            title = "Late Night Coffee Lo-Fi",
            artist = "Maeum Relax Sound",
            genre = "☕ 로우파이/힐링",
            audioUrl = "https://cdn.freesound.org/previews/612/612610_5674468-lq.mp3",
            coverUrl = "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=300&auto=format&fit=crop&q=80",
            duration = 30,
            license = "100% 저작권 무료 (CC0)"
        ),
        com.maeum.social.model.StoryBgm(
            id = "bgm_acoustic",
            title = "Sunny Morning Melody",
            artist = "Acoustic Breeze",
            genre = "🎸 어쿠스틱",
            audioUrl = "https://cdn.freesound.org/previews/689/689363_11861866-lq.mp3",
            coverUrl = "https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=300&auto=format&fit=crop&q=80",
            duration = 30,
            license = "100% 저작권 무료 (CC0)"
        ),
        com.maeum.social.model.StoryBgm(
            id = "bgm_piano",
            title = "Sentimental Piano Journey",
            artist = "Calm Keys Studio",
            genre = "🎹 피아노",
            audioUrl = "https://cdn.freesound.org/previews/563/563721_11861866-lq.mp3",
            coverUrl = "https://images.unsplash.com/photo-1520523839898-5071282544e1?w=300&auto=format&fit=crop&q=80",
            duration = 30,
            license = "100% 저작권 무료 (CC0)"
        ),
        com.maeum.social.model.StoryBgm(
            id = "bgm_synth",
            title = "City Lights Dream",
            artist = "Neon Wave Project",
            genre = "🌃 시티팝/신스",
            audioUrl = "https://cdn.freesound.org/previews/648/648589_11861866-lq.mp3",
            coverUrl = "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&auto=format&fit=crop&q=80",
            duration = 30,
            license = "100% 저작권 무료 (CC0)"
        ),
        com.maeum.social.model.StoryBgm(
            id = "bgm_tropical",
            title = "Tropical Breeze Island",
            artist = "Sunny Isle Sound",
            genre = "🏝️ 트로피컬",
            audioUrl = "https://cdn.freesound.org/previews/522/522258_11861866-lq.mp3",
            coverUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&auto=format&fit=crop&q=80",
            duration = 30,
            license = "100% 저작권 무료 (CC0)"
        ),
        com.maeum.social.model.StoryBgm(
            id = "bgm_ambient",
            title = "Serene Forest Ambient",
            artist = "Nature Flow",
            genre = "🌿 앰비언트",
            audioUrl = "https://cdn.freesound.org/previews/587/587842_11861866-lq.mp3",
            coverUrl = "https://images.unsplash.com/photo-1448375240586-882707db888b?w=300&auto=format&fit=crop&q=80",
            duration = 30,
            license = "100% 저작권 무료 (CC0)"
        ),
        com.maeum.social.model.StoryBgm(
            id = "bgm_jazz",
            title = "Autumn Cafe Jazz",
            artist = "Bossa Nova Quartet",
            genre = "🎷 재즈/보사노바",
            audioUrl = "https://cdn.freesound.org/previews/612/612610_5674468-lq.mp3",
            coverUrl = "https://images.unsplash.com/photo-1511192336575-5a79af67a629?w=300&auto=format&fit=crop&q=80",
            duration = 30,
            license = "100% 저작권 무료 (CC0)"
        ),
        com.maeum.social.model.StoryBgm(
            id = "bgm_indie",
            title = "Warm Sunset Indie",
            artist = "Meadow Acoustic",
            genre = "🌾 인디 포크",
            audioUrl = "https://cdn.freesound.org/previews/689/689363_11861866-lq.mp3",
            coverUrl = "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop&q=80",
            duration = 30,
            license = "100% 저작권 무료 (CC0)"
        ),
        com.maeum.social.model.StoryBgm(
            id = "bgm_upbeat",
            title = "Positive Energetic Pop",
            artist = "Sparkle Joy Band",
            genre = "⚡ 업비트",
            audioUrl = "https://cdn.freesound.org/previews/522/522258_11861866-lq.mp3",
            coverUrl = "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=300&auto=format&fit=crop&q=80",
            duration = 30,
            license = "100% 저작권 무료 (CC0)"
        )
    )

    val initialStories = listOf(
        Story(
            id = "story_1",
            author = currentUser,
            mediaUrl = "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600&auto=format&fit=crop&q=80",
            caption = "오늘의 성수동 산책 🌿",
            bgm = PRESET_BGMS[0],
            createdAt = "1시간 전"
        ),
        Story(
            id = "story_2",
            author = users[1],
            mediaUrl = "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=600&auto=format&fit=crop&q=80",
            caption = "작업실 오후 빛",
            bgm = PRESET_BGMS[1],
            createdAt = "3시간 전"
        )
    )

    val initialPosts = listOf(
        Post(
            id = "post_1",
            author = users[1],
            content = "주말 아침, 따스한 햇볕 받으며 동네 카페에서 조용히 책 한 권 읽고 왔어요 ☕\n날씨가 너무 맑아서 기분까지 상쾌해지는 하루입니다.",
            photos = listOf(
                "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&auto=format&fit=crop&q=80"
            ),
            location = "서울 마포구 연남동",
            regionalScope = RegionalScope.NEIGHBORHOOD,
            feeling = "✨ 행복함",
            bgm = PRESET_BGMS[1],
            likesCount = 42,
            commentsCount = 3,
            isLiked = true,
            isBookmarked = false,
            createdAt = "2시간 전",
            comments = listOf(
                Comment(
                    id = "comm_1",
                    postId = "post_1",
                    author = users[2],
                    content = "사진 색감이 정말 따뜻하네요! 어디 카페인가요?",
                    createdAt = "1시간 전",
                    likesCount = 3,
                    isLiked = true
                ),
                Comment(
                    id = "comm_1_reply_1",
                    postId = "post_1",
                    author = users[1],
                    content = "@seojun_dev 연남동 골목에 있는 '카페 모퉁이'예요! 추천합니다 ㅎㅎ",
                    createdAt = "45분 전",
                    likesCount = 1,
                    isLiked = false,
                    parentId = "comm_1"
                ),
                Comment(
                    id = "comm_2_voice",
                    postId = "post_1",
                    author = currentUser,
                    content = "봄바람 소리와 함께 음성 응원 남깁니다! 🌸",
                    createdAt = "30분 전",
                    likesCount = 2,
                    isLiked = false,
                    audioUrl = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
                    audioDuration = 8
                )
            )
        ),
        Post(
            id = "post_2",
            author = users[2],
            content = "Android 16 Jetpack Compose로 마이그레이션하면서 느낀 점: 선언형 UI 구성 속도가 정말 놀랍네요! 부드러운 애니메이션과 뛰어난 퍼포먼스 만족스럽습니다 💻🚀",
            videoUrl = "https://assets.mixkit.co/videos/preview/mixkit-software-developer-working-on-code-42866-large.mp4",
            videoThumbnail = "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&auto=format&fit=crop&q=80",
            location = "경기 성남시 판교테크노밸리",
            regionalScope = RegionalScope.CITY,
            feeling = "🔥 열정 가득",
            poll = com.maeum.social.model.Poll(
                id = "poll_1",
                question = "가장 선호하는 프론트엔드/모바일 개발 도구는?",
                options = listOf(
                    com.maeum.social.model.PollOption(id = "opt_1", text = "Jetpack Compose (Android)", votes = listOf("user_1", "user_2")),
                    com.maeum.social.model.PollOption(id = "opt_2", text = "Flutter (Cross-platform)", votes = listOf("user_3")),
                    com.maeum.social.model.PollOption(id = "opt_3", text = "React / Next.js", votes = listOf("user_me")),
                    com.maeum.social.model.PollOption(id = "opt_4", text = "SwiftUI (iOS)", votes = emptyList())
                ),
                totalVotes = 4
            ),
            likesCount = 89,
            commentsCount = 2,
            isLiked = false,
            isBookmarked = true,
            createdAt = "4시간 전",
            comments = listOf(
                Comment(
                    id = "comm_3",
                    postId = "post_2",
                    author = currentUser,
                    content = "Jetpack Compose 코드가 정말 간결하고 유지보수가 편하죠! 저도 완전 동의합니다.",
                    createdAt = "3시간 전",
                    likesCount = 5,
                    isLiked = true
                ),
                Comment(
                    id = "comm_3_reply",
                    postId = "post_2",
                    author = users[2],
                    content = "@maeum_kim 맞아요! 특히 상태 관리 StateFlow와 궁합이 최고입니다.",
                    createdAt = "2시간 전",
                    likesCount = 2,
                    isLiked = false,
                    parentId = "comm_3"
                )
            )
        ),
        Post(
            id = "post_3",
            author = currentUser,
            content = "전국 크리에이터 여러분, 오늘 하루도 모두 수고 많으셨습니다! 마음 앱에서 전국의 소식과 따뜻한 일상을 전파합니다 ✨",
            photos = listOf(
                "https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&auto=format&fit=crop&q=80"
            ),
            location = "서울 강남구 역삼동",
            regionalScope = RegionalScope.ALL,
            feeling = "🥐 힐링",
            bgm = PRESET_BGMS[0],
            likesCount = 58,
            commentsCount = 1,
            isLiked = true,
            isBookmarked = false,
            createdAt = "어제",
            comments = listOf(
                Comment(
                    id = "comm_4",
                    postId = "post_3",
                    author = adminUser,
                    content = "따뜻한 커뮤니티를 위해 힘써주셔서 감사합니다! 마음을 전합니다 🛡️",
                    createdAt = "어제",
                    likesCount = 8,
                    isLiked = true
                )
            )
        )
    )

    val initialConversations = listOf(
        Conversation(
            id = "conv_1",
            participant = users[1],
            messages = listOf(
                DirectMessage(
                    id = "msg_1",
                    senderId = "user_1",
                    text = "안녕하세요 작가님! 지난번 포토북 전시 잘 보았습니다 :)",
                    timestamp = "오후 2:30"
                ),
                DirectMessage(
                    id = "msg_2",
                    senderId = "user_me",
                    text = "감사합니다 지은님! 다음 달에도 새로운 사진 전시 계획 중이에요.",
                    timestamp = "오후 2:35"
                )
            ),
            unreadCount = 0
        )
    )
}
