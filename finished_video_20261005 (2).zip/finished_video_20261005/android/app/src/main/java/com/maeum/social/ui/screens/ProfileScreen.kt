package com.maeum.social.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.maeum.social.viewmodel.SocialViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: SocialViewModel,
    onNavigateToEditInfo: () -> Unit = {}
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val posts by viewModel.posts.collectAsState()
    val myPosts = posts.filter { it.authorId == currentUser.id }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("프로필") },
                actions = {
                    IconButton(onClick = onNavigateToEditInfo) {
                        Icon(Icons.Default.Settings, contentDescription = "회원정보 수정")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = currentUser.avatar,
                            contentDescription = null,
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(currentUser.name, style = MaterialTheme.typography.titleLarge)
                        Text("@${currentUser.handle}", fontSize = 13.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFEEF2FF)
                        ) {
                            Text(
                                text = "📍 ${currentUser.location} (${currentUser.neighborhood})",
                                fontSize = 12.sp,
                                color = Color(0xFF4F46E5),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = currentUser.bio.ifEmpty { "마음(Maeum)에서 이웃들과 따뜻한 일상을 나눕니다 ✨" },
                            fontSize = 13.sp,
                            color = Color(0xFF334155)
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = onNavigateToEditInfo,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("회원가입 정보 및 3.주거지 수정", fontSize = 12.sp, color = Color(0xFF4F46E5))
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Stats
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(horizontalAlignment = Alignment.CenterVertically) {
                                Text("${myPosts.size}", style = MaterialTheme.typography.titleMedium)
                                Text("작성글", fontSize = 11.sp, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.CenterVertically) {
                                Text("${currentUser.followersCount}", style = MaterialTheme.typography.titleMedium)
                                Text("팔로워", fontSize = 11.sp, color = Color.Gray)
                            }
                            Column(horizontalAlignment = Alignment.CenterVertically) {
                                Text("${currentUser.followingCount}", style = MaterialTheme.typography.titleMedium)
                                Text("팔로잉", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }

            // Local Room DB & Storage Media Cache Cleaner Optimization Card
            item {
                val cacheSizeBytes by viewModel.mediaCacheSizeBytes.collectAsState()
                val lastCleanup by viewModel.lastCleanupResult.collectAsState()
                var isOptimizing by remember { mutableStateOf(false) }
                var showFeedback by remember { mutableStateOf(false) }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.CleaningServices,
                                    contentDescription = null,
                                    tint = Color(0xFF4F46E5),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("로컬 미디어 캐시 최적화", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }

                            val cacheSizeMb = cacheSizeBytes / (1024f * 1024f)
                            Text(
                                text = String.format(Locale.KOREAN, "%.1f MB", cacheSizeMb),
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "업로드 완료된 동영상 및 7일 이상 경과한 임시 캐시 파일과 DB 레코드를 자동으로 정리하여 저장 공간을 확보합니다.",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                isOptimizing = true
                                viewModel.optimizeMediaCache(retentionDays = 7L) {
                                    isOptimizing = false
                                    showFeedback = true
                                }
                            },
                            enabled = !isOptimizing,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                        ) {
                            if (isOptimizing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("캐시 최적화 정리 중...", fontSize = 12.sp)
                            } else {
                                Text("7일 경과 및 완료 캐시 지금 최적화", fontSize = 12.sp)
                            }
                        }

                        if (showFeedback && lastCleanup != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            val freedMb = (lastCleanup?.freedBytes ?: 0L) / (1024f * 1024f)
                            Text(
                                text = "✓ 정리 완료: DB 레코드 ${lastCleanup?.deletedDbRecords ?: 0}건, 파일 ${lastCleanup?.deletedFilesCount ?: 0}개 삭제 (${String.format(Locale.KOREAN, "%.1f MB", freedMb)} 확보)",
                                fontSize = 11.sp,
                                color = Color(0xFF16A34A),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            item {
                Text("내가 작성한 동네 소식 (${myPosts.size})", style = MaterialTheme.typography.titleMedium)
            }

            if (myPosts.isEmpty()) {
                item {
                    Text("아직 작성한 게시글이 없습니다.", color = Color.Gray, fontSize = 13.sp)
                }
            } else {
                items(myPosts) { post ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(post.content, style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(post.createdAt, fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}
