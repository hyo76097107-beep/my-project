package com.maeum.social.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.maeum.social.audio.VoiceRecorderHelper
import com.maeum.social.theme.PrimaryIndigo
import kotlinx.coroutines.delay

@Composable
fun VoiceCommentRecorder(
    onSendVoice: (audioUrl: String, duration: Int) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val recorderHelper = remember { VoiceRecorderHelper(context) }

    var isRecording by remember { mutableStateOf(false) }
    var recordedSeconds by remember { mutableIntStateOf(0) }
    var recordedAudioPath by remember { mutableStateOf<String?>(null) }
    var isPreviewPlaying by remember { mutableStateOf(false) }

    // Pulsing animation for active recording
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    // Recording timer
    LaunchedEffect(isRecording) {
        if (isRecording) {
            recordedSeconds = 0
            while (isRecording && recordedSeconds < 60) {
                delay(1000)
                recordedSeconds += 1
            }
            if (recordedSeconds >= 60) {
                // Auto stop at 60s
                val file = recorderHelper.stopRecording()
                isRecording = false
                recordedAudioPath = file?.absolutePath
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            recorderHelper.cancelRecording()
            recorderHelper.stopPlayback()
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFFF1F5F9),
        border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryIndigo.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isRecording) Color.Red.copy(alpha = alpha) else PrimaryIndigo)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRecording) "음성 녹음 중..." else if (recordedAudioPath != null) "녹음 완료 (미리듣기 가능)" else "마이크를 눌러 음성 녹음을 시작하세요",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isRecording) Color.Red else PrimaryIndigo
                    )
                }

                IconButton(
                    onClick = {
                        recorderHelper.cancelRecording()
                        onCancel()
                    },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "닫기",
                        tint = Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Timer & waveform mock
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White, RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = String.format("%02d:%02d / 01:00", recordedSeconds / 60, recordedSeconds % 60),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1E293B)
                )

                Spacer(modifier = Modifier.width(12.dp))

                // Waveform bars
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val heights = listOf(8, 14, 20, 12, 24, 18, 10, 16, 22, 14, 26, 12, 18, 8, 14, 20)
                    heights.forEachIndexed { index, h ->
                        val active = isRecording || isPreviewPlaying
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(if (active) (h * (if (index % 2 == 0) alpha else 1f)).dp else 6.dp)
                                .background(
                                    if (active) PrimaryIndigo else Color(0xFFCBD5E1),
                                    RoundedCornerShape(2.dp)
                                )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isRecording && recordedAudioPath == null) {
                    Button(
                        onClick = {
                            val file = recorderHelper.startRecording()
                            if (file != null) {
                                isRecording = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Outlined.Mic, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("녹음 시작", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (isRecording) {
                    Button(
                        onClick = {
                            val file = recorderHelper.stopRecording()
                            isRecording = false
                            recordedAudioPath = file?.absolutePath ?: "sample_audio.m4a"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("녹음 중지", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Preview playback
                    OutlinedButton(
                        onClick = {
                            if (isPreviewPlaying) {
                                recorderHelper.stopPlayback()
                                isPreviewPlaying = false
                            } else {
                                recordedAudioPath?.let { path ->
                                    isPreviewPlaying = true
                                    recorderHelper.playAudio(path) {
                                        isPreviewPlaying = false
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            if (isPreviewPlaying) Icons.Outlined.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isPreviewPlaying) "일시정지" else "미리듣기", fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            recordedAudioPath?.let { path ->
                                onSendVoice(path, recordedSeconds.coerceAtLeast(1))
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Outlined.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("음성 댓글 등록", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun VoiceBubblePlayer(
    audioUrl: String,
    durationSeconds: Int = 5
) {
    val context = LocalContext.current
    val recorderHelper = remember { VoiceRecorderHelper(context) }
    var isPlaying by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose {
            recorderHelper.stopPlayback()
        }
    }

    Surface(
        modifier = Modifier
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFFEEF2FF)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(PrimaryIndigo)
                    .clickable {
                        if (isPlaying) {
                            recorderHelper.stopPlayback()
                            isPlaying = false
                        } else {
                            isPlaying = true
                            recorderHelper.playAudio(audioUrl) {
                                isPlaying = false
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Outlined.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "정지" else "재생",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Soundwave bars
            Row(
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val heights = listOf(6, 12, 18, 10, 20, 14, 8, 16, 12, 6)
                heights.forEach { h ->
                    Box(
                        modifier = Modifier
                            .width(2.5.dp)
                            .height(h.dp)
                            .background(if (isPlaying) PrimaryIndigo else Color(0xFF94A3B8), RoundedCornerShape(1.dp))
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = "🎙️ 0:${String.format("%02d", durationSeconds)}",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = PrimaryIndigo
            )
        }
    }
}
