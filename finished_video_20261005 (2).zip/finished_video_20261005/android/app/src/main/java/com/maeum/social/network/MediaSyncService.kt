package com.maeum.social.network

import android.content.Context
import android.net.Uri
import android.util.Log
import com.google.gson.Gson
import com.maeum.social.data.local.AppDatabase
import com.maeum.social.data.local.PostEntity
import com.maeum.social.model.Post
import com.maeum.social.model.RegionalScope
import com.maeum.social.model.User
import com.maeum.social.model.VideoSyncEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Event emitted when media (video/photo) finishes uploading and is ready
 * for immediate playback across all client devices.
 */
data class MediaSyncEvent(
    val postId: String,
    val videoUrls: List<String>,
    val thumbnailUrl: String? = null,
    val authorId: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * MediaSyncService coordinates real-time synchronization between the central backend database
 * (Firestore / realtime social DB), Web application, and Android native apps.
 *
 * It provides:
 * 1. Persistent real-time bi-directional WebSocket connection (/ws/sync) with SSE fallback (/api/sync/stream)
 * 2. Instant notification and Room DB updates when videos finish background upload on any device
 * 3. Proactive video streaming pre-warming (pre-fetch range buffer) for zero-latency instant playback
 * 4. Cross-device synchronized video playback (play, pause, seek position)
 */
object MediaSyncService {

    private const val TAG = "MediaSyncService"

    private val gson = Gson()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // High-performance OkHttpClient with streaming timeouts
    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS) // No read timeout for persistent streaming
            .writeTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    private var appContext: Context? = null
    private var webSocket: WebSocket? = null
    private var sseCall: Call? = null
    private var isConnecting = false
    private var reconnectAttempt = 0

    // Flows for UI and ViewModel observation
    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _mediaSyncEvents = MutableSharedFlow<MediaSyncEvent>(replay = 1, extraBufferCapacity = 20)
    val mediaSyncEvents: SharedFlow<MediaSyncEvent> = _mediaSyncEvents.asSharedFlow()

    private val _videoPlaybackSyncFlow = MutableSharedFlow<VideoSyncEvent>(extraBufferCapacity = 20)
    val videoPlaybackSyncFlow: SharedFlow<VideoSyncEvent> = _videoPlaybackSyncFlow.asSharedFlow()

    private val _realtimePostsFlow = MutableSharedFlow<List<Post>>(replay = 1, extraBufferCapacity = 10)
    val realtimePostsFlow: SharedFlow<List<Post>> = _realtimePostsFlow.asSharedFlow()

    /**
     * Initializes the service with application context
     */
    fun initialize(context: Context) {
        if (appContext == null) {
            appContext = context.applicationContext
            connect()
        }
    }

    /**
     * Connects to the real-time sync stream (WebSocket primary with auto fallback)
     */
    @Synchronized
    fun connect() {
        if (isConnecting || _isConnected.value) return
        isConnecting = true

        scope.launch {
            try {
                appContext?.let { NetworkSyncManager.autoDetectBaseUrl(it) }
                val baseUrl = NetworkSyncManager.baseUrl.trimEnd('/')

                // 1. Establish WebSocket connection
                val wsUrl = if (baseUrl.startsWith("https://")) {
                    baseUrl.replace("https://", "wss://") + "/ws/sync"
                } else {
                    baseUrl.replace("http://", "ws://") + "/ws/sync"
                }

                Log.d(TAG, "Connecting to real-time WebSocket: $wsUrl")
                val request = Request.Builder().url(wsUrl).build()

                webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        Log.i(TAG, "Connected to real-time sync WebSocket!")
                        _isConnected.value = true
                        isConnecting = false
                        reconnectAttempt = 0

                        // Immediately fetch latest posts to ensure consistency and resume any pending offline uploads
                        scope.launch {
                            syncLatestPostsFromBackend()
                            appContext?.let { ctx ->
                                MediaUploadManager.resumePendingUploadQueues(ctx)
                            }
                        }
                    }

                    override fun onMessage(webSocket: WebSocket, text: String) {
                        handleIncomingSyncMessage(text)
                    }

                    override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                        webSocket.close(1000, null)
                    }

                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                        Log.d(TAG, "WebSocket closed: $reason ($code)")
                        _isConnected.value = false
                        isConnecting = false
                        scheduleReconnect()
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        Log.w(TAG, "WebSocket failure: ${t.message}. Falling back to SSE stream...")
                        _isConnected.value = false
                        isConnecting = false
                        startSseFallback()
                        scheduleReconnect()
                    }
                })

            } catch (e: Exception) {
                Log.e(TAG, "Failed to initiate connection: ${e.message}")
                isConnecting = false
                startSseFallback()
                scheduleReconnect()
            }
        }
    }

    /**
     * Fallback SSE (Server-Sent Events) listener if WebSocket is unavailable or blocked by proxy
     */
    private fun startSseFallback() {
        if (_isConnected.value) return
        sseCall?.cancel()

        scope.launch {
            try {
                val sseUrl = "${NetworkSyncManager.baseUrl.trimEnd('/')}/api/sync/stream"
                val request = Request.Builder()
                    .url(sseUrl)
                    .header("Accept", "text/event-stream")
                    .build()

                sseCall = okHttpClient.newCall(request)
                val response = sseCall?.execute()

                if (response != null && response.isSuccessful) {
                    _isConnected.value = true
                    Log.i(TAG, "Connected to real-time SSE stream: $sseUrl")
                    appContext?.let { ctx ->
                        scope.launch {
                            MediaUploadManager.resumePendingUploadQueues(ctx)
                        }
                    }
                    val source = response.body?.byteStream() ?: return@launch
                    val reader = BufferedReader(InputStreamReader(source))

                    var line: String?
                    var eventType = "message"

                    while (reader.readLine().also { line = it } != null) {
                        val currentLine = line ?: break
                        if (currentLine.startsWith("event:")) {
                            eventType = currentLine.substringAfter("event:").trim()
                        } else if (currentLine.startsWith("data:")) {
                            val data = currentLine.substringAfter("data:").trim()
                            if (eventType == "sync" || eventType == "message") {
                                handleIncomingSyncMessage(data)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "SSE fallback error: ${e.message}")
            } finally {
                _isConnected.value = false
            }
        }
    }

    /**
     * Parses and processes incoming synchronization messages from Web or other Android phones
     */
    private fun handleIncomingSyncMessage(jsonString: String) {
        try {
            val root = JSONObject(jsonString)
            val type = root.optString("type")
            val payload = root.optJSONObject("payload") ?: return

            when (type) {
                "MEDIA_SYNC" -> {
                    val postId = payload.optString("postId")
                    val videoUrlsArr = payload.optJSONArray("videoUrls")
                    val videoUrls = mutableListOf<String>()
                    if (videoUrlsArr != null) {
                        for (i in 0 until videoUrlsArr.length()) {
                            videoUrls.add(videoUrlsArr.getString(i))
                        }
                    }
                    val thumbnailUrl = payload.optString("videoThumbnail", null)
                    val authorId = payload.optString("authorId", null)

                    val syncEvent = MediaSyncEvent(
                        postId = postId,
                        videoUrls = videoUrls,
                        thumbnailUrl = thumbnailUrl,
                        authorId = authorId
                    )
                    scope.launch {
                        _mediaSyncEvents.emit(syncEvent)

                        // Immediately pre-warm the first video so it starts playback instantaneously
                        val firstVideo = videoUrls.firstOrNull()
                        if (!firstVideo.isNullOrBlank()) {
                            prewarmVideoMedia(firstVideo)
                        }

                        // Update local Room database
                        updatePostWithUploadedMediaInRoom(postId, videoUrls, thumbnailUrl)
                    }
                }

                "POST_CREATED", "POST_UPDATED" -> {
                    val postObj = payload.optJSONObject("post")
                    if (postObj != null) {
                        val post = parsePostFromJson(postObj)
                        scope.launch {
                            updateSinglePostInRoom(post)

                            // Pre-warm newly attached videos
                            post.videoUrls.firstOrNull()?.let { prewarmVideoMedia(it) }
                                ?: post.videoUrl?.let { prewarmVideoMedia(it) }
                        }
                    }

                    // Also refresh posts if full list was sent
                    val postsArr = payload.optJSONArray("posts")
                    if (postsArr != null) {
                        val postsList = mutableListOf<Post>()
                        for (i in 0 until postsArr.length()) {
                            postsList.add(parsePostFromJson(postsArr.getJSONObject(i)))
                        }
                        scope.launch {
                            _realtimePostsFlow.emit(postsList)
                            savePostsListToRoom(postsList)
                        }
                    }
                }

                "VIDEO_PLAYBACK_SYNC" -> {
                    val videoId = payload.optString("videoId")
                    val positionMs = payload.optLong("positionMs", 0L)
                    val isPlaying = payload.optBoolean("isPlaying", false)
                    val senderId = payload.optString("senderId", "")
                    val timestamp = payload.optLong("timestamp", System.currentTimeMillis())

                    val event = VideoSyncEvent(
                        videoId = videoId,
                        positionMs = positionMs,
                        isPlaying = isPlaying,
                        senderId = senderId,
                        timestamp = timestamp
                    )
                    scope.launch {
                        _videoPlaybackSyncFlow.emit(event)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling incoming sync message: ${e.message}")
        }
    }

    /**
     * Pre-warms the HTTP video connection and buffers the first 128KB of the video.
     * This guarantees that when ExoPlayer opens the video on Android, the stream
     * starts instantaneously without waiting for TLS handshakes or initial byte buffering.
     */
    fun prewarmVideoMedia(videoUrl: String) {
        val resolvedUrl = NetworkSyncManager.resolveMediaUrl(videoUrl) ?: return
        if (!resolvedUrl.startsWith("http://") && !resolvedUrl.startsWith("https://")) return

        scope.launch {
            try {
                val prewarmRequest = Request.Builder()
                    .url(resolvedUrl)
                    .header("Range", "bytes=0-131071") // Pre-fetch first 128KB buffer
                    .header("User-Agent", "Maeum-Social-Android-Prewarmer")
                    .build()

                okHttpClient.newCall(prewarmRequest).enqueue(object : Callback {
                    override fun onFailure(call: Call, e: java.io.IOException) {}
                    override fun onResponse(call: Call, response: Response) {
                        response.close()
                        Log.d(TAG, "Proactively pre-warmed video stream for instant playback: $resolvedUrl")
                    }
                })
            } catch (_: Exception) {}
        }
    }

    /**
     * Broadcasts video upload completion to central database and all connected devices (Web & Android).
     */
    suspend fun notifyMediaUploaded(
        postId: String,
        videoUrls: List<String>,
        thumbnailUrl: String? = null,
        authorId: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val baseUrl = NetworkSyncManager.baseUrl.trimEnd('/')

            // 1. Post to REST /api/sync/media-sync
            val syncEndpoint = "$baseUrl/api/sync/media-sync"
            val jsonPayload = JSONObject().apply {
                put("postId", postId)
                put("videoUrls", JSONArray(videoUrls))
                if (thumbnailUrl != null) put("videoThumbnail", thumbnailUrl)
                if (authorId != null) put("authorId", authorId)
            }

            val requestBody = jsonPayload.toString().toRequestBody("application/json".toMediaTypeOrNull())
            val request = Request.Builder()
                .url(syncEndpoint)
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val isSuccess = response.isSuccessful
            response.close()

            // 2. Also send over WebSocket for sub-millisecond broadcast
            val wsPayload = JSONObject().apply {
                put("type", "MEDIA_SYNC")
                put("payload", jsonPayload)
            }
            webSocket?.send(wsPayload.toString())

            // 3. Pre-warm local videos
            videoUrls.firstOrNull()?.let { prewarmVideoMedia(it) }

            Log.i(TAG, "Notified media upload for post $postId with ${videoUrls.size} videos")
            isSuccess
        } catch (e: Exception) {
            Log.e(TAG, "Failed to notify media upload: ${e.message}")
            false
        }
    }

    /**
     * Broadcasts video playback synchronization (seek, play, pause) across connected devices.
     */
    fun broadcastPlaybackSync(videoId: String, positionMs: Long, isPlaying: Boolean, senderId: String) {
        val payload = JSONObject().apply {
            put("type", "VIDEO_PLAYBACK_SYNC")
            put("payload", JSONObject().apply {
                put("videoId", videoId)
                put("positionMs", positionMs)
                put("isPlaying", isPlaying)
                put("senderId", senderId)
                put("timestamp", System.currentTimeMillis())
            })
        }
        webSocket?.send(payload.toString())
    }

    /**
     * Updates post entity in Room DB when background media upload finishes
     */
    private suspend fun updatePostWithUploadedMediaInRoom(
        postId: String,
        videoUrls: List<String>,
        thumbnailUrl: String?
    ) {
        val context = appContext ?: return
        try {
            val db = AppDatabase.getDatabase(context)
            val dao = db.postDao()
            val existing = dao.getPostById(postId)
            if (existing != null) {
                val updated = existing.copy(
                    videoUrlsJson = gson.toJson(videoUrls)
                )
                dao.insertPost(updated)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update post with uploaded media in Room: ${e.message}")
        }
    }

    private suspend fun updateSinglePostInRoom(post: Post) {
        val context = appContext ?: return
        try {
            val db = AppDatabase.getDatabase(context)
            val dao = db.postDao()
            val entity = PostEntity(
                id = post.id,
                authorId = post.author.id,
                authorName = post.author.name,
                authorHandle = post.author.handle,
                authorAvatar = post.author.avatar,
                content = post.content,
                mediaUrlsJson = gson.toJson(post.photos),
                videoUrlsJson = gson.toJson(post.videoUrls),
                locationTag = post.location ?: post.author.location,
                neighborhood = post.neighborhood ?: post.author.neighborhood,
                likesCount = post.likesCount,
                isLiked = post.isLiked,
                commentsCount = post.commentsCount,
                createdAt = post.createdAt,
                scheduledAt = post.scheduledAt,
                isBanned = false
            )
            dao.insertPost(entity)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update single post in Room: ${e.message}")
        }
    }

    private suspend fun savePostsListToRoom(posts: List<Post>) {
        val context = appContext ?: return
        try {
            val db = AppDatabase.getDatabase(context)
            val dao = db.postDao()
            val entities = posts.map { post ->
                PostEntity(
                    id = post.id,
                    authorId = post.author.id,
                    authorName = post.author.name,
                    authorHandle = post.author.handle,
                    authorAvatar = post.author.avatar,
                    content = post.content,
                    mediaUrlsJson = gson.toJson(post.photos),
                    videoUrlsJson = gson.toJson(post.videoUrls),
                    locationTag = post.location ?: post.author.location,
                    neighborhood = post.neighborhood ?: post.author.neighborhood,
                    likesCount = post.likesCount,
                    isLiked = post.isLiked,
                    commentsCount = post.commentsCount,
                    createdAt = post.createdAt,
                    scheduledAt = post.scheduledAt,
                    isBanned = false
                )
            }
            dao.insertPosts(entities)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save posts to Room: ${e.message}")
        }
    }

    private suspend fun syncLatestPostsFromBackend() {
        val remotePosts = NetworkSyncManager.fetchPosts()
        if (remotePosts != null && remotePosts.isNotEmpty()) {
            _realtimePostsFlow.emit(remotePosts)
            savePostsListToRoom(remotePosts)
        }
    }

    private fun parsePostFromJson(obj: JSONObject): Post {
        val authorObj = obj.optJSONObject("author")
        val author = if (authorObj != null) {
            User(
                id = authorObj.optString("id", obj.optString("authorId", "user_1")),
                name = authorObj.optString("name", obj.optString("authorName", "회원")),
                handle = authorObj.optString("handle", obj.optString("authorHandle", "user")),
                avatar = authorObj.optString("avatar", obj.optString("authorAvatar", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200"))
            )
        } else {
            User(
                id = obj.optString("authorId", "user_1"),
                name = obj.optString("authorName", "회원"),
                handle = obj.optString("authorHandle", "user"),
                avatar = obj.optString("authorAvatar", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200")
            )
        }

        val videoUrlsList = mutableListOf<String>()
        val vUrlsArr = obj.optJSONArray("videoUrls")
        if (vUrlsArr != null) {
            for (i in 0 until vUrlsArr.length()) {
                val resolved = NetworkSyncManager.resolveMediaUrl(vUrlsArr.getString(i))
                if (resolved != null && !videoUrlsList.contains(resolved)) {
                    videoUrlsList.add(resolved)
                }
            }
        }
        val singleVideoRaw = obj.optString("video", "").takeIf { it.isNotBlank() && it != "null" }
        val singleVideo = NetworkSyncManager.resolveMediaUrl(singleVideoRaw)
        if (singleVideo != null && !videoUrlsList.contains(singleVideo)) {
            videoUrlsList.add(0, singleVideo)
        }

        val photosList = mutableListOf<String>()
        val imagesArr = obj.optJSONArray("images") ?: obj.optJSONArray("photos")
        if (imagesArr != null) {
            for (i in 0 until imagesArr.length()) {
                val resolved = NetworkSyncManager.resolveMediaUrl(imagesArr.getString(i))
                if (resolved != null && !photosList.contains(resolved)) {
                    photosList.add(resolved)
                }
            }
        }

        val mediaItemsList = mutableListOf<com.maeum.social.model.PostMediaItem>()
        val mediaItemsArr = obj.optJSONArray("mediaItems")
        if (mediaItemsArr != null) {
            for (j in 0 until mediaItemsArr.length()) {
                val mObj = mediaItemsArr.getJSONObject(j)
                val rawUrl = mObj.optString("url", "")
                val itemUrl = NetworkSyncManager.resolveMediaUrl(rawUrl) ?: ""
                val itemThumb = NetworkSyncManager.resolveMediaUrl(mObj.optString("thumbnail", null))
                val isVid = mObj.optString("type", "") == "video" || itemUrl.contains("/videos/") || itemUrl.endsWith(".mp4")
                val itemType = if (isVid) "video" else "image"
                if (itemUrl.isNotBlank()) {
                    mediaItemsList.add(
                        com.maeum.social.model.PostMediaItem(
                            id = mObj.optString("id", "media_$j"),
                            type = itemType,
                            url = itemUrl,
                            thumbnail = itemThumb
                        )
                    )
                    if (itemType == "video" && !videoUrlsList.contains(itemUrl)) {
                        videoUrlsList.add(itemUrl)
                    } else if (itemType == "image" && !photosList.contains(itemUrl)) {
                        photosList.add(itemUrl)
                    }
                }
            }
        }

        val scopeStr = obj.optString("regionalScope", "national")
        val regionalScope = when (scopeStr) {
            "neighborhood" -> RegionalScope.NEIGHBORHOOD
            "city" -> RegionalScope.CITY
            "province" -> RegionalScope.PROVINCE
            else -> RegionalScope.ALL
        }

        return Post(
            id = obj.optString("id"),
            author = author,
            content = obj.optString("content"),
            photos = photosList,
            videoUrl = videoUrlsList.firstOrNull(),
            videoUrls = videoUrlsList,
            videoThumbnail = NetworkSyncManager.resolveMediaUrl(obj.optString("videoThumbnail", null)),
            mediaItems = mediaItemsList,
            location = obj.optString("location", null),
            regionalScope = regionalScope,
            feeling = obj.optString("feeling", null),
            likesCount = obj.optJSONArray("likes")?.length() ?: obj.optInt("likesCount", 0),
            commentsCount = obj.optInt("commentsCount", 0),
            createdAt = obj.optString("createdAt", "방금 전"),
            scheduledAt = obj.optString("scheduledAt", null)
        )
    }

    private fun scheduleReconnect() {
        scope.launch {
            delay((2000L * (reconnectAttempt + 1)).coerceAtMost(15000L))
            reconnectAttempt++
            connect()
        }
    }

    fun disconnect() {
        webSocket?.close(1000, "Normal closure")
        webSocket = null
        sseCall?.cancel()
        sseCall = null
        _isConnected.value = false
    }
}
