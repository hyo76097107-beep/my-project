package com.maeum.social.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.maeum.social.data.MockData
import com.maeum.social.theme.PrimaryIndigo
import com.maeum.social.viewmodel.SocialViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditSignupInfoScreen(
    viewModel: SocialViewModel,
    onClose: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()

    var name by remember { mutableStateOf(currentUser.name) }
    var handle by remember { mutableStateOf(currentUser.handle) }
    var residence by remember { mutableStateOf(currentUser.location) } // 3. 주거지
    var role by remember { mutableStateOf(currentUser.role) }
    var bio by remember { mutableStateOf(currentUser.bio) }
    var avatar by remember { mutableStateOf(currentUser.avatar) }
    var selectedInterests by remember { mutableStateOf(currentUser.interests.toSet()) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            avatar = uri.toString()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("회원가입 정보 수정", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, contentDescription = "닫기")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            viewModel.updateSignupInfo(
                                name = name,
                                handle = handle,
                                residenceLocation = residence,
                                role = role,
                                bio = bio,
                                avatar = avatar,
                                interests = selectedInterests.toList()
                            )
                            onClose()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("저장", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // SECTION 1: 기본 정보
            item {
                Text("1. 기본 정보", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryIndigo)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("이름") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = handle,
                    onValueChange = { handle = it },
                    label = { Text("아이디 (@handle)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }

            // SECTION 3: 3. 주거지 (요청하신 정확한 명칭 적용)
            item {
                Text("3. 주거지", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryIndigo)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = residence,
                    onValueChange = { residence = it },
                    label = { Text("주거지 주소 (예: 서울 강남구 역삼동)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    trailingIcon = {
                        TextButton(onClick = { residence = "서울 강남구 역삼동" }) {
                            Text("GPS 감지", fontSize = 11.sp, color = PrimaryIndigo)
                        }
                    }
                )
            }

            // SECTION 4: 직업 / 역할 및 자기소개
            item {
                Text("4. 직업 / 역할 및 자기소개", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryIndigo)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = role,
                    onValueChange = { role = it },
                    label = { Text("활동 역할 / 직업") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text("자기소개") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    maxLines = 3
                )
            }

            // SECTION 5: 프로필 사진 (프리셋 샘플 사진 완전 제거)
            item {
                Text("5. 프로필 사진", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryIndigo)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(modifier = Modifier.size(64.dp)) {
                        AsyncImage(
                            model = avatar,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .border(2.dp, PrimaryIndigo, CircleShape)
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { photoPickerLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Outlined.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("내 사진 업로드", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { avatar = MockData.DEFAULT_SILHOUETTE_AVATAR },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("기본 실루엣으로 변경", fontSize = 11.sp)
                        }
                    }
                }
            }

            // SECTION 6: 41개 관심사 태그 선택
            item {
                Text("6. 관심사 태그 (선택: ${selectedInterests.size}개)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryIndigo)
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MockData.ALL_INTERESTS.chunked(3).forEach { rowTags ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            rowTags.forEach { tag ->
                                val isSelected = selectedInterests.contains(tag)
                                Surface(
                                    color = if (isSelected) PrimaryIndigo else MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            selectedInterests = if (isSelected) {
                                                selectedInterests - tag
                                            } else {
                                                selectedInterests + tag
                                            }
                                        }
                                ) {
                                    Text(
                                        text = tag,
                                        fontSize = 11.sp,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                        maxLines = 1
                                    )
                                }
                            }
                            repeat(3 - rowTags.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}
