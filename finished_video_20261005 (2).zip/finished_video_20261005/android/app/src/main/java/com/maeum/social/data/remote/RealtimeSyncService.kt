package com.maeum.social.data.remote

import com.maeum.social.model.VideoSyncEvent
import com.maeum.social.network.MediaSyncService
import kotlinx.coroutines.flow.SharedFlow

/**
 * Backward compatibility wrapper around MediaSyncService.
 * Connects directly to the central social database WebSocket/SSE for real-time video and post synchronization.
 */
class RealtimeSyncService(serverUrl: String? = null) {

    val videoSyncFlow: SharedFlow<VideoSyncEvent>
        get() = MediaSyncService.videoPlaybackSyncFlow

    fun connect() {
        MediaSyncService.connect()
    }

    fun broadcastVideoSync(videoId: String, positionMs: Long, isPlaying: Boolean, senderId: String) {
        MediaSyncService.broadcastPlaybackSync(videoId, positionMs, isPlaying, senderId)
    }

    fun disconnect() {
        // Controlled by MediaSyncService lifecycle
    }
}
