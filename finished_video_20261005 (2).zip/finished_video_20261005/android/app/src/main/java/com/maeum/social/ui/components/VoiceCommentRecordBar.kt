package com.maeum.social.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.maeum.social.util.AudioRecorderHelper
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun VoiceCommentRecordBar(
    audioRecorderHelper: AudioRecorderHelper,
    onVoiceCommentReady: (File?, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var isRecording by remember { mutableStateOf(false) }
    var recordingSeconds by remember { mutableIntStateOf(0) }

    LaunchedEffect(isRecording) {
        if (isRecording) {
            recordingSeconds = 0
            while (isRecording) {
                delay(1000L)
                recordingSeconds++
            }
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(if (isRecording) Color(0xFFFFF1F2) else Color(0xFFF1F5F9))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = {
                if (!isRecording) {
                    val file = audioRecorderHelper.startRecording()
                    if (file != null) isRecording = true
                } else {
                    isRecording = false
                    val (file, duration) = audioRecorderHelper.stopRecording()
                    onVoiceCommentReady(file, duration)
                }
            },
            modifier = Modifier
                .size(40.dp)
                .background(if (isRecording) Color(0xFFE11D48) else Color(0xFF4F46E5), CircleShape)
        ) {
            Icon(
                imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = if (isRecording) "녹음 정지" else "음성 녹음 시작",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        if (isRecording) {
            Text(
                text = "음성 녹음 중... ${String.format("%02d:%02d", recordingSeconds / 60, recordingSeconds % 60)}",
                color = Color(0xFFE11D48),
                fontSize = 13.sp,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.weight(1f))
            TextButton(onClick = {
                isRecording = false
                audioRecorderHelper.stopRecording()
            }) {
                Text("취소", color = Color(0xFF64748B), fontSize = 12.sp)
            }
        } else {
            Text(
                text = "마이크를 눌러 음성으로 댓글을 남겨보세요",
                color = Color(0xFF64748B),
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun VoiceCommentPlayer(
    audioUrl: String,
    durationSec: Int,
    audioRecorderHelper: AudioRecorderHelper,
    modifier: Modifier = Modifier
) {
    var isPlaying by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFEEF2FF))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = {
                if (isPlaying) {
                    audioRecorderHelper.stopAudio()
                    isPlaying = false
                } else {
                    audioRecorderHelper.playAudio(audioUrl) {
                        isPlaying = false
                    }
                    isPlaying = true
                }
            },
            modifier = Modifier
                .size(32.dp)
                .background(Color(0xFF4F46E5), CircleShape)
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = "음성 재생",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column {
            Text(
                text = if (isPlaying) "음성 댓글 재생 중..." else "음성 댓글",
                fontSize = 12.sp,
                color = Color(0xFF1E1B4B),
                style = MaterialTheme.typography.labelMedium
            )
            Text(
                text = "길이: ${durationSec}초",
                fontSize = 10.sp,
                color = Color(0xFF4F46E5)
            )
        }
    }
}
