package com.maeum.social.util

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import com.maeum.social.model.StoryBgm
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object BgmPlayerHelper {
    private var mediaPlayer: MediaPlayer? = null
    
    private val _currentPlayingBgm = MutableStateFlow<StoryBgm?>(null)
    val currentPlayingBgm: StateFlow<StoryBgm?> = _currentPlayingBgm.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    fun togglePlay(context: Context, bgm: StoryBgm) {
        val current = _currentPlayingBgm.value
        if (current?.id == bgm.id && _isPlaying.value) {
            pause()
        } else if (current?.id == bgm.id && !_isPlaying.value) {
            resume()
        } else {
            play(context, bgm)
        }
    }

    fun play(context: Context, bgm: StoryBgm) {
        val audioUrl = bgm.audioUrl
        if (audioUrl.isNullOrBlank()) {
            return
        }

        stop()

        _isLoading.value = true
        _currentPlayingBgm.value = bgm

        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )

                if (audioUrl.startsWith("http://") || audioUrl.startsWith("https://")) {
                    setDataSource(context, Uri.parse(audioUrl))
                } else if (audioUrl.startsWith("content://") || audioUrl.startsWith("file://")) {
                    setDataSource(context, Uri.parse(audioUrl))
                } else {
                    setDataSource(audioUrl)
                }

                setOnPreparedListener { mp ->
                    _isLoading.value = false
                    mp.start()
                    _isPlaying.value = true
                }

                setOnCompletionListener {
                    _isPlaying.value = false
                }

                setOnErrorListener { _, _, _ ->
                    _isLoading.value = false
                    _isPlaying.value = false
                    true
                }

                prepareAsync()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _isLoading.value = false
            _isPlaying.value = false
        }
    }

    fun resume() {
        mediaPlayer?.let {
            if (!it.isPlaying) {
                it.start()
                _isPlaying.value = true
            }
        }
    }

    fun pause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _isPlaying.value = false
            }
        }
    }

    fun stop() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            mediaPlayer = null
            _isPlaying.value = false
            _isLoading.value = false
            _currentPlayingBgm.value = null
        }
    }
}
