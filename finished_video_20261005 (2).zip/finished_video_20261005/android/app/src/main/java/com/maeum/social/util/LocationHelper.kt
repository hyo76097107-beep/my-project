package com.maeum.social.util

import android.annotation.SuppressLint
import android.content.Context
import android.location.Geocoder
import android.os.Build
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.maeum.social.model.LocationInfo
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import kotlin.coroutines.resume

class LocationHelper(private val context: Context) {
    private val fusedClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(): LocationInfo? = suspendCancellableCoroutine { cont ->
        val cts = CancellationTokenSource()
        fusedClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token)
            .addOnSuccessListener { location ->
                if (location != null) {
                    val info = reverseGeocode(location.latitude, location.longitude)
                    cont.resume(info)
                } else {
                    cont.resume(getFallbackLocation())
                }
            }
            .addOnFailureListener {
                cont.resume(getFallbackLocation())
            }
        cont.invokeOnCancellation { cts.cancel() }
    }

    private fun reverseGeocode(lat: Double, lng: Double): LocationInfo {
        return try {
            val geocoder = Geocoder(context, Locale.KOREAN)
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            if (!addresses.isNullOrEmpty()) {
                val address = addresses[0]
                val city = address.adminArea ?: "서울특별시"
                val district = address.subLocality ?: address.locality ?: "강남구"
                val neighborhood = address.thoroughfare ?: "역삼동"
                val full = address.getAddressLine(0) ?: "$city $district $neighborhood"

                LocationInfo(
                    latitude = lat,
                    longitude = lng,
                    city = city,
                    district = district,
                    neighborhood = neighborhood,
                    fullAddress = full
                )
            } else {
                getFallbackLocation(lat, lng)
            }
        } catch (e: Exception) {
            getFallbackLocation(lat, lng)
        }
    }

    private fun getFallbackLocation(lat: Double = 37.5000, lng: Double = 127.0365): LocationInfo {
        return LocationInfo(
            latitude = lat,
            longitude = lng,
            city = "서울특별시",
            district = "강남구",
            neighborhood = "역삼동",
            fullAddress = "서울특별시 강남구 역삼동"
        )
    }
}
