package com.maeum.social

import android.app.Application
import com.maeum.social.network.MediaSyncService
import com.maeum.social.network.MediaUploadManager
import com.maeum.social.network.NetworkSyncManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MaeumApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this

        // Initialize dynamic backend auto-detection and real-time cross-device media sync service
        NetworkSyncManager.autoDetectBaseUrl(this)
        MediaSyncService.initialize(this)

        // Safely resume any unfinished media upload queues from local database across app launches/reboots
        CoroutineScope(Dispatchers.IO).launch {
            MediaUploadManager.resumePendingUploadQueues(this@MaeumApplication)
            // Optimize and prune expired (> 7 days) and completed media cache on startup
            MediaUploadManager.cleanExpiredAndCompletedCache(this@MaeumApplication)
        }

        // Schedule periodic automatic media cache cleanup (runs daily via WorkManager)
        MediaUploadManager.schedulePeriodicCacheCleanup(this)
    }

    companion object {
        lateinit var instance: MaeumApplication
            private set
    }
}
