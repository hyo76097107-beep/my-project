package com.maeum.social.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import com.maeum.social.model.Comment
import com.maeum.social.model.Reply
import com.maeum.social.ui.components.VideoPlayerView
import com.maeum.social.ui.components.VoiceCommentPlayer
import com.maeum.social.ui.components.VoiceCommentRecordBar
import com.maeum.social.viewmodel.SocialViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(
    postId: String,
    viewModel: SocialViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val posts by viewModel.posts.collectAsState()
    val comments by viewModel.currentPostComments.collectAsState()
    val post = posts.find { it.id == postId }

    var textComment by remember { mutableStateOf("") }
    var replyingToCommentId by remember { mutableStateOf<String?>(null) }
    var replyingToAuthorName by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(postId) {
        viewModel.setSelectedPostId(postId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("게시물 상세") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "뒤로가기")
                    }
                }
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(8.dp)
            ) {
                // Active reply banner if replying to a comment
                if (replyingToCommentId != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${replyingToAuthorName}님에게 답글 작성 중...",
                            fontSize = 11.sp,
                            color = Color(0xFF4F46E5)
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        IconButton(
                            onClick = {
                                replyingToCommentId = null
                                replyingToAuthorName = null
                            },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "취소", modifier = Modifier.size(14.dp))
                        }
                    }
                }

                // Voice Recording Bar
                VoiceCommentRecordBar(
                    audioRecorderHelper = viewModel.audioRecorderHelper,
                    onVoiceCommentReady = { audioFile: File?, durationSec: Int ->
                        if (audioFile != null) {
                            if (replyingToCommentId != null) {
                                viewModel.addReply(postId, replyingToCommentId!!, "음성 답글", audioFile)
                                replyingToCommentId = null
                                replyingToAuthorName = null
                            } else {
                                viewModel.addComment(postId, "음성 댓글", audioFile, durationSec)
                            }
                            Toast.makeText(context, "음성 댓글이 등록되었습니다! 🎙️", Toast.LENGTH_SHORT).show()
                        }
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Text comment input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textComment,
                        onValueChange = { textComment = it },
                        placeholder = {
                            Text(
                                if (replyingToCommentId != null) "답글을 입력하세요..." else "댓글을 입력하세요...",
                                fontSize = 12.sp
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        shape = RoundedCornerShape(25.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (textComment.isNotBlank()) {
                                if (replyingToCommentId != null) {
                                    viewModel.addReply(postId, replyingToCommentId!!, textComment, null)
                                    replyingToCommentId = null
                                    replyingToAuthorName = null
                                    Toast.makeText(context, "답글이 등록되었습니다. 💬", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.addComment(postId, textComment, null, 0)
                                    Toast.makeText(context, "댓글이 성공적으로 등록되었습니다. 💬", Toast.LENGTH_SHORT).show()
                                }
                                textComment = ""
                            }
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .background(Color(0xFF4F46E5), CircleShape)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "등록", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    ) { padding ->
        if (post == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("게시물을 찾을 수 없습니다.")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Post header and body
                item {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(
                                model = post.authorAvatar,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(post.authorName, style = MaterialTheme.typography.titleMedium)
                                Text("@${post.authorHandle} • ${post.neighborhood ?: "동네"}", fontSize = 11.sp, color = Color.Gray)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(post.content, style = MaterialTheme.typography.bodyLarge)

                        // Videos
                        post.videoUrls.forEachIndexed { index, vUrl ->
                            Spacer(modifier = Modifier.height(10.dp))
                            VideoPlayerView(
                                videoUrl = vUrl,
                                videoId = "${post.id}_detail_$index",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(240.dp)
                            )
                        }

                        // Images
                        post.mediaUrls.forEach { imgUrl ->
                            Spacer(modifier = Modifier.height(8.dp))
                            AsyncImage(
                                model = imgUrl,
                                contentDescription = null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.FillWidth
                            )
                        }

                        Divider(modifier = Modifier.padding(vertical = 16.dp))
                        Text("댓글 (${comments.size})", style = MaterialTheme.typography.titleMedium)
                    }
                }

                // Comments list with replies
                items(comments, key = { it.id }) { comment ->
                    CommentItemView(
                        comment = comment,
                        viewModel = viewModel,
                        onReplyClick = {
                            replyingToCommentId = comment.id
                            replyingToAuthorName = comment.authorName
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun CommentItemView(
    comment: Comment,
    viewModel: SocialViewModel,
    onReplyClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = comment.authorAvatar,
                    contentDescription = null,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(comment.authorName, style = MaterialTheme.typography.labelLarge)
                    Text(comment.createdAt, fontSize = 10.sp, color = Color.Gray)
                }
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "답글 달기",
                    fontSize = 11.sp,
                    color = Color(0xFF4F46E5),
                    modifier = Modifier.clickable { onReplyClick() }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Text or voice comment player
            if (comment.audioUrl != null) {
                VoiceCommentPlayer(
                    audioUrl = comment.audioUrl,
                    durationSec = comment.audioDurationSec,
                    audioRecorderHelper = viewModel.audioRecorderHelper
                )
            } else {
                Text(comment.content, style = MaterialTheme.typography.bodyMedium)
            }

            // Replies to this comment ("댓글에 답글등록")
            if (comment.replies.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    comment.replies.forEach { reply ->
                        Row(verticalAlignment = Alignment.Top) {
                            Text("↳ ", color = Color(0xFF4F46E5), fontSize = 12.sp)
                            Column {
                                Text("${reply.authorName} (@${reply.authorHandle})", fontSize = 11.sp, style = MaterialTheme.typography.labelSmall)
                                if (reply.audioUrl != null) {
                                    VoiceCommentPlayer(
                                        audioUrl = reply.audioUrl,
                                        durationSec = 5,
                                        audioRecorderHelper = viewModel.audioRecorderHelper
                                    )
                                } else {
                                    Text(reply.content, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
