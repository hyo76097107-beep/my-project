package com.maeum.social.worker

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.maeum.social.network.MediaUploadManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Background WorkManager worker for automatic periodic media cache optimization.
 * Cleans up temporary media files and Room database records that:
 * 1. Have completed synchronization (status = COMPLETED)
 * 2. Have exceeded the retention period (default: 7 days)
 * 3. Are orphaned on disk with no active upload task
 */
class MediaCacheCleanupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val TAG = "MediaCacheCleanupWorker"
        const val WORK_NAME = "periodic_media_cache_cleanup"
        const val KEY_RETENTION_MILLIS = "KEY_RETENTION_MILLIS"
        const val DEFAULT_RETENTION_MILLIS = 7 * 24 * 60 * 60 * 1000L // 7 days
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val retentionMillis = inputData.getLong(KEY_RETENTION_MILLIS, DEFAULT_RETENTION_MILLIS)
        Log.i(TAG, "Starting periodic media cache cleanup worker (retention: ${retentionMillis / (1000 * 60 * 60 * 24)} days)...")

        try {
            val cleanupResult = MediaUploadManager.cleanExpiredAndCompletedCache(
                context = applicationContext,
                retentionMillis = retentionMillis,
                deleteCompletedImmediately = true
            )

            if (cleanupResult.success) {
                Log.i(
                    TAG,
                    "MediaCacheCleanupWorker succeeded: ${cleanupResult.deletedDbRecords} DB records removed, " +
                            "${cleanupResult.deletedFilesCount} files removed, ${cleanupResult.freedBytes / (1024 * 1024)} MB freed"
                )
                Result.success(
                    workDataOf(
                        "DELETED_RECORDS" to cleanupResult.deletedDbRecords,
                        "DELETED_FILES" to cleanupResult.deletedFilesCount,
                        "FREED_BYTES" to cleanupResult.freedBytes
                    )
                )
            } else {
                Log.w(TAG, "MediaCacheCleanupWorker completed with warnings: ${cleanupResult.errorMessage}")
                Result.success()
            }
        } catch (e: Exception) {
            Log.e(TAG, "MediaCacheCleanupWorker failed: ${e.message}", e)
            Result.retry()
        }
    }
}
