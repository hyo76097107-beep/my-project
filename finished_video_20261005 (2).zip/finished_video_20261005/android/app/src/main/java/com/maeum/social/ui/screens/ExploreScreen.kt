package com.maeum.social.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.maeum.social.data.MockData
import com.maeum.social.viewmodel.SocialViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(
    viewModel: SocialViewModel,
    onNavigateToPostDetail: (String) -> Unit
) {
    val posts by viewModel.posts.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedTag by remember { mutableStateOf<String?>(null) }

    val trendingTags = listOf(
        "오운완", "연남동", "성수동맛집", "개발자", "디저트그램",
        "소금빵", "제주도", "여행스타그램", "크로스핏", "브이로그"
    )

    val filteredPosts = posts.filter { post ->
        val query = searchQuery.trim().lowercase()
        val matchQuery = if (query.isNotBlank()) {
            post.content.lowercase().contains(query) ||
            post.authorName.lowercase().contains(query) ||
            post.authorHandle.lowercase().contains(query) ||
            (post.location ?: "").lowercase().contains(query) ||
            (post.neighborhood ?: "").lowercase().contains(query)
        } else true

        val matchTag = if (selectedTag != null) {
            post.content.contains("#$selectedTag") || post.content.contains(selectedTag!!)
        } else true

        matchQuery && matchTag
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("탐색 & 검색", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("키워드, 작성자, 동네 검색...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "검색어 지우기")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Trending Tags Section
            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.TrendingUp, contentDescription = null, tint = Color(0xFF4F46E5), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("인기 동네 해시태그", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                }

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(trendingTags) { tag ->
                        val isSelected = selectedTag == tag
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedTag = if (isSelected) null else tag
                            },
                            label = { Text("#$tag", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF4F46E5),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Search Results
            if (filteredPosts.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("일치하는 검색 결과가 없습니다.", color = Color.Gray, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filteredPosts, key = { it.id }) { post ->
                        PostCard(
                            post = post,
                            currentUserId = currentUser.id,
                            onLike = { viewModel.toggleLike(post.id) },
                            onVote = { optionId -> viewModel.votePoll(post.id, optionId) },
                            onClick = { onNavigateToPostDetail(post.id) },
                            onSyncBroadcast = { vid, pos, isP -> viewModel.syncVideoPlayback(vid, pos, isP) },
                            remoteSyncEvent = null
                        )
                    }
                }
            }
        }
    }
}
