package com.maeum.social.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.maeum.social.viewmodel.SocialViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessagesScreen(
    viewModel: SocialViewModel
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val otherUserId = "user_1" // Demo partner
    val messages by viewModel.getConversation(otherUserId).collectAsState(initial = emptyList())

    var messageText by remember { mutableStateOf("") }
    var isScheduled by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("김민우 (@minwoo_dev)")
                        Text("온라인 • 역삼동", fontSize = 11.sp, color = Color(0xFF10B981))
                    }
                }
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(8.dp)
            ) {
                // Scheduled message badge
                if (isScheduled) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF4F46E5), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("30분 뒤 예약 전송 모드 활성화됨", fontSize = 11.sp, color = Color(0xFF4F46E5))
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { isScheduled = !isScheduled }) {
                        Icon(
                            Icons.Default.Schedule,
                            contentDescription = "예약 전송",
                            tint = if (isScheduled) Color(0xFF4F46E5) else Color.Gray
                        )
                    }

                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        placeholder = { Text("메시지를 입력하세요...") },
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp),
                        shape = RoundedCornerShape(25.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (messageText.isNotBlank()) {
                                val scheduledTime = if (isScheduled) System.currentTimeMillis() + 30 * 60 * 1000L else null
                                viewModel.sendMessage(otherUserId, messageText, scheduledTime)
                                messageText = ""
                                isScheduled = false
                            }
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .background(Color(0xFF4F46E5), CircleShape)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "전송", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                val isMe = msg.senderId == currentUser.id
                val timeStr = SimpleDateFormat("HH:mm", Locale.KOREAN).format(Date(msg.timestamp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                ) {
                    Column(
                        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(
                                topStart = 16.dp,
                                topEnd = 16.dp,
                                bottomStart = if (isMe) 16.dp else 4.dp,
                                bottomEnd = if (isMe) 4.dp else 16.dp
                            ),
                            color = if (isMe) Color(0xFF4F46E5) else Color(0xFFF1F5F9)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = msg.content,
                                    color = if (isMe) Color.White else Color(0xFF0F172A),
                                    fontSize = 14.sp
                                )
                                if (msg.scheduledTime != null && !msg.isDelivered) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "⏱ 예약 전송 대기 중",
                                        fontSize = 10.sp,
                                        color = if (isMe) Color.White.copy(alpha = 0.8f) else Color.Gray
                                    )
                                }
                            }
                        }
                        Text(
                            text = timeStr,
                            fontSize = 10.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
