package com.maeum.social.ui.screens

import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.maeum.social.model.RegionalScope
import com.maeum.social.network.MediaUploadManager
import com.maeum.social.theme.PrimaryIndigo
import com.maeum.social.viewmodel.CreatePostMode
import com.maeum.social.viewmodel.SocialViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePostScreen(
    viewModel: SocialViewModel,
    initialMode: CreatePostMode = CreatePostMode.DEFAULT,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val currentLocationFromVm by viewModel.currentLocation.collectAsState()
    val isAutoLocationEnabled by viewModel.isAutoLocationEnabled.collectAsState()

    var content by remember { mutableStateOf("") }
    var selectedPhotos by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedVideos by remember { mutableStateOf<List<String>>(emptyList()) }
    var location by remember { mutableStateOf(currentLocationFromVm) }
    var regionalScope by remember { mutableStateOf(RegionalScope.ALL) }
    var feeling by remember { mutableStateOf<String?>(null) }
    var isScheduled by remember { mutableStateOf(initialMode == CreatePostMode.SCHEDULE) }
    var scheduledDateTime by remember { mutableStateOf("2026-10-01 18:00") }
    var isUploading by remember { mutableStateOf(false) }

    // BGM & Poll state
    var selectedBgm by remember { mutableStateOf<com.maeum.social.model.StoryBgm?>(null) }
    var showBgmDrawer by remember { mutableStateOf(false) }
    var bgmSearchQuery by remember { mutableStateOf("") }
    var activeBgmCategory by remember { mutableStateOf("all") }

    var isPollEnabled by remember { mutableStateOf(false) }
    var showPollDrawer by remember { mutableStateOf(false) }
    var pollQuestion by remember { mutableStateOf("") }
    var pollOptions by remember { mutableStateOf(listOf("", "")) }

    var showFeelingDialog by remember { mutableStateOf(false) }

    val activeUploadTasks by viewModel.activeUploadTasks.collectAsState()
    val uploadProgressMap by viewModel.uploadProgressMap.collectAsState()
    val uploadQueueMap by viewModel.uploadQueueMap.collectAsState()

    var showPhotoDrawer by remember { mutableStateOf(initialMode == CreatePostMode.PHOTO) }
    var showVideoDrawer by remember { mutableStateOf(initialMode == CreatePostMode.VIDEO) }
    var showLocationDrawer by remember { mutableStateOf(initialMode == CreatePostMode.LOCATION) }
    var showScheduleDrawer by remember { mutableStateOf(initialMode == CreatePostMode.SCHEDULE) }
    var showRegionalScopeDrawer by remember { mutableStateOf(false) }

    // GPS Permission Launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false
        if (fineGranted || coarseGranted) {
            viewModel.detectLocation(context) { detected ->
                location = detected
            }
        }
    }

    val coroutineScope = rememberCoroutineScope()
    var isCopyingVideos by remember { mutableStateOf(false) }

    // Android native image picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val newUris = uris.map { it.toString() }
            selectedPhotos = (selectedPhotos + newUris).distinct().take(10)
        }
    }

    // Android native multi-video picker launcher (동영상 동시 다중 선택 지원)
    // Copies raw video bytes immediately into app internal cache so permission never expires!
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            isCopyingVideos = true
            coroutineScope.launch(Dispatchers.IO) {
                val cachedPaths = uris.mapNotNull { uri ->
                    try {
                        val taskId = "pick_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}"
                        val cachedFile = MediaUploadManager.cacheMediaFileLocally(context, uri, taskId)
                        cachedFile?.let { "file://${it.absolutePath}" } ?: uri.toString()
                    } catch (e: Exception) {
                        uri.toString()
                    }
                }
                withContext(Dispatchers.Main) {
                    selectedVideos = (selectedVideos + cachedPaths).distinct().take(10)
                    isCopyingVideos = false
                }
            }
        }
    }

    // Android native single-video picker fallback (단일 파일 선택)
    val singleVideoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            isCopyingVideos = true
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val taskId = "pick_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}"
                    val cachedFile = MediaUploadManager.cacheMediaFileLocally(context, uri, taskId)
                    val resultUri = cachedFile?.let { "file://${it.absolutePath}" } ?: uri.toString()
                    withContext(Dispatchers.Main) {
                        selectedVideos = (selectedVideos + listOf(resultUri)).distinct().take(10)
                        isCopyingVideos = false
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        selectedVideos = (selectedVideos + listOf(uri.toString())).distinct().take(10)
                        isCopyingVideos = false
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("게시물 작성", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, contentDescription = "닫기")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            val hasContent = content.isNotBlank() || selectedPhotos.isNotEmpty() || selectedVideos.isNotEmpty() || (isPollEnabled && pollQuestion.isNotBlank())
                            if (!isUploading && hasContent) {
                                isUploading = true
                                val finalPoll = if (isPollEnabled && pollQuestion.isNotBlank()) {
                                    val validOpts = pollOptions.filter { it.isNotBlank() }
                                    if (validOpts.size >= 2) {
                                        com.maeum.social.model.Poll(
                                            id = "poll_${System.currentTimeMillis()}",
                                            question = pollQuestion.trim(),
                                            options = validOpts.mapIndexed { idx, text ->
                                                com.maeum.social.model.PollOption(id = "opt_${idx + 1}", text = text.trim())
                                            },
                                            totalVotes = 0
                                        )
                                    } else null
                                } else null

                                viewModel.createPost(
                                    context = context,
                                    content = content,
                                    photos = selectedPhotos,
                                    videoUrl = selectedVideos.firstOrNull(),
                                    videoUrls = selectedVideos,
                                    videoThumbnail = null,
                                    location = if (location.isNotBlank()) location else null,
                                    regionalScope = regionalScope,
                                    feeling = feeling,
                                    bgm = selectedBgm,
                                    poll = finalPoll,
                                    scheduledAt = if (isScheduled) scheduledDateTime else null,
                                    onComplete = {
                                        isUploading = false
                                        onClose()
                                    }
                                )
                            }
                        },
                        enabled = !isUploading,
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            if (isUploading) "업로드 중..." else if (isScheduled) "예약 등록" else "게시하기",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Live Real-Time Media Compression & WorkManager Background Queue Progress Banner
            val latestQueue = uploadQueueMap.values.lastOrNull { !it.isFinished }
            if (isUploading || activeUploadTasks.isNotEmpty() || latestQueue != null) {
                val overallProgress = latestQueue?.overallProgress
                    ?: if (activeUploadTasks.isNotEmpty()) {
                        activeUploadTasks.sumOf { it.progress } / activeUploadTasks.size
                    } else 50

                val titleText = if (latestQueue != null) {
                    "동영상 백그라운드 큐: (${latestQueue.currentIndex}/${latestQueue.totalCount}개 처리 중)"
                } else {
                    "동영상 압축 및 백그라운드 큐(WorkManager) 순차 업로드 중..."
                }

                Surface(
                    color = Color(0xFFF0FDF4),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color(0xFF16A34A)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = titleText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { overallProgress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = Color(0xFF16A34A)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "진행률: $overallProgress% • 병목현상 방지 순차 큐 동작 중 (Room DB & 실시간 동기화)",
                            fontSize = 10.sp,
                            color = Color(0xFF166534)
                        )
                    }
                }
            }

            // Main content input
            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                placeholder = { Text("어떤 따뜻한 생각을 나누고 싶으신가요? (#해시태그 지원)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 130.dp),
                shape = RoundedCornerShape(14.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Attached Photos preview
            if (selectedPhotos.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    selectedPhotos.forEach { uriString ->
                        Box(modifier = Modifier.size(80.dp)) {
                            AsyncImage(
                                model = uriString,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Attached Videos preview (다중 동영상 동시 첨부 목록 및 관리)
            if (selectedVideos.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "첨부된 동영상 (${selectedVideos.size}/10개)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2563EB)
                        )
                        TextButton(
                            onClick = { selectedVideos = emptyList() },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("전체 해제", fontSize = 11.sp, color = Color(0xFFDC2626))
                        }
                    }

                    selectedVideos.forEachIndexed { index, uriStr ->
                        Surface(
                            color = Color(0xFFEFF6FF),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Outlined.Videocam, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("동영상 ${index + 1}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))
                                    Text(
                                        text = uriStr.substringAfterLast("/").take(30),
                                        fontSize = 10.sp,
                                        color = Color(0xFF6B7280),
                                        maxLines = 1
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        selectedVideos = selectedVideos.filterIndexed { i, _ -> i != index }
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "삭제", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Regional Scope Preview badge
            Surface(
                color = Color(0xFFF1F5F9),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showRegionalScopeDrawer = !showRegionalScopeDrawer }
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Outlined.Public, contentDescription = null, tint = PrimaryIndigo, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "공개 범위: ${regionalScope.title}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1E293B)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Text("변경", fontSize = 11.sp, color = PrimaryIndigo, fontWeight = FontWeight.Bold)
                }
            }

            // 1. Regional Scope Selector Drawer
            if (showRegionalScopeDrawer) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF5FF)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD8B4FE)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("지역별 게시 범위 설정", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6B21A8))
                        Spacer(modifier = Modifier.height(8.dp))

                        RegionalScope.values().forEach { scope ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { regionalScope = scope }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = regionalScope == scope,
                                    onClick = { regionalScope = scope }
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(scope.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text(scope.description, fontSize = 10.5.sp, color = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }

            // 2. Photo Picker Drawer
            if (showPhotoDrawer) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("사진 첨부", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { photoPickerLauncher.launch("image/*") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Outlined.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("기기 갤러리에서 사진 선택 (다중 선택 가능)", fontSize = 12.sp)
                        }
                    }
                }
            }

            // 3. Video Picker Drawer
            if (showVideoDrawer) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("동영상 첨부 (다중 동시 선택 가능, 최대 10개)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("갤러리에서 여러 개의 동영상을 한 번에 선택하여 동시에 첨부할 수 있습니다.", fontSize = 11.sp, color = Color(0xFF6B7280))
                        Spacer(modifier = Modifier.height(8.dp))

                        if (isCopyingVideos) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color(0xFF2563EB))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("동영상 파일을 기기 저장소로 안전하게 복사 중입니다...", fontSize = 11.sp, color = Color(0xFF2563EB))
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { videoPickerLauncher.launch("video/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                shape = RoundedCornerShape(8.dp),
                                enabled = !isCopyingVideos && selectedVideos.size < 10
                            ) {
                                Icon(Icons.Outlined.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("갤러리 다중 선택", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { singleVideoPickerLauncher.launch("video/*") },
                                shape = RoundedCornerShape(8.dp),
                                enabled = !isCopyingVideos && selectedVideos.size < 10
                            ) {
                                Icon(Icons.Outlined.Videocam, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("단일 동영상", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 4. Location Drawer (위치 정보 & 체크박스는 주소입력란 아래로 배치)
            if (showLocationDrawer) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.LocationOn, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("GPS 위치 자동감지 및 설정", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                            }
                            TextButton(
                                onClick = {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                            ) {
                                Icon(Icons.Outlined.MyLocation, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF2563EB))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("GPS 자동감지", fontSize = 11.sp, color = Color(0xFF2563EB), fontWeight = FontWeight.Bold)
                            }
                        }

                        // 주소 직접 입력란
                        OutlinedTextField(
                            value = location,
                            onValueChange = { location = it },
                            placeholder = { Text("위치 직접 입력 (예: 서울 강남구 역삼동, 성수동)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // 주소입력란 아래: 위치 자동 추가 체크박스
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = isAutoLocationEnabled,
                                onCheckedChange = { viewModel.setAutoLocationEnabled(it) }
                            )
                            Text("위치 자동 추가", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            // 5. Schedule Drawer
            if (showScheduleDrawer) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEEF2FF)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Schedule, contentDescription = null, tint = PrimaryIndigo)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("게시물 예약 전송 (WorkManager 백그라운드 발송)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrimaryIndigo)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = scheduledDateTime,
                            onValueChange = { scheduledDateTime = it },
                            label = { Text("예약 일시 (YYYY-MM-DD HH:mm)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = isScheduled,
                                onCheckedChange = { isScheduled = it }
                            )
                            Text("예약 전송 활성화", fontSize = 12.sp)
                        }
                    }
                }
            }

            // 6. Royalty-Free BGM Drawer
            if (showBgmDrawer) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.MusicNote, contentDescription = null, tint = Color(0xFFD97706))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("저작권 무료 배경음악 (BGM)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                            }
                            if (selectedBgm != null) {
                                TextButton(onClick = { selectedBgm = null }) {
                                    Text("음악 해제", fontSize = 11.sp, color = Color(0xFFDC2626))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // CC0 Trust Banner
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFECFDF5),
                            border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Outlined.Shield, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("100% 저작권 무료 (CC0) 안심 음원으로 피드에 자유롭게 사용 가능합니다.", fontSize = 11.sp, color = Color(0xFF065F46))
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Category Chips
                        val categories = listOf(
                            "all" to "전체",
                            "lofi" to "☕ 로우파이",
                            "acoustic" to "🎸 어쿠스틱",
                            "piano" to "🎹 피아노",
                            "synth" to "🌃 시티팝",
                            "tropical" to "🏝️ 트로피컬",
                            "ambient" to "🌿 앰비언트",
                            "jazz" to "🎷 재즈",
                            "indie" to "🌾 인디",
                            "upbeat" to "⚡ 업비트"
                        )
                        androidx.compose.foundation.lazy.LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(categories) { (catId, label) ->
                                FilterChip(
                                    selected = activeBgmCategory == catId,
                                    onClick = { activeBgmCategory = catId },
                                    label = { Text(label, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFF59E0B),
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Search
                        OutlinedTextField(
                            value = bgmSearchQuery,
                            onValueChange = { bgmSearchQuery = it },
                            placeholder = { Text("음악 제목, 아티스트, 장르 검색...", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Track List
                        val filteredBgms = com.maeum.social.data.MockData.PRESET_BGMS.filter { bgm ->
                            val matchCat = when (activeBgmCategory) {
                                "lofi" -> bgm.genre.contains("로우파이")
                                "acoustic" -> bgm.genre.contains("어쿠스틱")
                                "piano" -> bgm.genre.contains("피아노")
                                "synth" -> bgm.genre.contains("시티팝")
                                "tropical" -> bgm.genre.contains("트로피컬")
                                "ambient" -> bgm.genre.contains("앰비언트")
                                "jazz" -> bgm.genre.contains("재즈")
                                "indie" -> bgm.genre.contains("인디")
                                "upbeat" -> bgm.genre.contains("업비트")
                                else -> true
                            }
                            val matchSearch = if (bgmSearchQuery.isNotBlank()) {
                                val q = bgmSearchQuery.trim().lowercase()
                                bgm.title.lowercase().contains(q) || bgm.artist.lowercase().contains(q) || bgm.genre.lowercase().contains(q)
                            } else true
                            matchCat && matchSearch
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            filteredBgms.forEach { bgm ->
                                val isSelected = selectedBgm?.id == bgm.id
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) Color(0xFFFEF3C7) else Color.White,
                                    border = BorderStroke(1.dp, if (isSelected) Color(0xFFF59E0B) else Color(0xFFE2E8F0)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedBgm = bgm }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Outlined.MusicNote, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(bgm.title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text("${bgm.artist} • ${bgm.genre}", fontSize = 10.sp, color = Color.Gray)
                                        }
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = "선택됨", tint = Color(0xFFD97706), modifier = Modifier.size(18.dp))
                                        } else {
                                            TextButton(
                                                onClick = { selectedBgm = bgm },
                                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text("선택", fontSize = 11.sp, color = Color(0xFFD97706))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 7. Poll Drawer
            if (showPollDrawer) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEEF2FF)),
                    border = BorderStroke(1.dp, Color(0xFFC7D2FE)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Poll, contentDescription = null, tint = PrimaryIndigo)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("투표 추가하기", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryIndigo)
                            }
                            if (isPollEnabled) {
                                TextButton(onClick = { isPollEnabled = false; pollQuestion = "" }) {
                                    Text("투표 삭제", fontSize = 11.sp, color = Color(0xFFDC2626))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = pollQuestion,
                            onValueChange = {
                                pollQuestion = it
                                isPollEnabled = it.isNotBlank()
                            },
                            placeholder = { Text("투표 질문을 입력하세요 (예: 가장 선호하는 개발 도구는?)", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        pollOptions.forEachIndexed { index, optionText ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            ) {
                                OutlinedTextField(
                                    value = optionText,
                                    onValueChange = { newText ->
                                        val updated = pollOptions.toMutableList()
                                        updated[index] = newText
                                        pollOptions = updated
                                        isPollEnabled = true
                                    },
                                    placeholder = { Text("선택지 ${index + 1}", fontSize = 12.sp) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    singleLine = true
                                )
                                if (pollOptions.size > 2) {
                                    IconButton(
                                        onClick = {
                                            pollOptions = pollOptions.filterIndexed { i, _ -> i != index }
                                        }
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "삭제", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }

                        if (pollOptions.size < 4) {
                            Spacer(modifier = Modifier.height(6.dp))
                            TextButton(
                                onClick = { pollOptions = pollOptions + "" },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("선택지 추가 (최대 4개)", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // 8. Feeling Dialog / Drawer
            if (showFeelingDialog) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.SentimentSatisfied, contentDescription = null, tint = Color(0xFFD97706))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("현재 기분 / 활동 선택", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                            }
                            if (feeling != null) {
                                TextButton(onClick = { feeling = null }) {
                                    Text("해제", fontSize = 11.sp, color = Color(0xFFDC2626))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        val feelingList = listOf(
                            "✨ 행복함", "🥐 힐링", "🔥 열정 가득", "☕ 여유로움",
                            "💻 열공/코딩", "🏃‍♂️ 오운완", "🌙 편안함", "🎉 축하",
                            "🤔 호기심 가득", "🍕 맛있는 음식", "✈️ 여행 중", "💪 동기부여"
                        )
                        androidx.compose.foundation.lazy.LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(feelingList) { f ->
                                FilterChip(
                                    selected = feeling == f,
                                    onClick = {
                                        feeling = f
                                        showFeelingDialog = false
                                    },
                                    label = { Text(f, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFF59E0B),
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Toolbar Icons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                IconButton(onClick = { showPhotoDrawer = !showPhotoDrawer }) {
                    Icon(Icons.Outlined.Image, contentDescription = "사진 첨부", tint = Color(0xFF059669))
                }
                IconButton(onClick = { showVideoDrawer = !showVideoDrawer }) {
                    Icon(Icons.Outlined.Videocam, contentDescription = "동영상 첨부", tint = Color(0xFFE11D48))
                }
                IconButton(onClick = { showLocationDrawer = !showLocationDrawer }) {
                    Icon(Icons.Outlined.LocationOn, contentDescription = "위치 추가", tint = Color(0xFF2563EB))
                }
                IconButton(onClick = { showScheduleDrawer = !showScheduleDrawer }) {
                    Icon(Icons.Outlined.Schedule, contentDescription = "예약 전송", tint = PrimaryIndigo)
                }
                IconButton(onClick = { showRegionalScopeDrawer = !showRegionalScopeDrawer }) {
                    Icon(Icons.Outlined.Public, contentDescription = "지역별 공개", tint = Color(0xFF9333EA))
                }
                IconButton(onClick = { showFeelingDialog = !showFeelingDialog }) {
                    Icon(Icons.Outlined.SentimentSatisfied, contentDescription = "기분 추가", tint = Color(0xFFD97706))
                }
                IconButton(onClick = { showBgmDrawer = !showBgmDrawer }) {
                    Icon(Icons.Outlined.MusicNote, contentDescription = "저작권 무료 BGM", tint = Color(0xFFF59E0B))
                }
                IconButton(onClick = { showPollDrawer = !showPollDrawer }) {
                    Icon(Icons.Outlined.Poll, contentDescription = "투표 추가", tint = Color(0xFF6366F1))
                }
            }
        }
    }
}
