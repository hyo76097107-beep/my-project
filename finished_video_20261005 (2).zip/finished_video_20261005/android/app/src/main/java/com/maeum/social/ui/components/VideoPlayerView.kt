package com.maeum.social.ui.components

import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView
import com.maeum.social.model.VideoSyncEvent
import com.maeum.social.network.NetworkSyncManager
import com.maeum.social.util.CodecSupportHelper
import com.maeum.social.util.H264CodecDiagnostic

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerView(
    videoUrl: String,
    videoId: String,
    modifier: Modifier = Modifier,
    isSyncEnabled: Boolean = true,
    remoteSyncEvent: VideoSyncEvent? = null,
    onSyncBroadcast: (videoId: String, positionMs: Long, isPlaying: Boolean) -> Unit = { _, _, _ -> }
) {
    val context = LocalContext.current
    var isSynchronizedWithPeer by remember { mutableStateOf(false) }
    var showCodecDialog by remember { mutableStateOf(false) }
    var playbackErrorMessage by remember { mutableStateOf<String?>(null) }
    var currentMediaSrc by remember(videoUrl) { mutableStateOf(videoUrl) }

    // Run Codec Diagnostic once for device hardware capabilities
    val codecDiagnostic: H264CodecDiagnostic = remember {
        CodecSupportHelper.checkH264CodecSupport()
    }

    // Initialize ExoPlayer with H.264 profile optimization and Hardware Acceleration
    val exoPlayer = remember(currentMediaSrc) {
        val sampleAssetPath = when {
            currentMediaSrc.contains("sample_fitness") -> "asset:///videos/sample_fitness.mp4"
            currentMediaSrc.contains("sample_tokyo") -> "asset:///videos/sample_tokyo.mp4"
            currentMediaSrc.contains("sample_nature") -> "asset:///videos/sample_nature.mp4"
            currentMediaSrc.contains("sample_drive") -> "asset:///videos/sample_drive.mp4"
            currentMediaSrc.contains("sample_sports") -> "asset:///videos/sample_sports.mp4"
            else -> null
        }

        val resolved = when {
            sampleAssetPath != null -> sampleAssetPath
            currentMediaSrc.startsWith("content://") || currentMediaSrc.startsWith("file://") || currentMediaSrc.startsWith("asset:///") -> currentMediaSrc
            else -> NetworkSyncManager.resolveMediaUrl(currentMediaSrc) ?: currentMediaSrc
        }

        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(30000)
            .setUserAgent("Maeum-Social-Android-ExoPlayer")

        val defaultDataSourceFactory = DefaultDataSource.Factory(context, httpDataSourceFactory)
        val mediaSourceFactory = DefaultMediaSourceFactory(context)
            .setDataSourceFactory(defaultDataSourceFactory)

        // 1. Hardware Acceleration & Safe Codec Fallback Factory:
        // Automatically falls back to secondary/software decoders if hardware decoder fails on high-profile video
        val renderersFactory = DefaultRenderersFactory(context).apply {
            setEnableDecoderFallback(true)
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        }

        // 2. TrackSelector supporting all compatible video formats
        val trackSelector = DefaultTrackSelector(context)

        // 3. Resilient buffer control for smooth playback of short (2s) and long (4s, 10s, 30s, 60s+) videos
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                5000,  // minBufferMs: 5.0s minimum buffer
                60000, // maxBufferMs: up to 60s buffer, prevents buffer underrun stalls on 4s+ and large videos
                1000,  // bufferForPlaybackMs: 1.0s initial startup
                2000   // bufferForPlaybackAfterRebufferMs: 2.0s rebuffer recovery
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        ExoPlayer.Builder(context, renderersFactory)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(mediaSourceFactory)
            .build().apply {
                repeatMode = Player.REPEAT_MODE_ONE
                try {
                    val mediaItem = MediaItem.fromUri(Uri.parse(resolved))
                    setMediaItem(mediaItem)
                    prepare()
                    playWhenReady = false
                } catch (e: Exception) {
                    playbackErrorMessage = "동영상 준비 오류: ${e.message}"
                }
            }
    }

    // Handle remote sync events received from other phones
    LaunchedEffect(remoteSyncEvent) {
        if (remoteSyncEvent != null && remoteSyncEvent.videoId == videoId) {
            val timeDiff = Math.abs(exoPlayer.currentPosition - remoteSyncEvent.positionMs)
            if (timeDiff > 1000) {
                exoPlayer.seekTo(remoteSyncEvent.positionMs)
            }
            if (remoteSyncEvent.isPlaying && !exoPlayer.isPlaying) {
                exoPlayer.play()
                isSynchronizedWithPeer = true
            } else if (!remoteSyncEvent.isPlaying && exoPlayer.isPlaying) {
                exoPlayer.pause()
                isSynchronizedWithPeer = true
            }
        }
    }

    // Listen to local player events to broadcast to other devices and handle errors
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                playbackErrorMessage = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> "하드웨어 코덱 초기화 실패: 지원되지 않는 H.264 프로파일일 수 있습니다."
                    PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED -> "디코더 조회 실패: 기기 코덱 지원 여부를 확인하세요."
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED -> "네트워크 연결 지연: 동영상 스트림을 다시 확인하세요."
                    else -> "동영상 재생 오류 (${error.errorCodeName}): 코덱 지원 여부를 확인하세요."
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    playbackErrorMessage = null
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isSyncEnabled) {
                    onSyncBroadcast(videoId, exoPlayer.currentPosition, isPlaying)
                }
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (isSyncEnabled && reason == Player.DISCONTINUITY_REASON_SEEK) {
                    onSyncBroadcast(videoId, newPosition.positionMs, exoPlayer.isPlaying)
                }
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.Black)
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                }
            },
            update = { playerView ->
                if (playerView.player != exoPlayer) {
                    playerView.player = exoPlayer
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Top Control Badges: Codec Diagnostic Button & Sync Status
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sync Status Indicator Badge
            if (isSyncEnabled) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.65f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "Sync",
                            tint = if (isSynchronizedWithPeer) Color(0xFF10B981) else Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isSynchronizedWithPeer) "동기화 연결됨" else "다중 기기 동기화",
                            color = Color.White,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Playback Error Overlay Banner (if playback failed)
        playbackErrorMessage?.let { errMsg ->
            Surface(
                color = Color(0xDD7F1D1D),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(12.dp)
                    .fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "경고",
                            tint = Color(0xFFFCA5A5),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "재생할 수 없습니다",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = errMsg,
                        color = Color(0xFFFEE2E2),
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                playbackErrorMessage = null
                                try {
                                    exoPlayer.seekTo(0)
                                    exoPlayer.prepare()
                                    exoPlayer.play()
                                } catch (_: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("다시 시도", color = Color(0xFF991B1B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Codec Support & ExoPlayer Hardware Acceleration Diagnostic Dialog
    if (showCodecDialog) {
        Dialog(onDismissRequest = { showCodecDialog = false }) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ExoPlayer 코덱 & HW 가속 진단",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(onClick = { showCodecDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "닫기")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Hardware Acceleration Status Card
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (codecDiagnostic.hasHardwareAcceleration) Color(0xFFECFDF5) else Color(0xFFFEF3C7),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (codecDiagnostic.hasHardwareAcceleration) Icons.Default.CheckCircle else Icons.Default.Info,
                                contentDescription = null,
                                tint = if (codecDiagnostic.hasHardwareAcceleration) Color(0xFF059669) else Color(0xFFD97706),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (codecDiagnostic.hasHardwareAcceleration) "GPU 하드웨어 가속 활성화됨" else "소프트웨어 디코딩 동작 중",
                                    color = if (codecDiagnostic.hasHardwareAcceleration) Color(0xFF065F46) else Color(0xFF92400E),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "주 디코더: ${codecDiagnostic.primaryDecoderName}",
                                    color = if (codecDiagnostic.hasHardwareAcceleration) Color(0xFF047857) else Color(0xFFB45309),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // ExoPlayer Settings Info
                    Text(
                        text = "ExoPlayer 적용 설정",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("• H.264/AVC 프로파일: ${codecDiagnostic.recommendedExoPlayerProfile}", fontSize = 11.sp)
                            Text("• 디코더 자동 폴백: 활성화 (하드웨어 실패 시 소프트웨어 복구)", fontSize = 11.sp)
                            Text("• 최대 지원 해상도: ${codecDiagnostic.maxResolution}", fontSize = 11.sp)
                            Text("• 버퍼 제어: 1,500ms ~ 6,000ms 저지연 고속 버퍼링", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Supported Profiles
                    Text(
                        text = "기기 H.264 프로파일 지원 여부",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ProfileBadge("Baseline", codecDiagnostic.isBaselineSupported)
                        ProfileBadge("Main", codecDiagnostic.isMainSupported)
                        ProfileBadge("High", codecDiagnostic.isHighSupported)
                        ProfileBadge("High 10-bit", codecDiagnostic.isHigh10Supported)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Decoders list
                    Text(
                        text = "기기 등록 디코더 (${codecDiagnostic.decoders.size}개)",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        codecDiagnostic.decoders.take(4).forEach { dec ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = dec.name, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                        Text(
                                            text = "해상도: ${dec.maxResolution} @ ${dec.maxFrameRate}fps",
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (dec.isHardwareAccelerated) Color(0xFFDCFCE7) else Color(0xFFF1F5F9)
                                    ) {
                                        Text(
                                            text = if (dec.isHardwareAccelerated) "HW 가속" else "SW",
                                            color = if (dec.isHardwareAccelerated) Color(0xFF166534) else Color(0xFF475569),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { showCodecDialog = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("확인 완료")
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileBadge(name: String, isSupported: Boolean) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isSupported) Color(0xFFECFDF5) else Color(0xFFF1F5F9)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isSupported) Icons.Default.CheckCircle else Icons.Default.Close,
                contentDescription = null,
                tint = if (isSupported) Color(0xFF10B981) else Color(0xFF94A3B8),
                modifier = Modifier.size(10.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = name,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = if (isSupported) Color(0xFF065F46) else Color(0xFF64748B)
            )
        }
    }
}
