package com.maeum.social.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.maeum.social.model.Post
import com.maeum.social.ui.components.VideoPlayerView
import com.maeum.social.viewmodel.SocialViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FeedScreen(
    viewModel: SocialViewModel,
    onNavigateToPostDetail: (String) -> Unit,
    onNavigateToCreatePost: () -> Unit = {}
) {
    val posts by viewModel.posts.collectAsState()
    val stories by viewModel.stories.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val selectedNeighborhood by viewModel.selectedNeighborhood.collectAsState()
    val detectedLocation by viewModel.detectedLocation.collectAsState()
    val videoSyncEvent by viewModel.videoSyncEvent.collectAsState()
    val activeUploadTasks by viewModel.activeUploadTasks.collectAsState()

    var showCreatePostDialog by remember { mutableStateOf(false) }
    var showCreateStoryDialog by remember { mutableStateOf(false) }
    var viewingStory by remember { mutableStateOf<com.maeum.social.model.Story?>(null) }
    var showServerConfigDialog by remember { mutableStateOf(false) }
    var customServerInput by remember { mutableStateOf(viewModel.getCustomServerUrl() ?: "") }
    var serverStatusText by remember { mutableStateOf(viewModel.getServerStatusSummary()) }

    LaunchedEffect(Unit) {
        viewModel.refreshPosts()
    }

    val neighborhoods = listOf("전체", "역삼동", "삼성동", "한남동", "서초동", "신사동", "판교동")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("마음 (Maeum)", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.width(8.dp))
                        // GPS Location Badge Button
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFEEF2FF),
                            modifier = Modifier.clickable {
                                viewModel.autoDetectGpsLocation()
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "GPS",
                                    tint = Color(0xFF4F46E5),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = detectedLocation?.neighborhood ?: "내 위치 감지",
                                    color = Color(0xFF4F46E5),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.refreshPosts {
                            serverStatusText = viewModel.getServerStatusSummary()
                        }
                    }) {
                        Icon(Icons.Default.Sync, contentDescription = "피드 새로고침 및 동기화")
                    }
                    IconButton(onClick = {
                        customServerInput = viewModel.getCustomServerUrl() ?: ""
                        serverStatusText = viewModel.getServerStatusSummary()
                        showServerConfigDialog = true
                    }) {
                        Icon(Icons.Default.Settings, contentDescription = "동기화 서버 설정")
                    }
                    IconButton(onClick = { viewModel.autoDetectGpsLocation() }) {
                        Icon(Icons.Default.MyLocation, contentDescription = "GPS 자동 감지")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNavigateToCreatePost,
                icon = { Icon(Icons.Default.Add, contentDescription = "글작성") },
                text = { Text("동네 소식 작성") },
                containerColor = Color(0xFF4F46E5),
                contentColor = Color.White
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Instagram-like Stories Row
            com.maeum.social.ui.components.StoryRow(
                stories = stories,
                currentUser = currentUser,
                onStoryClick = { viewingStory = it },
                onAddStoryClick = { showCreateStoryDialog = true }
            )

            HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)

            // Neighborhood Filter Tabs ("동지역별로 게시하기")
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(neighborhoods) { neighborhood ->
                    FilterChip(
                        selected = selectedNeighborhood == neighborhood,
                        onClick = { viewModel.setNeighborhood(neighborhood) },
                        label = { Text(neighborhood) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF4F46E5),
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // WorkManager Background Video Upload Queue Banner
            if (activeUploadTasks.isNotEmpty()) {
                Surface(
                    color = Color(0xFFEEF2FF),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.5.dp,
                            color = Color(0xFF4F46E5)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "동영상 백그라운드 업로드 중 (${activeUploadTasks.size}개 작업)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF1E1B4B)
                            )
                            val avgProgress = if (activeUploadTasks.isNotEmpty()) {
                                activeUploadTasks.map { it.progress }.average().toInt()
                            } else 0
                            Text(
                                "WorkManager 큐 진행률: ${avgProgress}% (다른 화면으로 이동해도 안전하게 계속 업로드됩니다)",
                                fontSize = 10.sp,
                                color = Color(0xFF4F46E5)
                            )
                        }
                    }
                }
            }

            // Post list
            if (posts.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("해당 동네에 등록된 소식이 없습니다.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(posts, key = { it.id }) { post ->
                        PostCard(
                            post = post,
                            currentUserId = currentUser.id,
                            isFollowing = currentUser.followingIds.contains(post.authorId),
                            onToggleFollow = {
                                viewModel.toggleFollow(post.authorId, post.authorName, post.authorHandle)
                            },
                            onLike = { viewModel.toggleLike(post.id) },
                            onVote = { optionId -> viewModel.votePoll(post.id, optionId) },
                            onClick = { onNavigateToPostDetail(post.id) },
                            onSyncBroadcast = { videoId, pos, playing ->
                                viewModel.syncVideoPlayback(videoId, pos, playing)
                            },
                            remoteSyncEvent = videoSyncEvent
                        )
                    }
                }
            }
        }
    }

    // Story Viewer Dialog
    viewingStory?.let { story ->
        com.maeum.social.ui.components.StoryViewerDialog(
            initialStory = story,
            allStories = stories,
            onDismiss = { viewingStory = null }
        )
    }

    // Create Story Dialog
    if (showCreateStoryDialog) {
        com.maeum.social.ui.components.CreateStoryDialog(
            viewModel = viewModel,
            onDismiss = { showCreateStoryDialog = false }
        )
    }

    if (showCreatePostDialog) {
        CreatePostDialog(
            viewModel = viewModel,
            onDismiss = { showCreatePostDialog = false }
        )
    }
}

@Composable
fun PostCard(
    post: Post,
    currentUserId: String,
    isFollowing: Boolean = false,
    onToggleFollow: () -> Unit = {},
    onLike: () -> Unit,
    onVote: (String) -> Unit,
    onClick: () -> Unit,
    onSyncBroadcast: (videoId: String, positionMs: Long, isPlaying: Boolean) -> Unit,
    remoteSyncEvent: com.maeum.social.model.VideoSyncEvent?
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Author info + Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = post.authorAvatar,
                        contentDescription = post.authorName,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(post.authorName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            if (post.authorId != currentUserId) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isFollowing) Color(0xFFF1F5F9) else Color(0xFFEEF2FF),
                                    modifier = Modifier.clickable { onToggleFollow() }
                                ) {
                                    Text(
                                        text = if (isFollowing) "팔로잉" else "팔로우",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isFollowing) Color.Gray else Color(0xFF4F46E5),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("@${post.authorHandle}", fontSize = 11.sp, color = Color.Gray)
                            if (post.neighborhood != null) {
                                Text(" • ${post.neighborhood}", fontSize = 11.sp, color = Color(0xFF4F46E5), fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }

                // Header right: regional scope badge and feeling
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    com.maeum.social.ui.components.PostRegionalScopeBadge(post.regionalScope)
                    post.feeling?.let { f ->
                        com.maeum.social.ui.components.PostFeelingBadge(f)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Post text
            Text(post.content, style = MaterialTheme.typography.bodyLarge)

            // BGM Player Card if BGM attached
            post.bgm?.let { bgm ->
                Spacer(modifier = Modifier.height(10.dp))
                com.maeum.social.ui.components.BgmPlayerCard(bgm = bgm)
            }

            // Interactive Poll Card if Poll attached
            post.poll?.let { poll ->
                Spacer(modifier = Modifier.height(10.dp))
                com.maeum.social.ui.components.PollCard(
                    poll = poll,
                    currentUserId = currentUserId,
                    onVote = onVote
                )
            }

            // Multiple Videos (supports simultaneous multiple video players)
            if (post.videoUrls.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                post.videoUrls.forEachIndexed { index, videoUrl ->
                    VideoPlayerView(
                        videoUrl = videoUrl,
                        videoId = "${post.id}_v_$index",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .padding(bottom = 8.dp),
                        onSyncBroadcast = onSyncBroadcast,
                        remoteSyncEvent = remoteSyncEvent
                    )
                }
            }

            // Multiple Images
            if (post.mediaUrls.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(post.mediaUrls) { imgUrl ->
                        AsyncImage(
                            model = imgUrl,
                            contentDescription = null,
                            modifier = Modifier
                                .size(140.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Interaction buttons (Like, Comment, Share)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onLike) {
                        Icon(
                            imageVector = if (post.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "좋아요",
                            tint = if (post.isLiked) Color(0xFFE11D48) else Color.Gray
                        )
                    }
                    Text("${post.likesCount}", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.width(16.dp))

                    IconButton(onClick = onClick) {
                        Icon(Icons.Default.ChatBubbleOutline, contentDescription = "댓글", tint = Color.Gray)
                    }
                    Text("${post.commentsCount}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Text(post.createdAt, fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun CreatePostDialog(
    viewModel: SocialViewModel,
    onDismiss: () -> Unit
) {
    var content by remember { mutableStateOf("") }
    val detectedLocation by viewModel.detectedLocation.collectAsState()
    var selectedNeighborhood by remember { mutableStateOf(detectedLocation?.neighborhood ?: "역삼동") }
    var selectedVideos by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedImages by remember { mutableStateOf<List<String>>(emptyList()) }
    var isScheduled by remember { mutableStateOf(false) }

    // Multi-Video Picker launcher
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        selectedVideos = uris.map { it.toString() }
    }

    // Multi-Image Picker launcher
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        selectedImages = uris.map { it.toString() }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("동네 소식 올리기", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    placeholder = { Text("이웃들에게 나눌 이야기나 사진, 동영상을 공유해보세요.") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // GPS & Neighborhood selection
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF4F46E5), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("게시 동네: $selectedNeighborhood", fontSize = 12.sp, color = Color(0xFF4F46E5))
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        viewModel.autoDetectGpsLocation { loc ->
                            selectedNeighborhood = loc.neighborhood
                        }
                    }) {
                        Text("GPS 감지", fontSize = 11.sp)
                    }
                }

                // Multi-Video & Multi-Image pick buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { videoPickerLauncher.launch("video/*") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("동영상 ${selectedVideos.size}개", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { imagePickerLauncher.launch("image/*") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("사진 ${selectedImages.size}개", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Scheduled Post option
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isScheduled, onCheckedChange = { isScheduled = it })
                    Text("예약 전송 (1시간 뒤 자동 공개)", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Submit Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("취소") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (content.isNotBlank() || selectedVideos.isNotEmpty() || selectedImages.isNotEmpty()) {
                                viewModel.createPost(
                                    content = content,
                                    images = selectedImages,
                                    videos = selectedVideos,
                                    neighborhood = selectedNeighborhood,
                                    scheduledAt = if (isScheduled) "1시간 뒤" else null
                                )
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                    ) {
                        Text("게시하기")
                    }
                }
            }
        }
    }

    // Server Sync & Connection Config Dialog
    if (showServerConfigDialog) {
        Dialog(onDismissRequest = { showServerConfigDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "서버 동기화 설정",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color(0xFF1E293B)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "현재 연결 서버: $serverStatusText",
                        fontSize = 12.sp,
                        color = Color(0xFF4F46E5)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        "사용자 지정 서버 URL (실제 기기 Wi-Fi 테스트 등):",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = customServerInput,
                        onValueChange = { customServerInput = it },
                        placeholder = { Text("예: http://192.168.0.10:3000", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = customServerInput.contains("10.0.2.2"),
                            onClick = { customServerInput = "http://10.0.2.2:3000" },
                            label = { Text("에뮬레이터", fontSize = 10.sp) }
                        )
                        FilterChip(
                            selected = customServerInput.contains("127.0.0.1"),
                            onClick = { customServerInput = "http://127.0.0.1:3000" },
                            label = { Text("USB포워드", fontSize = 10.sp) }
                        )
                        FilterChip(
                            selected = customServerInput.isBlank(),
                            onClick = { customServerInput = "" },
                            label = { Text("자동감지", fontSize = 10.sp) }
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showServerConfigDialog = false }) {
                            Text("닫기")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                viewModel.setCustomServerUrl(customServerInput.trim().ifEmpty { null })
                                serverStatusText = viewModel.getServerStatusSummary()
                                showServerConfigDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
                        ) {
                            Text("적용 및 동기화")
                        }
                    }
                }
            }
        }
    }
}
