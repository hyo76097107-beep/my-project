package com.maeum.social.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.gson.Gson
import com.maeum.social.data.local.AppDatabase
import com.maeum.social.model.Post
import com.maeum.social.model.User
import com.maeum.social.network.MediaSyncService
import com.maeum.social.network.MediaUploadManager
import com.maeum.social.network.NetworkSyncManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Worker executed at the end of a video upload chain to finalize the post,
 * update Room DB entities with remote URLs, and sync with the central server.
 */
class PostSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val TAG = "PostSyncWorker"
        const val KEY_POST_ID = "KEY_POST_ID"
        const val CHANNEL_ID = "post_sync_channel"
        const val NOTIFICATION_ID = 4999
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val postId = inputData.getString(KEY_POST_ID) ?: return@withContext Result.failure()
        val db = AppDatabase.getDatabase(applicationContext)
        val postDao = db.postDao()
        val mediaDao = db.mediaUploadDao()
        val gson = Gson()

        try {
            // Dismiss upload ongoing notifications
            val notificationManager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            for (i in 0..15) {
                notificationManager.cancel(VideoUploadWorker.NOTIFICATION_ID_BASE + i)
            }

            val postEntity = postDao.getPostById(postId)
            if (postEntity == null) {
                Log.w(TAG, "PostEntity not found for postId: $postId")
                return@withContext Result.success()
            }

            // Collect all completed upload tasks
            val tasks = mediaDao.getTasksForPost(postId)
            val remoteVideoUrls = tasks.mapNotNull { task ->
                task.remoteUrl ?: task.localUri
            }.filter { it.isNotBlank() }

            val firstThumb = tasks.firstOrNull { it.thumbnailUrl != null }?.thumbnailUrl

            val finalVideoUrls = if (remoteVideoUrls.isNotEmpty()) remoteVideoUrls else {
                gson.fromJson(postEntity.videoUrlsJson, Array<String>::class.java)?.toList() ?: emptyList()
            }

            // Update local Room entity with definitive remote URLs
            val updatedEntity = postEntity.copy(
                videoUrlsJson = gson.toJson(finalVideoUrls)
            )
            postDao.insertPost(updatedEntity)
            Log.d(TAG, "Post $postId updated with ${finalVideoUrls.size} uploaded videos")

            // Sync finalized post to central backend
            val photos = gson.fromJson(updatedEntity.mediaUrlsJson, Array<String>::class.java)?.toList() ?: emptyList()
            val user = User(
                id = updatedEntity.authorId,
                name = updatedEntity.authorName,
                handle = updatedEntity.authorHandle,
                avatar = updatedEntity.authorAvatar
            )

            val syncSuccess = NetworkSyncManager.createPost(
                Post(
                    id = updatedEntity.id,
                    author = user,
                    content = updatedEntity.content,
                    photos = photos,
                    videoUrl = finalVideoUrls.firstOrNull(),
                    videoUrls = finalVideoUrls,
                    videoThumbnail = firstThumb,
                    location = updatedEntity.locationTag,
                    neighborhood = updatedEntity.neighborhood,
                    likesCount = updatedEntity.likesCount,
                    isLiked = updatedEntity.isLiked,
                    commentsCount = updatedEntity.commentsCount,
                    createdAt = updatedEntity.createdAt,
                    scheduledAt = updatedEntity.scheduledAt
                )
            )

            // Mark queue as completed in MediaUploadManager
            MediaUploadManager.markQueueFinished(postId)

            // Safely clean up local cached media files ONLY after confirmed successful sync with server
            MediaUploadManager.cleanupLocalCacheForPost(applicationContext, postId)

            // Broadcast immediate real-time media sync to central database, Web app, and other Android devices
            try {
                MediaSyncService.notifyMediaUploaded(
                    postId = postId,
                    videoUrls = finalVideoUrls,
                    thumbnailUrl = firstThumb,
                    authorId = updatedEntity.authorId
                )
            } catch (syncErr: Exception) {
                Log.w(TAG, "MediaSyncService notification error: ${syncErr.message}")
            }

            // Show completion notification
            sendCompletionNotification(updatedEntity.content, finalVideoUrls.size)

            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "PostSyncWorker error for postId $postId: ${e.message}", e)
            Result.failure()
        }
    }

    private fun sendCompletionNotification(content: String, videoCount: Int) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "게시물 등록 완료",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "동영상 및 게시물이 서버에 정상 등록되었을 때 알림을 보냅니다."
            }
            manager.createNotificationChannel(channel)
        }

        val title = if (videoCount > 1) "동영상 ${videoCount}개 및 게시물이 등록되었습니다! 🎬" else "동영상 게시물이 성공적으로 등록되었습니다! ✨"
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title)
            .setContentText(content.take(60))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        manager.notify(NOTIFICATION_ID, notification)
    }
}
