package com.maeum.social.util

import android.media.MediaCodecInfo
import android.media.MediaCodecInfo.CodecCapabilities
import android.media.MediaCodecInfo.CodecProfileLevel
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build

data class H264ProfileLevel(
    val profileName: String,
    val levelName: String,
    val profileValue: Int,
    val levelValue: Int
)

data class DecoderDetail(
    val name: String,
    val isHardwareAccelerated: Boolean,
    val isSoftwareOnly: Boolean,
    val supportedProfiles: List<String>,
    val maxResolution: String,
    val maxFrameRate: Int,
    val colorFormats: List<String>
)

data class H264CodecDiagnostic(
    val isH264Supported: Boolean,
    val hasHardwareAcceleration: Boolean,
    val primaryDecoderName: String,
    val decoders: List<DecoderDetail>,
    val isBaselineSupported: Boolean,
    val isMainSupported: Boolean,
    val isHighSupported: Boolean,
    val isHigh10Supported: Boolean,
    val maxResolution: String,
    val recommendedExoPlayerProfile: String,
    val isExoPlayerReady: Boolean,
    val diagnosticSummary: String
)

object CodecSupportHelper {

    private const val MIME_H264 = "video/avc"

    /**
     * Inspects Android MediaCodecList to verify H.264/AVC hardware acceleration and profile support.
     */
    fun checkH264CodecSupport(): H264CodecDiagnostic {
        val decoders = mutableListOf<DecoderDetail>()
        var hasHardware = false
        var isBaseline = false
        var isMain = false
        var isHigh = false
        var isHigh10 = false
        var maxWidth = 0
        var maxHeight = 0
        var primaryName = "알 수 없음"

        try {
            val codecList = MediaCodecList(MediaCodecList.ALL_CODECS)
            for (codecInfo in codecList.codecInfos) {
                if (codecInfo.isEncoder) continue

                val types = codecInfo.supportedTypes
                val supportsAvc = types.any { it.equals(MIME_H264, ignoreCase = true) }
                if (!supportsAvc) continue

                val isHw = isCodecHardwareAccelerated(codecInfo)
                val isSw = isCodecSoftwareOnly(codecInfo)
                if (isHw) {
                    hasHardware = true
                }

                if (primaryName == "알 수 없음" || (isHw && !primaryName.startsWith("OMX.qcom") && !primaryName.startsWith("c2."))) {
                    primaryName = codecInfo.name
                }

                val caps = try {
                    codecInfo.getCapabilitiesForType(MIME_H264)
                } catch (_: Exception) {
                    null
                }

                val profileNames = mutableListOf<String>()
                var decoderMaxWidth = 1920
                var decoderMaxHeight = 1080
                var maxFps = 60
                val colorFormats = mutableListOf<String>()

                if (caps != null) {
                    caps.profileLevels?.forEach { pl ->
                        val pName = mapH264ProfileToString(pl.profile)
                        if (!profileNames.contains(pName)) {
                            profileNames.add(pName)
                        }
                        if (pl.profile == CodecProfileLevel.AVCProfileBaseline || pl.profile == CodecProfileLevel.AVCProfileConstrainedBaseline) {
                            isBaseline = true
                        }
                        if (pl.profile == CodecProfileLevel.AVCProfileMain) {
                            isMain = true
                        }
                        if (pl.profile == CodecProfileLevel.AVCProfileHigh) {
                            isHigh = true
                        }
                        if (pl.profile == CodecProfileLevel.AVCProfileHigh10) {
                            isHigh10 = true
                        }
                    }

                    caps.colorFormats?.take(5)?.forEach { cf ->
                        colorFormats.add(mapColorFormatToString(cf))
                    }

                    val videoCaps = caps.videoCapabilities
                    if (videoCaps != null) {
                        try {
                            decoderMaxWidth = videoCaps.supportedWidths.upper
                            decoderMaxHeight = videoCaps.supportedHeights.upper
                            maxFps = videoCaps.supportedFrameRates.upper.toInt()
                        } catch (_: Exception) {}
                    }
                }

                if (decoderMaxWidth > maxWidth) maxWidth = decoderMaxWidth
                if (decoderMaxHeight > maxHeight) maxHeight = decoderMaxHeight

                decoders.add(
                    DecoderDetail(
                        name = codecInfo.name,
                        isHardwareAccelerated = isHw,
                        isSoftwareOnly = isSw,
                        supportedProfiles = profileNames.ifEmpty { listOf("기본 프로파일 (Baseline/Main)") },
                        maxResolution = "${decoderMaxWidth}x${decoderMaxHeight}",
                        maxFrameRate = maxFps,
                        colorFormats = colorFormats.ifEmpty { listOf("YUV420 호환") }
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val isH264Supported = decoders.isNotEmpty()
        val resolutionText = if (maxWidth > 0 && maxHeight > 0) "${maxWidth}x${maxHeight}" else "1920x1080 (FHD)"

        val recommendedProfile = when {
            isHigh -> "H.264 High Profile (Level 4.1-5.1) - 고화질 하드웨어 가속 권장"
            isMain -> "H.264 Main Profile (Level 3.1-4.0) - 안정적 하드웨어 재생 권장"
            isBaseline -> "H.264 Baseline Profile (Level 3.0) - 범용 재생 권장"
            else -> "H.264 AVC 표준 프로파일"
        }

        val summary = buildString {
            if (isH264Supported) {
                append("H.264 코덱 정상 지원 (총 ${decoders.size}개 디코더 발견). ")
                if (hasHardware) {
                    append("GPU 하드웨어 가속 활성화됨 ($primaryName). ")
                } else {
                    append("하드웨어 가속 미지원(소프트웨어 디코딩 동작). ")
                }
                append("ExoPlayer 미디어 재생 준비 완료.")
            } else {
                append("기기에서 H.264 디코더를 찾을 수 없습니다. 미디어 재생 시 호환성 이슈가 발생할 수 있습니다.")
            }
        }

        return H264CodecDiagnostic(
            isH264Supported = isH264Supported,
            hasHardwareAcceleration = hasHardware,
            primaryDecoderName = primaryName,
            decoders = decoders,
            isBaselineSupported = isBaseline,
            isMainSupported = isMain,
            isHighSupported = isHigh,
            isHigh10Supported = isHigh10,
            maxResolution = resolutionText,
            recommendedExoPlayerProfile = recommendedProfile,
            isExoPlayerReady = isH264Supported,
            diagnosticSummary = summary
        )
    }

    private fun isCodecHardwareAccelerated(codecInfo: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return codecInfo.isHardwareAccelerated
        }
        val name = codecInfo.name.lowercase()
        return !name.startsWith("omx.google.") &&
                !name.startsWith("c2.android.") &&
                (name.startsWith("omx.qcom.") ||
                        name.startsWith("omx.exynos.") ||
                        name.startsWith("omx.tegra.") ||
                        name.startsWith("omx.mtk.") ||
                        name.startsWith("omx.intel.") ||
                        name.startsWith("c2.qti.") ||
                        name.startsWith("c2.exynos.") ||
                        name.startsWith("c2.mtk."))
    }

    private fun isCodecSoftwareOnly(codecInfo: MediaCodecInfo): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return codecInfo.isSoftwareOnly
        }
        val name = codecInfo.name.lowercase()
        return name.startsWith("omx.google.") || name.startsWith("c2.android.") || name.contains("sw")
    }

    private fun mapH264ProfileToString(profile: Int): String {
        return when (profile) {
            CodecProfileLevel.AVCProfileBaseline -> "Baseline (기본)"
            CodecProfileLevel.AVCProfileConstrainedBaseline -> "Constrained Baseline (제약 기본)"
            CodecProfileLevel.AVCProfileMain -> "Main (메인)"
            CodecProfileLevel.AVCProfileExtended -> "Extended"
            CodecProfileLevel.AVCProfileHigh -> "High (하이)"
            CodecProfileLevel.AVCProfileHigh10 -> "High 10 (10비트)"
            CodecProfileLevel.AVCProfileHigh422 -> "High 4:2:2"
            CodecProfileLevel.AVCProfileHigh444 -> "High 4:4:4"
            else -> "Profile 0x${Integer.toHexString(profile)}"
        }
    }

    private fun mapColorFormatToString(colorFormat: Int): String {
        return when (colorFormat) {
            CodecCapabilities.COLOR_FormatYUV420Planar -> "YUV420 Planar"
            CodecCapabilities.COLOR_FormatYUV420PackedPlanar -> "YUV420 Packed Planar"
            CodecCapabilities.COLOR_FormatYUV420SemiPlanar -> "YUV420 Semi-Planar (NV12/NV21)"
            CodecCapabilities.COLOR_FormatYUV420Flexible -> "YUV420 Flexible"
            CodecCapabilities.COLOR_FormatSurface -> "Surface Direct (HW 가속)"
            else -> "0x${Integer.toHexString(colorFormat)}"
        }
    }
}
