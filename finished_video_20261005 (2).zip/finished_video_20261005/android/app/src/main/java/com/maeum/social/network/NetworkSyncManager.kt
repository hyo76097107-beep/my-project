package com.maeum.social.network

import android.content.Context
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.maeum.social.model.Comment
import com.maeum.social.model.Post
import com.maeum.social.model.PostMediaItem
import com.maeum.social.model.RegionalScope
import com.maeum.social.model.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

object NetworkSyncManager {

    const val DEV_URL = "https://ais-dev-6smsrauqqgnzjddjo24cqp-179359444246.asia-east1.run.app"
    const val PRE_URL = "https://ais-pre-6smsrauqqgnzjddjo24cqp-179359444246.asia-east1.run.app"
    const val EMULATOR_URL = "http://10.0.2.2:3000"
    const val LOOPBACK_URL = "http://127.0.0.1:3000"

    // Default backend sync URL: automatically detected or fallback
    @Volatile
    var baseUrl: String = EMULATOR_URL

    private var hasAutoDetected = false

    /**
     * Intelligently auto-detects the active, responding backend server.
     * Supports:
     * 1. User-customized IP/URL (from SharedPreferences)
     * 2. Android Emulator host loopback (http://10.0.2.2:3000)
     * 3. ADB reverse port forward (http://127.0.0.1:3000)
     * 4. Pre/Dev Cloud Run instances
     */
    suspend fun autoDetectBaseUrl(context: Context? = null): String = withContext(Dispatchers.IO) {
        if (context != null) {
            val prefs = context.getSharedPreferences("maeum_network_prefs", Context.MODE_PRIVATE)
            val customUrl = prefs.getString("custom_server_url", null)
            if (!customUrl.isNullOrBlank() && checkServerHealth(customUrl)) {
                baseUrl = customUrl.trimEnd('/')
                hasAutoDetected = true
                Log.d("NetworkSyncManager", "Using verified custom backend: $baseUrl")
                return@withContext baseUrl
            }
        }

        // Test candidate URLs in priority order
        val candidates = listOf(
            EMULATOR_URL,
            LOOPBACK_URL,
            PRE_URL,
            DEV_URL
        )

        for (candidate in candidates) {
            if (checkServerHealth(candidate)) {
                baseUrl = candidate.trimEnd('/')
                hasAutoDetected = true
                Log.d("NetworkSyncManager", "Auto-detected active backend: $baseUrl")
                return@withContext baseUrl
            }
        }

        // If candidates fail or offline, keep current baseUrl
        hasAutoDetected = true
        baseUrl
    }

    /**
     * Checks if candidate server URL responds 200 to /api/health without redirect.
     */
    fun checkServerHealth(candidateUrl: String): Boolean {
        return try {
            val cleanUrl = candidateUrl.trimEnd('/')
            val url = URL("$cleanUrl/api/health")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 1500
                readTimeout = 1500
                instanceFollowRedirects = false // Do not treat 302 auth check as healthy
            }
            val code = conn.responseCode
            if (code == 200) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                text.contains("ok") || text.contains("status")
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun setCustomServerUrl(context: Context, customUrl: String?) {
        val prefs = context.getSharedPreferences("maeum_network_prefs", Context.MODE_PRIVATE)
        prefs.edit().apply {
            if (customUrl.isNullOrBlank()) {
                remove("custom_server_url")
            } else {
                putString("custom_server_url", customUrl.trimEnd('/'))
            }
            apply()
        }
        if (!customUrl.isNullOrBlank()) {
            baseUrl = customUrl.trimEnd('/')
        }
    }

    fun getCustomServerUrl(context: Context): String? {
        val prefs = context.getSharedPreferences("maeum_network_prefs", Context.MODE_PRIVATE)
        return prefs.getString("custom_server_url", null)
    }

    fun getServerStatusSummary(): String {
        return when {
            baseUrl.contains("10.0.2.2") -> "에뮬레이터 로컬 (10.0.2.2:3000)"
            baseUrl.contains("127.0.0.1") || baseUrl.contains("localhost") -> "USB 포워드 (localhost:3000)"
            baseUrl.contains("192.168") -> "LAN 서버 (${baseUrl.substringAfter("://")})"
            baseUrl.contains("ais-pre") -> "프리뷰 클라우드"
            baseUrl.contains("ais-dev") -> "개발 클라우드"
            else -> baseUrl.substringAfter("://")
        }
    }

    /**
     * Resolves relative media URLs like /uploads/... to full URLs with baseUrl
     */
    fun resolveMediaUrl(url: String?): String? {
        if (url == null || url.isBlank()) return null
        if (url.startsWith("content://") || url.startsWith("file://") || url.startsWith("asset:///")) {
            return url
        }
        if (url.startsWith("/")) {
            return baseUrl.trimEnd('/') + url
        }
        if (url.startsWith("blob:")) {
            return null
        }
        if (url.contains("localhost:3000") || url.contains("127.0.0.1:3000") || url.contains("10.0.2.2:3000")) {
            val path = url.substringAfter(":3000")
            return baseUrl.trimEnd('/') + (if (path.startsWith("/")) path else "/$path")
        }
        if (url.contains("/uploads/")) {
            val path = url.substring(url.indexOf("/uploads/"))
            return baseUrl.trimEnd('/') + path
        }
        if (url.contains("/videos/")) {
            val path = url.substring(url.indexOf("/videos/"))
            return baseUrl.trimEnd('/') + path
        }
        if (!url.startsWith("http://") && !url.startsWith("https://") && !url.startsWith("data:")) {
            return baseUrl.trimEnd('/') + "/" + url.trimStart('/')
        }
        return url
    }

    /**
     * Uploads a local media file (from Android content:// URI) to the central server
     * so that Web and other Android clients can access and play it directly.
     */
    suspend fun uploadMedia(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        if (!hasAutoDetected) {
            autoDetectBaseUrl(context)
        }

        val uriStr = uri.toString()
        if (uriStr.startsWith("http://") || uriStr.startsWith("https://") || uriStr.startsWith("/uploads/")) {
            return@withContext uriStr
        }

        // 1. Try Multipart upload to /api/sync/upload
        try {
            val contentResolver = context.contentResolver
            val mimeType = contentResolver.getType(uri) ?: if (uriStr.contains("video")) "video/mp4" else "image/jpeg"
            val isVideo = mimeType.startsWith("video/")
            val extension = when {
                mimeType.contains("mp4") -> ".mp4"
                mimeType.contains("webm") -> ".webm"
                mimeType.contains("quicktime") || mimeType.contains("mov") -> ".mov"
                mimeType.contains("png") -> ".png"
                mimeType.contains("webp") -> ".webp"
                isVideo -> ".mp4"
                else -> ".jpg"
            }
            val filename = "upload_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}$extension"
            val boundary = "===Boundary_${System.currentTimeMillis()}==="
            val lineEnd = "\r\n"
            val twoHyphens = "--"

            val url = URL("$baseUrl/api/sync/upload")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 30000
                readTimeout = 60000
                doOutput = true
                doInput = true
                useCaches = false
                setChunkedStreamingMode(64 * 1024)
                setRequestProperty("Connection", "Keep-Alive")
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            val outputStream = DataOutputStream(conn.outputStream)
            outputStream.writeBytes(twoHyphens + boundary + lineEnd)
            outputStream.writeBytes("Content-Disposition: form-data; name=\"files\"; filename=\"$filename\"$lineEnd")
            outputStream.writeBytes("Content-Type: $mimeType$lineEnd")
            outputStream.writeBytes(lineEnd)

            contentResolver.openInputStream(uri)?.use { inputStream ->
                val buffer = ByteArray(16384)
                var bytesRead: Int
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                }
            }
            outputStream.writeBytes(lineEnd)
            outputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd)
            outputStream.flush()
            outputStream.close()

            if (conn.responseCode in 200..299) {
                val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(responseText)
                if (json.optBoolean("success")) {
                    val urls = json.optJSONArray("urls")
                    if (urls != null && urls.length() > 0) {
                        return@withContext urls.getString(0)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("NetworkSyncManager", "Multipart upload failed: ${e.message}")
        }

        // 2. Fallback to Base64 upload to /api/sync/upload-base64
        try {
            val contentResolver = context.contentResolver
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null && bytes.size < 15 * 1024 * 1024) {
                val mimeType = contentResolver.getType(uri) ?: "video/mp4"
                val base64Data = "data:$mimeType;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
                val url = URL("$baseUrl/api/sync/upload-base64")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 30000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                val body = JSONObject().apply {
                    put("name", "media_${System.currentTimeMillis()}.${if (mimeType.contains("video")) "mp4" else "jpg"}")
                    put("type", mimeType)
                    put("data", base64Data)
                }
                OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
                if (conn.responseCode in 200..299) {
                    val res = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(res)
                    if (json.optBoolean("success")) {
                        return@withContext json.optString("url")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("NetworkSyncManager", "Base64 upload failed: ${e.message}")
        }

        uriStr
    }

    /**
     * Fetches current real-time posts from the centralized server
     */
    suspend fun fetchPosts(): List<Post>? = withContext(Dispatchers.IO) {
        if (!hasAutoDetected) {
            autoDetectBaseUrl()
        }
        try {
            val url = URL("$baseUrl/api/sync/state")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty("Accept", "application/json")
            }

            if (conn.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(conn.inputStream))
                val response = reader.readText()
                reader.close()

                val json = JSONObject(response)
                if (json.optBoolean("success")) {
                    val data = json.optJSONObject("data")
                    val postsArray = data?.optJSONArray("posts") ?: JSONArray()
                    val result = mutableListOf<Post>()

                    for (i in 0 until postsArray.length()) {
                        val p = postsArray.getJSONObject(i)
                        val author = User(
                            id = p.optString("authorId", "user_1"),
                            name = p.optString("authorName", "회원"),
                            handle = p.optString("authorHandle", "user"),
                            avatar = resolveMediaUrl(p.optString("authorAvatar", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200")) ?: "",
                            isVerified = p.optBoolean("authorVerified", false)
                        )

                        // 1. Parse mediaItems (Instagram carousel items)
                        val mediaItemsList = mutableListOf<PostMediaItem>()
                        val mediaItemsArr = p.optJSONArray("mediaItems")
                        if (mediaItemsArr != null) {
                            for (j in 0 until mediaItemsArr.length()) {
                                val mObj = mediaItemsArr.getJSONObject(j)
                                val itemUrl = resolveMediaUrl(mObj.optString("url", "")) ?: ""
                                val itemThumb = resolveMediaUrl(mObj.optString("thumbnail", null))
                                if (itemUrl.isNotBlank()) {
                                    mediaItemsList.add(
                                        PostMediaItem(
                                            id = mObj.optString("id", "media_$j"),
                                            type = mObj.optString("type", "image"),
                                            url = itemUrl,
                                            thumbnail = itemThumb
                                        )
                                    )
                                }
                            }
                        }

                        // 2. Parse videoUrls and video
                        val videoUrlsList = mutableListOf<String>()
                        val videoUrlsArr = p.optJSONArray("videoUrls")
                        if (videoUrlsArr != null) {
                            for (j in 0 until videoUrlsArr.length()) {
                                val vUrl = resolveMediaUrl(videoUrlsArr.getString(j))
                                if (vUrl != null && !videoUrlsList.contains(vUrl)) {
                                    videoUrlsList.add(vUrl)
                                }
                            }
                        }
                        mediaItemsList.filter { it.type == "video" }.forEach {
                            if (!videoUrlsList.contains(it.url)) {
                                videoUrlsList.add(it.url)
                            }
                        }

                        val singleVideoRaw = p.optString("video", null)?.takeIf { it.isNotBlank() && it != "null" }
                        val singleVideo = resolveMediaUrl(singleVideoRaw)
                        if (singleVideo != null && !videoUrlsList.contains(singleVideo)) {
                            videoUrlsList.add(0, singleVideo)
                        }

                        // 3. Parse photos and images
                        val photosList = mutableListOf<String>()
                        val imagesArr = p.optJSONArray("images")
                        if (imagesArr != null) {
                            for (j in 0 until imagesArr.length()) {
                                val pUrl = resolveMediaUrl(imagesArr.getString(j))
                                if (pUrl != null && !photosList.contains(pUrl)) {
                                    photosList.add(pUrl)
                                }
                            }
                        }
                        mediaItemsList.filter { it.type == "image" }.forEach {
                            if (!photosList.contains(it.url)) {
                                photosList.add(it.url)
                            }
                        }

                        val finalVideoUrl = videoUrlsList.firstOrNull() ?: singleVideo

                        val scopeStr = p.optString("regionalScope", "national")
                        val regionalScope = when (scopeStr) {
                            "neighborhood" -> RegionalScope.NEIGHBORHOOD
                            "city" -> RegionalScope.CITY
                            "province" -> RegionalScope.PROVINCE
                            else -> RegionalScope.ALL
                        }

                        result.add(
                            Post(
                                id = p.optString("id"),
                                author = author,
                                content = p.optString("content"),
                                photos = photosList,
                                videoUrl = finalVideoUrl,
                                videoUrls = videoUrlsList,
                                videoThumbnail = resolveMediaUrl(p.optString("videoThumbnail", null)),
                                mediaItems = mediaItemsList,
                                location = p.optString("location", null),
                                regionalScope = regionalScope,
                                feeling = p.optString("feeling", null),
                                likesCount = p.optJSONArray("likes")?.length() ?: p.optInt("likesCount", 0),
                                commentsCount = p.optInt("commentsCount", 0),
                                createdAt = p.optString("createdAt", "방금 전"),
                                scheduledAt = p.optString("scheduledAt", null)
                            )
                        )
                    }
                    return@withContext result
                }
            }
            null
        } catch (e: Exception) {
            Log.e("NetworkSyncManager", "Failed to fetch posts: ${e.message}")
            null
        }
    }

    /**
     * Publishes a post to the central server so all mobile devices receive it
     */
    suspend fun createPost(post: Post): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = URL("$baseUrl/api/sync/posts")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 5000
                readTimeout = 5000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }

            val body = JSONObject().apply {
                put("id", post.id)
                put("authorId", post.author.id)
                put("authorName", post.author.name)
                put("authorHandle", post.author.handle)
                put("authorAvatar", post.author.avatar)
                put("content", post.content)
                put("location", post.location)
                put("regionalScope", post.regionalScope.name.lowercase())
                put("feeling", post.feeling)
                put("createdAt", post.createdAt)
                put("likes", JSONArray())
                put("images", JSONArray(post.photos))
                if (post.videoUrl != null) put("video", post.videoUrl)
                if (post.videoUrls.isNotEmpty()) put("videoUrls", JSONArray(post.videoUrls))
                if (post.videoThumbnail != null) put("videoThumbnail", post.videoThumbnail)

                val mediaItemsArr = JSONArray()
                if (post.mediaItems.isNotEmpty()) {
                    post.mediaItems.forEach { item ->
                        val obj = JSONObject().apply {
                            put("id", item.id)
                            put("type", item.type)
                            put("url", item.url)
                            if (item.thumbnail != null) put("thumbnail", item.thumbnail)
                        }
                        mediaItemsArr.put(obj)
                    }
                } else {
                    post.videoUrls.forEachIndexed { idx, vUrl ->
                        val obj = JSONObject().apply {
                            put("id", "media_vid_${post.id}_$idx")
                            put("type", "video")
                            put("url", vUrl)
                        }
                        mediaItemsArr.put(obj)
                    }
                    post.photos.forEachIndexed { idx, pUrl ->
                        val obj = JSONObject().apply {
                            put("id", "media_img_${post.id}_$idx")
                            put("type", "image")
                            put("url", pUrl)
                        }
                        mediaItemsArr.put(obj)
                    }
                }
                if (mediaItemsArr.length() > 0) {
                    put("mediaItems", mediaItemsArr)
                }
            }

            val writer = OutputStreamWriter(conn.outputStream)
            writer.write(body.toString())
            writer.flush()
            writer.close()

            conn.responseCode in 200..299
        } catch (e: Exception) {
            Log.e("NetworkSyncManager", "Failed to sync createPost: ${e.message}")
            false
        }
    }

    /**
     * Toggles like on the central server
     */
    suspend fun toggleLike(postId: String, userId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = URL("$baseUrl/api/sync/posts/$postId/like")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "PUT"
                connectTimeout = 5000
                readTimeout = 5000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }

            val body = JSONObject().apply {
                put("userId", userId)
            }

            val writer = OutputStreamWriter(conn.outputStream)
            writer.write(body.toString())
            writer.flush()
            writer.close()

            conn.responseCode in 200..299
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Posts comment or voice comment to central server
     */
    suspend fun addComment(
        postId: String,
        author: User,
        content: String,
        parentId: String? = null,
        audioUrl: String? = null,
        audioDuration: Int? = null
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = URL("$baseUrl/api/sync/posts/$postId/comments")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 5000
                readTimeout = 5000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }

            val body = JSONObject().apply {
                put("id", "comm_${System.currentTimeMillis()}")
                put("postId", postId)
                put("authorId", author.id)
                put("authorName", author.name)
                put("authorHandle", author.handle)
                put("authorAvatar", author.avatar)
                put("content", content)
                if (parentId != null) put("parentId", parentId)
                if (audioUrl != null) put("audioUrl", audioUrl)
                if (audioDuration != null) put("audioDuration", audioDuration)
                put("createdAt", "방금 전")
                put("likes", JSONArray())
            }

            val writer = OutputStreamWriter(conn.outputStream)
            writer.write(body.toString())
            writer.flush()
            writer.close()

            conn.responseCode in 200..299
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Deletes a post on the central backend server
     */
    suspend fun deletePost(postId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = URL("$baseUrl/api/sync/posts/$postId")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "DELETE"
                connectTimeout = 5000
                readTimeout = 5000
            }
            conn.responseCode in 200..299
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Toggles follow / unfollow on the central backend server
     */
    suspend fun toggleFollow(
        currentUserId: String,
        targetUserId: String,
        currentUser: User? = null,
        targetName: String? = null,
        targetHandle: String? = null
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = URL("$baseUrl/api/sync/users/$targetUserId/follow")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 5000
                readTimeout = 5000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }

            val body = JSONObject().apply {
                put("currentUserId", currentUserId)
                if (currentUser != null) {
                    val userObj = JSONObject().apply {
                        put("id", currentUser.id)
                        put("name", currentUser.name)
                        put("handle", currentUser.handle)
                        put("avatar", currentUser.avatar)
                    }
                    put("currentUser", userObj)
                }
                if (targetName != null) put("targetName", targetName)
                if (targetHandle != null) put("targetHandle", targetHandle)
            }

            val writer = OutputStreamWriter(conn.outputStream)
            writer.write(body.toString())
            writer.flush()
            writer.close()

            conn.responseCode in 200..299
        } catch (e: Exception) {
            false
        }
    }
}
