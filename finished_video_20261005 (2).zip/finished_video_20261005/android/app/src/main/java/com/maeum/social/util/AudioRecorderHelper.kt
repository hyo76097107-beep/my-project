package com.maeum.social.util

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import java.io.IOException

class AudioRecorderHelper(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var currentOutputFile: File? = null
    private var recordingStartTime: Long = 0L

    fun startRecording(): File? {
        val audioDir = File(context.cacheDir, "voice_comments").apply { mkdirs() }
        val file = File(audioDir, "voice_${System.currentTimeMillis()}.m4a")
        currentOutputFile = file

        recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(128000)
            setAudioSamplingRate(44100)
            setOutputFile(file.absolutePath)
            try {
                prepare()
                start()
                recordingStartTime = System.currentTimeMillis()
            } catch (e: IOException) {
                e.printStackTrace()
                return null
            }
        }
        return file
    }

    fun stopRecording(): Pair<File?, Int> {
        val durationSec = ((System.currentTimeMillis() - recordingStartTime) / 1000).toInt().coerceAtLeast(1)
        try {
            recorder?.stop()
            recorder?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            recorder = null
        }
        return Pair(currentOutputFile, durationSec)
    }

    fun playAudio(filePath: String, onComplete: () -> Unit = {}) {
        stopAudio()
        player = MediaPlayer().apply {
            try {
                setDataSource(filePath)
                prepare()
                start()
                setOnCompletionListener {
                    onComplete()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun stopAudio() {
        try {
            player?.stop()
            player?.release()
        } catch (e: Exception) {
            // ignore
        } finally {
            player = null
        }
    }

    fun isPlaying(): Boolean {
        return player?.isPlaying ?: false
    }
}
