package com.maeum.social.network

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Base64
import android.util.Log
import androidx.work.*
import com.maeum.social.data.local.AppDatabase
import com.maeum.social.data.local.MediaUploadTaskEntity
import com.maeum.social.data.local.UploadStatus
import com.maeum.social.worker.PostSyncWorker
import com.maeum.social.worker.VideoUploadWorker
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.*
import java.util.UUID
import java.util.concurrent.TimeUnit

/**
 * Result data class for an uploaded media item
 */
data class UploadedMediaResult(
    val localUri: String,
    val remoteUrl: String,
    val thumbnailUrl: String? = null,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val fileSize: Long = 0L,
    val isSuccess: Boolean = true,
    val errorMessage: String? = null
)

/**
 * Real-time Upload Progress info for UI observation
 */
data class MediaUploadProgress(
    val taskId: String,
    val localUri: String,
    val progress: Int, // 0..100
    val status: UploadStatus,
    val remoteUrl: String? = null,
    val errorMessage: String? = null
)

/**
 * High-level WorkManager queue status for posts with multiple attached videos.
 * Allows UI and ViewModel to display real-time queue progress (e.g. 2/4 videos, 65%).
 */
data class UploadQueueInfo(
    val postId: String,
    val totalCount: Int,
    val currentIndex: Int,
    val currentProgress: Int,
    val overallProgress: Int, // 0..100 across all videos in the post
    val isFinished: Boolean = false,
    val isFailed: Boolean = false
)

/**
 * Result data class returned from media cache cleanup operations
 */
data class MediaCleanupResult(
    val deletedDbRecords: Int,
    val deletedFilesCount: Int,
    val freedBytes: Long,
    val success: Boolean = true,
    val errorMessage: String? = null
)

/**
 * Singleton MediaUploadManager that coordinates compression, chunked streaming,
 * sequential WorkManager background queueing, Room DB real-time synchronization,
 * and automatic media cache cleanup/optimization for multi-video attachments.
 */
object MediaUploadManager {

    private const val TAG = "MediaUploadManager"
    private const val DEFAULT_CHUNK_SIZE = 1024 * 1024 // 1 MB per chunk for reliable mobile transport
    private const val MAX_CONCURRENT_UPLOADS = 2 // Limits simultaneous video uploads to avoid network timeout

    // Default cache retention: 7 days
    const val DEFAULT_CACHE_RETENTION_DAYS = 7L
    const val DEFAULT_CACHE_RETENTION_MILLIS = DEFAULT_CACHE_RETENTION_DAYS * 24 * 60 * 60 * 1000L

    // Coroutine concurrency limiter
    private val uploadSemaphore = Semaphore(MAX_CONCURRENT_UPLOADS)

    // Dedicated OkHttpClient with extended timeouts to prevent socket drops on Android
    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    // In-memory real-time progress state map (taskId -> MediaUploadProgress)
    private val _uploadProgressMap = MutableStateFlow<Map<String, MediaUploadProgress>>(emptyMap())
    val uploadProgressMap: StateFlow<Map<String, MediaUploadProgress>> = _uploadProgressMap.asStateFlow()

    // WorkManager queue status map (postId -> UploadQueueInfo)
    private val _queueProgressMap = MutableStateFlow<Map<String, UploadQueueInfo>>(emptyMap())
    val queueProgressMap: StateFlow<Map<String, UploadQueueInfo>> = _queueProgressMap.asStateFlow()

    /**
     * Updates background queue progress for a post
     */
    fun updateQueueProgress(postId: String, index: Int, totalCount: Int, progress: Int) {
        val overall = if (totalCount > 0) {
            val base = ((index - 1) * 100) / totalCount
            val contribution = progress / totalCount
            (base + contribution).coerceIn(0, 100)
        } else progress

        val info = UploadQueueInfo(
            postId = postId,
            totalCount = totalCount,
            currentIndex = index,
            currentProgress = progress,
            overallProgress = overall,
            isFinished = false,
            isFailed = false
        )
        _queueProgressMap.value = _queueProgressMap.value + (postId to info)
    }

    /**
     * Marks background queue finished for a post
     */
    fun markQueueFinished(postId: String) {
        val current = _queueProgressMap.value[postId]
        if (current != null) {
            _queueProgressMap.value = _queueProgressMap.value + (postId to current.copy(
                currentProgress = 100,
                overallProgress = 100,
                isFinished = true
            ))
        }
    }

    /**
     * Dedicated persistent local cache directory for storing media files
     * until they are confirmed to be uploaded and synchronized with the backend.
     * Saved in internal storage (filesDir) so it survives cache evictions and offline restarts.
     */
    fun getLocalCacheDir(context: Context): File {
        val cacheDir = File(context.filesDir, "media_upload_cache")
        if (!cacheDir.exists()) cacheDir.mkdirs()
        return cacheDir
    }

    /**
     * Caches a media file from transient content:// or file:// URI into persistent app storage.
     * Guarantees the raw bytes remain safe and accessible offline across device reboots.
     */
    fun cacheMediaFileLocally(context: Context, uri: Uri, taskId: String): File? {
        return try {
            val dir = getLocalCacheDir(context)
            val destFile = File(dir, "cached_${taskId}.mp4")
            if (destFile.exists() && destFile.length() > 0) {
                return destFile
            }
            val uriStr = uri.toString()
            if (uriStr.startsWith("file://")) {
                val srcFile = File(uri.path ?: uriStr.removePrefix("file://"))
                if (srcFile.exists()) {
                    srcFile.copyTo(destFile, overwrite = true)
                    return destFile
                }
            }
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    val buffer = ByteArray(65536)
                    var bytesRead: Int
                    while (input.read(buffer).also { bytesRead = it } != -1) {
                        output.write(buffer, 0, bytesRead)
                    }
                    output.flush()
                    output.fd.sync()
                }
            }
            if (destFile.exists() && destFile.length() > 0) destFile else null
        } catch (e: Exception) {
            Log.e(TAG, "Failed to cache media locally for $taskId: ${e.message}", e)
            null
        }
    }

    /**
     * Resolves or creates a persistent local cached copy of a media file.
     * Guarantees that even if original content:// URI permissions expire or device reboots,
     * the raw file remains safely stored in local internal cache.
     */
    fun resolveOrCacheLocalFile(
        context: Context,
        uri: Uri,
        taskId: String,
        cachedPath: String? = null,
        dao: com.maeum.social.data.local.MediaUploadDao? = null
    ): File {
        // 1. If cachedPath parameter points to an existing file, use it
        if (!cachedPath.isNullOrBlank()) {
            val f = File(cachedPath)
            if (f.exists() && f.length() > 0) return f
        }

        // 2. Check the deterministic persistent cache destination
        val dir = getLocalCacheDir(context)
        val destFile = File(dir, "cached_${taskId}.mp4")
        if (destFile.exists() && destFile.length() > 0) {
            return destFile
        }

        // 3. Cache from source URI into persistent internal storage
        val cached = cacheMediaFileLocally(context, uri, taskId)
        if (cached != null && cached.exists() && cached.length() > 0) {
            if (dao != null) {
                runBlocking(Dispatchers.IO) {
                    try {
                        dao.updateCachedPath(taskId, cached.absolutePath)
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to update Room DB cached path for $taskId: ${e.message}")
                    }
                }
            }
            return cached
        }

        // 4. Fallback if URI itself is a file:// scheme
        val uriStr = uri.toString()
        if (uriStr.startsWith("file://")) {
            val f = File(uri.path ?: uriStr.removePrefix("file://"))
            if (f.exists() && f.length() > 0) return f
        }

        throw IOException("로컬 캐시 파일을 생성하거나 불러올 수 없습니다: $uri")
    }

    /**
     * Checks if a media item is already safely cached in local persistent storage.
     */
    fun isLocallyCached(context: Context, taskId: String): Boolean {
        val dir = getLocalCacheDir(context)
        val file = File(dir, "cached_${taskId}.mp4")
        return file.exists() && file.length() > 0
    }

    /**
     * Retrieves the local cached file for a task if present.
     */
    fun getLocalCachedFile(context: Context, taskId: String): File? {
        val dir = getLocalCacheDir(context)
        val file = File(dir, "cached_${taskId}.mp4")
        return if (file.exists() && file.length() > 0) file else null
    }

    /**
     * Safely deletes local cached media file after successful synchronization with server.
     */
    fun cleanupLocalCache(context: Context, taskId: String) {
        try {
            val dir = getLocalCacheDir(context)
            val target = File(dir, "cached_${taskId}.mp4")
            if (target.exists()) {
                target.delete()
                Log.d(TAG, "Cleaned up local cached media file: ${target.name}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to cleanup local cache for task $taskId: ${e.message}")
        }
    }

    /**
     * Deletes all local cached files associated with a post once synchronized.
     */
    fun cleanupLocalCacheForPost(context: Context, postId: String) {
        val db = AppDatabase.getDatabase(context)
        val dao = db.mediaUploadDao()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val tasks = dao.getTasksForPost(postId)
                tasks.forEach { task ->
                    task.localCachedPath?.let { path ->
                        val f = File(path)
                        if (f.exists()) f.delete()
                    }
                    cleanupLocalCache(context, task.id)
                }
                Log.d(TAG, "Cleaned up local cached media files for synchronized post $postId")
            } catch (e: Exception) {
                Log.w(TAG, "Failed to cleanup local cache for post $postId: ${e.message}")
            }
        }
    }

    /**
     * Clears all local cached media files (useful on user logout or storage maintenance).
     */
    fun clearAllLocalCaches(context: Context) {
        try {
            val dir = getLocalCacheDir(context)
            dir.listFiles()?.forEach { file ->
                if (file.isFile) file.delete()
            }
            Log.d(TAG, "Cleared all files in local media cache directory")
        } catch (e: Exception) {
            Log.w(TAG, "Failed to clear local media cache: ${e.message}")
        }
    }

    /**
     * Calculates the total size in bytes of currently cached media files in persistent cache directory.
     */
    fun calculateMediaCacheSize(context: Context): Long {
        val dir = getLocalCacheDir(context)
        return dir.listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L
    }

    /**
     * Automatically cleans up temporary media cache files from storage and records from Room DB:
     * 1. Successfully uploaded tasks (status = COMPLETED)
     * 2. Cancelled tasks (status = CANCELLED)
     * 3. Tasks and temporary files older than the retention period (default: 7 days)
     * 4. Orphaned cached files on disk that have no active tasks in Room DB
     *
     * @param context Application context
     * @param retentionMillis Retention window in milliseconds (default: 7 days)
     * @param deleteCompletedImmediately Whether completed upload caches should be purged immediately (default: true)
     */
    suspend fun cleanExpiredAndCompletedCache(
        context: Context,
        retentionMillis: Long = DEFAULT_CACHE_RETENTION_MILLIS,
        deleteCompletedImmediately: Boolean = true
    ): MediaCleanupResult = withContext(Dispatchers.IO) {
        val db = AppDatabase.getDatabase(context)
        val dao = db.mediaUploadDao()
        val cacheDir = getLocalCacheDir(context)
        val now = System.currentTimeMillis()
        val cutoffTimestamp = now - retentionMillis

        var deletedFiles = 0
        var freedBytes = 0L
        var deletedRecords = 0

        try {
            // 1. Fetch cleanup candidate tasks from Room DB
            val candidateTasks = dao.getCleanupCandidateTasks(cutoffTimestamp)
            val idsToDelete = mutableListOf<String>()

            for (task in candidateTasks) {
                val shouldDelete = when (task.status) {
                    UploadStatus.COMPLETED.name -> deleteCompletedImmediately || task.updatedAt < cutoffTimestamp
                    UploadStatus.CANCELLED.name -> true
                    else -> task.createdAt < cutoffTimestamp // Expired pending/failed task older than 7 days
                }

                if (shouldDelete) {
                    // Delete local cached file
                    task.localCachedPath?.let { path ->
                        val f = File(path)
                        if (f.exists()) {
                            val size = f.length()
                            if (f.delete()) {
                                deletedFiles++
                                freedBytes += size
                            }
                        }
                    }

                    // Delete standard cached file if exists
                    val standardFile = File(cacheDir, "cached_${task.id}.mp4")
                    if (standardFile.exists()) {
                        val size = standardFile.length()
                        if (standardFile.delete()) {
                            deletedFiles++
                            freedBytes += size
                        }
                    }

                    idsToDelete.add(task.id)
                }
            }

            // Remove task entities from Room DB
            if (idsToDelete.isNotEmpty()) {
                dao.deleteTasksByIds(idsToDelete)
                deletedRecords = idsToDelete.size
            }

            // 2. Scan media_upload_cache directory for orphaned or expired files
            val pendingTaskIds = dao.getPendingTasks().map { it.id }.toSet()
            val dirFiles = cacheDir.listFiles() ?: emptyArray()

            for (file in dirFiles) {
                if (!file.isFile) continue

                val lastModified = file.lastModified()
                val isOlderThanRetention = (now - lastModified) > retentionMillis

                val isCachedPattern = file.name.startsWith("cached_") && file.name.endsWith(".mp4")
                val extractedTaskId = if (isCachedPattern) {
                    file.name.removePrefix("cached_").removeSuffix(".mp4")
                } else null

                val isOrphaned = extractedTaskId != null && !pendingTaskIds.contains(extractedTaskId)

                if (isOlderThanRetention || isOrphaned) {
                    val size = file.length()
                    if (file.delete()) {
                        deletedFiles++
                        freedBytes += size
                        Log.d(TAG, "Deleted orphaned/expired cache file: ${file.name} (${size / 1024} KB)")
                    }
                }
            }

            // 3. Clean up any temporary opt_ files in app cacheDir older than retention (or older than 1 day)
            context.cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("opt_") && (now - file.lastModified()) > (24 * 60 * 60 * 1000L)) {
                    val size = file.length()
                    if (file.delete()) {
                        deletedFiles++
                        freedBytes += size
                    }
                }
            }

            Log.i(
                TAG,
                "Media cache cleanup finished: $deletedRecords DB records deleted, $deletedFiles files deleted, ${freedBytes / (1024 * 1024)} MB freed"
            )

            MediaCleanupResult(
                deletedDbRecords = deletedRecords,
                deletedFilesCount = deletedFiles,
                freedBytes = freedBytes,
                success = true
            )
        } catch (e: Exception) {
            Log.e(TAG, "Media cache cleanup error: ${e.message}", e)
            MediaCleanupResult(
                deletedDbRecords = deletedRecords,
                deletedFilesCount = deletedFiles,
                freedBytes = freedBytes,
                success = false,
                errorMessage = e.message
            )
        }
    }

    /**
     * Schedules a periodic background WorkManager task to automatically clean up
     * expired media cache files (> 7 days) and completed upload records daily.
     */
    fun schedulePeriodicCacheCleanup(context: Context) {
        val workManager = WorkManager.getInstance(context)
        val cleanupRequest = PeriodicWorkRequestBuilder<com.maeum.social.worker.MediaCacheCleanupWorker>(
            repeatInterval = 1,
            repeatIntervalTimeUnit = TimeUnit.DAYS
        )
            .setConstraints(
                Constraints.Builder()
                    .setRequiresBatteryNotLow(true)
                    .build()
            )
            .addTag("media_cache_cleanup")
            .build()

        workManager.enqueueUniquePeriodicWork(
            com.maeum.social.worker.MediaCacheCleanupWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            cleanupRequest
        )
        Log.d(TAG, "Enqueued periodic media cache cleanup worker (daily, 7-day retention)")
    }

    /**
     * Recovers and resumes any unfinished upload queues from Room DB.
     * Preserves offline upload queue safety after app restart or device reboot.
     */
    suspend fun resumePendingUploadQueues(context: Context) = withContext(Dispatchers.IO) {
        try {
            val db = AppDatabase.getDatabase(context)
            val dao = db.mediaUploadDao()
            val pendingTasks = dao.getAllUnfinishedTasks()
            if (pendingTasks.isEmpty()) return@withContext

            Log.i(TAG, "Found ${pendingTasks.size} unfinished media upload tasks. Validating local cache and resuming queue...")
            val workManager = WorkManager.getInstance(context)
            val groupedByPost = pendingTasks.groupBy { it.postId ?: "orphan" }

            groupedByPost.forEach { (postId, tasks) ->
                if (postId == "orphan") return@forEach

                val workInfos = try {
                    workManager.getWorkInfosForUniqueWork("post_upload_$postId").get()
                } catch (_: Exception) {
                    emptyList()
                }

                val isAlreadyActive = workInfos.any {
                    it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.ENQUEUED
                }

                if (!isAlreadyActive) {
                    Log.i(TAG, "Resuming offline upload queue for post $postId (${tasks.size} tasks)...")
                    val constraints = Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()

                    val totalCount = tasks.size
                    val uploadRequests = tasks.mapIndexed { index, task ->
                        // Ensure local cache exists; if not, re-cache from localUri
                        val effectiveCachedPath = if (!task.localCachedPath.isNullOrBlank() && File(task.localCachedPath).exists()) {
                            task.localCachedPath
                        } else {
                            try {
                                val reCached = cacheMediaFileLocally(context, Uri.parse(task.localUri), task.id)
                                reCached?.absolutePath?.also { path ->
                                    dao.updateCachedPath(task.id, path)
                                } ?: task.localCachedPath
                            } catch (_: Exception) {
                                task.localCachedPath
                            }
                        }

                        val inputData = workDataOf(
                            VideoUploadWorker.KEY_TASK_ID to task.id,
                            VideoUploadWorker.KEY_POST_ID to postId,
                            VideoUploadWorker.KEY_LOCAL_URI to task.localUri,
                            VideoUploadWorker.KEY_CACHED_PATH to (effectiveCachedPath ?: ""),
                            VideoUploadWorker.KEY_FILE_NAME to task.fileName,
                            VideoUploadWorker.KEY_INDEX to (index + 1),
                            VideoUploadWorker.KEY_TOTAL_COUNT to totalCount
                        )

                        OneTimeWorkRequestBuilder<VideoUploadWorker>()
                            .setConstraints(constraints)
                            .setInputData(inputData)
                            .addTag("video_upload")
                            .addTag("post_$postId")
                            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                            .build()
                    }

                    val postSyncRequest = OneTimeWorkRequestBuilder<PostSyncWorker>()
                        .setConstraints(constraints)
                        .setInputData(workDataOf(PostSyncWorker.KEY_POST_ID to postId))
                        .addTag("post_sync")
                        .addTag("post_$postId")
                        .build()

                    if (uploadRequests.isNotEmpty()) {
                        var continuation = workManager.beginUniqueWork(
                            "post_upload_$postId",
                            ExistingWorkPolicy.KEEP,
                            uploadRequests.first()
                        )
                        for (i in 1 until uploadRequests.size) {
                            continuation = continuation.then(uploadRequests[i])
                        }
                        continuation.then(postSyncRequest).enqueue()
                        Log.i(TAG, "Successfully re-enqueued offline work queue for post $postId")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error resuming pending upload queues: ${e.message}", e)
        }
    }

    /**
     * Enqueues multiple video uploads to the Android WorkManager background queue.
     * Uses a sequential WorkContinuation queue pipeline to completely eliminate
     * CPU, memory, and network upload bottlenecks when attaching multiple videos.
     * Caches files locally into persistent internal storage so that upload queues
     * are 100% preserved offline and across device reboots.
     */
    fun enqueueBackgroundUpload(
        context: Context,
        videoUris: List<Uri>,
        postId: String
    ): List<String> {
        if (videoUris.isEmpty()) return emptyList()

        val db = AppDatabase.getDatabase(context)
        val dao = db.mediaUploadDao()
        val totalCount = videoUris.size

        // 1. Immediately cache each media file into persistent internal storage
        // to guarantee zero data loss and offline preservation across reboots
        val cachedTasks = mutableListOf<MediaUploadTaskEntity>()
        val cachedFileUrls = mutableListOf<String>()

        for ((index, uri) in videoUris.withIndex()) {
            val uriStr = uri.toString()
            val taskId = "upload_${System.currentTimeMillis()}_${index}_${UUID.randomUUID().toString().take(6)}"
            val fileName = "video_${index + 1}_${System.currentTimeMillis()}.mp4"

            // Cache file locally into persistent internal storage
            val cachedFile = cacheMediaFileLocally(context, uri, taskId)
            val cachedPath = cachedFile?.absolutePath
            val fileSize = cachedFile?.length() ?: 0L

            cachedTasks.add(
                MediaUploadTaskEntity(
                    id = taskId,
                    postId = postId,
                    localUri = uriStr,
                    localCachedPath = cachedPath,
                    fileName = fileName,
                    fileSize = fileSize,
                    mediaType = "video/mp4",
                    status = UploadStatus.QUEUED.name,
                    progress = 0
                )
            )

            if (cachedPath != null) {
                cachedFileUrls.add("file://$cachedPath")
            } else {
                cachedFileUrls.add(uriStr)
            }
        }

        // Store tasks in Room DB and update PostEntity video URLs with local cached paths
        // so offline playback works immediately
        runBlocking(Dispatchers.IO) {
            dao.insertTasks(cachedTasks)

            if (cachedFileUrls.isNotEmpty()) {
                val postDao = db.postDao()
                val post = postDao.getPostById(postId)
                if (post != null) {
                    val gson = com.google.gson.Gson()
                    postDao.insertPost(post.copy(videoUrlsJson = gson.toJson(cachedFileUrls)))
                }
            }
        }

        cachedTasks.forEach { task ->
            updateInMemoryProgress(task.id, task.localUri, 0, UploadStatus.QUEUED)
        }

        // Initialize queue progress info
        updateQueueProgress(postId, 1, totalCount, 0)

        // 2. Build WorkManager requests with network constraint
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val workManager = WorkManager.getInstance(context)

        val uploadRequests = cachedTasks.mapIndexed { index, task ->
            val inputData = workDataOf(
                VideoUploadWorker.KEY_TASK_ID to task.id,
                VideoUploadWorker.KEY_POST_ID to postId,
                VideoUploadWorker.KEY_LOCAL_URI to task.localUri,
                VideoUploadWorker.KEY_CACHED_PATH to (task.localCachedPath ?: ""),
                VideoUploadWorker.KEY_FILE_NAME to task.fileName,
                VideoUploadWorker.KEY_INDEX to (index + 1),
                VideoUploadWorker.KEY_TOTAL_COUNT to totalCount
            )

            OneTimeWorkRequestBuilder<VideoUploadWorker>()
                .setConstraints(constraints)
                .setInputData(inputData)
                .addTag("video_upload")
                .addTag("post_$postId")
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                .build()
        }

        // 3. PostSyncWorker executes once all videos in queue are finished
        val postSyncRequest = OneTimeWorkRequestBuilder<PostSyncWorker>()
            .setConstraints(constraints)
            .setInputData(workDataOf(PostSyncWorker.KEY_POST_ID to postId))
            .addTag("post_sync")
            .addTag("post_$postId")
            .build()

        // 4. Sequential Queue Pipeline: Chaining requests one after another
        if (uploadRequests.isNotEmpty()) {
            var continuation = workManager.beginUniqueWork(
                "post_upload_$postId",
                ExistingWorkPolicy.REPLACE,
                uploadRequests.first()
            )
            for (i in 1 until uploadRequests.size) {
                continuation = continuation.then(uploadRequests[i])
            }
            continuation.then(postSyncRequest).enqueue()
        }

        Log.d(TAG, "Enqueued sequential WorkManager queue of ${uploadRequests.size} cached videos for post $postId")
        return cachedTasks.map { it.id }
    }

    /**
     * Cancels any pending or in-progress WorkManager upload tasks for a given post.
     */
    fun cancelUploadsForPost(context: Context, postId: String) {
        val workManager = WorkManager.getInstance(context)
        workManager.cancelUniqueWork("post_upload_$postId")

        val db = AppDatabase.getDatabase(context)
        val dao = db.mediaUploadDao()
        CoroutineScope(Dispatchers.IO).launch {
            val tasks = dao.getTasksForPost(postId)
            tasks.forEach { task ->
                if (task.status in listOf(UploadStatus.QUEUED.name, UploadStatus.COMPRESSING.name, UploadStatus.UPLOADING.name)) {
                    dao.updateProgress(task.id, 0, UploadStatus.CANCELLED.name)
                    updateInMemoryProgress(task.id, task.localUri, 0, UploadStatus.CANCELLED)
                }
            }
            cleanupLocalCacheForPost(context, postId)
        }
    }

    /**
     * Batch processes, compresses, and uploads multiple video files.
     * Uses Semaphore for concurrency control, chunks for large videos, and updates Room DB in real-time.
     */
    suspend fun processAndUploadVideos(
        context: Context,
        videoUris: List<Uri>,
        postId: String? = null,
        onProgress: ((completedCount: Int, totalCount: Int, overallProgress: Int) -> Unit)? = null
    ): List<UploadedMediaResult> = withContext(Dispatchers.IO) {
        if (videoUris.isEmpty()) return@withContext emptyList()

        // Ensure baseUrl is dynamically auto-detected to active server
        NetworkSyncManager.autoDetectBaseUrl(context)

        val db = AppDatabase.getDatabase(context)
        val dao = db.mediaUploadDao()
        val totalCount = videoUris.size
        var completedCount = 0

        // Create tasks in Room DB with QUEUED status and local persistent cache
        val taskEntities = videoUris.mapIndexed { index, uri ->
            val uriStr = uri.toString()
            val taskId = "upload_${System.currentTimeMillis()}_${index}_${UUID.randomUUID().toString().take(6)}"
            val cachedFile = cacheMediaFileLocally(context, uri, taskId)
            MediaUploadTaskEntity(
                id = taskId,
                postId = postId,
                localUri = uriStr,
                localCachedPath = cachedFile?.absolutePath,
                fileName = "video_${System.currentTimeMillis()}_$index.mp4",
                fileSize = cachedFile?.length() ?: 0L,
                mediaType = "video/mp4",
                status = UploadStatus.QUEUED.name,
                progress = 0
            )
        }
        dao.insertTasks(taskEntities)

        // Process videos in parallel with concurrency controlled by uploadSemaphore
        val deferredResults = videoUris.mapIndexed { index, uri ->
            val taskEntity = taskEntities[index]
            async {
                uploadSemaphore.withPermit {
                    try {
                        val result = processSingleVideo(
                            context = context,
                            uri = uri,
                            taskId = taskEntity.id,
                            postId = postId,
                            dao = dao,
                            cachedPath = taskEntity.localCachedPath
                        )
                        synchronized(this@MediaUploadManager) {
                            completedCount++
                            val currentMap = _uploadProgressMap.value
                            val totalPct = if (totalCount > 0) {
                                val sumProgress = currentMap.values.sumOf { it.progress }
                                sumProgress / totalCount
                            } else 100
                            onProgress?.invoke(completedCount, totalCount, totalPct)
                        }
                        result
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to upload video: ${uri}: ${e.message}", e)
                        dao.markFailed(taskEntity.id, e.message ?: "Unknown error")
                        updateInMemoryProgress(taskEntity.id, uri.toString(), 0, UploadStatus.FAILED, errorMessage = e.message)
                        UploadedMediaResult(
                            localUri = uri.toString(),
                            remoteUrl = uri.toString(), // fallback to local URI if upload failed
                            isSuccess = false,
                            errorMessage = e.message
                        )
                    }
                }
            }
        }

        deferredResults.awaitAll()
    }

    /**
     * Processes, extracts metadata/thumbnail, compresses, and chunk-uploads a single video.
     * Reads directly from persistent local cache to ensure offline safety and survival
     * across app restarts and device reboots.
     */
    suspend fun processSingleVideo(
        context: Context,
        uri: Uri,
        taskId: String,
        postId: String?,
        dao: com.maeum.social.data.local.MediaUploadDao,
        cachedPath: String? = null,
        onProgressUpdate: ((Int) -> Unit)? = null
    ): UploadedMediaResult = withContext(Dispatchers.IO) {
        val uriStr = uri.toString()

        // 1. Skip upload if already a remote or relative URL
        if (uriStr.startsWith("http://") || uriStr.startsWith("https://") || uriStr.startsWith("/uploads/")) {
            dao.markCompleted(taskId, uriStr, null)
            updateInMemoryProgress(taskId, uriStr, 100, UploadStatus.COMPLETED, remoteUrl = uriStr)
            onProgressUpdate?.invoke(100)
            return@withContext UploadedMediaResult(
                localUri = uriStr,
                remoteUrl = uriStr,
                isSuccess = true
            )
        }

        // 2. Resolve persistent local cached file (guarantees offline resilience)
        val localFile = resolveOrCacheLocalFile(context, uri, taskId, cachedPath, dao)
        val workingUri = Uri.fromFile(localFile)

        // 3. Status: COMPRESSING & Metadata Extraction
        dao.updateProgress(taskId, 10, UploadStatus.COMPRESSING.name)
        updateInMemoryProgress(taskId, uriStr, 10, UploadStatus.COMPRESSING)
        onProgressUpdate?.invoke(10)

        val metadata = extractVideoMetadata(context, workingUri, localFile)
        val thumbnailBitmap = extractVideoThumbnail(context, workingUri, localFile)

        // Upload thumbnail first if available
        var remoteThumbnailUrl: String? = null
        if (thumbnailBitmap != null) {
            try {
                remoteThumbnailUrl = uploadBitmapThumbnail(thumbnailBitmap)
            } catch (e: Exception) {
                Log.w(TAG, "Thumbnail upload failed: ${e.message}")
            }
        }

        dao.updateProgress(taskId, 25, UploadStatus.COMPRESSING.name)
        updateInMemoryProgress(taskId, uriStr, 25, UploadStatus.COMPRESSING)
        onProgressUpdate?.invoke(25)

        // 4. Use locally cached file for streaming/chunks
        val fileLength = localFile.length()

        dao.updateProgress(taskId, 35, UploadStatus.UPLOADING.name)
        updateInMemoryProgress(taskId, uriStr, 35, UploadStatus.UPLOADING)
        onProgressUpdate?.invoke(35)

        // 5. Perform Chunked Upload or Direct Streaming with multi-tier fallback
        var remoteUrl: String? = null
        if (fileLength > DEFAULT_CHUNK_SIZE) {
            try {
                // Tier 1: Sequential Chunks
                remoteUrl = uploadVideoInChunks(localFile, taskId, metadata.fileName) { chunkProgress ->
                    val scaledProgress = 35 + (chunkProgress * 60 / 100)
                    dao.updateProgress(taskId, scaledProgress, UploadStatus.UPLOADING.name)
                    updateInMemoryProgress(taskId, uriStr, scaledProgress, UploadStatus.UPLOADING)
                    onProgressUpdate?.invoke(scaledProgress)
                }
            } catch (chunkErr: Exception) {
                Log.w(TAG, "Chunked upload failed, falling back to direct stream: ${chunkErr.message}")
            }
        }

        if (remoteUrl == null) {
            try {
                // Tier 2: Direct Multipart Streaming
                remoteUrl = uploadSingleFileStreaming(localFile, metadata.fileName) { directProgress ->
                    val scaledProgress = 35 + (directProgress * 60 / 100)
                    dao.updateProgress(taskId, scaledProgress, UploadStatus.UPLOADING.name)
                    updateInMemoryProgress(taskId, uriStr, scaledProgress, UploadStatus.UPLOADING)
                    onProgressUpdate?.invoke(scaledProgress)
                }
            } catch (streamErr: Exception) {
                Log.w(TAG, "Direct stream upload failed: ${streamErr.message}")
            }
        }

        if (remoteUrl == null && fileLength < 15 * 1024 * 1024) {
            try {
                // Tier 3: Base64 JSON fallback for mobile network resilience
                remoteUrl = uploadBase64File(localFile, metadata.fileName)
            } catch (b64Err: Exception) {
                Log.w(TAG, "Base64 upload failed: ${b64Err.message}")
            }
        }

        if (remoteUrl != null) {
            dao.markCompleted(taskId, remoteUrl, remoteThumbnailUrl)
            updateInMemoryProgress(taskId, uriStr, 100, UploadStatus.COMPLETED, remoteUrl = remoteUrl)
            onProgressUpdate?.invoke(100)
            Log.d(TAG, "Video upload succeeded: $remoteUrl for task $taskId")

            // If independent task (postId == null), clean up immediately.
            // If part of post, PostSyncWorker cleans it up once the entire post is verified synced with server.
            if (postId == null) {
                cleanupLocalCache(context, taskId)
            }

            UploadedMediaResult(
                localUri = uriStr,
                remoteUrl = remoteUrl,
                thumbnailUrl = remoteThumbnailUrl,
                durationMs = metadata.durationMs,
                width = metadata.width,
                height = metadata.height,
                fileSize = fileLength,
                isSuccess = true
            )
        } else {
            throw IOException("서버로부터 업로드 URL을 반환받지 못했습니다.")
        }
    }

    /**
     * Uploads a video file in sequential chunks with retry and timeout protection.
     */
    private suspend fun uploadVideoInChunks(
        file: File,
        uploadId: String,
        originalFileName: String,
        onChunkProgress: suspend (progress: Int) -> Unit
    ): String? = withContext(Dispatchers.IO) {
        val totalLength = file.length()
        val totalChunks = ((totalLength + DEFAULT_CHUNK_SIZE - 1) / DEFAULT_CHUNK_SIZE).toInt()
        val baseUrl = NetworkSyncManager.baseUrl.trimEnd('/')
        val chunkUrl = "$baseUrl/api/sync/upload-chunk"

        val buffer = ByteArray(DEFAULT_CHUNK_SIZE)
        var finalRemoteUrl: String? = null

        FileInputStream(file).use { fis ->
            for (chunkIndex in 0 until totalChunks) {
                val bytesRead = fis.read(buffer)
                if (bytesRead <= 0) break

                val chunkData = if (bytesRead == buffer.size) buffer else buffer.copyOf(bytesRead)

                // Retry chunk upload up to 3 times with exponential backoff
                var success = false
                var lastException: Exception? = null

                for (attempt in 1..3) {
                    try {
                        val requestBody = MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("uploadId", uploadId)
                            .addFormDataPart("chunkIndex", chunkIndex.toString())
                            .addFormDataPart("totalChunks", totalChunks.toString())
                            .addFormDataPart("fileName", originalFileName)
                            .addFormDataPart(
                                "chunk",
                                "chunk_$chunkIndex.tmp",
                                chunkData.toRequestBody("application/octet-stream".toMediaTypeOrNull())
                            )
                            .build()

                        val request = Request.Builder()
                            .url(chunkUrl)
                            .post(requestBody)
                            .build()

                        okHttpClient.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                val bodyString = response.body?.string() ?: ""
                                val json = JSONObject(bodyString)
                                if (json.optBoolean("success")) {
                                    if (json.optBoolean("completed")) {
                                        finalRemoteUrl = json.optString("url")
                                    }
                                    success = true
                                }
                            } else {
                                Log.w(TAG, "Chunk $chunkIndex upload returned HTTP ${response.code}")
                            }
                        }

                        if (success) break
                    } catch (e: Exception) {
                        lastException = e
                        Log.w(TAG, "Chunk $chunkIndex attempt $attempt failed: ${e.message}")
                        delay(attempt * 500L) // Exponential backoff: 500ms, 1000ms, 1500ms
                    }
                }

                if (!success) {
                    throw lastException ?: IOException("청크 $chunkIndex/$totalChunks 전송 실패")
                }

                val currentProgress = ((chunkIndex + 1) * 100) / totalChunks
                onChunkProgress(currentProgress)
            }
        }

        finalRemoteUrl
    }

    /**
     * Uploads a single file using streaming multipart body.
     */
    private suspend fun uploadSingleFileStreaming(
        file: File,
        fileName: String,
        onProgress: suspend (progress: Int) -> Unit
    ): String? = withContext(Dispatchers.IO) {
        val baseUrl = NetworkSyncManager.baseUrl.trimEnd('/')
        val uploadUrl = "$baseUrl/api/sync/upload"

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "files",
                fileName,
                file.asRequestBodyWithProgress("video/mp4".toMediaTypeOrNull(), onProgress)
            )
            .build()

        val request = Request.Builder()
            .url(uploadUrl)
            .post(requestBody)
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                val bodyString = response.body?.string() ?: ""
                val json = JSONObject(bodyString)
                if (json.optBoolean("success")) {
                    val urls = json.optJSONArray("urls")
                    if (urls != null && urls.length() > 0) {
                        return@withContext urls.getString(0)
                    }
                }
            }
        }
        null
    }

    /**
     * Uploads a generated video thumbnail Bitmap to the server.
     */
    private suspend fun uploadBitmapThumbnail(bitmap: Bitmap): String? = withContext(Dispatchers.IO) {
        val baseUrl = NetworkSyncManager.baseUrl.trimEnd('/')
        val uploadUrl = "$baseUrl/api/sync/upload"

        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, baos)
        val bytes = baos.toByteArray()

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
                "files",
                "thumb_${System.currentTimeMillis()}.jpg",
                bytes.toRequestBody("image/jpeg".toMediaTypeOrNull())
            )
            .build()

        val request = Request.Builder()
            .url(uploadUrl)
            .post(requestBody)
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                val bodyString = response.body?.string() ?: ""
                val json = JSONObject(bodyString)
                if (json.optBoolean("success")) {
                    val urls = json.optJSONArray("urls")
                    if (urls != null && urls.length() > 0) {
                        return@withContext urls.getString(0)
                    }
                }
            }
        }
        null
    }

    /**
     * Uploads a video file encoded as Base64 JSON payload as fallback.
     */
    private suspend fun uploadBase64File(file: File, fileName: String): String? = withContext(Dispatchers.IO) {
        val baseUrl = NetworkSyncManager.baseUrl.trimEnd('/')
        val uploadUrl = "$baseUrl/api/sync/upload-base64"
        val bytes = file.readBytes()
        val base64Data = "data:video/mp4;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        val bodyJson = JSONObject().apply {
            put("name", fileName)
            put("type", "video/mp4")
            put("data", base64Data)
        }
        val requestBody = bodyJson.toString().toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(uploadUrl)
            .post(requestBody)
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                val bodyString = response.body?.string() ?: ""
                val json = JSONObject(bodyString)
                if (json.optBoolean("success")) {
                    return@withContext json.optString("url")
                }
            }
        }
        null
    }

    /**
     * Prepares an optimized temp video file from Android content URI with streaming I/O.
     */
    private fun prepareOptimizedVideoFile(context: Context, uri: Uri, taskId: String): File {
        val tempFile = File(context.cacheDir, "opt_${taskId}.mp4")
        if (tempFile.exists()) tempFile.delete()

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tempFile).use { output ->
                val buffer = ByteArray(65536) // 64 KB streaming buffer
                var bytesRead: Int
                while (input.read(buffer).also { bytesRead = it } != -1) {
                    output.write(buffer, 0, bytesRead)
                }
                output.flush()
            }
        }
        return tempFile
    }

    /**
     * Extracts video duration, dimensions, and metadata.
     */
    private fun extractVideoMetadata(context: Context, uri: Uri, fallbackFile: File? = null): VideoMetadata {
        val retriever = MediaMetadataRetriever()
        var duration = 0L
        var width = 0
        var height = 0
        var fileName = fallbackFile?.name ?: "video_${System.currentTimeMillis()}.mp4"

        try {
            if (fallbackFile != null && fallbackFile.exists() && fallbackFile.length() > 0) {
                retriever.setDataSource(fallbackFile.absolutePath)
            } else {
                retriever.setDataSource(context, uri)
            }
            duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        } catch (e: Exception) {
            Log.w(TAG, "Failed to extract metadata for $uri: ${e.message}")
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }

        return VideoMetadata(
            durationMs = duration,
            width = width,
            height = height,
            fileName = fileName
        )
    }

    /**
     * Extracts a frame thumbnail from video.
     */
    private fun extractVideoThumbnail(context: Context, uri: Uri, fallbackFile: File? = null): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            if (fallbackFile != null && fallbackFile.exists() && fallbackFile.length() > 0) {
                retriever.setDataSource(fallbackFile.absolutePath)
            } else {
                retriever.setDataSource(context, uri)
            }
            // Retrieve frame at 1 second mark or first available
            retriever.getFrameAtTime(1000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: retriever.getFrameAtTime(0)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to extract thumbnail: ${e.message}")
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    private fun updateInMemoryProgress(
        taskId: String,
        localUri: String,
        progress: Int,
        status: UploadStatus,
        remoteUrl: String? = null,
        errorMessage: String? = null
    ) {
        val updated = _uploadProgressMap.value.toMutableMap()
        updated[taskId] = MediaUploadProgress(
            taskId = taskId,
            localUri = localUri,
            progress = progress,
            status = status,
            remoteUrl = remoteUrl,
            errorMessage = errorMessage
        )
        _uploadProgressMap.value = updated
    }

    private data class VideoMetadata(
        val durationMs: Long,
        val width: Int,
        val height: Int,
        val fileName: String
    )

    /**
     * RequestBody extension that reports progress during writeTo
     */
    private fun File.asRequestBodyWithProgress(
        contentType: MediaType?,
        onProgress: suspend (progress: Int) -> Unit
    ): RequestBody {
        return object : RequestBody() {
            override fun contentType(): MediaType? = contentType
            override fun contentLength(): Long = length()

            override fun writeTo(sink: okio.BufferedSink) {
                val totalLength = length()
                val buffer = ByteArray(65536)
                var uploaded = 0L

                FileInputStream(this@asRequestBodyWithProgress).use { input ->
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        sink.write(buffer, 0, read)
                        uploaded += read
                        val pct = ((uploaded * 100) / totalLength).toInt()
                        runBlocking {
                            onProgress(pct)
                        }
                    }
                }
            }
        }
    }
}
