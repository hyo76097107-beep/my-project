package com.maeum.social.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.maeum.social.data.local.AppDatabase
import com.maeum.social.data.local.CommentEntity
import com.maeum.social.data.local.MessageEntity
import com.maeum.social.data.local.PostEntity
import com.maeum.social.data.remote.RealtimeSyncService
import com.maeum.social.model.*
import com.maeum.social.network.NetworkSyncManager
import com.maeum.social.util.AudioRecorderHelper
import com.maeum.social.util.LocationHelper
import com.google.gson.Gson
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import com.maeum.social.data.local.MediaUploadTaskEntity
import com.maeum.social.network.MediaCleanupResult
import com.maeum.social.network.MediaSyncService
import com.maeum.social.network.MediaUploadManager
import com.maeum.social.network.UploadQueueInfo
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.*

class SocialViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val postDao = db.postDao()
    private val commentDao = db.commentDao()
    private val messageDao = db.messageDao()
    private val mediaUploadDao = db.mediaUploadDao()
    private val gson = Gson()

    val locationHelper = LocationHelper(application)
    val audioRecorderHelper = AudioRecorderHelper(application)
    val realtimeSyncService = RealtimeSyncService()

    // Real-time Media Upload Task Flow from Room DB
    val activeUploadTasks: StateFlow<List<MediaUploadTaskEntity>> = mediaUploadDao
        .getActiveTasksFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val uploadProgressMap = MediaUploadManager.uploadProgressMap
    val uploadQueueMap = MediaUploadManager.queueProgressMap

    // Media Cache Storage Info and Optimization States
    private val _mediaCacheSizeBytes = MutableStateFlow(0L)
    val mediaCacheSizeBytes: StateFlow<Long> = _mediaCacheSizeBytes.asStateFlow()

    private val _lastCleanupResult = MutableStateFlow<MediaCleanupResult?>(null)
    val lastCleanupResult: StateFlow<MediaCleanupResult?> = _lastCleanupResult.asStateFlow()

    // Current Logged-in User
    private val _currentUser = MutableStateFlow(
        User(
            id = "user_me",
            name = "김마음",
            handle = "maeum_official",
            avatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200",
            location = "서울특별시 강남구 역삼동",
            neighborhood = "역삼동",
            role = "프론트엔드 & 안드로이드 엔지니어",
            bio = "마음(Maeum)에서 이웃들과 따뜻한 일상을 나눕니다 ✨",
            interests = listOf("인공지능", "모바일", "프로그래밍", "여행/캠핑")
        )
    )
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    // Selected Neighborhood Filter (e.g., "전체", "역삼동", "삼성동", "한남동")
    private val _selectedNeighborhood = MutableStateFlow("전체")
    val selectedNeighborhood: StateFlow<String> = _selectedNeighborhood.asStateFlow()

    // Current Location string & toggle
    private val _currentLocation = MutableStateFlow("서울특별시 강남구 역삼동")
    val currentLocation: StateFlow<String> = _currentLocation.asStateFlow()

    private val _isAutoLocationEnabled = MutableStateFlow(true)
    val isAutoLocationEnabled: StateFlow<Boolean> = _isAutoLocationEnabled.asStateFlow()

    // Detected GPS Location
    private val _detectedLocation = MutableStateFlow<LocationInfo?>(null)
    val detectedLocation: StateFlow<LocationInfo?> = _detectedLocation.asStateFlow()

    // Multi-Phone Video Sync State
    private val _videoSyncEvent = MutableStateFlow<VideoSyncEvent?>(null)
    val videoSyncEvent: StateFlow<VideoSyncEvent?> = _videoSyncEvent.asStateFlow()

    // Stories Feed Flow
    private val _stories = MutableStateFlow<List<Story>>(com.maeum.social.data.MockData.initialStories)
    val stories: StateFlow<List<Story>> = _stories.asStateFlow()

    fun createStory(mediaUrl: String, caption: String? = null, bgm: StoryBgm? = null) {
        val newStory = Story(
            id = "story_${System.currentTimeMillis()}",
            author = _currentUser.value,
            mediaUrl = mediaUrl,
            caption = caption,
            bgm = bgm,
            createdAt = "방금 전"
        )
        _stories.value = listOf(newStory) + _stories.value
    }

    // Posts Feed
    val posts: StateFlow<List<Post>> = combine(
        postDao.getAllPosts(),
        _selectedNeighborhood
    ) { postEntities, neighborhood ->
        val mapped = postEntities.map { entity ->
            val imgs = gson.fromJson(entity.mediaUrlsJson, Array<String>::class.java)?.toList() ?: emptyList()
            val vids = gson.fromJson(entity.videoUrlsJson, Array<String>::class.java)?.toList() ?: emptyList()
            val parsedBgm = entity.bgmJson?.let {
                try { gson.fromJson(it, StoryBgm::class.java) } catch (_: Exception) { null }
            }
            val parsedPoll = entity.pollJson?.let {
                try { gson.fromJson(it, Poll::class.java) } catch (_: Exception) { null }
            }
            val parsedScope = try {
                RegionalScope.valueOf(entity.regionalScope ?: "ALL")
            } catch (_: Exception) {
                RegionalScope.ALL
            }
            val authorUser = User(
                id = entity.authorId,
                name = entity.authorName,
                handle = entity.authorHandle,
                avatar = entity.authorAvatar
            )
            Post(
                id = entity.id,
                author = authorUser,
                authorId = entity.authorId,
                authorName = entity.authorName,
                authorHandle = entity.authorHandle,
                authorAvatar = entity.authorAvatar,
                content = entity.content,
                mediaUrls = imgs,
                photos = imgs,
                videoUrls = vids,
                videoUrl = vids.firstOrNull(),
                locationTag = entity.locationTag,
                location = entity.locationTag,
                neighborhood = entity.neighborhood,
                regionalScope = parsedScope,
                feeling = entity.feeling,
                bgm = parsedBgm,
                poll = parsedPoll,
                likesCount = entity.likesCount,
                isLiked = entity.isLiked,
                commentsCount = entity.commentsCount,
                createdAt = entity.createdAt,
                scheduledAt = entity.scheduledAt,
                isBanned = entity.isBanned
            )
        }
        if (neighborhood == "전체") mapped else mapped.filter { it.neighborhood == neighborhood }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Comments for selected post
    private val _currentPostId = MutableStateFlow<String?>(null)
    val currentPostComments: StateFlow<List<Comment>> = _currentPostId.flatMapLatest { postId ->
        if (postId == null) flowOf(emptyList())
        else commentDao.getCommentsForPost(postId).map { list ->
            list.map { entity ->
                val authorUser = User(
                    id = entity.authorId,
                    name = entity.authorName,
                    handle = entity.authorHandle,
                    avatar = entity.authorAvatar
                )
                Comment(
                    id = entity.id,
                    postId = entity.postId,
                    author = authorUser,
                    authorId = entity.authorId,
                    authorName = entity.authorName,
                    authorHandle = entity.authorHandle,
                    authorAvatar = entity.authorAvatar,
                    content = entity.content,
                    audioUrl = entity.audioUrl,
                    audioDurationSec = entity.audioDurationSec,
                    audioDuration = entity.audioDurationSec,
                    createdAt = entity.createdAt,
                    replies = gson.fromJson(entity.repliesJson, Array<Reply>::class.java)?.toList() ?: emptyList()
                )
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Connect real-time media and database sync service
        MediaSyncService.initialize(application)
        MediaSyncService.connect()

        // Calculate initial local media cache size
        refreshMediaCacheSize()

        viewModelScope.launch {
            MediaSyncService.videoPlaybackSyncFlow.collect { syncEvent ->
                _videoSyncEvent.value = syncEvent
            }
        }

        viewModelScope.launch {
            MediaSyncService.mediaSyncEvents.collect { mediaEvent ->
                Log.d("SocialViewModel", "Real-time media sync event received for post ${mediaEvent.postId}")
                // Pre-warm first video stream proactively
                mediaEvent.videoUrls.firstOrNull()?.let { vUrl ->
                    MediaSyncService.prewarmVideoMedia(vUrl)
                }
            }
        }

        viewModelScope.launch {
            MediaSyncService.realtimePostsFlow.collect { remotePosts ->
                Log.d("SocialViewModel", "Received live real-time posts update (${remotePosts.size} posts)")
            }
        }

        // Seed initial posts if empty and fetch real-time posts from backend
        seedInitialData()
        refreshPosts()
    }

    // Sync posts from remote backend with Room DB
    fun refreshPosts(onComplete: (() -> Unit)? = null) {
        viewModelScope.launch {
            try {
                NetworkSyncManager.autoDetectBaseUrl(getApplication())
                val remotePosts = NetworkSyncManager.fetchPosts()
                if (remotePosts != null && remotePosts.isNotEmpty()) {
                    val entities = remotePosts.map { post ->
                        PostEntity(
                            id = post.id,
                            authorId = post.author.id,
                            authorName = post.author.name,
                            authorHandle = post.author.handle,
                            authorAvatar = post.author.avatar,
                            content = post.content,
                            mediaUrlsJson = gson.toJson(post.photos),
                            videoUrlsJson = gson.toJson(post.videoUrls),
                            locationTag = post.location ?: post.author.location,
                            neighborhood = post.neighborhood ?: post.location?.split(" ")?.lastOrNull() ?: post.author.neighborhood,
                            likesCount = post.likesCount,
                            isLiked = post.isLiked,
                            commentsCount = post.commentsCount,
                            createdAt = post.createdAt,
                            scheduledAt = post.scheduledAt,
                            isBanned = false
                        )
                    }
                    postDao.insertPosts(entities)
                }
            } catch (e: Exception) {
                Log.e("SocialViewModel", "Failed to refresh posts from backend: ${e.message}")
            } finally {
                onComplete?.invoke()
            }
        }
    }

    fun setNeighborhood(neighborhood: String) {
        _selectedNeighborhood.value = neighborhood
    }

    fun setSelectedPostId(postId: String?) {
        _currentPostId.value = postId
    }

    fun setAutoLocationEnabled(enabled: Boolean) {
        _isAutoLocationEnabled.value = enabled
    }

    fun detectLocation(context: Context, onComplete: (String) -> Unit = {}) {
        viewModelScope.launch {
            val loc = locationHelper.getCurrentLocation()
            if (loc != null) {
                _detectedLocation.value = loc
                _currentLocation.value = loc.fullAddress
                onComplete(loc.fullAddress)
            }
        }
    }

    // GPS Auto Detection
    fun autoDetectGpsLocation(onComplete: (LocationInfo) -> Unit = {}) {
        viewModelScope.launch {
            val loc = locationHelper.getCurrentLocation()
            if (loc != null) {
                _detectedLocation.value = loc
                _currentLocation.value = loc.fullAddress
                onComplete(loc)
            }
        }
    }

    fun updateSignupInfo(
        name: String,
        handle: String,
        residenceLocation: String,
        role: String,
        bio: String,
        avatar: String,
        interests: List<String>
    ) {
        _currentUser.value = _currentUser.value.copy(
            name = name,
            handle = handle,
            location = residenceLocation,
            neighborhood = residenceLocation.substringAfterLast(" ").ifEmpty { "역삼동" },
            role = role,
            bio = bio,
            avatar = avatar,
            interests = interests
        )
    }

    // Create New Post with multiple images, videos, BGM, and Poll
    fun createPost(
        content: String,
        images: List<String>,
        videos: List<String>,
        neighborhood: String?,
        bgm: StoryBgm? = null,
        poll: Poll? = null,
        scheduledAt: String? = null
    ) {
        val user = _currentUser.value
        createPost(
            context = getApplication(),
            content = content,
            photos = images,
            videoUrl = videos.firstOrNull(),
            videoUrls = videos,
            videoThumbnail = null,
            location = neighborhood ?: user.location,
            regionalScope = RegionalScope.NEIGHBORHOOD,
            feeling = null,
            bgm = bgm,
            poll = poll,
            scheduledAt = scheduledAt
        )
    }

    // Overloaded createPost for CreatePostScreen with MediaUploadManager batch processing & upload
    fun createPost(
        context: Context,
        content: String,
        photos: List<String>,
        videoUrl: String?,
        videoUrls: List<String>,
        videoThumbnail: String?,
        location: String?,
        regionalScope: RegionalScope,
        feeling: String?,
        bgm: StoryBgm? = null,
        poll: Poll? = null,
        scheduledAt: String? = null,
        onComplete: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            val user = _currentUser.value
            val nowStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREAN).format(Date())
            val postId = "post_${System.currentTimeMillis()}"
            val extractedNeighborhood = location?.split(" ")?.lastOrNull() ?: user.neighborhood
            val allRawVideos = if (videoUrls.isNotEmpty()) videoUrls else listOfNotNull(videoUrl)
            val bgmJson = bgm?.let { gson.toJson(it) }
            val pollJson = poll?.let { gson.toJson(it) }

            // 0. Ensure backend baseUrl is auto-detected
            NetworkSyncManager.autoDetectBaseUrl(context)

            // 1. Process local videos via WorkManager background queue to eliminate UI bottlenecks
            val videoUrisToUpload = allRawVideos.mapNotNull { vStr ->
                if (vStr.startsWith("content://") || vStr.startsWith("file://")) {
                    Uri.parse(vStr)
                } else null
            }

            if (videoUrisToUpload.isNotEmpty()) {
                // Upload photos if any
                val uploadedPhotos = photos.map { pStr ->
                    if (pStr.startsWith("content://") || pStr.startsWith("file://")) {
                        NetworkSyncManager.uploadMedia(context, Uri.parse(pStr)) ?: pStr
                    } else {
                        pStr
                    }
                }

                // Insert post into Room DB immediately with local URIs for instant UI responsiveness
                val newPostEntity = PostEntity(
                    id = postId,
                    authorId = user.id,
                    authorName = user.name,
                    authorHandle = user.handle,
                    authorAvatar = user.avatar,
                    content = content,
                    mediaUrlsJson = gson.toJson(uploadedPhotos),
                    videoUrlsJson = gson.toJson(allRawVideos),
                    locationTag = location ?: user.location,
                    neighborhood = extractedNeighborhood,
                    regionalScope = regionalScope.name,
                    feeling = feeling,
                    bgmJson = bgmJson,
                    pollJson = pollJson,
                    likesCount = 0,
                    isLiked = false,
                    commentsCount = 0,
                    createdAt = nowStr,
                    scheduledAt = scheduledAt,
                    isBanned = false
                )
                postDao.insertPost(newPostEntity)

                // Offload multiple video compression and chunked uploads to WorkManager queue
                MediaUploadManager.enqueueBackgroundUpload(
                    context = context,
                    videoUris = videoUrisToUpload,
                    postId = postId
                )

                onComplete?.invoke()
                return@launch
            }

            // Direct path for posts without pending video uploads
            val uploadedPhotos = photos.map { pStr ->
                if (pStr.startsWith("content://") || pStr.startsWith("file://")) {
                    NetworkSyncManager.uploadMedia(context, Uri.parse(pStr)) ?: pStr
                } else {
                    pStr
                }
            }

            val newPostEntity = PostEntity(
                id = postId,
                authorId = user.id,
                authorName = user.name,
                authorHandle = user.handle,
                authorAvatar = user.avatar,
                content = content,
                mediaUrlsJson = gson.toJson(uploadedPhotos),
                videoUrlsJson = gson.toJson(allRawVideos),
                locationTag = location ?: user.location,
                neighborhood = extractedNeighborhood,
                regionalScope = regionalScope.name,
                feeling = feeling,
                bgmJson = bgmJson,
                pollJson = pollJson,
                likesCount = 0,
                isLiked = false,
                commentsCount = 0,
                createdAt = nowStr,
                scheduledAt = scheduledAt,
                isBanned = false
            )
            postDao.insertPost(newPostEntity)

            try {
                NetworkSyncManager.createPost(
                    Post(
                        id = newPostEntity.id,
                        author = user,
                        content = content,
                        photos = uploadedPhotos,
                        videoUrl = allRawVideos.firstOrNull(),
                        videoUrls = allRawVideos,
                        videoThumbnail = videoThumbnail,
                        location = location,
                        regionalScope = regionalScope,
                        feeling = feeling,
                        bgm = bgm,
                        poll = poll,
                        likesCount = 0,
                        isLiked = false,
                        commentsCount = 0,
                        createdAt = nowStr,
                        scheduledAt = scheduledAt,
                        isBanned = false
                    )
                )
            } catch (e: Exception) {
                // Background network error fallback to local Room
            }

            onComplete?.invoke()
        }
    }

    fun votePoll(postId: String, optionId: String) {
        viewModelScope.launch {
            val post = postDao.getPostById(postId) ?: return@launch
            val currentPoll = post.pollJson?.let {
                try { gson.fromJson(it, Poll::class.java) } catch (_: Exception) { null }
            } ?: return@launch
            val userId = _currentUser.value.id
            val updatedOptions = currentPoll.options.map { opt ->
                if (opt.id == optionId) {
                    if (!opt.votes.contains(userId)) {
                        opt.copy(votes = opt.votes + userId)
                    } else opt
                } else {
                    opt.copy(votes = opt.votes.filter { it != userId })
                }
            }
            val totalVotes = updatedOptions.sumOf { it.votes.size }
            val updatedPoll = currentPoll.copy(options = updatedOptions, totalVotes = totalVotes)
            postDao.insertPost(post.copy(pollJson = gson.toJson(updatedPoll)))
        }
    }

    fun toggleBookmark(postId: String) {
        viewModelScope.launch {
            val post = postDao.getPostById(postId) ?: return@launch
            // Toggle bookmark state in Room or local
        }
    }
                        commentsCount = 0,
                        createdAt = nowStr,
                        scheduledAt = scheduledAt
                    )
                )
            } catch (e: Exception) {
                // local first fallback
            }

            onComplete?.invoke()
        }
    }

    // Toggle Post Like
    fun toggleLike(postId: String) {
        viewModelScope.launch {
            val post = postDao.getPostById(postId) ?: return@launch
            val updated = post.copy(
                isLiked = !post.isLiked,
                likesCount = if (!post.isLiked) post.likesCount + 1 else (post.likesCount - 1).coerceAtLeast(0)
            )
            postDao.insertPost(updated)
            try {
                NetworkSyncManager.toggleLike(postId, _currentUser.value.id)
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    // Toggle Follow / Unfollow User
    fun toggleFollow(targetUserId: String, targetName: String? = null, targetHandle: String? = null) {
        viewModelScope.launch {
            val user = _currentUser.value
            val isFollowing = user.followingIds.contains(targetUserId)
            val updatedFollowingIds = if (isFollowing) {
                user.followingIds - targetUserId
            } else {
                user.followingIds + targetUserId
            }
            val updatedUser = user.copy(
                followingIds = updatedFollowingIds,
                followingCount = updatedFollowingIds.size
            )
            _currentUser.value = updatedUser

            try {
                withContext(Dispatchers.IO) {
                    NetworkSyncManager.toggleFollow(user.id, targetUserId, user, targetName, targetHandle)
                }
            } catch (e: Exception) {
                // keep local state
            }
        }
    }

    // Add Comment (Text or Voice Recording)
    fun addComment(postId: String, content: String, audioFile: File?, durationSec: Int) {
        viewModelScope.launch {
            val user = _currentUser.value
            val nowStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREAN).format(Date())
            val commentEntity = CommentEntity(
                id = "comment_${System.currentTimeMillis()}",
                postId = postId,
                authorId = user.id,
                authorName = user.name,
                authorHandle = user.handle,
                authorAvatar = user.avatar,
                content = content,
                audioUrl = audioFile?.absolutePath,
                audioDurationSec = durationSec,
                createdAt = nowStr,
                repliesJson = "[]"
            )
            commentDao.insertComment(commentEntity)

            val post = postDao.getPostById(postId)
            if (post != null) {
                postDao.insertPost(post.copy(commentsCount = post.commentsCount + 1))
            }

            try {
                NetworkSyncManager.addComment(
                    postId = postId,
                    author = user,
                    content = content,
                    audioUrl = audioFile?.absolutePath,
                    audioDuration = durationSec
                )
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    // Add Reply (Nested comment to a comment)
    fun addReply(postId: String, commentId: String, content: String, audioFile: File?) {
        viewModelScope.launch {
            val user = _currentUser.value
            val nowStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREAN).format(Date())
            val newReply = Reply(
                id = "reply_${System.currentTimeMillis()}",
                commentId = commentId,
                authorId = user.id,
                authorName = user.name,
                authorHandle = user.handle,
                authorAvatar = user.avatar,
                content = content,
                audioUrl = audioFile?.absolutePath,
                createdAt = nowStr
            )

            val existingComments = commentDao.getCommentsForPost(postId).first()
            val target = existingComments.find { it.id == commentId } ?: return@launch
            val currentReplies = gson.fromJson(target.repliesJson, Array<Reply>::class.java)?.toMutableList() ?: mutableListOf()
            currentReplies.add(newReply)

            val updated = target.copy(repliesJson = gson.toJson(currentReplies))
            commentDao.insertComment(updated)

            try {
                NetworkSyncManager.addComment(
                    postId = postId,
                    author = user,
                    content = content,
                    parentId = commentId,
                    audioUrl = audioFile?.absolutePath
                )
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    // Broadcast multi-phone synchronized video playback
    fun syncVideoPlayback(videoId: String, positionMs: Long, isPlaying: Boolean) {
        realtimeSyncService.broadcastVideoSync(
            videoId = videoId,
            positionMs = positionMs,
            isPlaying = isPlaying,
            senderId = _currentUser.value.id
        )
    }

    // Send Direct Message (Immediate or Scheduled)
    fun sendMessage(receiverId: String, content: String, scheduledTime: Long? = null) {
        viewModelScope.launch {
            val msg = MessageEntity(
                id = "msg_${System.currentTimeMillis()}",
                senderId = _currentUser.value.id,
                receiverId = receiverId,
                content = content,
                mediaUrl = null,
                timestamp = System.currentTimeMillis(),
                scheduledTime = scheduledTime,
                isDelivered = scheduledTime == null
            )
            messageDao.insertMessage(msg)
        }
    }

    fun getConversation(otherUserId: String): Flow<List<DirectMessage>> {
        return messageDao.getConversation(_currentUser.value.id, otherUserId).map { list ->
            list.map {
                DirectMessage(
                    id = it.id,
                    senderId = it.senderId,
                    receiverId = it.receiverId,
                    content = it.content,
                    mediaUrl = it.mediaUrl,
                    timestamp = it.timestamp,
                    scheduledTime = it.scheduledTime,
                    isDelivered = it.isDelivered
                )
            }
        }
    }

    private fun seedInitialData() {
        viewModelScope.launch {
            val existing = postDao.getAllPosts().first()
            if (existing.isEmpty()) {
                val seedEntities = com.maeum.social.data.MockData.initialPosts.map { post ->
                    PostEntity(
                        id = post.id,
                        authorId = post.author.id,
                        authorName = post.author.name,
                        authorHandle = post.author.handle,
                        authorAvatar = post.author.avatar,
                        content = post.content,
                        mediaUrlsJson = gson.toJson(post.photos),
                        videoUrlsJson = gson.toJson(post.videoUrls.ifEmpty { listOfNotNull(post.videoUrl) }),
                        locationTag = post.location ?: post.author.location,
                        neighborhood = post.neighborhood ?: post.location?.split(" ")?.lastOrNull() ?: post.author.neighborhood,
                        regionalScope = post.regionalScope.name,
                        feeling = post.feeling,
                        bgmJson = post.bgm?.let { gson.toJson(it) },
                        pollJson = post.poll?.let { gson.toJson(it) },
                        likesCount = post.likesCount,
                        isLiked = post.isLiked,
                        commentsCount = post.commentsCount,
                        createdAt = post.createdAt,
                        scheduledAt = post.scheduledAt,
                        isBanned = false
                    )
                }
                postDao.insertPosts(seedEntities)
            }
        }
    }

    fun setCustomServerUrl(url: String?) {
        NetworkSyncManager.setCustomServerUrl(getApplication(), url)
        refreshPosts()
    }

    fun getCustomServerUrl(): String? {
        return NetworkSyncManager.getCustomServerUrl(getApplication())
    }

    fun getServerStatusSummary(): String {
        return NetworkSyncManager.getServerStatusSummary()
    }

    /**
     * Refreshes the total size in bytes of local persistent media cache
     */
    fun refreshMediaCacheSize() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val size = MediaUploadManager.calculateMediaCacheSize(getApplication())
            _mediaCacheSizeBytes.value = size
        }
    }

    /**
     * Executes media cache cleaner optimization:
     * Removes completed upload tasks and temporary files older than retention days (default: 7 days)
     */
    fun optimizeMediaCache(
        retentionDays: Long = 7L,
        onComplete: ((MediaCleanupResult) -> Unit)? = null
    ) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val result = MediaUploadManager.cleanExpiredAndCompletedCache(
                context = getApplication(),
                retentionMillis = retentionDays * 24 * 60 * 60 * 1000L,
                deleteCompletedImmediately = true
            )
            _lastCleanupResult.value = result
            refreshMediaCacheSize()
            onComplete?.invoke(result)
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioRecorderHelper.stopAudio()
        realtimeSyncService.disconnect()
    }
}
