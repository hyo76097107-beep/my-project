package com.maeum.social.worker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.maeum.social.data.local.AppDatabase
import com.maeum.social.network.MediaUploadManager
import com.maeum.social.network.NetworkSyncManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * WorkManager CoroutineWorker for reliable, persistent background video upload.
 * Solves upload bottleneck when attaching multiple videos by offloading heavy
 * compression and chunk streaming to the OS background work queue.
 */
class VideoUploadWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val TAG = "VideoUploadWorker"
        const val KEY_TASK_ID = "KEY_TASK_ID"
        const val KEY_POST_ID = "KEY_POST_ID"
        const val KEY_LOCAL_URI = "KEY_LOCAL_URI"
        const val KEY_CACHED_PATH = "KEY_CACHED_PATH"
        const val KEY_FILE_NAME = "KEY_FILE_NAME"
        const val KEY_INDEX = "KEY_INDEX"
        const val KEY_TOTAL_COUNT = "KEY_TOTAL_COUNT"

        const val CHANNEL_ID = "media_upload_channel"
        const val NOTIFICATION_ID_BASE = 4000
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val taskId = inputData.getString(KEY_TASK_ID) ?: return@withContext Result.failure()
        val postId = inputData.getString(KEY_POST_ID)
        val uriStr = inputData.getString(KEY_LOCAL_URI) ?: return@withContext Result.failure()
        val cachedPathInput = inputData.getString(KEY_CACHED_PATH)
        val fileName = inputData.getString(KEY_FILE_NAME) ?: "video.mp4"
        val index = inputData.getInt(KEY_INDEX, 1)
        val totalCount = inputData.getInt(KEY_TOTAL_COUNT, 1)

        val db = AppDatabase.getDatabase(applicationContext)
        val dao = db.mediaUploadDao()

        createNotificationChannel()

        // Set foreground info to prevent process termination on Android 8+
        try {
            setForeground(createForegroundInfo(index, totalCount, 10, fileName))
        } catch (e: Exception) {
            Log.w(TAG, "Could not set foreground service info: ${e.message}")
        }

        try {
            // Ensure server URL is detected
            NetworkSyncManager.autoDetectBaseUrl(applicationContext)

            val uri = Uri.parse(uriStr)
            val taskFromDb = dao.getTaskById(taskId)
            val cachedPath = if (!cachedPathInput.isNullOrBlank() && java.io.File(cachedPathInput).exists()) {
                cachedPathInput
            } else {
                taskFromDb?.localCachedPath
            }

            val result = MediaUploadManager.processSingleVideo(
                context = applicationContext,
                uri = uri,
                taskId = taskId,
                postId = postId,
                dao = dao,
                cachedPath = cachedPath,
                onProgressUpdate = { pct ->
                    setProgressAsync(
                        workDataOf(
                            "PROGRESS" to pct,
                            "INDEX" to index,
                            "TOTAL" to totalCount,
                            "TASK_ID" to taskId,
                            "POST_ID" to (postId ?: "")
                        )
                    )
                    updateNotification(index, totalCount, pct, fileName)
                    if (postId != null) {
                        MediaUploadManager.updateQueueProgress(postId, index, totalCount, pct)
                    }
                }
            )

            if (result.isSuccess) {
                Log.d(TAG, "VideoUploadWorker finished for task $taskId ($index/$totalCount) -> ${result.remoteUrl}")
                Result.success(
                    workDataOf(
                        "TASK_ID" to taskId,
                        "POST_ID" to (postId ?: ""),
                        "LOCAL_URI" to uriStr,
                        "REMOTE_URL" to result.remoteUrl,
                        "THUMBNAIL_URL" to (result.thumbnailUrl ?: ""),
                        "IS_SUCCESS" to true
                    )
                )
            } else {
                if (runAttemptCount < 3) {
                    Log.w(TAG, "VideoUploadWorker retrying task $taskId (attempt $runAttemptCount)")
                    Result.retry()
                } else {
                    Log.e(TAG, "VideoUploadWorker exhausted retries for task $taskId. Marking failed and continuing queue.")
                    dao.markFailed(taskId, result.errorMessage ?: "Upload failed after 3 attempts")
                    // Do not break the WorkContinuation chain so other queued videos still upload
                    Result.success(
                        workDataOf(
                            "TASK_ID" to taskId,
                            "POST_ID" to (postId ?: ""),
                            "IS_SUCCESS" to false
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "VideoUploadWorker error for task $taskId: ${e.message}", e)
            if (runAttemptCount < 3) {
                Result.retry()
            } else {
                dao.markFailed(taskId, e.message ?: "Upload worker exception")
                // Allow continuation so other videos can finish
                Result.success(
                    workDataOf(
                        "TASK_ID" to taskId,
                        "POST_ID" to (postId ?: ""),
                        "IS_SUCCESS" to false
                    )
                )
            }
        }
    }

    private fun createForegroundInfo(index: Int, total: Int, progress: Int, fileName: String): ForegroundInfo {
        val notification = createNotification(index, total, progress, fileName)
        val notifId = NOTIFICATION_ID_BASE + index
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(notifId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(notifId, notification)
        }
    }

    private fun createNotification(index: Int, total: Int, progress: Int, fileName: String): Notification {
        val title = if (total > 1) "동영상 업로드 중 ($index/$total)" else "동영상 업로드 중"
        val content = if (progress >= 100) "동영상 전송 완료 처리 중..." else "$fileName 압축 및 전송 ($progress%)"

        return NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setProgress(100, progress, progress <= 0)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    private fun updateNotification(index: Int, total: Int, progress: Int, fileName: String) {
        try {
            val notif = createNotification(index, total, progress, fileName)
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID_BASE + index, notif)
        } catch (_: Exception) {}
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "동영상 업로드 상태",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "백그라운드 동영상 파일 압축 및 업로드 진행 상태를 표시합니다."
                setShowBadge(false)
            }
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
