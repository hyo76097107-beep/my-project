package com.maeum.social.model

import com.google.gson.annotations.SerializedName

enum class RegionalScope(val title: String, val description: String) {
    ALL("전체 공개", "모든 지역의 사용자에게 게시물이 표시됩니다."),
    NEIGHBORHOOD("우리 동네 한정", "내 주변 동네 사용자에게만 표시됩니다."),
    DISTRICT("구 단위 한정", "같은 구 사용자에게만 표시됩니다."),
    CITY("시/도 단위 한정", "같은 시/도 사용자에게만 표시됩니다."),
    PROVINCE("전국 단위 한정", "전국 사용자에게 표시됩니다.")
}

enum class CreatePostMode {
    DEFAULT, PHOTO, VIDEO, LOCATION, SCHEDULE
}

data class User(
    val id: String,
    val name: String,
    val handle: String,
    val email: String? = null,
    val phoneNumber: String? = null,
    val avatar: String = "",
    val bio: String = "",
    val role: String = "회원",
    val location: String = "서울특별시 강남구",
    val neighborhood: String = "역삼동",
    val signupIp: String = "127.0.0.1",
    val isBanned: Boolean = false,
    val isAdmin: Boolean = false,
    val isVerified: Boolean = false,
    val followingIds: List<String> = emptyList(),
    val followersCount: Int = 128,
    val followingCount: Int = 84,
    val interests: List<String> = emptyList(),
    val createdAt: String = ""
)

data class StoryBgm(
    val id: String,
    val title: String,
    val artist: String,
    val genre: String,
    val audioUrl: String? = null,
    val coverUrl: String? = null,
    val duration: Int = 30,
    val license: String = "100% 저작권 무료 (CC0)",
    val isCustom: Boolean = false
)

data class PollOption(
    val id: String,
    val text: String,
    val votes: List<String> = emptyList()
)

data class Poll(
    val id: String,
    val question: String,
    val options: List<PollOption>,
    val totalVotes: Int = 0
)

data class PostMediaItem(
    val id: String,
    val type: String, // "image" or "video"
    val url: String,
    val thumbnail: String? = null
)

data class Post(
    val id: String,
    val author: User = User(id = "", name = "", handle = ""),
    val authorId: String = author.id,
    val authorName: String = author.name,
    val authorHandle: String = author.handle,
    val authorAvatar: String = author.avatar,
    val content: String = "",
    val mediaUrls: List<String> = emptyList(),
    val photos: List<String> = mediaUrls,
    val videoUrls: List<String> = emptyList(),
    val videoUrl: String? = videoUrls.firstOrNull(),
    val videoThumbnail: String? = null,
    val mediaItems: List<PostMediaItem> = emptyList(),
    val locationTag: String? = null,
    val location: String? = locationTag,
    val neighborhood: String? = null,
    val regionalScope: RegionalScope = RegionalScope.ALL,
    val feeling: String? = null,
    val bgm: StoryBgm? = null,
    val poll: Poll? = null,
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val isBookmarked: Boolean = false,
    val commentsCount: Int = 0,
    val comments: List<Comment> = emptyList(),
    val createdAt: String = "",
    val scheduledAt: String? = null,
    val isBanned: Boolean = false
) {
    val displayAuthorName: String get() = if (authorName.isNotBlank()) authorName else author.name
    val displayAuthorHandle: String get() = if (authorHandle.isNotBlank()) authorHandle else author.handle
    val displayAuthorAvatar: String get() = if (authorAvatar.isNotBlank()) authorAvatar else author.avatar
}

data class Comment(
    val id: String,
    val postId: String = "",
    val author: User = User(id = "", name = "", handle = ""),
    val authorId: String = author.id,
    val authorName: String = author.name,
    val authorHandle: String = author.handle,
    val authorAvatar: String = author.avatar,
    val content: String = "",
    val audioUrl: String? = null,
    val audioDurationSec: Int = 0,
    val audioDuration: Int = audioDurationSec,
    val parentId: String? = null,
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val createdAt: String = "",
    val replies: List<Reply> = emptyList()
)

data class Reply(
    val id: String,
    val commentId: String,
    val authorId: String,
    val authorName: String,
    val authorHandle: String,
    val authorAvatar: String,
    val content: String = "",
    val audioUrl: String? = null,
    val createdAt: String = ""
)

data class Story(
    val id: String,
    val author: User,
    val mediaUrl: String,
    val caption: String? = null,
    val bgm: StoryBgm? = null,
    val filterId: String? = null,
    val createdAt: String = ""
)

data class DirectMessage(
    val id: String,
    val senderId: String,
    val receiverId: String = "",
    val content: String = "",
    val text: String = content,
    val mediaUrl: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val scheduledTime: Long? = null,
    val isDelivered: Boolean = true
) {
    constructor(
        id: String,
        senderId: String,
        text: String,
        timestamp: String
    ) : this(
        id = id,
        senderId = senderId,
        receiverId = "",
        content = text,
        text = text,
        mediaUrl = null,
        timestamp = System.currentTimeMillis(),
        scheduledTime = null,
        isDelivered = true
    )
}

data class Conversation(
    val id: String,
    val participant: User,
    val messages: List<DirectMessage> = emptyList(),
    val unreadCount: Int = 0
)

data class VideoSyncEvent(
    @SerializedName("videoId") val videoId: String,
    @SerializedName("positionMs") val positionMs: Long,
    @SerializedName("isPlaying") val isPlaying: Boolean,
    @SerializedName("senderId") val senderId: String,
    @SerializedName("timestamp") val timestamp: Long = System.currentTimeMillis()
)

data class LocationInfo(
    val latitude: Double,
    val longitude: Double,
    val city: String = "서울특별시",
    val district: String = "강남구",
    val neighborhood: String = "역삼동",
    val fullAddress: String = "서울특별시 강남구 역삼동"
)
