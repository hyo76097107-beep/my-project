package com.maeum.social.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class ScheduledPostWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val postContent = inputData.getString("POST_CONTENT") ?: "예약된 게시물"
        val postId = inputData.getString("POST_ID") ?: "post"

        sendDispatchNotification(postId, postContent)
        return Result.success()
    }

    private fun sendDispatchNotification(postId: String, content: String) {
        val notificationManager =
            applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channelId = "scheduled_posts_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "예약 게시물 알림",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "예약 전송된 게시물이 피드에 성공적으로 등록되었을 때 알림을 보냅니다."
            }
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("예약 게시물이 발행되었습니다! 🚀")
            .setContentText(content.take(60))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(postId.hashCode(), notification)
    }
}
