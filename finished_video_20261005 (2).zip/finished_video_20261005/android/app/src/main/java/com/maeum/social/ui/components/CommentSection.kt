package com.maeum.social.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.SubdirectoryArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import com.maeum.social.model.Comment
import com.maeum.social.model.User
import com.maeum.social.theme.PrimaryIndigo

data class HierarchicalComment(
    val comment: Comment,
    val depth: Int,
    val parentComment: Comment?
)

fun buildHierarchicalComments(allComments: List<Comment>): List<HierarchicalComment> {
    val commentMap = allComments.associateBy { it.id }
    val childrenMap = allComments.filter { it.parentId != null }.groupBy { it.parentId!! }
    val result = mutableListOf<HierarchicalComment>()

    fun traverse(comm: Comment, depth: Int, parent: Comment?) {
        result.add(HierarchicalComment(comm, depth, parent))
        val children = childrenMap[comm.id] ?: emptyList()
        children.forEach { child ->
            traverse(child, depth + 1, comm)
        }
    }

    val rootComments = allComments.filter { it.parentId == null || !commentMap.containsKey(it.parentId) }
    rootComments.forEach { root ->
        traverse(root, 0, null)
    }

    return result
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentSection(
    comments: List<Comment>,
    currentUser: User,
    onAddComment: (content: String, parentId: String?, audioUrl: String?, audioDuration: Int?) -> Unit,
    onToggleLike: (commentId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var commentText by remember { mutableStateOf("") }
    var replyingTo by remember { mutableStateOf<Comment?>(null) }
    var isVoiceRecordingOpen by remember { mutableStateOf(false) }

    val hierarchicalComments = remember(comments) { buildHierarchicalComments(comments) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
    ) {
        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
        Spacer(modifier = Modifier.height(12.dp))

        // 1. Voice Comment Recorder OR Text Input Form
        if (isVoiceRecordingOpen) {
            VoiceCommentRecorder(
                onSendVoice = { audioUrl, duration ->
                    val finalContent = if (replyingTo != null && commentText.isNotBlank()) {
                        "@${replyingTo!!.author.handle} $commentText"
                    } else commentText

                    onAddComment(finalContent, replyingTo?.id, audioUrl, duration)
                    Toast.makeText(context, "음성 댓글이 등록되었습니다! 🎙️", Toast.LENGTH_SHORT).show()
                    isVoiceRecordingOpen = false
                    commentText = ""
                    replyingTo = null
                },
                onCancel = {
                    isVoiceRecordingOpen = false
                }
            )
            Spacer(modifier = Modifier.height(8.dp))
        } else {
            // Text input row with integrated microphone inside the field
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                AsyncImage(
                    model = currentUser.avatar,
                    contentDescription = currentUser.name,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    // Replying banner
                    if (replyingTo != null) {
                        Surface(
                            color = Color(0xFFEFF6FF),
                            shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = "@${replyingTo!!.author.handle}님에게 답글 작성 중...",
                                    fontSize = 11.sp,
                                    color = Color(0xFF1D4ED8),
                                    fontWeight = FontWeight.Medium
                                )
                                IconButton(
                                    onClick = { replyingTo = null },
                                    modifier = Modifier.size(18.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "답글 취소",
                                        tint = Color(0xFF60A5FA),
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }

                    // Input field with microphone icon placed cleanly INSIDE the text field
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        placeholder = {
                            Text(
                                text = if (replyingTo != null) "@${replyingTo!!.author.handle}님에게 답글..." else "댓글 입력 또는 마이크로 음성 녹음...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        },
                        trailingIcon = {
                            // Mic icon INSIDE the comment box
                            IconButton(
                                onClick = { isVoiceRecordingOpen = true },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Mic,
                                    contentDescription = "음성 녹음",
                                    tint = PrimaryIndigo,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 44.dp),
                        shape = if (replyingTo != null) RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp) else RoundedCornerShape(22.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryIndigo,
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                        ),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Send button
                IconButton(
                    onClick = {
                        if (commentText.isNotBlank()) {
                            val isReply = replyingTo != null
                            val finalContent = if (isReply) {
                                "@${replyingTo!!.author.handle} $commentText"
                            } else commentText
                            onAddComment(finalContent, replyingTo?.id, null, null)
                            Toast.makeText(
                                context,
                                if (isReply) "답글이 등록되었습니다. 💬" else "댓글이 성공적으로 등록되었습니다. 💬",
                                Toast.LENGTH_SHORT
                            ).show()
                            commentText = ""
                            replyingTo = null
                        }
                    },
                    enabled = commentText.isNotBlank(),
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (commentText.isNotBlank()) PrimaryIndigo else Color(0xFFCBD5E1))
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Send,
                        contentDescription = "전송",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // 2. Comments List
        if (hierarchicalComments.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "첫 번째 댓글이나 따뜻한 음성 메시지를 남겨보세요! 💬🎙️",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                hierarchicalComments.forEach { item ->
                    CommentItemView(
                        comment = item.comment,
                        depth = item.depth,
                        parentComment = item.parentComment,
                        onReplyClick = { replyingTo = item.comment },
                        onLikeClick = { onToggleLike(item.comment.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun CommentItemView(
    comment: Comment,
    depth: Int,
    parentComment: Comment?,
    onReplyClick: () -> Unit,
    onLikeClick: () -> Unit
) {
    val indentPadding = when {
        depth >= 2 -> 48.dp
        depth == 1 -> 26.dp
        else -> 0.dp
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = indentPadding),
        verticalAlignment = Alignment.Top
    ) {
        if (depth > 0) {
            Icon(
                imageVector = Icons.Outlined.SubdirectoryArrowRight,
                contentDescription = "답글",
                tint = if (depth >= 2) PrimaryIndigo else Color(0xFF94A3B8),
                modifier = Modifier
                    .size(16.dp)
                    .padding(top = 4.dp, end = 2.dp)
            )
        }

        AsyncImage(
            model = comment.author.avatar,
            contentDescription = comment.author.name,
            modifier = Modifier
                .size(if (depth >= 2) 26.dp else if (depth == 1) 28.dp else 32.dp)
                .clip(CircleShape)
        )

        Spacer(modifier = Modifier.width(8.dp))

        Column(modifier = Modifier.weight(1f)) {
            // Author row
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = comment.author.name,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "@${comment.author.handle}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (parentComment != null) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Surface(
                        color = Color(0xFFEFF6FF),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "@${parentComment.author.handle}님에게",
                            fontSize = 9.5.sp,
                            color = PrimaryIndigo,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = comment.createdAt,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }

            // Text Content
            if (comment.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = comment.content,
                    fontSize = 12.5.sp,
                    lineHeight = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Voice comment audio player if present
            if (!comment.audioUrl.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                VoiceCommentPlayer(
                    audioUrl = comment.audioUrl,
                    durationSeconds = comment.audioDuration ?: 6
                )
            }

            // Actions row: Reply button & Like button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 4.dp)
            ) {
                Text(
                    text = "답글 달기",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = PrimaryIndigo,
                    modifier = Modifier
                        .clickable(onClick = onReplyClick)
                        .padding(vertical = 2.dp, horizontal = 4.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable(onClick = onLikeClick)
                ) {
                    Icon(
                        imageVector = if (comment.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "좋아요",
                        tint = if (comment.isLiked) Color(0xFFF43F5E) else Color(0xFF94A3B8),
                        modifier = Modifier.size(12.dp)
                    )
                    if (comment.likesCount > 0) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = comment.likesCount.toString(),
                            fontSize = 11.sp,
                            color = if (comment.isLiked) Color(0xFFF43F5E) else Color(0xFF94A3B8),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
