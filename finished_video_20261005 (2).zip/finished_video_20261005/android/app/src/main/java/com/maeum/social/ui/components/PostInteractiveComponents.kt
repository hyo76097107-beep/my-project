package com.maeum.social.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.maeum.social.model.Poll
import com.maeum.social.model.RegionalScope
import com.maeum.social.model.StoryBgm
import com.maeum.social.util.BgmPlayerHelper

@Composable
fun BgmPlayerCard(
    bgm: StoryBgm,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentPlayingBgm by BgmPlayerHelper.currentPlayingBgm.collectAsState()
    val isPlayingGlobal by BgmPlayerHelper.isPlaying.collectAsState()
    val isLoading by BgmPlayerHelper.isLoading.collectAsState()

    val isThisPlaying = currentPlayingBgm?.id == bgm.id && isPlayingGlobal

    // Infinite rotation animation for vinyl
    val infiniteTransition = rememberInfiniteTransition(label = "vinyl_rotate")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isThisPlaying) Color(0xFFFFFBEB) else Color(0xFFF8FAFC),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isThisPlaying) Color(0xFFFDE68A) else Color(0xFFE2E8F0)
        ),
        modifier = modifier
            .fillMaxWidth()
            .clickable {
                BgmPlayerHelper.togglePlay(context, bgm)
            }
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Vinyl Record Art
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E293B))
                    .border(2.dp, Color(0xFF334155), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (!bgm.coverUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = bgm.coverUrl,
                        contentDescription = bgm.title,
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(if (isThisPlaying) rotation else 0f),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = Color(0xFFF59E0B),
                        modifier = Modifier
                            .size(24.dp)
                            .rotate(if (isThisPlaying) rotation else 0f)
                    )
                }

                // Vinyl Center Hole
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(1.dp, Color(0xFF94A3B8), CircleShape)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Track Details
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = bgm.title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    // CC0 Badge
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFFECFDF5),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA7F3D0))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = Color(0xFF059669),
                                modifier = Modifier.size(9.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "CC0 무료",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF065F46)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "${bgm.artist} • ${bgm.genre}",
                    fontSize = 10.sp,
                    color = Color(0xFF64748B),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Animated Equalizer Waveform
            if (isThisPlaying) {
                EqualizerWaveform()
                Spacer(modifier = Modifier.width(8.dp))
            }

            // Play / Pause Button
            FilledIconButton(
                onClick = {
                    BgmPlayerHelper.togglePlay(context, bgm)
                },
                modifier = Modifier.size(32.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = if (isThisPlaying) Color(0xFFF59E0B) else Color(0xFFF1F5F9),
                    contentColor = if (isThisPlaying) Color.White else Color(0xFF475569)
                )
            ) {
                if (isLoading && currentPlayingBgm?.id == bgm.id) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color(0xFFF59E0B)
                    )
                } else if (isThisPlaying) {
                    Icon(
                        imageVector = Icons.Default.Pause,
                        contentDescription = "일시정지",
                        modifier = Modifier.size(16.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "재생",
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun EqualizerWaveform() {
    val infiniteTransition = rememberInfiniteTransition(label = "equalizer")
    val h1 by infiniteTransition.animateFloat(
        initialValue = 4f, targetValue = 14f,
        animationSpec = infiniteRepeatable(tween(300, easing = LinearEasing), RepeatMode.Reverse),
        label = "h1"
    )
    val h2 by infiniteTransition.animateFloat(
        initialValue = 14f, targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(450, easing = LinearEasing), RepeatMode.Reverse),
        label = "h2"
    )
    val h3 by infiniteTransition.animateFloat(
        initialValue = 6f, targetValue = 16f,
        animationSpec = infiniteRepeatable(tween(350, easing = LinearEasing), RepeatMode.Reverse),
        label = "h3"
    )
    val h4 by infiniteTransition.animateFloat(
        initialValue = 12f, targetValue = 4f,
        animationSpec = infiniteRepeatable(tween(400, easing = LinearEasing), RepeatMode.Reverse),
        label = "h4"
    )

    Row(
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        modifier = Modifier.height(16.dp)
    ) {
        Box(modifier = Modifier.width(2.5.dp).height(h1.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
        Box(modifier = Modifier.width(2.5.dp).height(h2.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
        Box(modifier = Modifier.width(2.5.dp).height(h3.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
        Box(modifier = Modifier.width(2.5.dp).height(h4.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
    }
}

@Composable
fun PollCard(
    poll: Poll,
    currentUserId: String,
    onVote: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val hasVoted = poll.options.any { it.votes.contains(currentUserId) }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFFF8FAFC),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Poll,
                    contentDescription = null,
                    tint = Color(0xFF6366F1),
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = poll.question,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Options list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                poll.options.forEach { option ->
                    val isMyVote = option.votes.contains(currentUserId)
                    val percent = if (poll.totalVotes > 0) {
                        (option.votes.size.toFloat() / poll.totalVotes.toFloat()) * 100f
                    } else 0f

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White)
                            .border(
                                1.5.dp,
                                if (isMyVote) Color(0xFF6366F1) else Color(0xFFE2E8F0),
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { onVote(option.id) }
                    ) {
                        // Progress bar fill
                        if (hasVoted) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(percent / 100f)
                                    .background(
                                        if (isMyVote) Color(0xFFEEF2FF) else Color(0xFFF1F5F9)
                                    )
                            )
                        }

                        // Content
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (isMyVote) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF6366F1),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Text(
                                    text = option.text,
                                    fontSize = 12.sp,
                                    fontWeight = if (isMyVote) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isMyVote) Color(0xFF4338CA) else Color(0xFF334155)
                                )
                            }

                            if (hasVoted) {
                                Text(
                                    text = "${percent.toInt()}% (${option.votes.size}표)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isMyVote) Color(0xFF4338CA) else Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "총 ${poll.totalVotes}명 참여 • 항목을 탭하여 투표하세요",
                fontSize = 10.sp,
                color = Color(0xFF94A3B8)
            )
        }
    }
}

@Composable
fun PostFeelingBadge(
    feeling: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFFEF3C7),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A)),
        modifier = modifier
    ) {
        Text(
            text = feeling,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF92400E),
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun PostRegionalScopeBadge(
    scope: RegionalScope,
    modifier: Modifier = Modifier
) {
    val (label, bg, fg) = when (scope) {
        RegionalScope.NEIGHBORHOOD -> Triple("우리 동네", Color(0xFFEFF6FF), Color(0xFF1D4ED8))
        RegionalScope.DISTRICT -> Triple("구 단위", Color(0xFFF5F3FF), Color(0xFF6D28D9))
        RegionalScope.CITY -> Triple("시/도 단위", Color(0xFFECFDF5), Color(0xFF047857))
        RegionalScope.PROVINCE -> Triple("전국", Color(0xFFFFF7ED), Color(0xFFC2410C))
        RegionalScope.ALL -> Triple("전체 공개", Color(0xFFF8FAFC), Color(0xFF475569))
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bg,
        modifier = modifier
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = fg,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
