package com.maeum.social.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.maeum.social.model.Reply

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey val id: String,
    val authorId: String,
    val authorName: String,
    val authorHandle: String,
    val authorAvatar: String,
    val content: String,
    val mediaUrlsJson: String, // List<String> as JSON
    val videoUrlsJson: String, // List<String> as JSON
    val locationTag: String?,
    val neighborhood: String?,
    val regionalScope: String? = null,
    val feeling: String? = null,
    val bgmJson: String? = null,
    val pollJson: String? = null,
    val likesCount: Int,
    val isLiked: Boolean,
    val commentsCount: Int,
    val createdAt: String,
    val scheduledAt: String?,
    val isBanned: Boolean
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey val id: String,
    val postId: String,
    val authorId: String,
    val authorName: String,
    val authorHandle: String,
    val authorAvatar: String,
    val content: String,
    val audioUrl: String?,
    val audioDurationSec: Int,
    val createdAt: String,
    val repliesJson: String // List<Reply> as JSON
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val senderId: String,
    val receiverId: String,
    val content: String,
    val mediaUrl: String?,
    val timestamp: Long,
    val scheduledTime: Long?,
    val isDelivered: Boolean
)

class Converters {
    private val gson = Gson()

    @TypeConverter
    fun fromStringList(value: List<String>?): String {
        return gson.toJson(value ?: emptyList<String>())
    }

    @TypeConverter
    fun toStringList(value: String): List<String> {
        val type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }

    @TypeConverter
    fun fromReplyList(value: List<Reply>?): String {
        return gson.toJson(value ?: emptyList<Reply>())
    }

    @TypeConverter
    fun toReplyList(value: String): List<Reply> {
        val type = object : TypeToken<List<Reply>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }
}
