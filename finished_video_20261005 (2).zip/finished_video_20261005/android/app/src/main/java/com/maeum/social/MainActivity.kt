package com.maeum.social

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.maeum.social.ui.screens.*
import com.maeum.social.ui.theme.MaeumTheme
import com.maeum.social.viewmodel.SocialViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: SocialViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request essential runtime permissions (Location, Audio, Media)
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.READ_MEDIA_IMAGES)
                add(Manifest.permission.READ_MEDIA_VIDEO)
                add(Manifest.permission.READ_MEDIA_AUDIO)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }.toTypedArray()

        ActivityCompat.requestPermissions(this, permissions, 1001)

        setContent {
            MaeumTheme {
                MainAppNavHost(viewModel)
            }
        }
    }
}

@Composable
fun MainAppNavHost(viewModel: SocialViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomBarRoutes = listOf("feed", "explore", "messages", "profile")

    Scaffold(
        bottomBar = {
            if (currentRoute in bottomBarRoutes) {
                NavigationBar {
                    NavigationBarItem(
                        selected = currentRoute == "feed",
                        onClick = { navController.navigate("feed") { popUpTo("feed") { inclusive = true } } },
                        icon = { Icon(Icons.Default.Home, contentDescription = "홈 피드") },
                        label = { Text("동네 피드") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "explore",
                        onClick = { navController.navigate("explore") { popUpTo("feed") } },
                        icon = { Icon(Icons.Default.Search, contentDescription = "탐색") },
                        label = { Text("탐색/검색") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "messages",
                        onClick = { navController.navigate("messages") { popUpTo("feed") } },
                        icon = { Icon(Icons.Default.Mail, contentDescription = "메시지") },
                        label = { Text("메시지") }
                    )
                    NavigationBarItem(
                        selected = currentRoute == "profile",
                        onClick = { navController.navigate("profile") { popUpTo("feed") } },
                        icon = { Icon(Icons.Default.Person, contentDescription = "프로필") },
                        label = { Text("내 정보") }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "feed",
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable("feed") {
                FeedScreen(
                    viewModel = viewModel,
                    onNavigateToPostDetail = { postId ->
                        navController.navigate("post_detail/$postId")
                    },
                    onNavigateToCreatePost = {
                        navController.navigate("create_post")
                    }
                )
            }

            composable("explore") {
                ExploreScreen(
                    viewModel = viewModel,
                    onNavigateToPostDetail = { postId ->
                        navController.navigate("post_detail/$postId")
                    }
                )
            }

            composable(
                route = "post_detail/{postId}",
                arguments = listOf(navArgument("postId") { type = NavType.StringType })
            ) { backStackEntry ->
                val postId = backStackEntry.arguments?.getString("postId") ?: ""
                PostDetailScreen(
                    postId = postId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("messages") {
                MessagesScreen(viewModel = viewModel)
            }

            composable("profile") {
                ProfileScreen(
                    viewModel = viewModel,
                    onNavigateToEditInfo = { navController.navigate("edit_signup_info") }
                )
            }

            composable("edit_signup_info") {
                EditSignupInfoScreen(
                    viewModel = viewModel,
                    onClose = { navController.popBackStack() }
                )
            }

            composable("create_post") {
                CreatePostScreen(
                    viewModel = viewModel,
                    onClose = { navController.popBackStack() }
                )
            }

            composable("auth") {
                AuthScreen(
                    viewModel = viewModel,
                    onLoginSuccess = { navController.navigate("feed") }
                )
            }
        }
    }
}
