package com.maeum.social.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/**
 * Status of media compression and upload task
 */
enum class UploadStatus {
    QUEUED,
    COMPRESSING,
    UPLOADING,
    COMPLETED,
    FAILED,
    CANCELLED
}

/**
 * Local Room Entity for tracking video & media upload tasks in real time
 */
@Entity(tableName = "media_upload_tasks")
data class MediaUploadTaskEntity(
    @PrimaryKey val id: String,
    val postId: String? = null,
    val localUri: String,
    val localCachedPath: String? = null, // Persistent local cache file path preserving media offline
    val fileName: String,
    val fileSize: Long = 0L,
    val mediaType: String = "video/mp4", // video/mp4, image/jpeg, etc.
    val status: String = UploadStatus.QUEUED.name,
    val progress: Int = 0, // 0..100
    val remoteUrl: String? = null,
    val thumbnailUrl: String? = null,
    val durationMs: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface MediaUploadDao {
    @Query("SELECT * FROM media_upload_tasks ORDER BY createdAt DESC")
    fun getAllTasksFlow(): Flow<List<MediaUploadTaskEntity>>

    @Query("SELECT * FROM media_upload_tasks WHERE postId = :postId ORDER BY createdAt ASC")
    fun getTasksForPostFlow(postId: String): Flow<List<MediaUploadTaskEntity>>

    @Query("SELECT * FROM media_upload_tasks WHERE postId = :postId ORDER BY createdAt ASC")
    suspend fun getTasksForPost(postId: String): List<MediaUploadTaskEntity>

    @Query("SELECT * FROM media_upload_tasks WHERE status IN ('QUEUED', 'COMPRESSING', 'UPLOADING') ORDER BY createdAt ASC")
    fun getActiveTasksFlow(): Flow<List<MediaUploadTaskEntity>>

    @Query("SELECT * FROM media_upload_tasks WHERE status IN ('QUEUED', 'COMPRESSING', 'UPLOADING', 'FAILED') ORDER BY createdAt ASC")
    suspend fun getPendingTasks(): List<MediaUploadTaskEntity>

    @Query("SELECT * FROM media_upload_tasks WHERE status != 'COMPLETED' AND status != 'CANCELLED' ORDER BY createdAt ASC")
    suspend fun getAllUnfinishedTasks(): List<MediaUploadTaskEntity>

    @Query("SELECT * FROM media_upload_tasks WHERE id = :id LIMIT 1")
    suspend fun getTaskById(id: String): MediaUploadTaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: MediaUploadTaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<MediaUploadTaskEntity>)

    @Query("UPDATE media_upload_tasks SET status = :status, progress = :progress, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateProgress(id: String, progress: Int, status: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE media_upload_tasks SET localCachedPath = :cachedPath, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateCachedPath(id: String, cachedPath: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE media_upload_tasks SET status = 'COMPLETED', progress = 100, remoteUrl = :remoteUrl, thumbnailUrl = :thumbnailUrl, updatedAt = :updatedAt WHERE id = :id")
    suspend fun markCompleted(id: String, remoteUrl: String, thumbnailUrl: String?, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE media_upload_tasks SET status = 'FAILED', errorMessage = :error, updatedAt = :updatedAt WHERE id = :id")
    suspend fun markFailed(id: String, error: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM media_upload_tasks WHERE id = :id")
    suspend fun deleteTask(id: String)

    @Query("DELETE FROM media_upload_tasks WHERE postId = :postId")
    suspend fun deleteTasksForPost(postId: String)

    @Query("SELECT * FROM media_upload_tasks WHERE status IN ('COMPLETED', 'CANCELLED') OR createdAt < :cutoffTimestamp")
    suspend fun getCleanupCandidateTasks(cutoffTimestamp: Long): List<MediaUploadTaskEntity>

    @Query("SELECT * FROM media_upload_tasks WHERE status = 'COMPLETED'")
    suspend fun getCompletedTasks(): List<MediaUploadTaskEntity>

    @Query("SELECT * FROM media_upload_tasks WHERE createdAt < :cutoffTimestamp")
    suspend fun getExpiredTasks(cutoffTimestamp: Long): List<MediaUploadTaskEntity>

    @Query("DELETE FROM media_upload_tasks WHERE id IN (:ids)")
    suspend fun deleteTasksByIds(ids: List<String>)

    @Query("DELETE FROM media_upload_tasks WHERE status = 'COMPLETED'")
    suspend fun deleteCompletedTasks()

    @Query("DELETE FROM media_upload_tasks WHERE status IN ('COMPLETED', 'CANCELLED') OR createdAt < :cutoffTimestamp")
    suspend fun deleteCleanupCandidates(cutoffTimestamp: Long)
}
