# Proguard rules for Maeum Social Network Android App

-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses
-keepattributes EnclosingMethod

# Keep Room database classes
-keep class androidx.room.** { *; }
-dontwarn androidx.room.**

# Keep Media3 / ExoPlayer classes
-keep class androidx.media3.** { *; }

# Keep Coil image loader
-keep class coil.** { *; }

# Keep Gson models
-keepclassmembers class com.maeum.social.model.** { <fields>; }
-keep class com.maeum.social.model.** { *; }
