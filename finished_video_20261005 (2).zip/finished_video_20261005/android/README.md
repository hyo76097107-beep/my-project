# 마음(Maeum) Android 네이티브 프로젝트

웹 애플리케이션의 디자인 및 모든 사용자 경험을 Android 네이티브 환경에 완벽히 이식한 **Kotlin & Jetpack Compose** 기반 프로젝트입니다.

---

## 📱 프로젝트 사양 (Project Specifications)

- **언어 (Language)**: Kotlin 2.0.0
- **UI 툴킷 (UI Toolkit)**: Jetpack Compose (Material 3)
- **Target SDK**: **Android 16 (API 36)**
- **Compile SDK**: **36**
- **Min SDK**: **26 (Android 8.0 Oreo 이상 완벽 지원)**
- **빌드 시스템 (Build System)**: Gradle Kotlin DSL (`build.gradle.kts`)
- **패키지 명 (Application ID)**: `com.maeum.social`
- **배포 형식 (Release Artifact)**: Google Play AAB (Android App Bundle) & APK

---

## 🚀 구현된 핵심 기능 목록 (Full Parity with Web App)

1. **스토리 (Stories) & 인라인 뷰어 (`StoryComponents.kt`)**
   - 상단 그라디언트 링 피드 스토리 바 (인스타그램 스타일)
   - 5초 자동 전환 타이머 프로그레스 바, 이전/다음 탭 제스처, 작성자 헤더
   - 스토리 전용 저작권 무료 BGM 자동 재생 및 사진/동영상 등록

2. **100% 저작권 무료(CC0) 배경음악 (BGM) 시스템 (`BgmPlayerHelper.kt` & `PostInteractiveComponents.kt`)**
   - 로우파이/힐링, 어쿠스틱, 피아노, 시티팝, 트로피컬, 앰비언트, 재즈, 인디, 업비트 등 전 장르 프리셋 음원 내장
   - 게시물 작성/수정 시 BGM 선택 서랍 (CC0 안심 배지, 카테고리 필터, 실시간 검색, 미리듣기 재생)
   - 피드 내 인터랙티브 바이닐 회전 BGM 플레이어 카드, 4채널 그래픽 이퀄라이저 파형 애니메이션, 원클릭 재생/일시정지

3. **인터랙티브 투표 (Poll) 기능 (`PollCard` in `PostInteractiveComponents.kt`)**
   - 질문 및 2~4개 선택지 입력 생성
   - 피드에서 사용자가 즉시 투표 참여 가능 (실시간 백분율 % 게이지 바, 득표수, 선택 완료 체크 표시)

4. **기분(Mood/Feeling) 및 지역 공개 범위 배지**
   - 12가지 감성 기분 이모지 태그 (✨ 행복함, 🥐 힐링, 🔥 열정 가득 등)
   - 게시물 공개 지역 범위 선택 및 배지 (전체, 우리 동네, 구 단위, 시/도 단위, 전국)

5. **글로벌 탐색 & 검색 화면 (`ExploreScreen.kt`)**
   - 인기 동네 해시태그 칩 필터링 (#오운완, #연남동, #성수동맛집, #개발자 등)
   - 키워드, 작성자명, 핸들, 동네 기반 실시간 피드 통합 검색

6. **로그인 / 회원가입 (`AuthScreen.kt`)**
   - 아이디(@handle), 이메일, 휴대폰 번호 기반 계정 가입 및 로그인
   - 사용자 세션 및 내 프로필 연동

7. **동·지역별 피드 및 게시 (`FeedScreen.kt`)**
   - 전체 / 역삼동 / 삼성동 / 한남동 / 서초동 등 동 단위 필터링 탭
   - 게시글 작성 시 선택된 동네 태그 자동 부여 및 지역 공개 범위 배지

8. **팔로우 및 언팔로우 기능 (`FeedScreen.kt` & `ProfileScreen.kt`)**
   - 피드 내 다른 회원의 게시물 헤더에서 원클릭 [팔로우] / [팔로잉] 실시간 토글
   - 내 프로필 및 상대방 프로필의 팔로워/팔로잉 통계 실시간 반영
   - 백엔드(`/api/sync/users/:id/follow`)와 자동 동기화

9. **GPS 위치 자동 감지 (`LocationHelper.kt`)**
   - `FusedLocationProviderClient`를 이용한 GPS 고정밀 실시간 좌표 추출
   - 한국어 Geocoder 기반 시/구/동(예: `서울특별시 강남구 역삼동`) 자동 역지오코딩

10. **사진 및 여러 개의 동영상 한 번에 업로드 (`CreatePostScreen.kt`)**
    - `ActivityResultContracts.GetMultipleContents()`를 활용한 멀티 미디어 피커
    - 여러 개의 동영상 및 사진을 한 번에 선택하여 게시글에 첨부 및 일괄 등록
    - 대용량 동영상 백그라운드 WorkManager 순차 업로드 큐 지원

11. **4초 이상 긴 동영상 무제한 재생 및 기기간 동기화 시청 (`VideoPlayerView.kt`)**
    - 2초 짧은 영상뿐만 아니라 4초, 10초, 30초 이상의 고화질 동영상도 버퍼 언더런 없이 매끄럽게 스트리밍 재생
    - Android Media3 / ExoPlayer 기반 하드웨어 가속 및 안전한 디코더 폴백 지원
    - RFC 7233 Range 스트리밍 및 faststart(+moov atom) 최적화
    - WebSocket 실시간 브로드캐스트를 통해 서로 다른 휴대폰 간 재생 위치(Position), 재생/일시정지 상태 실시간 동기화

12. **댓글 및 답글(대댓글) 등록 (`PostDetailScreen.kt`)**
    - 원댓글 등록 및 댓글 항목 우측 [답글 달기] 클릭 시 대댓글(`Reply`) 등록
    - 계층형 대댓글 트리 렌더링 지원

13. **음성 녹음 댓글 등록 (`AudioRecorderHelper.kt` & `VoiceCommentRecordBar.kt`)**
    - Android `MediaRecorder`를 활용한 마이크 음성 댓글 녹음 (.m4a)
    - 녹음 타이머, 취소, 재생 지원 및 음성 답글 지원

14. **메시지 및 예약 전송 (`MessagesScreen.kt`)**
    - 실시간 1:1 대화
    - 30분 뒤 또는 지정 시간에 전송되는 예약 전송 기능

15. **프로필 관리 및 로컬 캐시 최적화 (`ProfileScreen.kt`)**
    - 내 작성글 모아보기, 팔로워/팔로잉 현황, 소개글 및 위치 정보
    - Room DB 및 디바이스 저장공간 최적화 캐시 클리너 내장

---

## 🛠️ Google Play 배포용 AAB (Android App Bundle) 빌드 방법

### 1. Android Studio에서 프로젝트 열기
1. Android Studio를 실행하고 **Open**을 클릭합니다.
2. 이 디렉토리(`android/`)를 선택하여 엽니다.
3. Gradle Sync가 완료되면 빌드 준비가 완료됩니다.

### 2. 원클릭 빌드 스크립트 실행
- **AAB 번들 빌드 (Google Play 출시용)**:
  ```bash
  cd android
  ./build_aab.sh
  # 또는
  ./gradlew bundleRelease
  ```
- **테스트용 APK 빌드 (기기 직접 설치용)**:
  ```bash
  cd android
  ./build_apk.sh
  # 또는
  ./gradlew assembleDebug
  ```

### 3. 생성된 배포 파일 위치
- **Google Play 업로드용 AAB 번들**:
  ```
  android/app/build/outputs/bundle/release/app-release.aab
  ```
- **테스트 설치용 Debug APK**:
  ```
  android/app/build/outputs/apk/debug/app-debug.apk
  ```

### 4. Google Play Console 업로드 안내
1. [Google Play Console](https://play.google.com/console)에 접속하여 개발자 계정으로 로그인합니다.
2. 애플리케이션을 생성하고 **프로덕션** (또는 비공개/내부 테스트) 트랙의 새 버전 생성을 클릭합니다.
3. 위에서 생성된 `app-release.aab` 파일을 업로드합니다.
4. **Android 16 (API 36)** targetSdk 사양 및 64비트 아키텍처 번들 최적화가 완료되어 즉시 심사 제출이 가능합니다.
