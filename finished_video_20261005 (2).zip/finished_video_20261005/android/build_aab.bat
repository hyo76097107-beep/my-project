@echo off
echo ========================================================
echo  [마음 소셜] Google Play 배포용 AAB 빌드 시작
echo ========================================================

call gradlew.bat clean
call gradlew.bat bundleRelease --stacktrace

if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================================
    echo  [성공] AAB 빌드가 성공적으로 완료되었습니다!
    echo  파일 위치: app\build\outputs\bundle\release\app-release.aab
    echo ========================================================
) else (
    echo.
    echo [오류] 빌드 중 오류가 발생했습니다. JDK 17 및 Android SDK 환경을 확인해주세요.
)
pause
