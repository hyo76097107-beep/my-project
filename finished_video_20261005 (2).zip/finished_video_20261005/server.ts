import express from 'express';
import http from 'http';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { WebSocketServer } from 'ws';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { requestSmsVerification, verifySmsCode, dispatchRealSms } from './server/smsService';
import {
  initSmsApiConfig,
  getMaskedSmsApiConfig,
  getRawSmsApiConfig,
  updateSmsApiConfig,
  resetSmsApiConfig,
} from './server/smsConfig';
import {
  initSmsDb,
  getAllSmsRecords,
  getSmsDbStats,
  insertSmsVerificationRecord,
  markSmsRecordVerified,
  deleteSmsRecord,
  clearAllSmsRecords,
  linkUserToSmsRecord,
} from './server/smsDb';
import { requestEmailVerification, verifyEmailCode } from './server/emailService';
import syncRoutes from './server/syncRoutes';
import { initSyncStore, registerWsClient } from './server/syncStore';

dotenv.config();

const PORT = 3000;

function getAIClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  // Initialize persistent SMS verification database & SMS API configuration
  initSmsDb();
  initSmsApiConfig();
  initSyncStore();

  const app = express();

  // Global CORS and Streaming headers for Android & Cross-Origin clients
  app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS, PATCH');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Range, X-Requested-With, Origin, Accept');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Range, Accept-Ranges, Content-Length');
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
      return;
    }
    next();
  });

  // Middleware for JSON parsing (up to 300mb for high-res / multi-video attachments)
  app.use(express.json({ limit: '300mb' }));
  app.use(express.urlencoded({ extended: true, limit: '300mb' }));

  // Static files in public directory (videos, icons, assets, uploaded media) with range streaming support
  const publicDir = path.join(process.cwd(), 'public');
  const uploadsDir = path.join(publicDir, 'uploads');
  const videosDir = path.join(publicDir, 'videos');
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  const staticVideoOptions = {
    setHeaders: (res: any, filePath: string) => {
      res.setHeader('Accept-Ranges', 'bytes');
      res.setHeader('Access-Control-Allow-Origin', '*');
      const lower = filePath.toLowerCase();
      if (lower.endsWith('.mp4') || lower.endsWith('.m4v')) {
        res.setHeader('Content-Type', 'video/mp4');
      } else if (lower.endsWith('.webm')) {
        res.setHeader('Content-Type', 'video/webm');
      } else if (lower.endsWith('.mov')) {
        res.setHeader('Content-Type', 'video/mp4');
      } else if (lower.endsWith('.ogg') || lower.endsWith('.ogv')) {
        res.setHeader('Content-Type', 'video/ogg');
      } else if (lower.endsWith('.3gp')) {
        res.setHeader('Content-Type', 'video/3gpp');
      }
    },
  };

  // Dedicated RFC 7233 compliant Range streaming helper for seamless seeking on iOS Safari, Chrome & Android ExoPlayer
  // Handles byte-range streaming without socket stalls on 10s+ or large video files
  const streamVideo = (filePath: string, req: express.Request, res: express.Response) => {
    try {
      if (!fs.existsSync(filePath)) {
        res.status(404).type('text/plain').send('Video not found');
        return;
      }

      // Handle OPTIONS CORS preflight immediately
      if (req.method === 'OPTIONS') {
        res.writeHead(204, {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization, Range, X-Requested-With, Origin, Accept',
          'Access-Control-Expose-Headers': 'Content-Range, Accept-Ranges, Content-Length, ETag, Last-Modified',
          'Access-Control-Max-Age': '86400',
        });
        res.end();
        return;
      }

      const stat = fs.statSync(filePath);
      const fileSize = stat.size;
      const lower = filePath.toLowerCase();
      let contentType = 'application/octet-stream';
      if (lower.endsWith('.mp4') || lower.endsWith('.m4v')) {
        contentType = 'video/mp4';
      } else if (lower.endsWith('.webm')) {
        contentType = 'video/webm';
      } else if (lower.endsWith('.mov')) {
        contentType = 'video/mp4';
      } else if (lower.endsWith('.ogg') || lower.endsWith('.ogv')) {
        contentType = 'video/ogg';
      } else if (lower.endsWith('.3gp')) {
        contentType = 'video/3gpp';
      } else if (lower.endsWith('.jpg') || lower.endsWith('.jpeg')) {
        contentType = 'image/jpeg';
      } else if (lower.endsWith('.png')) {
        contentType = 'image/png';
      } else if (lower.endsWith('.webp')) {
        contentType = 'image/webp';
      } else if (lower.endsWith('.gif')) {
        contentType = 'image/gif';
      } else if (lower.endsWith('.svg')) {
        contentType = 'image/svg+xml';
      } else if (lower.endsWith('.mp3')) {
        contentType = 'audio/mpeg';
      } else if (lower.endsWith('.m4a')) {
        contentType = 'audio/mp4';
      } else if (lower.endsWith('.wav')) {
        contentType = 'audio/wav';
      }

      const commonHeaders: Record<string, string> = {
        'Content-Type': contentType,
        'Accept-Ranges': 'bytes',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, Range, X-Requested-With, Origin, Accept',
        'Access-Control-Expose-Headers': 'Content-Range, Accept-Ranges, Content-Length, Last-Modified',
        'Cache-Control': 'public, max-age=3600',
        'Last-Modified': stat.mtime.toUTCString(),
      };

      // Handle HEAD request
      if (req.method === 'HEAD') {
        res.writeHead(200, {
          ...commonHeaders,
          'Content-Length': String(fileSize),
        });
        res.end();
        return;
      }

      const range = req.headers.range;

      if (range) {
        // Parse Range: bytes=start-end or bytes=start-
        const matches = range.match(/^bytes=(\d*)-(\d*)$/);
        if (!matches) {
          res.writeHead(416, {
            ...commonHeaders,
            'Content-Range': `bytes */${fileSize}`,
          });
          res.end();
          return;
        }

        let start: number;
        let end: number;

        if (matches[1] === '') {
          // Suffix range: bytes=-500 (last 500 bytes)
          const suffixLength = parseInt(matches[2], 10);
          start = Math.max(0, fileSize - suffixLength);
          end = fileSize - 1;
        } else {
          start = parseInt(matches[1], 10);
          if (matches[2] !== '') {
            end = Math.min(parseInt(matches[2], 10), fileSize - 1);
          } else {
            // Open-ended range: bytes=0- or bytes=start-
            // Stream completely to the end of the file (RFC 7233)
            // Node.js stream backpressure and socket close handle pause/seeking automatically
            end = fileSize - 1;
          }
        }

        if (isNaN(start) || isNaN(end) || start >= fileSize || end >= fileSize || start > end) {
          res.writeHead(416, {
            ...commonHeaders,
            'Content-Range': `bytes */${fileSize}`,
          });
          res.end();
          return;
        }

        // Bound range responses so large media never becomes one huge proxy response.
        end = Math.min(end, start + 4 * 1024 * 1024 - 1);
        const chunkLength = end - start + 1;
        res.writeHead(206, {
          ...commonHeaders,
          'Content-Range': `bytes ${start}-${end}/${fileSize}`,
          'Content-Length': String(chunkLength),
        });

        const fileStream = fs.createReadStream(filePath, { start, end });
        fileStream.pipe(res);

        fileStream.on('error', (err) => {
          console.error('[MediaStreamError]', err);
          if (!res.headersSent) res.status(500).end();
          else res.destroy();
        });

        res.on('close', () => {
          fileStream.destroy();
        });
      } else {
        // Non-range request: serve entire file with 200 OK and Accept-Ranges: bytes
        res.writeHead(200, {
          ...commonHeaders,
          // No Content-Length: Node uses chunked transfer for a full GET.
        });
        res.flushHeaders();

        const fileStream = fs.createReadStream(filePath);
        fileStream.pipe(res);

        fileStream.on('error', (err) => {
          console.error('[MediaStreamError]', err);
          if (!res.headersSent) res.status(500).end();
          else res.destroy();
        });

        res.on('close', () => {
          fileStream.destroy();
        });
      }
    } catch (err: any) {
      console.error('[MediaResponseError]', err);
      if (!res.headersSent) res.status(500).end();
      else res.destroy();
    }
  };

  const resolveAndStream = (dir: string, req: express.Request, res: express.Response) => {
    let rawFilename = req.params[0] || (req.params as any).filename || '';
    rawFilename = rawFilename.split('?')[0];
    try {
      rawFilename = decodeURIComponent(rawFilename);
    } catch {}
    const filename = path.basename(rawFilename);
    if (!filename) {
      res.status(404).type('text/plain').send('File not found');
      return;
    }
    const filePath = path.join(dir, filename);
    const distFilePath = path.join(process.cwd(), 'dist', path.basename(dir), filename);
    const resolvedPath = fs.existsSync(filePath) ? filePath : fs.existsSync(distFilePath) ? distFilePath : null;
    if (resolvedPath) {
      streamVideo(resolvedPath, req, res);
    } else {
      res.status(404).type('text/plain').send('File not found');
    }
  };

  app.all('/uploads/*', (req, res) => {
    resolveAndStream(uploadsDir, req, res);
  });

  app.all('/videos/*', (req, res) => {
    resolveAndStream(videosDir, req, res);
  });

  app.use('/uploads', express.static(uploadsDir, staticVideoOptions));
  app.use('/videos', express.static(videosDir, staticVideoOptions));
  app.use(express.static(publicDir, staticVideoOptions));

  // Real-time synchronization API (SSE & Multi-device syncing)
  app.use('/api/sync', syncRoutes);

  // Direct alias for message read and message API
  app.use('/api/messages', (req, res, next) => {
    req.url = '/messages' + req.url;
    syncRoutes(req, res, next);
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // SMS Gateway Status Check (Reads dynamic sms_api_config.json)
  app.get('/api/sms/gateway-status', (req, res) => {
    const rawConfig = getRawSmsApiConfig();
    const maskedConfig = getMaskedSmsApiConfig();

    res.json({
      configured: maskedConfig.hasCredentials && rawConfig.enabled && !rawConfig.testMode,
      provider: rawConfig.provider,
      providerLabel:
        rawConfig.provider === 'CoolSMS'
          ? 'CoolSMS / Solapi (대한민국 이동통신사 SMS)'
          : rawConfig.provider === 'Aligo'
          ? '알리고 (Aligo SMS 대한민국)'
          : rawConfig.provider === 'Twilio'
          ? 'Twilio (글로벌 SMS)'
          : rawConfig.provider === 'NaverSENS'
          ? 'Naver Cloud SENS (네이버 클라우드 SMS)'
          : rawConfig.provider === 'Custom'
          ? 'Custom HTTP REST API'
          : '시뮬레이션 샌드박스 (DB 기록 모드)',
      senderNumber: rawConfig.senderNumber || null,
      testMode: rawConfig.testMode,
      enabled: rawConfig.enabled,
      hasCredentials: maskedConfig.hasCredentials,
      updatedAt: rawConfig.updatedAt,
    });
  });

  // Get SMS API Configuration (Masked for Admin UI)
  app.get('/api/sms/config', (req, res) => {
    try {
      const config = getMaskedSmsApiConfig();
      res.json({ success: true, config });
    } catch (err: any) {
      console.error('Error fetching SMS API config:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Update SMS API Configuration
  app.post('/api/sms/config', (req, res) => {
    try {
      const updated = updateSmsApiConfig(req.body, req.body.updatedBy || '관리자');
      const masked = getMaskedSmsApiConfig();
      res.json({
        success: true,
        message: `SMS API 설정(${updated.provider})이 성공적으로 저장되었습니다.`,
        config: masked,
      });
    } catch (err: any) {
      console.error('Error updating SMS API config:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Reset SMS API Configuration
  app.post('/api/sms/config/reset', (req, res) => {
    try {
      resetSmsApiConfig();
      const masked = getMaskedSmsApiConfig();
      res.json({
        success: true,
        message: 'SMS API 설정이 기본값으로 초기화되었습니다.',
        config: masked,
      });
    } catch (err: any) {
      console.error('Error resetting SMS API config:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Test SMS API Gateway Connection Directly
  app.post('/api/sms/test-connection', async (req, res) => {
    try {
      const { phoneNumber, customMessage } = req.body;
      const targetPhone = phoneNumber || getRawSmsApiConfig().senderNumber || '01012345678';
      const testText = customMessage || `[마음(Maeum)] SMS API 연동 테스트 메시지입니다. (${new Date().toLocaleTimeString('ko-KR')})`;

      const result = await dispatchRealSms(targetPhone, testText);
      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/sms/test-connection:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'SMS API 연결 테스트 중 오류가 발생했습니다.',
      });
    }
  });

  // Send SMS Verification Code Endpoint
  app.post('/api/sms/send-verification', async (req, res) => {
    try {
      const { phoneNumber } = req.body;
      if (!phoneNumber || typeof phoneNumber !== 'string') {
        res.status(400).json({ success: false, error: '휴대폰 번호를 전달해주세요.' });
        return;
      }

      const result = await requestSmsVerification(phoneNumber);
      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/sms/send-verification:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'SMS 발송 처리 중 오류가 발생했습니다.',
      });
    }
  });

  // Verify SMS Code Endpoint
  app.post('/api/sms/verify-code', (req, res) => {
    try {
      const { phoneNumber, code } = req.body;
      if (!phoneNumber || !code) {
        res.status(400).json({ success: false, error: '휴대폰 번호와 인증번호를 입력해주세요.' });
        return;
      }

      const result = verifySmsCode(phoneNumber, code);
      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/sms/verify-code:', err);
      res.status(500).json({
        success: false,
        error: err.message || '인증번호 검증 중 오류가 발생했습니다.',
      });
    }
  });

  // SMS Database: Get all verification records & stats
  app.get('/api/sms/db-records', (req, res) => {
    try {
      const search = req.query.search as string | undefined;
      const status = req.query.status as string | undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 100;

      const records = getAllSmsRecords({ search, status, limit });
      const stats = getSmsDbStats();

      res.json({
        success: true,
        records,
        stats,
        total: records.length,
      });
    } catch (err: any) {
      console.error('Error in GET /api/sms/db-records:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // SMS Database: Direct insertion (칸 / 레코드 직접 등록)
  app.post('/api/sms/db-records', (req, res) => {
    try {
      const {
        phoneNumber,
        code,
        status = 'pending',
        provider = 'Manual_Admin_Input',
        notes = '관리자 수동 직접 입력',
        expiresInMinutes = 3,
      } = req.body;

      if (!phoneNumber) {
        res.status(400).json({ success: false, error: '휴대폰 번호를 입력해주세요.' });
        return;
      }

      const generatedCode = code && code.toString().trim()
        ? code.toString().trim()
        : Math.floor(100000 + Math.random() * 900000).toString();

      const record = insertSmsVerificationRecord({
        phoneNumber,
        code: generatedCode,
        provider,
        smsText: `[마음(Maeum)] 본인확인 인증번호 [${generatedCode}] (관리자 직접 등록)`,
        isRealSmsSent: false,
        expiresInMinutes: Number(expiresInMinutes) || 3,
        status,
        notes,
      });

      res.json({
        success: true,
        message: 'SMS 인증 데이터베이스에 레코드가 성공적으로 입력되었습니다.',
        record,
      });
    } catch (err: any) {
      console.error('Error in POST /api/sms/db-records:', err);
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // SMS Database: Manual verify a record
  app.post('/api/sms/db-records/:id/verify', (req, res) => {
    try {
      const { id } = req.params;
      const record = markSmsRecordVerified(id, {
        notes: '관리자에 의해 DB에서 수동 인증 처리됨',
      });
      if (!record) {
        res.status(404).json({ success: false, error: '해당 DB 레코드를 찾을 수 없습니다.' });
        return;
      }
      res.json({ success: true, message: 'DB 레코드가 인증완료 처리되었습니다.', record });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // SMS Database: Delete a record
  app.delete('/api/sms/db-records/:id', (req, res) => {
    try {
      const { id } = req.params;
      const ok = deleteSmsRecord(id);
      res.json({ success: ok, message: ok ? 'DB 레코드가 삭제되었습니다.' : '삭제할 레코드가 없습니다.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // SMS Database: Clear test records
  app.post('/api/sms/db-records/clear', (req, res) => {
    try {
      clearAllSmsRecords();
      res.json({ success: true, message: 'DB 테스트 기록이 초기화되었습니다.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // SMS Database: Link user to verified phone record
  app.post('/api/sms/link-user', (req, res) => {
    try {
      const { phoneNumber, userId, userHandle } = req.body;
      if (phoneNumber && userId) {
        linkUserToSmsRecord(phoneNumber, userId, userHandle || '');
      }
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // Email Gateway Status Check
  app.get('/api/email/gateway-status', (req, res) => {
    const hasSmtp = !!(
      (process.env.SMTP_USER || process.env.GMAIL_USER) &&
      (process.env.SMTP_PASS || process.env.GMAIL_APP_PASSWORD)
    );
    const hasResend = !!process.env.RESEND_API_KEY;

    res.json({
      configured: hasSmtp || hasResend,
      provider: hasResend
        ? 'Resend API (초고속 이메일 게이트웨이)'
        : hasSmtp
        ? process.env.SMTP_HOST
          ? `SMTP 서버 (${process.env.SMTP_HOST})`
          : 'Gmail SMTP (구글 메일 서버)'
        : 'none',
      senderEmail: process.env.EMAIL_FROM || process.env.SMTP_FROM || process.env.SMTP_USER || process.env.GMAIL_USER || null,
    });
  });

  // Send 6-Digit Email Verification Code Endpoint
  app.post('/api/email/send-verification', async (req, res) => {
    try {
      const { email, purpose = '본인확인' } = req.body;
      if (!email || typeof email !== 'string') {
        res.status(400).json({ success: false, error: '이메일 주소를 입력해주세요.' });
        return;
      }

      const result = await requestEmailVerification(email, purpose);
      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/email/send-verification:', err);
      res.status(500).json({
        success: false,
        error: err.message || '이메일 발송 처리 중 오류가 발생했습니다.',
      });
    }
  });

  // Verify 6-Digit Email Verification Code Endpoint
  app.post('/api/email/verify-code', (req, res) => {
    try {
      const { email, code } = req.body;
      if (!email || !code) {
        res.status(400).json({ success: false, error: '이메일 주소와 6자리 인증번호를 모두 입력해주세요.' });
        return;
      }

      const result = verifyEmailCode(email, code);
      res.json(result);
    } catch (err: any) {
      console.error('Error in /api/email/verify-code:', err);
      res.status(500).json({
        success: false,
        error: err.message || '인증번호 검증 중 오류가 발생했습니다.',
      });
    }
  });

  // Real-time Translation endpoint powered by Gemini API
  app.post('/api/translate', async (req, res) => {
    try {
      const { text, targetLanguage = 'Korean', sourceLanguage = 'auto' } = req.body;

      if (!text || typeof text !== 'string' || !text.trim()) {
        res.status(400).json({ error: '번역할 텍스트를 입력해주세요.' });
        return;
      }

      const ai = getAIClient();

      if (!ai) {
        // Fallback message if API key is not yet set
        res.status(503).json({
          error: 'GEMINI_API_KEY가 설정되지 않았습니다. Settings > Secrets에서 키를 확인해주세요.',
          hasApiKey: false,
        });
        return;
      }

      const prompt = `You are a professional social media translator.
Translate the following social media post text accurately, naturally, and contextually into ${targetLanguage}.
Guidelines:
1. Preserve hashtags (e.g. #React, #일상), user mentions (e.g. @username), URLs, and emojis in their proper positions.
2. Keep the tone conversational, friendly, and natural suited for social network feeds.
3. Return ONLY a valid JSON object matching this exact format, with no markdown code fences:
{
  "translatedText": "the translated content here",
  "detectedLanguage": "the detected source language name in Korean, e.g. 한국어, 영어, 일본어, 중국어, 스페인어, etc.",
  "targetLanguage": "${targetLanguage}"
}

Post Text to translate:
"""
${text}
"""`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.3,
        },
      });

      const responseText = response.text || '';
      
      let parsed;
      try {
        parsed = JSON.parse(responseText.trim());
      } catch (parseErr) {
        // In case JSON parsing fails, strip possible markdown fences or wrap raw text
        const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
        try {
          parsed = JSON.parse(cleaned);
        } catch {
          parsed = {
            translatedText: cleaned || responseText,
            detectedLanguage: '자동 감지',
            targetLanguage: targetLanguage,
          };
        }
      }

      res.json({
        success: true,
        translatedText: parsed.translatedText || text,
        detectedLanguage: parsed.detectedLanguage || '자동 감지',
        targetLanguage: parsed.targetLanguage || targetLanguage,
      });
    } catch (error: any) {
      console.error('Translation error:', error);
      res.status(500).json({
        error: error.message || '번역 중 오류가 발생했습니다.',
        success: false,
      });
    }
  });

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const httpServer = http.createServer(app);

  // Initialize real-time WebSocket server for Android & Web cross-device media synchronization
  const wss = new WebSocketServer({ server: httpServer, path: '/ws/sync' });
  wss.on('connection', (ws) => {
    registerWsClient(ws);
  });

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server running on http://0.0.0.0:${PORT}`);
    console.log(`📡 WebSocket MediaSync running on ws://0.0.0.0:${PORT}/ws/sync`);
  });
}

startServer();
