#!/bin/bash
set -e

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
if [ -d "/usr/lib/jvm/java-17-openjdk-amd64" ]; then
  export JAVA_HOME="/usr/lib/jvm/java-17-openjdk-amd64"
elif [ -z "$JAVA_HOME" ] || [ ! -x "$JAVA_HOME/bin/java" ]; then
  if [ -x "/usr/bin/java" ]; then
    export JAVA_HOME="/usr"
  fi
fi
export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-/opt/android-sdk}"

echo "========================================================"
echo "  마음(Maeum) Android 프로젝트 Bash 명령어 실행기"
echo "  Target SDK: Android 16 (API 36) | Kotlin 2.0.0 Compose"
echo "========================================================"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/android"

check_jdk() {
  if ! command -v java >/dev/null 2>&1 && [ ! -x "$JAVA_HOME/bin/java" ]; then
    echo "⚠️  알림: 현재 쉘 환경에 Java(JDK 17+)가 설치되어 있지 않습니다."
    echo "💡 로컬 터미널, CI/CD 또는 Android Studio에서 아래 명령어를 실행하세요:"
    echo ""
    echo "  [Ubuntu/Debian 환경]"
    echo "    sudo apt-get update && sudo apt-get install -y openjdk-17-jdk"
    echo ""
    echo "  [macOS Homebrew 환경]"
    echo "    brew install openjdk@17"
    echo ""
    echo "  [Google Play 배포용 AAB 빌드 명령어]"
    echo "    cd android && ./gradlew bundleRelease"
    echo ""
    echo "  [테스트 설치용 Debug APK 빌드 명령어]"
    echo "    cd android && ./gradlew assembleDebug"
    echo "========================================================"
    return 1
  fi
  return 0
}

ACTION="${1:-help}"

case "$ACTION" in
  aab|bundle)
    echo "📦 Google Play 출시용 AAB (Android App Bundle) 빌드를 실행합니다..."
    if check_jdk; then
      chmod +x ./gradlew
      ./gradlew bundleRelease --stacktrace --no-daemon --console=plain
      echo "✅ 완료: android/app/build/outputs/bundle/release/app-release.aab"
    fi
    ;;
  apk|debug)
    echo "📲 테스트 설치용 APK (Debug APK) 빌드를 실행합니다..."
    if check_jdk; then
      chmod +x ./gradlew
      ./gradlew assembleDebug --stacktrace --no-daemon --console=plain
      echo "✅ 완료: android/app/build/outputs/apk/debug/app-debug.apk"
    fi
    ;;
  clean)
    echo "🧹 빌드 캐시를 정리합니다..."
    if check_jdk; then
      chmod +x ./gradlew
      ./gradlew clean --no-daemon --console=plain
    fi
    ;;
  check|test)
    echo "🔍 프로젝트 컴파일 및 린트 검사를 실행합니다..."
    if check_jdk; then
      chmod +x ./gradlew
      ./gradlew check --no-daemon --console=plain
    fi
    ;;
  *)
    echo "사용 가능한 Bash 명령어:"
    echo "  ./build_android.sh aab      - Google Play 출시용 AAB 번들 빌드 (bundleRelease)"
    echo "  ./build_android.sh apk      - 테스트 기기 설치용 APK 빌드 (assembleDebug)"
    echo "  ./build_android.sh clean    - Gradle 빌드 캐시 정리 (clean)"
    echo "  ./build_android.sh check    - 프로젝트 코드 무결성 검사 (check)"
    echo ""
    echo "직접 gradlew를 사용하는 Bash 명령어:"
    echo "  cd android && ./gradlew bundleRelease  # Google Play AAB 빌드"
    echo "  cd android && ./gradlew assembleDebug  # 기기 테스트용 APK 빌드"
    echo "========================================================"
    ;;
esac
