import { generateVideoThumbnail } from '../utils/imageCompressor';

export interface UploadResult {
  url: string;
  thumbnail?: string;
  name: string;
  size: number;
}

/**
 * Uploads a large file in sequential 2MB chunks to /api/sync/upload-chunk
 */
async function uploadFileInChunks(
  file: File,
  onStatusUpdate?: (text: string) => void
): Promise<{ url: string; thumbnail?: string } | null> {
  const CHUNK_SIZE = 2 * 1024 * 1024; // 2 MB chunks
  const totalChunks = Math.ceil(file.size / CHUNK_SIZE);
  const uploadId = `upload_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  let finalResult: { url: string; thumbnail?: string } | null = null;

  for (let chunkIndex = 0; chunkIndex < totalChunks; chunkIndex++) {
    const start = chunkIndex * CHUNK_SIZE;
    const end = Math.min(file.size, start + CHUNK_SIZE);
    const chunkBlob = file.slice(start, end);

    const formData = new FormData();
    formData.append('uploadId', uploadId);
    formData.append('chunkIndex', chunkIndex.toString());
    formData.append('totalChunks', totalChunks.toString());
    formData.append('fileName', file.name);
    formData.append('chunk', chunkBlob, `chunk_${chunkIndex}.tmp`);

    const pct = Math.round(((chunkIndex + 1) / totalChunks) * 100);
    onStatusUpdate?.(`${file.name} 순차 청크 전송 중 (${chunkIndex + 1}/${totalChunks} - ${pct}%)...`);

    // Retry up to 3 times per chunk
    let success = false;
    let lastErr: any = null;

    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        const res = await fetch('/api/sync/upload-chunk', {
          method: 'POST',
          body: formData,
        });

        if (res.ok) {
          const data = await res.json();
          if (data.success) {
            success = true;
            if (data.completed && data.url) {
              finalResult = {
                url: data.url,
                thumbnail: data.thumbnail,
              };
            }
            break;
          } else {
            lastErr = new Error(data.error || 'Chunk error');
          }
        } else {
          lastErr = new Error(`HTTP ${res.status}`);
        }
      } catch (e) {
        lastErr = e;
        await new Promise((r) => setTimeout(r, attempt * 400));
      }
    }

    if (!success) {
      throw lastErr || new Error(`청크 ${chunkIndex + 1}/${totalChunks} 전송 실패`);
    }
  }

  return finalResult;
}

/**
 * Uploads a single media file (video or image) to persistent server storage (/uploads/...)
 * Ensures cross-device synchronization between Web and Android app.
 */
export async function uploadMediaFile(
  file: File,
  onStatusUpdate?: (text: string) => void
): Promise<UploadResult> {
  const isVideo = file.type.startsWith('video/') || /\.(mp4|mov|webm|mkv|3gp|avi|m4v)$/i.test(file.name);
  let thumbnail: string | undefined = undefined;

  if (isVideo) {
    try {
      thumbnail = await generateVideoThumbnail(file);
    } catch {}
  }

  // Tier 1: Direct high-speed multipart FormData upload to /api/sync/upload
  try {
    onStatusUpdate?.(`${file.name} 서버로 업로드 및 최적화 중...`);
    const formData = new FormData();
    formData.append('files', file);

    const response = await fetch('/api/sync/upload', {
      method: 'POST',
      body: formData,
    });

    if (response.ok) {
      const data = await response.json();
      if (data.success && Array.isArray(data.urls) && data.urls.length > 0) {
        const firstFile = data.files?.[0];
        return {
          url: data.urls[0],
          thumbnail: firstFile?.thumbnail || thumbnail,
          name: file.name,
          size: firstFile?.size || file.size,
        };
      }
    } else {
      console.warn(`[MediaUpload] Direct upload returned HTTP ${response.status}, switching to fallback tier.`);
    }
  } catch (err) {
    console.warn('[MediaUpload] Direct multipart upload failed, attempting chunked upload fallback:', err);
  }

  // Tier 2: Resumable chunked upload to /api/sync/upload-chunk
  try {
    onStatusUpdate?.(`${file.name} 안정화 청크 분할 전송 시작...`);
    const chunkRes = await uploadFileInChunks(file, onStatusUpdate);
    if (chunkRes && chunkRes.url) {
      return {
        url: chunkRes.url,
        thumbnail: chunkRes.thumbnail || thumbnail,
        name: file.name,
        size: file.size,
      };
    }
  } catch (chunkErr) {
    console.warn('[MediaUpload] Chunked upload failed, attempting base64 fallback:', chunkErr);
  }

  // Tier 3: Base64 JSON fallback to /api/sync/upload-base64 (guarantees upload even through restrictive proxies)
  try {
    onStatusUpdate?.(`${file.name} Base64 무결성 안전 인코딩 전송 중...`);
    const base64Data = await readFileAsDataURL(file);
    const b64Res = await fetch('/api/sync/upload-base64', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: file.name,
        type: file.type || 'video/mp4',
        data: base64Data,
      }),
    });

    if (b64Res.ok) {
      const b64Data = await b64Res.json();
      if (b64Data.success && b64Data.url) {
        return {
          url: b64Data.url,
          thumbnail: b64Data.thumbnail || thumbnail,
          name: file.name,
          size: file.size,
        };
      }
    }
  } catch (b64Err) {
    console.warn('[MediaUpload] Base64 fallback upload failed:', b64Err);
  }

  // Tier 4: Fallback to local Object URL for reliable instant playback
  try {
    const blobUrl = URL.createObjectURL(file);
    return {
      url: blobUrl,
      thumbnail,
      name: file.name,
      size: file.size,
    };
  } catch (blobErr) {
    throw new Error('동영상 로컬 미리보기를 생성할 수 없습니다.');
  }
}

/**
 * Uploads multiple media files in batch or sequentially
 */
export async function uploadMultipleMediaFiles(
  files: File[],
  onProgress?: (current: number, total: number, currentName: string) => void
): Promise<UploadResult[]> {
  if (files.length === 0) return [];

  const results: UploadResult[] = [];
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    onProgress?.(i + 1, files.length, file.name);
    const result = await uploadMediaFile(file, (msg) => {
      onProgress?.(i + 1, files.length, msg);
    });
    results.push(result);
  }
  return results;
}

function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
