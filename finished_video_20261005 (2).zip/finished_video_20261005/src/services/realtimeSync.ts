import { Post, Comment, Message, User, UserStory, KickedUserRecord, Notification } from '../types';

export type SyncEventHandler = (event: string, payload: any) => void;

class RealtimeSyncManager {
  private eventSource: EventSource | null = null;
  private listeners: Set<SyncEventHandler> = new Set();
  private isConnected: boolean = false;
  private reconnectTimer: any = null;

  public subscribe(handler: SyncEventHandler): () => void {
    this.listeners.add(handler);
    if (!this.eventSource && typeof window !== 'undefined') {
      this.initEventSource();
    }
    return () => {
      this.listeners.delete(handler);
    };
  }

  public initEventSource(): void {
    if (typeof window === 'undefined') return;

    if (this.eventSource) {
      try {
        this.eventSource.close();
      } catch {
        // Ignore
      }
    }

    try {
      this.eventSource = new EventSource('/api/sync/stream');

      this.eventSource.addEventListener('connected', (e: MessageEvent) => {
        this.isConnected = true;
      });

      this.eventSource.addEventListener('sync', (e: MessageEvent) => {
        try {
          const parsed = JSON.parse(e.data);
          if (parsed && parsed.type) {
            this.notify(parsed.type, parsed.payload);
          }
        } catch (err) {
          console.error('[RealtimeSync] Failed to parse sync event:', err);
        }
      });

      this.eventSource.onerror = () => {
        this.isConnected = false;
        try {
          this.eventSource?.close();
        } catch {
          // Ignore
        }
        this.eventSource = null;

        // Auto-reconnect after 3 seconds
        if (!this.reconnectTimer) {
          this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.initEventSource();
          }, 3000);
        }
      };
    } catch (err) {
      console.error('[RealtimeSync] Failed to start EventSource:', err);
    }
  }

  private notify(event: string, payload: any) {
    for (const handler of this.listeners) {
      try {
        handler(event, payload);
      } catch (err) {
        console.error('[RealtimeSync] Handler error:', err);
      }
    }
  }

  // Fetch full state from server
  public async fetchServerState(): Promise<{
    posts: Post[];
    comments: Comment[];
    messages: Message[];
    stories: UserStory[];
    users: User[];
    notifications?: Notification[];
    deletedPostIds?: string[];
    kickedUsers?: KickedUserRecord[];
  } | null> {
    try {
      const res = await fetch('/api/sync/state');
      if (!res.ok) return null;
      const json = await res.json();
      return json.success && json.data ? json.data : null;
    } catch {
      return null;
    }
  }

  // Seed server with initial mock data if server is brand new
  public async seedServer(initialData: {
    posts: Post[];
    comments: Comment[];
    messages: Message[];
    stories: UserStory[];
    users: User[];
  }): Promise<void> {
    try {
      await fetch('/api/sync/seed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(initialData),
      });
    } catch {
      // Ignore
    }
  }

  public async addNotification(notif: Notification): Promise<void> {
    try {
      await fetch('/api/sync/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(notif),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync addNotification:', err);
    }
  }

  // Real-time API mutations
  public async createPost(post: Post): Promise<void> {
    try {
      await fetch('/api/sync/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(post),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync createPost:', err);
    }
  }

  public async updatePost(postId: string, updatedFields: Partial<Post>): Promise<void> {
    try {
      await fetch(`/api/sync/posts/${postId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedFields),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync updatePost:', err);
    }
  }

  public async deletePost(postId: string): Promise<void> {
    try {
      await fetch(`/api/sync/posts/${postId}`, {
        method: 'DELETE',
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync deletePost:', err);
    }
  }

  public async toggleLike(postId: string, userId: string, userName?: string, userAvatar?: string): Promise<void> {
    try {
      await fetch(`/api/sync/posts/${postId}/like`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, userName, userAvatar }),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync toggleLike:', err);
    }
  }

  public async toggleBookmark(postId: string, userId: string): Promise<void> {
    try {
      await fetch(`/api/sync/posts/${postId}/bookmark`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync toggleBookmark:', err);
    }
  }

  public async clearBookmarks(userId: string): Promise<void> {
    try {
      await fetch('/api/sync/bookmarks/clear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync clearBookmarks:', err);
    }
  }

  public async addComment(comment: Comment): Promise<void> {
    try {
      await fetch(`/api/sync/posts/${comment.postId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(comment),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync addComment:', err);
    }
  }

  public async toggleCommentLike(commentId: string, userId: string): Promise<void> {
    try {
      await fetch(`/api/sync/comments/${commentId}/like`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync toggleCommentLike:', err);
    }
  }

  public async sendMessage(msg: Message): Promise<void> {
    try {
      await fetch('/api/sync/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(msg),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync sendMessage:', err);
    }
  }

  public async markConversationAsRead(partnerId: string, userId: string): Promise<void> {
    try {
      await fetch('/api/sync/messages/read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ partnerId, userId }),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync markConversationAsRead:', err);
    }
  }

  public async markMessageAsRead(messageId: string, userId?: string): Promise<void> {
    try {
      await fetch(`/api/sync/messages/${messageId}/read`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync markMessageAsRead:', err);
    }
  }

  public async markAllMessagesAsRead(userId: string): Promise<void> {
    try {
      await fetch('/api/sync/messages/read-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync markAllMessagesAsRead:', err);
    }
  }

  public async toggleStarMessage(messageId: string): Promise<void> {
    try {
      await fetch(`/api/sync/messages/${messageId}/star`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync toggleStarMessage:', err);
    }
  }

  public async createStory(story: UserStory): Promise<void> {
    try {
      await fetch('/api/sync/stories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(story),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync createStory:', err);
    }
  }

  public async updateUser(userId: string, updatedFields: Partial<User>): Promise<void> {
    try {
      await fetch(`/api/sync/users/${userId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedFields),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync updateUser:', err);
    }
  }

  public async registerUser(user: User): Promise<any> {
    try {
      const res = await fetch('/api/sync/users/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user),
      });
      return await res.json();
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync registerUser:', err);
      return null;
    }
  }

  public async kickUser(userId: string, reason?: string, adminName?: string, userData?: any, userPosts?: any[]): Promise<void> {
    try {
      await fetch(`/api/sync/users/${userId}/kick`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason, adminName, userData, userPosts }),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync kickUser:', err);
    }
  }

  public async restoreUser(userId: string, restoredUser?: any, userPosts?: any[]): Promise<any> {
    try {
      const res = await fetch(`/api/sync/users/${userId}/restore`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ restoredUser, userPosts }),
      });
      return await res.json();
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync restoreUser:', err);
      return { success: false, error: '서버 통신 실패' };
    }
  }

  public async toggleBanUser(userId: string, reason?: string): Promise<void> {
    try {
      await fetch(`/api/sync/users/${userId}/ban`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync toggleBanUser:', err);
    }
  }

  public async toggleFollow(
    targetUserId: string,
    currentUserId: string,
    currentUser?: any,
    targetName?: string,
    targetHandle?: string
  ): Promise<{
    success: boolean;
    isFollowing: boolean;
    currentUser: any;
    targetUser: any;
    users: User[];
    notification?: Notification;
  } | null> {
    try {
      const res = await fetch(`/api/sync/users/${targetUserId}/follow`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentUserId, currentUser, targetName, targetHandle }),
      });
      return await res.json();
    } catch (err) {
      console.error('[RealtimeSync] Failed to sync toggleFollow:', err);
      return null;
    }
  }
}

export const realtimeSync = new RealtimeSyncManager();
