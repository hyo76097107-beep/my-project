/**
 * MediaSyncService for Web Application
 * Coordinates real-time media synchronization with Android apps and central database.
 * 
 * Provides:
 * 1. Immediate video availability notifications across devices
 * 2. Proactive video streaming pre-warming (preloads first buffer for instant playback)
 * 3. Cross-device synchronized video playback (watch together)
 */

export interface MediaSyncPayload {
  postId: string;
  videoUrls: string[];
  thumbnailUrl?: string;
  authorId?: string;
  timestamp?: number;
}

export interface VideoPlaybackSyncPayload {
  videoId: string;
  positionMs: number;
  isPlaying: boolean;
  senderId: string;
  timestamp?: number;
}

type SyncCallback = (event: string, payload: any) => void;

class WebMediaSyncService {
  private ws: WebSocket | null = null;
  private isConnecting = false;
  private listeners = new Set<SyncCallback>();
  private prewarmedUrls = new Set<string>();

  constructor() {
    this.initWebSocket();
  }

  public initWebSocket(): void {
    if (typeof window === 'undefined') return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    try {
      this.isConnecting = true;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws/sync`;

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.isConnecting = false;
        console.log('[MediaSyncService] Connected to real-time WebSocket');
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data && data.type) {
            this.handleIncomingEvent(data.type, data.payload);
          }
        } catch (err) {
          console.warn('[MediaSyncService] Failed to parse WebSocket message:', err);
        }
      };

      this.ws.onerror = (err) => {
        console.warn('[MediaSyncService] WebSocket error:', err);
      };

      this.ws.onclose = () => {
        this.isConnecting = false;
        this.ws = null;
        // Reconnect after 3 seconds
        setTimeout(() => this.initWebSocket(), 3000);
      };
    } catch (e) {
      this.isConnecting = false;
      console.warn('[MediaSyncService] Failed to initialize WebSocket:', e);
    }
  }

  private handleIncomingEvent(type: string, payload: any): void {
    if (type === 'MEDIA_SYNC') {
      const videoUrls: string[] = payload?.videoUrls || [];
      if (videoUrls.length > 0) {
        this.prewarmVideo(videoUrls[0]);
      }
    }

    // Notify listeners
    this.listeners.forEach((callback) => {
      try {
        callback(type, payload);
      } catch (err) {
        console.error('[MediaSyncService] Listener error:', err);
      }
    });
  }

  /**
   * Pre-warms video stream so playback starts instantaneously without buffering delay.
   */
  public prewarmVideo(url: string): void {
    if (!url || this.prewarmedUrls.has(url) || typeof window === 'undefined') return;
    this.prewarmedUrls.add(url);

    try {
      // Prime browser HTTP cache with initial metadata bytes (first 64KB)
      fetch(url, {
        method: 'GET',
        headers: { Range: 'bytes=0-65535' },
        cache: 'force-cache'
      }).catch(() => {});
    } catch (e) {
      console.warn('[MediaSyncService] Video prewarm failed:', e);
    }
  }

  /**
   * Notifies central database and all connected devices that media upload has completed.
   */
  public async notifyMediaUploaded(payload: MediaSyncPayload): Promise<boolean> {
    try {
      // 1. Post to REST endpoint
      const res = await fetch('/api/sync/media-sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      // 2. Also send over WebSocket for instant broadcast
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({
          type: 'MEDIA_SYNC',
          payload,
        }));
      }

      if (payload.videoUrls?.[0]) {
        this.prewarmVideo(payload.videoUrls[0]);
      }

      return res.ok;
    } catch (err) {
      console.error('[MediaSyncService] Failed to notify media upload:', err);
      return false;
    }
  }

  /**
   * Broadcasts video playback synchronization (play, pause, seek position) to other devices.
   */
  public broadcastPlaybackSync(payload: VideoPlaybackSyncPayload): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'VIDEO_PLAYBACK_SYNC',
        payload,
      }));
    }
  }

  /**
   * Subscribes to real-time media sync events.
   */
  public subscribe(callback: SyncCallback): () => void {
    this.listeners.add(callback);
    return () => {
      this.listeners.delete(callback);
    };
  }
}

export const mediaSyncService = new WebMediaSyncService();
