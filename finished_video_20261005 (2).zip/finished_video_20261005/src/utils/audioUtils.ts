/**
 * Audio utility for voice comments
 * Includes synthetic WAV generator fallback and time formatting
 */

export const formatAudioDuration = (seconds: number): string => {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

/**
 * Generate a pleasant synthetic voice/melody note as a fallback WAV data URL
 * Uses Web Audio API offline rendering
 */
export const generateSyntheticAudioBlob = async (
  durationSeconds: number = 4
): Promise<{ blob: Blob; url: string }> => {
  const sampleRate = 44100;
  const numSamples = Math.floor(sampleRate * durationSeconds);
  const audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
  const buffer = audioContext.createBuffer(1, numSamples, sampleRate);
  const data = buffer.getChannelData(0);

  // Generate a pleasant voice-like modulated harmonic sound
  const baseFreq = 220; // A3 note
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    // Envelope (attack, decay, sustain, release)
    const env = Math.sin((Math.PI * i) / numSamples);
    // Harmonic frequencies simulating human speech formant
    const osc1 = Math.sin(2 * Math.PI * baseFreq * t);
    const osc2 = 0.5 * Math.sin(2 * Math.PI * (baseFreq * 1.5) * t + 0.3);
    const osc3 = 0.25 * Math.sin(2 * Math.PI * (baseFreq * 2.2) * t + 0.8);
    const vibrato = 1 + 0.05 * Math.sin(2 * Math.PI * 5.5 * t);
    
    data[i] = (osc1 + osc2 + osc3) * env * vibrato * 0.4;
  }

  // Convert AudioBuffer to WAV Blob
  const wavBlob = audioBufferToWav(buffer);
  const url = URL.createObjectURL(wavBlob);
  return { blob: wavBlob, url };
};

function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numOfChan = buffer.numberOfChannels;
  const length = buffer.length * numOfChan * 2 + 44;
  const out = new DataView(new ArrayBuffer(length));
  const channels: Float32Array[] = [];
  let sample: number = 0;
  let offset = 0;
  let pos = 0;

  function setUint16(data: number) {
    out.setUint16(pos, data, true);
    pos += 2;
  }

  function setUint32(data: number) {
    out.setUint32(pos, data, true);
    pos += 4;
  }

  // write WAVE header
  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8); // file length - 8
  setUint32(0x45564157); // "WAVE"

  setUint32(0x20746d66); // "fmt " chunk
  setUint32(16); // length = 16
  setUint16(1); // PCM (uncompressed)
  setUint16(numOfChan);
  setUint32(buffer.sampleRate);
  setUint32(buffer.sampleRate * 2 * numOfChan); // avg. bytes/sec
  setUint16(numOfChan * 2); // block-align
  setUint16(16); // 16-bit precision

  setUint32(0x61746164); // "data" chunk
  setUint32(length - pos - 4); // chunk length

  for (let i = 0; i < buffer.numberOfChannels; i++) {
    channels.push(buffer.getChannelData(i));
  }

  while (offset < buffer.length) {
    for (let i = 0; i < numOfChan; i++) {
      sample = Math.max(-1, Math.min(1, channels[i][offset]));
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0;
      out.setInt16(pos, sample, true);
      pos += 2;
    }
    offset++;
  }

  return new Blob([out], { type: 'audio/wav' });
}
