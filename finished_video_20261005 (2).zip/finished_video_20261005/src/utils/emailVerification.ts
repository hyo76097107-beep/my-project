export interface EmailVerificationState {
  email: string;
  code: string;
  sentAt: number;
  expiresAt: number;
  isVerified: boolean;
  isRealEmailSent?: boolean;
}

/**
 * Validate standard email format
 */
export function isValidEmailAddress(email: string): boolean {
  if (!email || typeof email !== 'string') return false;
  const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return re.test(email.trim());
}

/**
 * Mask email for privacy display e.g. "hyo***@gmail.com"
 */
export function maskEmail(email: string): string {
  if (!email || !email.includes('@')) return email;
  const [local, domain] = email.split('@');
  if (local.length <= 2) {
    return `${local}***@${domain}`;
  }
  const visible = local.slice(0, 3);
  return `${visible}***@${domain}`;
}
