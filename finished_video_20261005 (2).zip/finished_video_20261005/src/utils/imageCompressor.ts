/**
 * Client-side image compression and video thumbnail generator.
 * Compresses camera photos (5-20MB) down to ~100KB without visible quality loss,
 * preventing memory crashes, canvas GPU exhaustion, and LocalStorage quota errors.
 */

export async function compressImageFile(
  file: File,
  maxWidth = 1280,
  maxHeight = 1280,
  quality = 0.82
): Promise<string> {
  return new Promise((resolve) => {
    // If not an image, fallback to object URL
    if (!file.type.startsWith('image/')) {
      resolve(URL.createObjectURL(file));
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        // Calculate aspect-ratio preserved dimensions
        if (width > maxWidth || height > maxHeight) {
          if (width / height > maxWidth / maxHeight) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, width);
        canvas.height = Math.max(1, height);
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          // Fallback to original data URL if 2D context fails
          resolve(e.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);

        // Convert to lightweight JPEG data URL
        try {
          const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
          resolve(compressedDataUrl);
        } catch {
          resolve(e.target?.result as string);
        }
      };

      img.onerror = () => {
        resolve(e.target?.result as string);
      };

      img.src = e.target?.result as string;
    };

    reader.onerror = () => {
      // Fallback to Blob URL if FileReader fails
      resolve(URL.createObjectURL(file));
    };

    reader.readAsDataURL(file);
  });
}

/**
 * Capture a fast, lightweight thumbnail from a video file safely across all browsers
 */
export async function generateVideoThumbnail(file: File): Promise<string | undefined> {
  return new Promise((resolve) => {
    let isSettled = false;
    let objectUrl = '';
    let video: HTMLVideoElement | null = null;
    let timer: any = null;

    const cleanupAndResolve = (result?: string) => {
      if (isSettled) return;
      isSettled = true;
      if (timer) clearTimeout(timer);
      if (objectUrl) {
        try {
          URL.revokeObjectURL(objectUrl);
        } catch {}
      }
      if (video) {
        try {
          video.onloadedmetadata = null;
          video.onseeked = null;
          video.onerror = null;
          video.src = '';
          video.load();
          video.remove();
        } catch {}
        video = null;
      }
      resolve(result);
    };

    // Fallback timeout (up to 3.5s per video for large or 10s+ files)
    timer = setTimeout(() => {
      cleanupAndResolve(undefined);
    }, 3500);

    try {
      objectUrl = URL.createObjectURL(file);
      video = document.createElement('video');
      video.muted = true;
      video.playsInline = true;
      video.preload = 'auto';

      const drawFrame = () => {
        try {
          if (!video) {
            cleanupAndResolve(undefined);
            return;
          }
          const canvas = document.createElement('canvas');
          const maxDim = 480;
          let w = video.videoWidth || 480;
          let h = video.videoHeight || 360;

          if (w > maxDim || h > maxDim) {
            if (w > h) {
              h = Math.round((h * maxDim) / w);
              w = maxDim;
            } else {
              w = Math.round((w * maxDim) / h);
              h = maxDim;
            }
          }

          canvas.width = Math.max(1, w);
          canvas.height = Math.max(1, h);
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, w, h);
            const thumb = canvas.toDataURL('image/jpeg', 0.75);
            cleanupAndResolve(thumb);
            return;
          }
        } catch {
          // ignore canvas capture error
        }
        cleanupAndResolve(undefined);
      };

      const handleReady = () => {
        if (!video) return;
        try {
          const duration = video.duration;
          // Target a frame around 0.5s or midpoint of short videos
          const targetTime = isFinite(duration) && duration > 0 ? Math.min(0.5, duration / 2) : 0;
          video.onseeked = drawFrame;
          video.currentTime = targetTime;
        } catch {
          drawFrame();
        }
      };

      video.onloadedmetadata = handleReady;
      video.onloadeddata = () => {
        if (!isSettled && video && video.readyState >= 2) {
          drawFrame();
        }
      };

      video.onerror = () => {
        cleanupAndResolve(undefined);
      };

      video.src = objectUrl;
      video.load();
    } catch {
      cleanupAndResolve(undefined);
    }
  });
}
