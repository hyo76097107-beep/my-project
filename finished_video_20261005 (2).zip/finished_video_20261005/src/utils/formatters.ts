export function formatRelativeTime(dateString: string): string {
  try {
    const now = new Date();
    const date = new Date(dateString);
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffInSeconds < 60) {
      return '방금 전';
    }
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
      return `${diffInMinutes}분 전`;
    }
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return `${diffInHours}시간 전`;
    }
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) {
      return `${diffInDays}일 전`;
    }
    return date.toLocaleDateString('ko-KR', {
      month: 'short',
      day: 'numeric'
    });
  } catch {
    return '방금 전';
  }
}

export function formatNumber(num: number): string {
  if (num >= 10000) {
    return (num / 10000).toFixed(1).replace(/\.0$/, '') + '만';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1).replace(/\.0$/, '') + '천';
  }
  return num.toLocaleString();
}

export function extractHashtags(text: string): string[] {
  const match = text.match(/#[a-zA-Z0-9가-힣_]+/g);
  if (!match) return [];
  return match.map((tag) => tag.replace('#', ''));
}

export function formatScheduledDateTime(dateString: string): string {
  try {
    const date = new Date(dateString);
    return date.toLocaleString('ko-KR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      weekday: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  } catch {
    return dateString;
  }
}

export function formatScheduledCountdown(dateString: string): string {
  try {
    const target = new Date(dateString).getTime();
    const now = Date.now();
    const diffMs = target - now;

    if (diffMs <= 0) {
      return '곧 발행 예정';
    }

    const diffMinutes = Math.floor(diffMs / (1000 * 60));
    if (diffMinutes < 60) {
      return `${diffMinutes}분 후 발행`;
    }

    const diffHours = Math.floor(diffMinutes / 60);
    const remainingMinutes = diffMinutes % 60;
    if (diffHours < 24) {
      return `${diffHours}시간 ${remainingMinutes > 0 ? `${remainingMinutes}분 ` : ''}후 발행`;
    }

    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}일 후 발행`;
  } catch {
    return '발행 대기 중';
  }
}

