import { SpamFilterSettings, SpamCheckResult, SpamFilterAction } from '../types';

export const GAMBLING_SPAM_KEYWORDS = [
  '불법도박',
  '카지노',
  '바카라',
  '사설토토',
  '릴게임',
  '환전보장',
  '슬롯머신',
  '홀덤펍'
];

export const FINANCE_SPAM_KEYWORDS = [
  '불법대출',
  '급전대출',
  '통장매매',
  '보이스피싱',
  '주식리딩방',
  '고수익보장',
  '코인리딩방',
  '원금보장'
];

export const ADULT_SPAM_KEYWORDS = [
  '조건만남',
  '성인용품',
  '출장안마',
  '야동사이트',
  '애인대행',
  '밤문화'
];

export const PROMO_SPAM_KEYWORDS = [
  '카톡ID추가',
  '라인ID추가',
  '무료체험단선정',
  '매크로프로그램',
  '홍보봇',
  '상위노출보장'
];

export const DEFAULT_SPAM_KEYWORDS = [
  ...GAMBLING_SPAM_KEYWORDS,
  ...FINANCE_SPAM_KEYWORDS,
  ...ADULT_SPAM_KEYWORDS,
  ...PROMO_SPAM_KEYWORDS
];

export const DEFAULT_SPAM_SETTINGS: SpamFilterSettings = {
  isEnabled: true,
  action: 'block',
  replacementMask: '***',
  keywords: DEFAULT_SPAM_KEYWORDS,
  targetScope: {
    posts: true,
    comments: true,
    messages: true,
    stories: true
  },
  customNoticeMessage: '운영 정책상 금지된 스팸/유해 단어가 포함되어 있습니다.',
  stats: {
    totalBlockedCount: 0,
    totalMaskedCount: 0,
    totalAutoBlindedCount: 0
  }
};

/**
 * Escapes characters for safe regular expression generation
 */
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Performs spam keyword filtering on text
 */
export function checkSpam(
  text: string,
  settings: SpamFilterSettings,
  scope: 'posts' | 'comments' | 'messages' | 'stories'
): SpamCheckResult {
  if (!text || !settings || !settings.isEnabled || !settings.targetScope[scope]) {
    return {
      hasSpam: false,
      detectedWords: [],
      cleanText: text || '',
      actionTaken: 'none'
    };
  }

  const validKeywords = (settings.keywords || []).filter(
    (kw) => typeof kw === 'string' && kw.trim().length > 0
  );

  if (validKeywords.length === 0) {
    return {
      hasSpam: false,
      detectedWords: [],
      cleanText: text,
      actionTaken: 'none'
    };
  }

  const lowerText = text.toLowerCase();
  const detectedWords: string[] = [];

  for (const keyword of validKeywords) {
    const trimmed = keyword.trim();
    if (!trimmed) continue;

    // Check lowercase containment
    if (lowerText.includes(trimmed.toLowerCase())) {
      if (!detectedWords.includes(trimmed)) {
        detectedWords.push(trimmed);
      }
    }
  }

  if (detectedWords.length === 0) {
    return {
      hasSpam: false,
      detectedWords: [],
      cleanText: text,
      actionTaken: 'none'
    };
  }

  // Handle Action
  if (settings.action === 'block') {
    return {
      hasSpam: true,
      detectedWords,
      cleanText: text,
      actionTaken: 'block',
      noticeMessage: `🚫 스팸 및 금지어 [${detectedWords.join(', ')}]이(가) 포함되어 있어 전송 또는 등록할 수 없습니다.`
    };
  }

  if (settings.action === 'mask') {
    let masked = text;
    const maskStr = settings.replacementMask || '***';

    for (const word of detectedWords) {
      const reg = new RegExp(escapeRegExp(word), 'gi');
      masked = masked.replace(reg, maskStr);
    }

    return {
      hasSpam: true,
      detectedWords,
      cleanText: masked,
      actionTaken: 'mask',
      noticeMessage: `⚠️ 스팸 단어 [${detectedWords.join(', ')}]이(가) 감지되어 마스킹(${maskStr}) 처리되었습니다.`
    };
  }

  if (settings.action === 'auto_blind') {
    return {
      hasSpam: true,
      detectedWords,
      cleanText: text,
      actionTaken: 'auto_blind',
      noticeMessage: `⚠️ 스팸 단어 [${detectedWords.join(', ')}]이(가) 감지되어 관리자 검토를 위해 자동 차단(블라인드) 처리되었습니다.`
    };
  }

  return {
    hasSpam: true,
    detectedWords,
    cleanText: text,
    actionTaken: 'none'
  };
}
