/**
 * Codec Support & ExoPlayer Hardware Acceleration Checker
 * Evaluates H.264/AVC profiles, GPU hardware acceleration, and ExoPlayer compatibility.
 */

export interface CodecProfileSupport {
  name: string;
  mimeType: string;
  codecString: string;
  canPlay: 'probably' | 'maybe' | '';
  isSupported: boolean;
  isHardwareAccelerated: boolean;
  isSmooth: boolean;
  description: string;
}

export interface DeviceCodecDiagnosticReport {
  hasH264Support: boolean;
  hasHardwareAcceleration: boolean;
  isExoPlayerReady: boolean;
  profiles: CodecProfileSupport[];
  recommendedProfile: string;
  userAgent: string;
  timestamp: number;
  recommendations: string[];
}

export interface VideoFileCompatibilityResult {
  fileName: string;
  fileSize: number;
  container: string;
  isExoPlayerCompatible: boolean;
  codecNotice: string;
  warnings: string[];
  recommendedAction: string;
}

const H264_PROFILE_DEFINITIONS: Array<{
  name: string;
  mimeType: string;
  codecString: string;
  description: string;
  recommendedForExoPlayer: boolean;
}> = [
  {
    name: 'H.264 Baseline Profile (Level 3.0)',
    mimeType: 'video/mp4',
    codecString: 'avc1.42E01E',
    description: '모든 안드로이드 기기 및 ExoPlayer에서 100% 보증되는 표준 프로파일 (저전력/광범위 호환)',
    recommendedForExoPlayer: true
  },
  {
    name: 'H.264 Main Profile (Level 3.1)',
    mimeType: 'video/mp4',
    codecString: 'avc1.4D401F',
    description: '표준 고화질 소셜 미디어 및 ExoPlayer 기본 권장 프로파일',
    recommendedForExoPlayer: true
  },
  {
    name: 'H.264 High Profile (Level 4.1)',
    mimeType: 'video/mp4',
    codecString: 'avc1.640029',
    description: '1080p 고화질 하드웨어 가속 최적화 프로파일 (최신 모바일 기기 완벽 호환)',
    recommendedForExoPlayer: true
  },
  {
    name: 'H.264 High 10 Profile (10-bit)',
    mimeType: 'video/mp4',
    codecString: 'avc1.6E0028',
    description: '10비트 고색상 프로파일 (일부 구형 안드로이드 기기에서 하드웨어 디코더 미지원 가능)',
    recommendedForExoPlayer: false
  },
  {
    name: 'HEVC / H.265 Main',
    mimeType: 'video/mp4',
    codecString: 'hvc1.1.6.L93.B0',
    description: '고효율 압축 코덱 (일부 구형 웹 브라우저 및 기기에서 "재생할 수 없다" 오류 발생 원인)',
    recommendedForExoPlayer: false
  },
  {
    name: 'VP9 Profile 0',
    mimeType: 'video/webm',
    codecString: 'vp09.00.10.08',
    description: '웹 표준 오픈 비디오 코덱',
    recommendedForExoPlayer: false
  }
];

/**
 * Checks device MediaCapabilities and HTML5 video canPlayType to diagnose
 * H.264/AVC codec support and hardware acceleration.
 */
export async function checkDeviceCodecCapabilities(): Promise<DeviceCodecDiagnosticReport> {
  const dummyVideo = typeof document !== 'undefined' ? document.createElement('video') : null;
  const profilesResult: CodecProfileSupport[] = [];

  let hasHw = false;
  let hasH264 = false;

  for (const def of H264_PROFILE_DEFINITIONS) {
    const fullType = `${def.mimeType}; codecs="${def.codecString}"`;
    const canPlay = dummyVideo ? dummyVideo.canPlayType(fullType) : '';
    let isHwAccelerated = false;
    let isSmooth = false;
    let isSupported = canPlay === 'probably' || canPlay === 'maybe';

    // Query MediaCapabilities API for hardware acceleration info if available
    if (typeof navigator !== 'undefined' && 'mediaCapabilities' in navigator && navigator.mediaCapabilities?.decodingInfo) {
      try {
        const mcResult = await navigator.mediaCapabilities.decodingInfo({
          type: 'file',
          video: {
            contentType: fullType,
            width: 1920,
            height: 1080,
            bitrate: 4_000_000,
            framerate: 30
          }
        });
        isSupported = mcResult.supported;
        isSmooth = mcResult.smooth;
        isHwAccelerated = mcResult.powerEfficient;
      } catch {
        // Fallback to canPlayType
      }
    }

    if (def.codecString.startsWith('avc1') && isSupported) {
      hasH264 = true;
      if (isHwAccelerated || canPlay === 'probably') {
        hasHw = true;
      }
    }

    profilesResult.push({
      name: def.name,
      mimeType: def.mimeType,
      codecString: def.codecString,
      canPlay: canPlay as 'probably' | 'maybe' | '',
      isSupported,
      isHardwareAccelerated: isHwAccelerated,
      isSmooth,
      description: def.description
    });
  }

  const recommendations: string[] = [
    'Android ExoPlayer 재생을 위해 H.264/AVC Baseline 또는 Main Profile (Level 3.1-4.1)로 인코딩된 MP4 형식을 권장합니다.',
    'ExoPlayer DefaultRenderersFactory에 Decoder Fallback이 적용되어 하드웨어 코덱 미지원 시 자동으로 소프트웨어 디코더로 안전하게 전환됩니다.',
    'Web 동영상 첨부 시 moov atom을 파일 선두에 배치(faststart)하여 스트리밍 버퍼링 지연을 최소화합니다.'
  ];

  return {
    hasH264Support: hasH264,
    hasHardwareAcceleration: hasHw,
    isExoPlayerReady: hasH264,
    profiles: profilesResult,
    recommendedProfile: 'H.264 AVC Baseline/Main Profile (yuv420p)',
    userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown',
    timestamp: Date.now(),
    recommendations
  };
}

/**
 * Validates a video file selected by the user for ExoPlayer & Web playback compatibility.
 */
export function validateVideoFileForExoPlayer(file: File): VideoFileCompatibilityResult {
  const fileName = file.name;
  const fileSize = file.size;
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  const warnings: string[] = [];

  let container = 'MP4 (권장)';
  let isCompatible = true;
  let codecNotice = 'H.264/AVC 호환성 최적';

  if (ext === 'mov' || ext === 'quicktime') {
    container = 'Apple QuickTime (MOV)';
    warnings.push('Apple QuickTime(MOV) 파일은 기기별 디코더에 따라 안드로이드 ExoPlayer에서 오류가 발생할 수 있습니다. MP4 변환 후 재생을 지원합니다.');
    codecNotice = '호환 변환 적용 권장';
  } else if (ext === 'webm') {
    container = 'WebM (VP8/VP9)';
    codecNotice = '웹 표준 재생 지원';
  } else if (ext === 'mkv') {
    container = 'Matroska (MKV)';
    warnings.push('MKV 컨테이너는 일부 모바일 브라우저에서 직접 재생을 지원하지 않을 수 있습니다.');
  } else if (ext === 'avi') {
    container = 'AVI';
    warnings.push('구형 AVI 포맷은 ExoPlayer 및 웹에서 직접 재생되지 않을 수 있습니다.');
    isCompatible = false;
  }

  if (fileSize > 150 * 1024 * 1024) {
    warnings.push('150MB를 초과하는 고용량 동영상은 모바일 기기 메모리 및 하드웨어 디코더 과부하를 유발할 수 있습니다.');
  }

  return {
    fileName,
    fileSize,
    container,
    isExoPlayerCompatible: isCompatible,
    codecNotice,
    warnings,
    recommendedAction: isCompatible ? '업로드 및 즉시 재생 가능' : 'H.264 MP4로 최적화 권장'
  };
}
