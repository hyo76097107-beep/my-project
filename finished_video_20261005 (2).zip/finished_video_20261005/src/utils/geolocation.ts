/**
 * Utility for automatic geolocation detection and reverse geocoding
 */

export interface DetectedLocation {
  address: string;
  latitude?: number;
  longitude?: number;
  source: 'gps' | 'profile' | 'preset';
}

/**
 * Format raw reverse geocoded address into a clean, human-readable display string
 */
function formatKoreanAddress(addr: Record<string, string>): string {
  // Try to construct Korean region hierarchy: 시/도 + 구/군 + 동/읍/면
  const city = addr.city || addr.province || addr.state || '';
  const borough = addr.borough || addr.district || addr.county || addr.city_district || '';
  const town = addr.suburb || addr.quarter || addr.neighbourhood || addr.town || addr.village || '';

  // Clean city names (e.g., '서울특별시' -> '서울', '부산광역시' -> '부산')
  const cleanCity = city
    .replace(/특별시$/, '')
    .replace(/광역시$/, '')
    .replace(/특별자치시$/, '')
    .replace(/특별자치도$/, '도');

  const parts: string[] = [];
  if (cleanCity) parts.push(cleanCity);
  if (borough && borough !== cleanCity) parts.push(borough);
  if (town && town !== borough) parts.push(town);

  if (parts.length > 0) {
    return parts.join(' ');
  }

  // Fallback to name or display name snippet
  return addr.road || addr.county || '서울 강남구';
}

/**
 * Reverse geocode latitude and longitude to a human-readable address
 */
export async function reverseGeocode(lat: number, lon: number): Promise<string | null> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);

    const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=16&addressdetails=1&accept-language=ko`;
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'Accept': 'application/json'
      }
    });
    clearTimeout(timeoutId);

    if (!response.ok) return null;

    const data = await response.json();
    if (data && data.address) {
      const formatted = formatKoreanAddress(data.address);
      if (formatted && formatted.trim().length > 0) {
        return formatted;
      }
    }

    if (data && data.display_name) {
      // Return a brief portion of the display name
      const chunks = data.display_name.split(',').map((s: string) => s.trim());
      return chunks.slice(0, 2).join(' ');
    }
  } catch (err) {
    console.warn('Reverse geocoding request failed or timed out:', err);
  }

  return null;
}

/**
 * Approximate Korean city from coordinates if offline or geocode fails
 */
function approximateKoreanRegion(lat: number, lon: number): string {
  // Approximate bounding boxes for main Korean metro areas
  if (lat >= 37.4 && lat <= 37.7 && lon >= 126.8 && lon <= 127.2) {
    return '서울 강남구';
  } else if (lat >= 37.3 && lat <= 37.5 && lon >= 127.0 && lon <= 127.2) {
    return '경기 성남시 판교';
  } else if (lat >= 35.0 && lat <= 35.3 && lon >= 128.9 && lon <= 129.2) {
    return '부산 해운대구';
  } else if (lat >= 33.1 && lat <= 33.6 && lon >= 126.1 && lon <= 126.9) {
    return '제주도 애월읍';
  }
  return '서울 강남구';
}

/**
 * Get current location automatically with fallback chain:
 * 1. GPS + Reverse Geocode
 * 2. GPS + Coordinate approximation
 * 3. User profile location
 * 4. Default fallback ('서울 강남구')
 */
export async function getAutoLocation(fallbackProfileLocation?: string): Promise<DetectedLocation> {
  // Check if navigator.geolocation is supported
  if (typeof window !== 'undefined' && 'geolocation' in navigator) {
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: false,
          timeout: 4500,
          maximumAge: 1000 * 60 * 5 // 5 minutes cache
        });
      });

      const { latitude, longitude } = position.coords;

      // Reverse geocode
      const geocoded = await reverseGeocode(latitude, longitude);
      if (geocoded) {
        return {
          address: geocoded,
          latitude,
          longitude,
          source: 'gps'
        };
      }

      // Approximate from coordinates
      const approx = approximateKoreanRegion(latitude, longitude);
      return {
        address: approx,
        latitude,
        longitude,
        source: 'gps'
      };
    } catch (geoError) {
      console.info('Geolocation access not available or denied, using profile/default fallback:', geoError);
    }
  }

  // Fallback 1: User's profile location
  if (fallbackProfileLocation && fallbackProfileLocation.trim().length > 0) {
    return {
      address: fallbackProfileLocation.trim(),
      source: 'profile'
    };
  }

  // Fallback 2: Default location
  return {
    address: '서울 강남구',
    source: 'preset'
  };
}

export const POPULAR_LOCATIONS = [
  '서울 성수동',
  '서울 강남구',
  '서울 마포구 연남동',
  '서울 용산구 한남동',
  '경기 성남시 판교',
  '제주도 애월읍',
  '부산 해운대구',
  '강원도 양양'
];
