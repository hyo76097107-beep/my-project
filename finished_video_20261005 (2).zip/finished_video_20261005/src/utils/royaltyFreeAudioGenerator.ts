/**
 * Royalty-Free Copyright-Free Music Synthesizer & Audio Utilities
 * 100% CC0 Public Domain / Royalty-Free guarantees with zero copyright claims.
 * Generates rich, relaxing musical compositions via Web Audio API offline rendering.
 */

// Cache generated blob URLs so they are only created once per session
const audioBlobCache = new Map<string, string>();

function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numOfChan = buffer.numberOfChannels;
  const length = buffer.length * numOfChan * 2 + 44;
  const out = new DataView(new ArrayBuffer(length));
  const channels: Float32Array[] = [];
  const sampleRate = buffer.sampleRate;
  let offset = 0;
  let pos = 0;

  function setUint16(data: number) {
    out.setUint16(pos, data, true);
    pos += 2;
  }
  function setUint32(data: number) {
    out.setUint32(pos, data, true);
    pos += 4;
  }

  // RIFF header
  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8);
  setUint32(0x45564157); // "WAVE"

  // fmt chunk
  setUint32(0x20746d66); // "fmt "
  setUint32(16);
  setUint16(1); // PCM
  setUint16(numOfChan);
  setUint32(sampleRate);
  setUint32(sampleRate * 2 * numOfChan);
  setUint16(numOfChan * 2);
  setUint16(16);

  // data chunk
  setUint32(0x61746164); // "data"
  setUint32(length - pos - 4);

  for (let i = 0; i < numOfChan; i++) {
    channels.push(buffer.getChannelData(i));
  }

  while (offset < buffer.length) {
    for (let i = 0; i < numOfChan; i++) {
      let sample = Math.max(-1, Math.min(1, channels[i][offset]));
      sample = (sample < 0 ? sample * 32768 : sample * 32767) | 0;
      out.setInt16(pos, sample, true);
      pos += 2;
    }
    offset++;
  }

  return new Blob([out.buffer], { type: 'audio/wav' });
}

/**
 * Synthesizes a specific track style into a high-quality looping WAV Blob URL
 */
export async function getOrGenerateRoyaltyFreeTrack(trackId: string): Promise<string> {
  if (audioBlobCache.has(trackId)) {
    return audioBlobCache.get(trackId)!;
  }

  if (typeof window === 'undefined') {
    return '';
  }

  const sampleRate = 22050; // Balanced quality & super-fast generation (< 50ms)
  const durationSec = 16; // 16-second seamless musical loop
  const totalSamples = sampleRate * durationSec;

  const OfflineCtx = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  if (!OfflineCtx) {
    return '';
  }

  const offlineCtx = new OfflineCtx(2, totalSamples, sampleRate);

  // Common Master Reverb & Master Gain
  const masterGain = offlineCtx.createGain();
  masterGain.gain.setValueAtTime(0.7, 0);
  masterGain.connect(offlineCtx.destination);

  const bpm = 80;
  const beatSec = 60 / bpm; // 0.75s per beat

  // Note frequency helper (MIDI note number to Hz)
  const mToHz = (midi: number) => 440 * Math.pow(2, (midi - 69) / 12);

  // Helper: Play a warm electric piano / bell note
  const playTone = (
    freq: number,
    startTime: number,
    noteDuration: number,
    gainLevel: number = 0.25,
    waveType: OscillatorType = 'sine'
  ) => {
    if (startTime >= durationSec) return;
    const osc = offlineCtx.createOscillator();
    const noteGain = offlineCtx.createGain();

    osc.type = waveType;
    osc.frequency.setValueAtTime(freq, startTime);

    // ADSR Envelope
    noteGain.gain.setValueAtTime(0.0001, startTime);
    noteGain.gain.linearRampToValueAtTime(gainLevel, startTime + 0.04);
    noteGain.gain.exponentialRampToValueAtTime(0.0001, startTime + noteDuration);

    osc.connect(noteGain);
    noteGain.connect(masterGain);

    osc.start(startTime);
    osc.stop(startTime + noteDuration);
  };

  // Helper: Play gentle kick or low percussion
  const playKick = (startTime: number) => {
    if (startTime >= durationSec) return;
    const osc = offlineCtx.createOscillator();
    const g = offlineCtx.createGain();
    osc.frequency.setValueAtTime(120, startTime);
    osc.frequency.exponentialRampToValueAtTime(35, startTime + 0.15);

    g.gain.setValueAtTime(0.4, startTime);
    g.gain.exponentialRampToValueAtTime(0.001, startTime + 0.2);

    osc.connect(g);
    g.connect(masterGain);
    osc.start(startTime);
    osc.stop(startTime + 0.25);
  };

  // Helper: Play soft snare / hihat click
  const playSnareOrHat = (startTime: number, isSnare: boolean) => {
    if (startTime >= durationSec) return;
    const osc = offlineCtx.createOscillator();
    const g = offlineCtx.createGain();
    osc.type = isSnare ? 'triangle' : 'sine';
    osc.frequency.setValueAtTime(isSnare ? 220 : 8000, startTime);

    g.gain.setValueAtTime(isSnare ? 0.18 : 0.08, startTime);
    g.gain.exponentialRampToValueAtTime(0.0001, startTime + (isSnare ? 0.12 : 0.04));

    osc.connect(g);
    g.connect(masterGain);
    osc.start(startTime);
    osc.stop(startTime + (isSnare ? 0.15 : 0.05));
  };

  // Compose based on track style
  switch (trackId) {
    case 'bgm_lofi': {
      // Warm Lo-Fi Progression: Cmaj7 - Am7 - Dm7 - G7
      const chords = [
        [60, 64, 67, 71], // Cmaj7
        [57, 60, 64, 67], // Am7
        [50, 53, 57, 60], // Dm7
        [55, 59, 62, 65]  // G7
      ];
      for (let bar = 0; bar < 4; bar++) {
        const barStart = bar * (beatSec * 4);
        const chord = chords[bar % chords.length];

        // Soft Rhodes chords
        chord.forEach((note, idx) => {
          playTone(mToHz(note), barStart + idx * 0.02, beatSec * 3.5, 0.14, 'sine');
          playTone(mToHz(note - 12), barStart, beatSec * 3.8, 0.16, 'triangle'); // Bass
        });

        // Lo-Fi drum beat: Kick on 1 and 3, Snare on 2 and 4
        playKick(barStart);
        playSnareOrHat(barStart + beatSec, true);
        playKick(barStart + beatSec * 2);
        playSnareOrHat(barStart + beatSec * 3, true);

        // Hi-hats
        for (let b = 0; b < 8; b++) {
          playSnareOrHat(barStart + b * (beatSec / 2), false);
        }
      }
      break;
    }

    case 'bgm_acoustic': {
      // Gentle Acoustic Guitar / Folk Arpeggios (G - Em - C - D)
      const arps = [
        [55, 59, 62, 67, 71], // G
        [52, 55, 59, 64, 67], // Em
        [48, 52, 55, 60, 64], // C
        [50, 54, 57, 62, 66]  // D
      ];
      for (let bar = 0; bar < 4; bar++) {
        const barStart = bar * (beatSec * 4);
        const arp = arps[bar % arps.length];
        for (let noteIdx = 0; noteIdx < 8; noteIdx++) {
          const note = arp[noteIdx % arp.length];
          const t = barStart + noteIdx * (beatSec / 2);
          playTone(mToHz(note), t, beatSec * 0.9, 0.2, 'triangle');
        }
      }
      break;
    }

    case 'bgm_piano': {
      // Peaceful Neoclassical Piano (Gymnopédie / Yiruma mood)
      const pianoChords = [
        [53, 57, 60, 65], // Fmaj7
        [55, 58, 62, 65], // Gm7
        [52, 55, 59, 62], // Em7
        [57, 60, 64, 69]  // Am
      ];
      for (let bar = 0; bar < 4; bar++) {
        const barStart = bar * (beatSec * 4);
        const chord = pianoChords[bar % pianoChords.length];

        // Bass root
        playTone(mToHz(chord[0] - 12), barStart, beatSec * 3.8, 0.22, 'sine');

        // Melodic arpeggio
        chord.forEach((n, idx) => {
          playTone(mToHz(n), barStart + idx * (beatSec * 0.8), beatSec * 2.2, 0.18, 'sine');
          playTone(mToHz(n + 12), barStart + beatSec * 1.5 + idx * 0.3, beatSec * 1.8, 0.12, 'sine');
        });
      }
      break;
    }

    case 'bgm_synth': {
      // Neon 80s Synthwave / Citypop Drive
      const bassNotes = [48, 48, 44, 44, 46, 46, 43, 43];
      for (let bar = 0; bar < 4; bar++) {
        const barStart = bar * (beatSec * 4);
        // Synth bass 8th notes
        for (let i = 0; i < 8; i++) {
          const n = bassNotes[i % bassNotes.length];
          playTone(mToHz(n), barStart + i * (beatSec / 2), beatSec * 0.45, 0.22, 'sawtooth');
        }
        // Synth chords
        playTone(mToHz(60), barStart, beatSec * 2, 0.16, 'sawtooth');
        playTone(mToHz(63), barStart, beatSec * 2, 0.16, 'sawtooth');
        playTone(mToHz(67), barStart, beatSec * 2, 0.16, 'sawtooth');

        playKick(barStart);
        playSnareOrHat(barStart + beatSec, true);
        playKick(barStart + beatSec * 2);
        playSnareOrHat(barStart + beatSec * 3, true);
      }
      break;
    }

    case 'bgm_tropical': {
      // Tropical Sunny Marimba Melody (C - G - Am - F)
      const melody = [72, 74, 76, 79, 76, 74, 72, 69, 72, 76, 74, 71, 72, 74, 76, 79];
      for (let i = 0; i < melody.length; i++) {
        const t = i * beatSec;
        playTone(mToHz(melody[i]), t, beatSec * 0.7, 0.24, 'triangle');
        playTone(mToHz(melody[i] - 12), t + 0.05, beatSec * 0.6, 0.15, 'sine');
        if (i % 2 === 0) playKick(t);
        else playSnareOrHat(t, false);
      }
      break;
    }

    case 'bgm_jazz': {
      // Cozy Cafe Swing Jazz: Dm9 - G13 - Cmaj9 - A7b13
      const jazzChords = [
        [50, 57, 60, 64, 65], // Dm9
        [55, 59, 63, 65, 69], // G13
        [48, 55, 59, 62, 64], // Cmaj9
        [57, 61, 64, 67, 68]  // A7
      ];
      for (let bar = 0; bar < 4; bar++) {
        const barStart = bar * (beatSec * 4);
        const chord = jazzChords[bar % jazzChords.length];
        // Walking upright bass
        playTone(mToHz(chord[0] - 12), barStart, beatSec * 0.9, 0.22, 'triangle');
        playTone(mToHz(chord[1] - 12), barStart + beatSec, beatSec * 0.9, 0.2, 'triangle');
        playTone(mToHz(chord[2] - 12), barStart + beatSec * 2, beatSec * 0.9, 0.2, 'triangle');
        playTone(mToHz(chord[0] - 12 + 7), barStart + beatSec * 3, beatSec * 0.9, 0.2, 'triangle');

        // Mellow electric piano chords with swing
        chord.forEach((n, idx) => {
          playTone(mToHz(n), barStart + 0.1 + idx * 0.03, beatSec * 1.5, 0.13, 'sine');
          playTone(mToHz(n), barStart + beatSec * 2.5 + idx * 0.03, beatSec * 1.2, 0.12, 'sine');
        });

        // Soft brush snare & hi-hat swing
        playSnareOrHat(barStart + beatSec, true);
        playSnareOrHat(barStart + beatSec * 3, true);
        playSnareOrHat(barStart + beatSec * 0.66, false);
        playSnareOrHat(barStart + beatSec * 1.66, false);
        playSnareOrHat(barStart + beatSec * 2.66, false);
        playSnareOrHat(barStart + beatSec * 3.66, false);
      }
      break;
    }

    case 'bgm_indie': {
      // Warm K-Indie Acoustic Sunset (D - F#m - G - A)
      const indieChords = [
        [50, 54, 57, 62], // D
        [54, 57, 61, 66], // F#m
        [55, 59, 62, 67], // G
        [57, 61, 64, 69]  // A
      ];
      for (let bar = 0; bar < 4; bar++) {
        const barStart = bar * (beatSec * 4);
        const chord = indieChords[bar % indieChords.length];
        for (let step = 0; step < 8; step++) {
          const note = chord[step % chord.length];
          const t = barStart + step * (beatSec / 2);
          playTone(mToHz(note), t, beatSec * 0.8, 0.18, 'triangle');
          if (step === 0 || step === 4) {
            playTone(mToHz(chord[0] - 12), t, beatSec * 1.8, 0.22, 'sine');
          }
        }
        playKick(barStart);
        playSnareOrHat(barStart + beatSec * 2, true);
      }
      break;
    }

    case 'bgm_upbeat': {
      // Bright Upbeat Sunshine Groove (A - D - F#m - E)
      const upbeatMelody = [69, 71, 73, 76, 73, 71, 69, 76, 78, 76, 73, 71, 69, 71, 73, 76];
      for (let i = 0; i < upbeatMelody.length; i++) {
        const t = i * (beatSec / 2);
        playTone(mToHz(upbeatMelody[i]), t, beatSec * 0.45, 0.22, 'sawtooth');
        playTone(mToHz(upbeatMelody[i] - 12), t, beatSec * 0.4, 0.15, 'triangle');
        if (i % 2 === 0) playKick(t);
        else playSnareOrHat(t, true);
      }
      break;
    }

    case 'bgm_ambient':
    default: {
      // Calming Ambient Meditation & Rain Tones
      const ambientFrequencies = [261.63, 329.63, 392.0, 523.25, 659.25]; // C major pentatonic
      for (let i = 0; i < 16; i++) {
        const f = ambientFrequencies[i % ambientFrequencies.length];
        const t = i * 1.0;
        playTone(f, t, 4.0, 0.15, 'sine');
        playTone(f * 0.5, t, 4.5, 0.18, 'sine');
      }
      break;
    }
  }

  const renderedBuffer = await offlineCtx.startRendering();
  const wavBlob = audioBufferToWav(renderedBuffer);
  const blobUrl = URL.createObjectURL(wavBlob);

  audioBlobCache.set(trackId, blobUrl);
  return blobUrl;
}
