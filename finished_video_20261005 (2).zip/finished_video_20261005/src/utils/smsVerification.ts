export interface SmsVerificationState {
  phoneNumber: string;
  code: string;
  sentAt: number;
  expiresAt: number;
  isVerified: boolean;
}

/**
 * Clean phone number to standard digits
 */
export function formatPhoneNumber(value: string): string {
  const digits = value.replace(/\D/g, '');
  if (digits.length <= 3) {
    return digits;
  }
  if (digits.length <= 7) {
    return `${digits.slice(0, 3)}-${digits.slice(3)}`;
  }
  if (digits.length <= 11) {
    return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7, 11)}`;
  }
  return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7, 11)}`;
}

/**
 * Validate Korean mobile phone number format
 * Validates 010, 011, 016, 017, 018, 019 with 10-11 digits
 */
export function isValidKoreanPhoneNumber(phoneNumber: string): boolean {
  const digits = phoneNumber.replace(/\D/g, '');
  // Standard Korean mobile numbers: 010-XXXX-XXXX (11 digits) or 01X-XXX-XXXX (10 digits)
  return /^01[016789]\d{7,8}$/.test(digits);
}

/**
 * Generate a random 6-digit numeric verification code
 */
export function generateVerificationCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
