import React, { useState } from 'react';
import { SocialProvider, useSocial } from './context/SocialContext';
import { Sidebar } from './components/Sidebar';
import { MobileNav } from './components/MobileNav';
import { FeedView } from './components/FeedView';
import { ExploreView } from './components/ExploreView';
import { NotificationsView } from './components/NotificationsView';
import { MessagesView } from './components/MessagesView';
import { BookmarksView } from './components/BookmarksView';
import { ProfileView } from './components/ProfileView';
import { RightWidgets } from './components/RightWidgets';
import { CreatePostModal, CreatePostInitialMode } from './components/CreatePostModal';
import { CreateStoryModal } from './components/CreateStoryModal';
import { StoryViewerModal } from './components/StoryViewerModal';
import { EditProfileModal } from './components/EditProfileModal';
import { EditSignupInfoModal } from './components/EditSignupInfoModal';
import { AuthModal } from './components/AuthModal';
import { Toast } from './components/Toast';
import { SystemThemeToast } from './components/SystemThemeToast';
import { Header } from './components/Header';
import { AdminDashboard } from './components/AdminDashboard';
import { DatabaseManagementView } from './components/DatabaseManagementView';
import { ScrollToTopButton } from './components/ScrollToTopButton';
import { ErrorBoundary } from './components/ErrorBoundary';

const MainLayout: React.FC = () => {
  const {
    activeTab,
    isAuthenticated,
    openAuthModal,
    isCreateStoryOpen,
    openCreateStoryModal,
    closeCreateStoryModal
  } = useSocial();
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [createPostInitialMode, setCreatePostInitialMode] = useState<CreatePostInitialMode>(null);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);

  const handleOpenCreatePost = (mode?: CreatePostInitialMode) => {
    if (!isAuthenticated) {
      openAuthModal('login');
      return;
    }
    setCreatePostInitialMode(mode || null);
    setIsCreatePostOpen(true);
  };

  const handleOpenCreateStory = () => {
    if (!isAuthenticated) {
      openAuthModal('login');
      return;
    }
    openCreateStoryModal();
  };

  const renderActiveView = () => {
    switch (activeTab) {
      case 'feed':
        return (
          <FeedView
            onOpenCreatePost={handleOpenCreatePost}
            onOpenCreateStory={handleOpenCreateStory}
          />
        );
      case 'explore':
        return <ExploreView />;
      case 'notifications':
        return <NotificationsView />;
      case 'messages':
        return <MessagesView />;
      case 'bookmarks':
        return <BookmarksView />;
      case 'profile':
        return (
          <ProfileView
            onOpenEditProfile={() => {
              if (!isAuthenticated) {
                openAuthModal('login');
                return;
              }
              setIsEditProfileOpen(true);
            }}
          />
        );
      case 'admin':
        return <AdminDashboard />;
      case 'database':
        return <DatabaseManagementView />;
      default:
        return (
          <FeedView
            onOpenCreatePost={handleOpenCreatePost}
            onOpenCreateStory={handleOpenCreateStory}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 dark:bg-slate-950 dark:text-slate-100 font-sans transition-colors">
      {/* Mobile Top & Bottom Navigation */}
      <MobileNav onOpenCreatePost={handleOpenCreatePost} />

      {/* Main Responsive Grid Frame */}
      <div className="mx-auto max-w-7xl flex justify-center">
        {/* Left Sidebar (Desktop) */}
        <Sidebar onOpenCreatePost={handleOpenCreatePost} />

        {/* Center Main Content Area */}
        <main className={`w-full ${activeTab === 'messages' || activeTab === 'admin' || activeTab === 'database' ? 'max-w-5xl' : 'max-w-2xl'} flex-1 px-3 py-4 md:px-6 md:py-6 pb-24 md:pb-8 min-h-screen transition-all duration-200`}>
          <Header onOpenCreatePost={handleOpenCreatePost} />
          {renderActiveView()}
        </main>

        {/* Right Widgets (Desktop) */}
        {activeTab !== 'messages' && activeTab !== 'admin' && activeTab !== 'database' && <RightWidgets />}
      </div>

      {/* Global Interactive Modals */}
      <CreatePostModal
        isOpen={isCreatePostOpen}
        onClose={() => {
          setIsCreatePostOpen(false);
          setCreatePostInitialMode(null);
        }}
        initialMode={createPostInitialMode}
      />

      <CreateStoryModal
        isOpen={isCreateStoryOpen}
        onClose={closeCreateStoryModal}
      />

      <StoryViewerModal />

      <EditProfileModal
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
      />

      {/* Edit Signup/Account Info Modal */}
      <EditSignupInfoModal />

      {/* Authentication Modal (Login / Signup / Demo Switch) */}
      <AuthModal />

      {/* Toast Notification Container */}
      <Toast />

      {/* System Theme Automatic Switch Top Notification */}
      <SystemThemeToast />

      {/* Global Scroll to Top Shortcut Button (Hidden on messages page) */}
      {activeTab !== 'messages' && <ScrollToTopButton />}
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <SocialProvider>
        <MainLayout />
      </SocialProvider>
    </ErrorBoundary>
  );
}

