export interface User {
  id: string;
  name: string;
  handle: string;
  email?: string;
  emailVerified?: boolean;
  password?: string;
  avatar: string;
  banner: string;
  bio: string;
  phoneNumber?: string;
  phoneVerified?: boolean;
  location?: string;
  website?: string;
  joinedDate: string;
  followingIds: string[];
  followerIds?: string[];
  followersCount: number;
  followingCount: number;
  isVerified?: boolean;
  role?: string;
  interests?: string[];
  featuredPhotos?: string[];
  statusMessage?: string;
  githubUrl?: string;
  instagramUrl?: string;
  isAdmin?: boolean;
  birthdate?: string;
  isOver14Confirmed?: boolean;
  isBanned?: boolean;
  bannedAt?: string;
  banReason?: string;
  createdAt?: string; // ISO string for exact registration date/time calculation
  signupIp?: string; // IP address recorded upon user registration
}

export interface KickedUserRecord {
  id: string;
  name: string;
  handle: string;
  email?: string;
  phoneNumber?: string;
  signupIp?: string;
  kickedAt: string;
  reason: string;
  kickedBy: string;
  userData?: User;
  userPosts?: Post[];
}

export type AuthMode = 'login' | 'signup' | 'demo' | 'find-id' | 'reset-password';

export type SignupVerificationMethod = 'email' | 'sms' | 'both' | 'either' | 'none';

export interface SignupAuthConfig {
  verificationMethod: SignupVerificationMethod;
  allowEmailLogin: boolean;
  codeExpirationMinutes: number;
  updatedAt?: string;
  updatedBy?: string;
}

export type SmsVerificationStatus = 'pending' | 'verified' | 'expired' | 'failed';
export type SmsProviderType =
  | 'CoolSMS'
  | 'Aligo'
  | 'Twilio'
  | 'NaverSENS'
  | 'Custom'
  | 'DirectSMS'
  | 'Manual_Admin_Input'
  | 'Sandbox';

export interface SmsApiConfig {
  provider: SmsProviderType;
  enabled: boolean;
  senderNumber: string;
  // CoolSMS (Solapi)
  coolsmsApiKey?: string;
  coolsmsApiSecret?: string;
  // Aligo (알리고)
  aligoApiKey?: string;
  aligoUserId?: string;
  // Twilio
  twilioAccountSid?: string;
  twilioAuthToken?: string;
  // Naver Cloud SENS
  naverAccessKey?: string;
  naverSecretKey?: string;
  naverServiceId?: string;
  // Custom API
  customApiUrl?: string;
  customAuthHeader?: string;
  // SMS Template & Security
  smsTemplate: string;
  codeExpirationMinutes: number;
  maxAttempts: number;
  testMode: boolean;
  updatedAt?: string;
  updatedBy?: string;
}

export interface SmsDbRecord {
  id: string;
  phoneNumber: string;
  displayPhone: string;
  code: string;
  status: SmsVerificationStatus;
  attempts: number;
  provider: SmsProviderType;
  smsText: string;
  isRealSmsSent: boolean;
  createdAt: string;
  createdTimestamp: number;
  expiresAt: string;
  expiresTimestamp: number;
  verifiedAt?: string | null;
  verifiedTimestamp?: number | null;
  userId?: string | null;
  userHandle?: string | null;
  ipAddress?: string | null;
  notes?: string | null;
}

export interface SmsDbStats {
  total: number;
  verified: number;
  pending: number;
  expired: number;
  failed: number;
  todayCount: number;
  successRate: number;
}

export interface PollOption {
  id: string;
  text: string;
  votes: string[]; // user ids
}

export interface Poll {
  question: string;
  options: PollOption[];
  totalVotes: number;
  expiresAt?: string;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  content: string;
  createdAt: string;
  likes: string[]; // user ids
  parentId?: string; // for nested replies
  audioUrl?: string; // Base64 or Blob audio URL for voice comments
  audioDuration?: number; // Duration in seconds
}

export type RegionalScope = 'city' | 'province' | 'national' | 'global';

export interface PostMediaItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  thumbnail?: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  authorVerified?: boolean;
  content: string;
  images?: string[];
  video?: string; // Video URL (MP4, WebM, etc.)
  videoUrls?: string[]; // Multiple video URLs for cross-platform Android & Web sync
  videoThumbnail?: string;
  mediaItems?: PostMediaItem[]; // Instagram carousel: up to 10 photos/videos
  tags?: string[];
  poll?: Poll;
  feeling?: string;
  location?: string;
  bgm?: StoryBgm; // 100% CC0 / Royalty-Free Background Music
  createdAt: string;
  likes: string[]; // user ids
  bookmarks: string[]; // user ids
  reposts: string[]; // user ids
  commentsCount: number;
  visibility: 'public' | 'followers';
  regionalScope?: RegionalScope;
  isEdited?: boolean;
  updatedAt?: string;
  scheduledAt?: string;
  isBlocked?: boolean;
  blockedAt?: string;
  blockReason?: string;
  blockedBy?: string;
  isDeleted?: boolean;
  deletedAt?: string;
  deletedBy?: string;
}

export interface ScheduledPost {
  id: string;
  authorId: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string;
  authorVerified?: boolean;
  content: string;
  images?: string[];
  video?: string;
  videoThumbnail?: string;
  mediaItems?: PostMediaItem[];
  tags?: string[];
  poll?: Poll;
  feeling?: string;
  location?: string;
  bgm?: StoryBgm;
  scheduledAt: string; // ISO String
  visibility: 'public' | 'followers';
  regionalScope?: RegionalScope;
  createdAt: string;
}

export interface StoryViewer {
  userId: string;
  userName: string;
  userAvatar: string;
  userHandle?: string;
  viewedAt: string;
  reactionEmoji?: string;
  watchDurationSeconds?: number; // 시청 유지 시간 (초, e.g. 1~5초)
  completionRate?: number; // 시청 완료율 (0~100%)
  deviceType?: 'mobile' | 'desktop' | 'tablet';
}

export interface StoryReaction {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  emoji: string;
  label?: string;
  createdAt: string;
}

export interface StoryBgm {
  id: string;
  title: string;
  artist: string;
  genre: string;
  audioUrl: string;
  coverUrl?: string;
  duration?: number;
  license?: string;
  isCustom?: boolean;
}

export interface StoryTextOverlay {
  id: string;
  text: string;
  x: number; // percentage 0 - 100
  y: number; // percentage 0 - 100
  color: string; // text color e.g. '#ffffff'
  bgColor?: string; // background pill style e.g. 'bg-black/60', 'bg-white/90', 'transparent'
  styleType: 'classic' | 'modern' | 'neon' | 'badge' | 'highlight';
  fontSize: 'sm' | 'base' | 'lg' | 'xl' | '2xl';
  rotation?: number; // deg
}

export interface StoryStickerOverlay {
  id: string;
  content: string; // emoji or badge string
  type: 'emoji' | 'badge' | 'sticker';
  x: number; // percentage 0 - 100
  y: number; // percentage 0 - 100
  scale?: number; // 0.8 - 2.0
  rotation?: number; // deg
}

export interface StoryFilterPreset {
  id: string;
  name: string;
  cssFilter: string;
  icon?: string;
  tag?: string;
}

export interface StoryDraft {
  id: string;
  mediaUrl: string;
  mediaType?: 'image' | 'video';
  caption?: string;
  bgColor?: string;
  bgm?: StoryBgm;
  filterId?: string;
  textOverlays?: StoryTextOverlay[];
  stickerOverlays?: StoryStickerOverlay[];
  savedAt: string;
}

export interface StoryItem {
  /** Video duration in seconds, when known. */
  duration?: number;
  id: string;
  mediaUrl: string;
  mediaType: 'image' | 'video';
  caption?: string;
  bgColor?: string;
  createdAt: string;
  viewers?: StoryViewer[];
  reactions?: StoryReaction[];
  bgm?: StoryBgm;
  filterId?: string;
  textOverlays?: StoryTextOverlay[];
  stickerOverlays?: StoryStickerOverlay[];
}

export interface UserStory {
  userId: string;
  userName: string;
  userAvatar: string;
  hasUnseen: boolean;
  items: StoryItem[];
}

export interface MessageReplyInfo {
  messageId: string;
  senderName: string;
  content: string;
  mediaUrl?: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  mediaUrl?: string;
  createdAt: string;
  isRead: boolean;
  readAt?: string;
  replyTo?: MessageReplyInfo;
  isForwarded?: boolean;
  isStarred?: boolean;
  starredAt?: string;
}

export interface Conversation {
  id: string;
  participantIds: string[];
  lastMessage: string;
  lastMessageAt: string;
  unreadCount: number;
}

export interface Notification {
  id: string;
  recipientId: string;
  actorId: string;
  actorName: string;
  actorAvatar: string;
  type: 'like' | 'comment' | 'follow' | 'repost' | 'mention' | 'story_reaction' | 'system' | 'welcome';
  postId?: string;
  commentId?: string;
  storyId?: string;
  content?: string;
  createdAt: string;
  isRead: boolean;
}

export type TrendCategoryKey = 'tech' | 'news' | 'sports' | 'food' | 'lifestyle' | 'entertainment' | 'travel';

export interface TrendingTopic {
  id: string;
  tag: string;
  category: string;
  categoryType?: TrendCategoryKey;
  postCount: number;
  isHot?: boolean;
  description?: string;
}

export type ActiveTab = 'feed' | 'explore' | 'notifications' | 'messages' | 'bookmarks' | 'profile' | 'admin' | 'database';

export type DatabaseTableKey = 'users' | 'posts' | 'comments' | 'stories' | 'messages' | 'api_keys';

export interface ApiKeyRecord {
  id: string;
  serviceName: string;
  provider: SmsProviderType | 'GeminiAI' | 'Custom';
  keyName: string;
  apiKey: string;
  secretName: string;
  apiSecret: string;
  senderNumber?: string;
  extraParam?: string;
  status: 'active' | 'inactive' | 'sandbox';
  description: string;
  updatedAt: string;
  updatedBy?: string;
}

export type SpamFilterAction = 'block' | 'mask' | 'auto_blind';

export interface SpamFilterSettings {
  isEnabled: boolean;
  action: SpamFilterAction;
  replacementMask: string;
  keywords: string[];
  targetScope: {
    posts: boolean;
    comments: boolean;
    messages: boolean;
    stories: boolean;
  };
  customNoticeMessage?: string;
  stats: {
    totalBlockedCount: number;
    totalMaskedCount: number;
    totalAutoBlindedCount: number;
    lastDetectedKeyword?: string;
    lastDetectedAt?: string;
  };
}

export interface SpamCheckResult {
  hasSpam: boolean;
  detectedWords: string[];
  cleanText: string;
  actionTaken: 'none' | 'block' | 'mask' | 'auto_blind';
  noticeMessage?: string;
}

export interface FullDatabaseBackup {
  version: string;
  exportedAt: string;
  exportedBy: string;
  tables: {
    users: User[];
    posts: Post[];
    comments: Comment[];
    stories: UserStory[];
    messages: Message[];
    api_keys?: ApiKeyRecord[];
  };
}

export type ThemeMode = 'system' | 'light' | 'dark';

export interface TargetLanguageOption {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
}

export interface PostTranslationState {
  translatedText: string;
  detectedLanguage?: string;
  targetLanguage: string;
  targetLanguageCode: string;
  isLoading: boolean;
  error?: string | null;
}

export interface SystemThemeNotice {
  id: string;
  message: string;
  mode: 'light' | 'dark';
  timestamp: number;
}
