import { RegionalScope } from './regionalScope';

export interface LocationParts {
  raw: string;
  isForeign: boolean;
  country?: string;
  province?: string; // e.g., '서울', '경기', '부산', '대구', '인천', '광주', '대전', '울산', '세종', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'
  cityDistrict?: string; // e.g., '강남구', '성동구', '마포구', '서초구', '성남시', '가평군', '애월읍', '해운대구'
}

// Normalized Korean provinces/metropolitan cities
const KR_PROVINCES = [
  { key: '서울', aliases: ['서울', '서울특별시'] },
  { key: '경기', aliases: ['경기', '경기도'] },
  { key: '인천', aliases: ['인천', '인천광역시'] },
  { key: '부산', aliases: ['부산', '부산광역시'] },
  { key: '대구', aliases: ['대구', '대구광역시'] },
  { key: '광주', aliases: ['광주', '광주광역시'] },
  { key: '대전', aliases: ['대전', '대전광역시'] },
  { key: '울산', aliases: ['울산', '울산광역시'] },
  { key: '세종', aliases: ['세종', '세종특별자치시'] },
  { key: '강원', aliases: ['강원', '강원도', '강원특별자치도'] },
  { key: '충북', aliases: ['충북', '충청북도'] },
  { key: '충남', aliases: ['충남', '충청남도'] },
  { key: '전북', aliases: ['전북', '전라북도', '전북특별자치도'] },
  { key: '전남', aliases: ['전남', '전라남도'] },
  { key: '경북', aliases: ['경북', '경상북도'] },
  { key: '경남', aliases: ['경남', '경상남도'] },
  { key: '제주', aliases: ['제주', '제주도', '제주특별자치도'] }
];

// Foreign keywords to detect non-Korean locations
const FOREIGN_KEYWORDS = [
  '일본', '도쿄', '오사카', '교토', '후쿠오카', '삿포로', 'japan', 'tokyo',
  '미국', '뉴욕', 'la', '로스앤젤레스', '샌프란시스코', '하와이', 'usa',
  '프랑스', '파리', 'france', 'paris',
  '영국', '런던', 'uk', 'london',
  '독일', '베를린', '뮌헨', 'germany',
  '베트남', '다낭', '하노이', '호치민', 'vietnam',
  '태국', '방콕', '치앙마이', '푸켓', 'thailand',
  '대만', '타이베이', 'taiwan',
  '홍콩', 'hong kong',
  '이탈리아', '로마', '밀라노', '피렌체', 'italy',
  '스페인', '바르셀로나', '마드리드', 'spain',
  '스위스', '인터라켄', '알프스', '호주', '시드니', '멜버른', '캐나다', '싱가포르', '중국', '상하이', '베이징'
];

/**
 * Parse a location string into structured parts (province, city/district, isForeign)
 */
export function parseLocation(locationStr?: string | null): LocationParts {
  const raw = (locationStr || '').trim();
  if (!raw) {
    return { raw: '', isForeign: false };
  }

  const lower = raw.toLowerCase();

  // 1. Check if foreign
  const isForeign = FOREIGN_KEYWORDS.some((kw) => lower.includes(kw));
  if (isForeign) {
    return {
      raw,
      isForeign: true
    };
  }

  // 2. Extract Korean province
  let matchedProvince: string | undefined;
  for (const prov of KR_PROVINCES) {
    if (prov.aliases.some((alias) => raw.startsWith(alias) || raw.includes(alias))) {
      matchedProvince = prov.key;
      break;
    }
  }

  // 3. Extract city / district / county (구, 시, 군, 읍)
  const tokens = raw.split(/[\s,·/]+/);
  let matchedDistrict: string | undefined;

  for (const token of tokens) {
    // Skip if it's just the province name
    if (matchedProvince && KR_PROVINCES.some((p) => p.aliases.includes(token))) {
      continue;
    }
    // Match tokens ending with 구, 시, 군, 읍, 동 or known districts
    if (/[시구군읍]$/.test(token) || /^[가-힣]{2,4}(동|로|가)$/.test(token)) {
      matchedDistrict = token;
      break;
    }
  }

  // Special fallbacks for famous local spots
  if (!matchedDistrict) {
    if (raw.includes('판교')) matchedDistrict = '판교';
    else if (raw.includes('성수')) matchedDistrict = '성동구';
    else if (raw.includes('연남')) matchedDistrict = '마포구';
    else if (raw.includes('한남')) matchedDistrict = '용산구';
    else if (raw.includes('반포')) matchedDistrict = '서초구';
    else if (raw.includes('역삼')) matchedDistrict = '강남구';
    else if (raw.includes('애월')) matchedDistrict = '애월읍';
    else if (raw.includes('양양')) matchedDistrict = '양양군';
    else if (raw.includes('가평')) matchedDistrict = '가평군';
    else if (tokens.length > 1) matchedDistrict = tokens[1];
  }

  return {
    raw,
    isForeign: false,
    province: matchedProvince,
    cityDistrict: matchedDistrict
  };
}

/**
 * Get readable user location description for UI badges/tooltips
 */
export function getScopeFilterExplanation(
  userLocation: string | undefined | null,
  scope: RegionalScope
): { targetRegion: string; explanation: string } {
  const userParts = parseLocation(userLocation || '서울 강남구');
  const userLocDisplay = userParts.raw || '서울 강남구';

  switch (scope) {
    case 'city': {
      const cityOrDistrict = userParts.cityDistrict || userParts.province || '서울';
      const fullDisplay = userParts.province 
        ? `${userParts.province} ${userParts.cityDistrict || ''}`.trim()
        : cityOrDistrict;
      return {
        targetRegion: fullDisplay,
        explanation: `내 위치(${userLocDisplay})와 동일한 시·구 권역(${fullDisplay}) 게시물`
      };
    }
    case 'province': {
      const prov = userParts.province || '서울';
      const provName = prov === '서울' ? '서울특별시' : prov.endsWith('도') ? prov : `${prov}도/광역시`;
      return {
        targetRegion: provName,
        explanation: `내 위치(${userLocDisplay})와 동일한 도·광역시(${provName}) 권역 게시물`
      };
    }
    case 'national': {
      return {
        targetRegion: '대한민국 국내',
        explanation: `대한민국 국내 모든 지역의 게시물`
      };
    }
    case 'global': {
      return {
        targetRegion: '해외 / 글로벌',
        explanation: `해외(국외) 위치 또는 글로벌 게시물`
      };
    }
  }
}

/**
 * Determine if a post matches the user's location based on the selected regional scope.
 * 
 * Scopes:
 * - 'all': match everything
 * - 'city' (같은 시 지역):
 *      동일한 시/군/구 권역 (e.g. 강남구 - 강남구/역삼동 등, 또는 특별시/광역시 내 동일 생활권)
 * - 'province' (같은 도 내):
 *      동일 광역 시/도 권역 (e.g., 서울-서울, 경기-경기, 강원-강원, 제주-제주)
 * - 'national' (국내):
 *      대한민국 국내 위치 게시물 (해외가 아닌 모든 게시물)
 * - 'global' (국외):
 *      해외(국외) 위치 게시물
 */
export function isPostMatchingUserLocation(
  postLocation: string | undefined | null,
  userLocation: string | undefined | null,
  scope: RegionalScope | 'all',
  postDeclaredScope?: RegionalScope
): boolean {
  if (scope === 'all') return true;

  const userParts = parseLocation(userLocation || '서울 강남구');
  const postParts = parseLocation(postLocation);

  // If post has no location text at all:
  if (!postParts.raw) {
    if (scope === 'global') return postDeclaredScope === 'global';
    if (scope === 'national') return postDeclaredScope !== 'global';
    if (scope === 'province') return postDeclaredScope === 'province' || postDeclaredScope === 'city';
    if (scope === 'city') return postDeclaredScope === 'city';
    return true;
  }

  switch (scope) {
    case 'global': {
      // Must be foreign location OR post declared regionalScope is 'global'
      return postParts.isForeign || postDeclaredScope === 'global';
    }

    case 'national': {
      // Must NOT be foreign location (domestic Korea) AND not explicitly global only
      if (postParts.isForeign) return false;
      if (postDeclaredScope === 'global') return false;
      return true;
    }

    case 'province': {
      // If either is foreign, cannot be same Korean province
      if (postParts.isForeign || userParts.isForeign) return false;

      // Check if provinces match
      if (userParts.province && postParts.province) {
        return userParts.province === postParts.province;
      }

      // Check raw strings
      if (userParts.province && postParts.raw.includes(userParts.province)) {
        return true;
      }
      return false;
    }

    case 'city': {
      // If either is foreign, cannot be same Korean city
      if (postParts.isForeign || userParts.isForeign) return false;

      // Must be in the same province/metro city
      if (userParts.province && postParts.province && userParts.province !== postParts.province) {
        return false;
      }

      // If user is in a district (e.g. 강남구)
      if (userParts.cityDistrict) {
        const uClean = userParts.cityDistrict.replace(/(구|시|군|읍|동)$/, '');

        if (postParts.cityDistrict) {
          const pClean = postParts.cityDistrict.replace(/(구|시|군|읍|동)$/, '');
          if (uClean && pClean && (uClean === pClean || uClean.includes(pClean) || pClean.includes(uClean))) {
            return true;
          }
        }

        if (uClean && postParts.raw.includes(uClean)) {
          return true;
        }
      }

      // Fallback: If both locations share the exact same city or district token in raw strings
      if (userParts.cityDistrict && postParts.raw.includes(userParts.cityDistrict)) {
        return true;
      }

      return false;
    }

    default:
      return true;
  }
}
