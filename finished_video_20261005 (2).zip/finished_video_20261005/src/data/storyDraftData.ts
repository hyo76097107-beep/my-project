import { StoryDraft } from '../types';
import { PRESET_POST_PHOTOS } from './mockData';
import { PRESET_STORY_BGMS } from './storyBgmData';

export const INITIAL_STORY_DRAFTS: StoryDraft[] = [
  {
    id: 'draft_1',
    mediaUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
    caption: '노을 지는 해변에서의 여유로운 순간 🌊🌅',
    bgColor: 'from-amber-600 to-rose-700',
    bgm: PRESET_STORY_BGMS[0], // Late Night Coffee
    filterId: 'warm',
    textOverlays: [
      {
        id: 'txt_d1',
        text: 'Sunset Vibe 🌅',
        x: 50,
        y: 28,
        color: '#ffffff',
        styleType: 'badge',
        fontSize: 'lg'
      }
    ],
    stickerOverlays: [
      {
        id: 'stk_d1_1',
        content: 'VIBE ✨',
        type: 'badge',
        x: 82,
        y: 18,
        scale: 1,
        rotation: 8
      },
      {
        id: 'stk_d1_2',
        content: '🏖️',
        type: 'emoji',
        x: 20,
        y: 32,
        scale: 1.2,
        rotation: -10
      }
    ],
    savedAt: new Date(Date.now() - 1000 * 60 * 25).toISOString() // 25 mins ago
  },
  {
    id: 'draft_2',
    mediaUrl: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=80',
    caption: '새로 찾은 아늑한 성수동 북카페 ☕️ 책 읽기 좋은 날',
    bgColor: 'from-emerald-600 to-teal-800',
    bgm: PRESET_STORY_BGMS[2], // Spring Garden Whisper
    filterId: 'vintage',
    textOverlays: [
      {
        id: 'txt_d2',
        text: '책과 따뜻한 커피 한 잔 📖',
        x: 50,
        y: 35,
        color: '#ffffff',
        styleType: 'highlight',
        fontSize: 'base'
      }
    ],
    stickerOverlays: [
      {
        id: 'stk_d2_1',
        content: 'DAILY ☕',
        type: 'badge',
        x: 75,
        y: 18,
        scale: 1,
        rotation: -4
      }
    ],
    savedAt: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString() // 3 hours ago
  },
  {
    id: 'draft_3',
    mediaUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=800&auto=format&fit=crop&q=80',
    caption: '주말 서울 야경 드라이브 🌃 반짝이는 빌딩 숲',
    bgColor: 'from-purple-700 to-indigo-900',
    bgm: PRESET_STORY_BGMS[3], // Neon Sunset Drive
    filterId: 'cyber',
    textOverlays: [
      {
        id: 'txt_d3',
        text: 'SEOUL CITY LIGHTS ✨',
        x: 50,
        y: 30,
        color: '#ffffff',
        styleType: 'neon',
        fontSize: 'lg'
      }
    ],
    stickerOverlays: [
      {
        id: 'stk_d3_1',
        content: 'HOT 🔥',
        type: 'badge',
        x: 22,
        y: 20,
        scale: 1.1,
        rotation: -8
      },
      {
        id: 'stk_d3_2',
        content: '● REC 00:24',
        type: 'badge',
        x: 76,
        y: 20,
        scale: 0.95
      }
    ],
    savedAt: new Date(Date.now() - 1000 * 60 * 60 * 18).toISOString() // 18 hours ago
  }
];
