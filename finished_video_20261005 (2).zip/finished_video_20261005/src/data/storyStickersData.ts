export interface StickerCategory {
  id: string;
  name: string;
  items: {
    id: string;
    content: string;
    type: 'badge' | 'emoji' | 'sticker';
    label: string;
    styleClass?: string;
  }[];
}

export const STORY_STICKER_CATEGORIES: StickerCategory[] = [
  {
    id: 'badges',
    name: '🌟 감성 뱃지',
    items: [
      { id: 'b_hot', content: 'HOT 🔥', type: 'badge', label: 'HOT', styleClass: 'bg-gradient-to-r from-red-600 to-amber-500 text-white font-black' },
      { id: 'b_vibe', content: 'VIBE ✨', type: 'badge', label: 'VIBE', styleClass: 'bg-gradient-to-r from-purple-600 to-pink-500 text-white font-black' },
      { id: 'b_daily', content: 'DAILY ☕', type: 'badge', label: 'DAILY', styleClass: 'bg-stone-800/90 text-amber-200 border border-amber-400/40 font-bold' },
      { id: 'b_weekend', content: 'WEEKEND 🏖️', type: 'badge', label: 'WEEKEND', styleClass: 'bg-gradient-to-r from-teal-500 to-cyan-600 text-white font-black' },
      { id: 'b_love', content: 'LOVE ❤️', type: 'badge', label: 'LOVE', styleClass: 'bg-gradient-to-r from-rose-500 to-pink-600 text-white font-bold' },
      { id: 'b_music', content: 'MUSIC 🎧', type: 'badge', label: 'MUSIC', styleClass: 'bg-indigo-600 text-white font-bold' },
      { id: 'b_yummy', content: 'YUMMY 🥐', type: 'badge', label: 'YUMMY', styleClass: 'bg-amber-500 text-white font-black' },
      { id: 'b_today', content: 'TODAY 📅', type: 'badge', label: 'TODAY', styleClass: 'bg-blue-600 text-white font-bold' },
      { id: 'b_night', content: 'NIGHT 🌙', type: 'badge', label: 'NIGHT', styleClass: 'bg-slate-900/90 text-indigo-200 border border-indigo-500/50 font-bold' },
      { id: 'b_ootd', content: '#OOTD 👗', type: 'badge', label: 'OOTD', styleClass: 'bg-emerald-600 text-white font-black' }
    ]
  },
  {
    id: 'emojis',
    name: '😀 인기 이모지',
    items: [
      { id: 'e_fire', content: '🔥', type: 'emoji', label: '불꽃' },
      { id: 'e_sparkles', content: '✨', type: 'emoji', label: '반짝' },
      { id: 'e_heart_eyes', content: '😍', type: 'emoji', label: '하트눈' },
      { id: 'e_heart', content: '💖', type: 'emoji', label: '핑크하트' },
      { id: 'e_party', content: '🥳', type: 'emoji', label: '파티' },
      { id: 'e_sunglasses', content: '😎', type: 'emoji', label: '선글라스' },
      { id: 'e_rainbow', content: '🌈', type: 'emoji', label: '무지개' },
      { id: 'e_cherry', content: '🌸', type: 'emoji', label: '벚꽃' },
      { id: 'e_coffee', content: '☕', type: 'emoji', label: '커피' },
      { id: 'e_camera', content: '📸', type: 'emoji', label: '카메라' },
      { id: 'e_cake', content: '🎂', type: 'emoji', label: '케이크' },
      { id: 'e_plane', content: '✈️', type: 'emoji', label: '비행기' },
      { id: 'e_music_note', content: '🎵', type: 'emoji', label: '음표' },
      { id: 'e_peace', content: '✌️', type: 'emoji', label: '브이' },
      { id: 'e_clover', content: '🍀', type: 'emoji', label: '네잎클로버' },
      { id: 'e_pizza', content: '🍕', type: 'emoji', label: '피자' }
    ]
  },
  {
    id: 'labels',
    name: '🏷️ 레트로 라벨',
    items: [
      { id: 'l_rec', content: '● REC 00:24', type: 'badge', label: 'REC', styleClass: 'bg-black/80 text-red-500 font-mono tracking-wider border border-red-500/60' },
      { id: 'l_live', content: 'LIVE 🔴', type: 'badge', label: 'LIVE', styleClass: 'bg-red-600 text-white font-extrabold tracking-wide' },
      { id: 'l_new', content: 'NEW ARRIVAL', type: 'badge', label: 'NEW', styleClass: 'bg-amber-400 text-black font-black tracking-tighter' },
      { id: 'l_goodvibes', content: 'GOOD VIBES ONLY', type: 'badge', label: 'GOOD VIBES', styleClass: 'bg-purple-900/80 text-pink-300 border border-pink-400/40 font-bold' },
      { id: 'l_chill', content: 'CHILL TIME ☁️', type: 'badge', label: 'CHILL', styleClass: 'bg-sky-500/80 text-white font-bold' },
      { id: 'l_workout', content: 'WORKOUT DONE 💪', type: 'badge', label: 'WORKOUT', styleClass: 'bg-orange-600 text-white font-black' }
    ]
  }
];

export const PRESET_TEXT_COLORS = [
  { name: '화이트', value: '#ffffff', class: 'bg-white' },
  { name: '골드 옐로우', value: '#fbbf24', class: 'bg-amber-400' },
  { name: '로즈 핑크', value: '#fb7185', class: 'bg-rose-400' },
  { name: '스카이 블루', value: '#38bdf8', class: 'bg-sky-400' },
  { name: '에메랄드 그린', value: '#4ade80', class: 'bg-emerald-400' },
  { name: '바이올렛 퍼플', value: '#c084fc', class: 'bg-purple-400' },
  { name: '딥 블랙', value: '#0f172a', class: 'bg-slate-900' }
];

export const PRESET_TEXT_STYLES = [
  { id: 'badge', name: '블랙 배지', bgClass: 'bg-black/70 backdrop-blur-md px-3 py-1 rounded-xl shadow-lg border border-white/10' },
  { id: 'highlight', name: '화이트 글래스', bgClass: 'bg-white/90 backdrop-blur-md px-3 py-1 rounded-xl shadow-lg text-black border border-black/10' },
  { id: 'neon', name: '네온 글로우', bgClass: 'bg-purple-950/80 backdrop-blur-md px-3 py-1 rounded-xl border border-pink-400 shadow-[0_0_15px_rgba(236,72,153,0.5)]' },
  { id: 'modern', name: '그라데이션', bgClass: 'bg-gradient-to-r from-blue-600 to-indigo-600 px-3 py-1 rounded-xl shadow-md text-white' },
  { id: 'classic', name: '텍스트만', bgClass: 'drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]' }
];
