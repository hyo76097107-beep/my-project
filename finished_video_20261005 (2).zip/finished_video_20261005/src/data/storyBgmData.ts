import { StoryBgm } from '../types';
import { getOrGenerateRoyaltyFreeTrack } from '../utils/royaltyFreeAudioGenerator';

export interface BgmCategory {
  id: string;
  label: string;
  icon?: string;
}

export const COPYRIGHT_FREE_CATEGORIES: BgmCategory[] = [
  { id: 'all', label: '전체' },
  { id: 'lofi', label: '☕ 로우파이/힐링' },
  { id: 'acoustic', label: '🎸 어쿠스틱' },
  { id: 'piano', label: '🎹 피아노' },
  { id: 'synth', label: '🌆 시티팝/신스' },
  { id: 'tropical', label: '🌴 브이로그' },
  { id: 'ambient', label: '🌧️ 앰비언스' },
  { id: 'jazz', label: '🎷 카페 재즈' },
  { id: 'indie', label: '🌅 인디 포크' },
  { id: 'upbeat', label: '✨ 신나는/활기찬' },
  { id: 'custom', label: '📁 내 등록 음원' }
];

export const PRESET_STORY_BGMS: StoryBgm[] = [
  {
    id: 'bgm_lofi',
    title: 'Late Night Coffee Lo-Fi',
    artist: 'Maeum Lo-Fi Lab',
    genre: 'Lo-Fi Chill',
    audioUrl: '',
    coverUrl: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=300&auto=format&fit=crop&q=80',
    duration: 32,
    license: '저작권 무료 (CC0 / 상업적·개인용 무료)',
    isCustom: false
  },
  {
    id: 'bgm_acoustic',
    title: 'Sunny Morning Melody',
    artist: 'Acoustic Days',
    genre: 'Acoustic / Warm',
    audioUrl: '',
    coverUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=300&auto=format&fit=crop&q=80',
    duration: 28,
    license: '저작권 무료 (CC0 / 상업적·개인용 무료)',
    isCustom: false
  },
  {
    id: 'bgm_piano',
    title: 'Spring Garden Whisper',
    artist: 'Luna White',
    genre: 'Calm Piano',
    audioUrl: '',
    coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&auto=format&fit=crop&q=80',
    duration: 35,
    license: '저작권 무료 (CC0 / 상업적·개인용 무료)',
    isCustom: false
  },
  {
    id: 'bgm_synth',
    title: 'Neon Sunset Drive',
    artist: 'Citypop Wave',
    genre: 'Citypop / Synth',
    audioUrl: '',
    coverUrl: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=300&auto=format&fit=crop&q=80',
    duration: 30,
    license: '저작권 무료 (CC0 / 상업적·개인용 무료)',
    isCustom: false
  },
  {
    id: 'bgm_tropical',
    title: 'Island Summer Breeze',
    artist: 'Tropical Island',
    genre: 'Tropical Chill',
    audioUrl: '',
    coverUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=300&auto=format&fit=crop&q=80',
    duration: 32,
    license: '저작권 무료 (CC0 / 상업적·개인용 무료)',
    isCustom: false
  },
  {
    id: 'bgm_ambient',
    title: 'Cozy Rain & Meditation',
    artist: 'Raindrop Studio',
    genre: 'Ambient Relax',
    audioUrl: '',
    coverUrl: 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=300&auto=format&fit=crop&q=80',
    duration: 30,
    license: '저작권 무료 (CC0 / 상업적·개인용 무료)',
    isCustom: false
  },
  {
    id: 'bgm_jazz',
    title: 'Twilight Cafe Swing Jazz',
    artist: 'Blue Moon Trio',
    genre: 'Smooth Cafe Jazz',
    audioUrl: '',
    coverUrl: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?w=300&auto=format&fit=crop&q=80',
    duration: 32,
    license: '저작권 무료 (CC0 / 상업적·개인용 무료)',
    isCustom: false
  },
  {
    id: 'bgm_indie',
    title: 'Sunset Acoustic Folk',
    artist: 'Seoul Forest Folk',
    genre: 'K-Indie Folk',
    audioUrl: '',
    coverUrl: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=300&auto=format&fit=crop&q=80',
    duration: 32,
    license: '저작권 무료 (CC0 / 상업적·개인용 무료)',
    isCustom: false
  },
  {
    id: 'bgm_upbeat',
    title: 'Happy Sunshine Groove',
    artist: 'Sparkle Pop Lab',
    genre: 'Upbeat Summer',
    audioUrl: '',
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop&q=80',
    duration: 28,
    license: '저작권 무료 (CC0 / 상업적·개인용 무료)',
    isCustom: false
  }
];

/**
 * Resolves a valid playable audio URL for a StoryBgm (synthesizing on demand or using existing URL)
 */
export async function resolveBgmAudioUrl(bgm: StoryBgm): Promise<string> {
  if (bgm.audioUrl && (bgm.audioUrl.startsWith('blob:') || bgm.audioUrl.startsWith('data:') || bgm.audioUrl.startsWith('http'))) {
    return bgm.audioUrl;
  }
  const generated = await getOrGenerateRoyaltyFreeTrack(bgm.id);
  if (generated) {
    bgm.audioUrl = generated;
  }
  return generated;
}

// Background warm-up preset tracks in browser so playback is immediate
if (typeof window !== 'undefined') {
  PRESET_STORY_BGMS.forEach((track) => {
    getOrGenerateRoyaltyFreeTrack(track.id)
      .then((url) => {
        if (url) {
          track.audioUrl = url;
        }
      })
      .catch(() => {});
  });
}
