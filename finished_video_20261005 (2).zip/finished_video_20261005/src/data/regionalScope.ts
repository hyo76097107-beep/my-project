export type RegionalScope = 'city' | 'province' | 'national' | 'global';

export interface RegionalScopeConfig {
  id: RegionalScope;
  label: string;
  shortLabel: string;
  emoji: string;
  description: string;
  detail: string;
  badgeClass: string;
  activeBtnClass: string;
  accentColor: string;
}

export const REGIONAL_SCOPES: RegionalScopeConfig[] = [
  {
    id: 'city',
    label: '같은 시 지역',
    shortLabel: '시 지역',
    emoji: '🏙️',
    description: '동일 시·군·구 권역 이웃에게 공개',
    detail: '작성자의 시·군·구 생활권 이웃들에게 집중 공개됩니다',
    badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800',
    activeBtnClass: 'border-emerald-600 bg-emerald-50/70 text-emerald-700 dark:bg-emerald-950/50 dark:border-emerald-500 dark:text-emerald-300 ring-2 ring-emerald-500/20',
    accentColor: 'text-emerald-600 dark:text-emerald-400'
  },
  {
    id: 'province',
    label: '같은 도 내',
    shortLabel: '도 내',
    emoji: '🗺️',
    description: '동일 도·광역 시도 권역 사용자에게 공개',
    detail: '작성자의 광역도(경기도, 강원도 등) 및 광역 시도 권역에 공개됩니다',
    badgeClass: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800',
    activeBtnClass: 'border-blue-600 bg-blue-50/70 text-blue-700 dark:bg-blue-950/50 dark:border-blue-500 dark:text-blue-300 ring-2 ring-blue-500/20',
    accentColor: 'text-blue-600 dark:text-blue-400'
  },
  {
    id: 'national',
    label: '국내',
    shortLabel: '국내 전체',
    emoji: '🇰🇷',
    description: '대한민국 전국 모든 사용자에게 공개',
    detail: '지역 제한 없이 대한민국 전국 피드에 노출됩니다',
    badgeClass: 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800',
    activeBtnClass: 'border-indigo-600 bg-indigo-50/70 text-indigo-700 dark:bg-indigo-950/50 dark:border-indigo-500 dark:text-indigo-300 ring-2 ring-indigo-500/20',
    accentColor: 'text-indigo-600 dark:text-indigo-400'
  },
  {
    id: 'global',
    label: '국외',
    shortLabel: '국외/글로벌',
    emoji: '🌏',
    description: '전 세계 및 글로벌 사용자에게 공개',
    detail: '해외 체류자, 여행자, 글로벌 사용자 피드에 널리 공유됩니다',
    badgeClass: 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/60 dark:text-purple-300 dark:border-purple-800',
    activeBtnClass: 'border-purple-600 bg-purple-50/70 text-purple-700 dark:bg-purple-950/50 dark:border-purple-500 dark:text-purple-300 ring-2 ring-purple-500/20',
    accentColor: 'text-purple-600 dark:text-purple-400'
  }
];

export const getRegionalScopeConfig = (id?: RegionalScope | string): RegionalScopeConfig => {
  const found = REGIONAL_SCOPES.find((s) => s.id === id);
  return found || REGIONAL_SCOPES[2]; // Default to 'national' (국내)
};
