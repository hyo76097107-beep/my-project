import { StoryFilterPreset } from '../types';

export const STORY_FILTER_PRESETS: StoryFilterPreset[] = [
  {
    id: 'normal',
    name: '원본',
    cssFilter: 'none',
    tag: 'Original'
  },
  {
    id: 'warm',
    name: '노을 웜톤',
    cssFilter: 'sepia(0.25) saturate(1.45) brightness(1.04) hue-rotate(-8deg)',
    tag: 'Warm Sunset'
  },
  {
    id: 'vintage',
    name: '필름 빈티지',
    cssFilter: 'sepia(0.35) contrast(1.15) brightness(0.96) saturate(0.85)',
    tag: 'Film 90s'
  },
  {
    id: 'cool',
    name: '청량 쿨톤',
    cssFilter: 'saturate(1.25) hue-rotate(12deg) brightness(1.05) contrast(1.05)',
    tag: 'Cool Breeze'
  },
  {
    id: 'vivid',
    name: '비비드 팝',
    cssFilter: 'saturate(1.7) contrast(1.15) brightness(1.02)',
    tag: 'Vivid Pop'
  },
  {
    id: 'mono',
    name: '모노 흑백',
    cssFilter: 'grayscale(1) contrast(1.25) brightness(0.95)',
    tag: 'B&W Classic'
  },
  {
    id: 'dreamy',
    name: '몽환 소프트',
    cssFilter: 'brightness(1.12) contrast(0.92) saturate(1.35)',
    tag: 'Dreamy Pastel'
  },
  {
    id: 'cyber',
    name: '네온 사이버',
    cssFilter: 'hue-rotate(175deg) saturate(1.85) contrast(1.2)',
    tag: 'Cyber Neon'
  },
  {
    id: 'fade',
    name: '무드 페이드',
    cssFilter: 'contrast(0.85) brightness(1.08) saturate(0.88)',
    tag: 'Muted Tone'
  }
];

export const getStoryFilterCss = (filterId?: string): string => {
  if (!filterId || filterId === 'normal') return 'none';
  const found = STORY_FILTER_PRESETS.find((f) => f.id === filterId);
  return found ? found.cssFilter : 'none';
};

export const getStoryFilterName = (filterId?: string): string => {
  if (!filterId || filterId === 'normal') return '원본';
  const found = STORY_FILTER_PRESETS.find((f) => f.id === filterId);
  return found ? found.name : '원본';
};
