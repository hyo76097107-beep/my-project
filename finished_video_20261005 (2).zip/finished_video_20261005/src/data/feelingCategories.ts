/**
 * Mood / Feeling Categories
 * 
 * Major Categories:
 * 1. 긍정 (Positive)
 *    - 행복함, 감사, 설렘, 자부심, 평온, 활기, 연민, 사랑, 연애, 흥미, 기쁨, 애정, 다정, 열정
 * 2. 중립 (Neutral)
 *    - 덤덤함, 궁금함, 황당함, 지루함, 여유로움, 여행중
 * 3. 부정 (Negative)
 *    - 슬픔, 우울, 분노, 피로, 외로움, 불쾌감, 공포, 불안, 죄악감, 수치감, 혐오감, 증오, 미움
 */

export type MoodCategoryId = 'positive' | 'neutral' | 'negative';

export interface MoodCategory {
  id: MoodCategoryId;
  name: string; // '긍정' | '중립' | '부정'
  emoji: string;
  description: string;
  colorClass: {
    tabActive: string;
    tabInactive: string;
    chipActive: string;
    chipInactive: string;
    badge: string;
  };
  items: string[];
}

export const MOOD_CATEGORIES: MoodCategory[] = [
  {
    id: 'positive',
    name: '긍정',
    emoji: '😊',
    description: '기쁘고 따뜻한 긍정적 감정',
    colorClass: {
      tabActive: 'bg-emerald-600 text-white shadow-xs',
      tabInactive: 'text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100/70 dark:hover:bg-emerald-950/60',
      chipActive: 'bg-emerald-600 text-white font-semibold shadow-xs border-emerald-600',
      chipInactive: 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-200 border border-emerald-200/70 dark:border-emerald-800/70 hover:bg-emerald-100 dark:hover:bg-emerald-900/60',
      badge: 'bg-emerald-50 text-emerald-700 border border-emerald-200/80 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800/80'
    },
    items: [
      '행복함',
      '감사',
      '설렘',
      '자부심',
      '평온',
      '활기',
      '연민',
      '사랑',
      '연애',
      '흥미',
      '기쁨',
      '애정',
      '다정',
      '열정'
    ]
  },
  {
    id: 'neutral',
    name: '중립',
    emoji: '😐',
    description: '차분하고 일상적인 중립적 감정',
    colorClass: {
      tabActive: 'bg-blue-600 text-white shadow-xs',
      tabInactive: 'text-blue-700 dark:text-blue-300 hover:bg-blue-100/70 dark:hover:bg-blue-950/60',
      chipActive: 'bg-blue-600 text-white font-semibold shadow-xs border-blue-600',
      chipInactive: 'bg-blue-50 text-blue-800 dark:bg-blue-950/40 dark:text-blue-200 border border-blue-200/70 dark:border-blue-800/70 hover:bg-blue-100 dark:hover:bg-blue-900/60',
      badge: 'bg-blue-50 text-blue-700 border border-blue-200/80 dark:bg-blue-950/60 dark:text-blue-300 dark:border-blue-800/80'
    },
    items: [
      '덤덤함',
      '궁금함',
      '황당함',
      '지루함',
      '여유로움',
      '여행중'
    ]
  },
  {
    id: 'negative',
    name: '부정',
    emoji: '😔',
    description: '위로와 해소가 필요한 감정',
    colorClass: {
      tabActive: 'bg-rose-600 text-white shadow-xs',
      tabInactive: 'text-rose-700 dark:text-rose-300 hover:bg-rose-100/70 dark:hover:bg-rose-950/60',
      chipActive: 'bg-rose-600 text-white font-semibold shadow-xs border-rose-600',
      chipInactive: 'bg-rose-50 text-rose-800 dark:bg-rose-950/40 dark:text-rose-200 border border-rose-200/70 dark:border-rose-800/70 hover:bg-rose-100 dark:hover:bg-rose-900/60',
      badge: 'bg-rose-50 text-rose-700 border border-rose-200/80 dark:bg-rose-950/60 dark:text-rose-300 dark:border-rose-800/80'
    },
    items: [
      '슬픔',
      '우울',
      '분노',
      '피로',
      '외로움',
      '불쾌감',
      '공포',
      '불안',
      '죄악감',
      '수치감',
      '혐오감',
      '증오',
      '미움'
    ]
  }
];

/**
 * Helper to find which major category a feeling belongs to
 */
export function findMoodCategoryByItem(item?: string): MoodCategory | undefined {
  if (!item) return undefined;
  // Clean off emojis, category prefixes or spaces if present
  const cleanItem = item.replace(/^[^\w\s가-힣]+/, '').trim();
  return MOOD_CATEGORIES.find((cat) =>
    cat.items.some((i) => i === item || i === cleanItem || item.endsWith(i) || item.includes(i))
  );
}
