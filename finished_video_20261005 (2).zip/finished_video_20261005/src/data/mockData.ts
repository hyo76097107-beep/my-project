import { User, Post, Comment, UserStory, Message, Notification, TrendingTopic } from '../types';
import { PRESET_STORY_BGMS } from './storyBgmData';
import { RegionalScope } from './regionalScope';

export const INITIAL_USERS: User[] = [
  {
    id: 'user_admin',
    name: '최고 관리자',
    handle: 'admin',
    email: 'admin@maeum.io',
    emailVerified: true,
    password: 'mgms7658##',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
    bio: '마음(Maeum) 소셜 네트워크 총괄 관리자 계정입니다 🛡️',
    phoneNumber: '010-1234-5678',
    phoneVerified: true,
    location: '서울 본사 운영팀',
    website: 'https://maeum.io',
    statusMessage: '회원 보호 및 쾌적한 커뮤니티 운영 관리 중 🛡️',
    interests: ['커뮤니티 관리', '회원 보호', '보안 & 모니터링'],
    joinedDate: '2023년 1월',
    followingIds: ['user_1', 'user_2', 'user_3', 'user_4'],
    followersCount: 9999,
    followingCount: 4,
    isVerified: true,
    isAdmin: true,
    role: '서비스 총괄 관리자',
    signupIp: '127.0.0.1 (시스템)',
    createdAt: '2023-01-01T00:00:00.000Z'
  },
  {
    id: 'user_1',
    name: '김민우',
    handle: 'minwoo_dev',
    email: 'minwoo@pulse.io',
    emailVerified: true,
    password: 'password123',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
    bio: 'Frontend Engineer 🚀 | React, Next.js, AI 인터페이스 탐구 중 | 커피와 테크를 사랑합니다 ☕️💻',
    phoneNumber: '010-9876-5432',
    phoneVerified: true,
    location: '서울 강남구',
    website: 'https://github.com/minwoo-dev',
    githubUrl: 'https://github.com/minwoo-dev',
    instagramUrl: 'https://instagram.com/minwoo_codes',
    statusMessage: '새로운 사이드 프로젝트 구상 중 💡',
    interests: ['React & Next.js', 'AI 인터페이스', '스페셜티 커피', '클라이밍', '오픈소스'],
    featuredPhotos: [
      'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&auto=format&fit=crop&q=80'
    ],
    joinedDate: '2023년 3월',
    followingIds: ['user_2', 'user_3', 'user_4'],
    followersCount: 1420,
    followingCount: 380,
    isVerified: true,
    role: '프론트엔드 개발자',
    signupIp: '211.234.120.45',
    createdAt: '2023-03-15T09:30:00.000Z'
  },
  {
    id: 'user_2',
    name: '이지수',
    handle: 'jisoo_lens',
    email: 'jisoo@pulse.io',
    password: 'password123',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1200&auto=format&fit=crop&q=80',
    bio: 'Photographer & Visual Creator 📷 | 여행과 필름 감성 기록 ✈️ | 서울 & 도쿄 📍',
    phoneNumber: '010-3344-5566',
    phoneVerified: true,
    location: '서울 성동구',
    website: 'https://instagram.com/jisoo_photo',
    instagramUrl: 'https://instagram.com/jisoo_photo',
    statusMessage: '제주도 필름 사진 스캔 중 📸✨',
    interests: ['필름 사진', '풍경 출사', '도쿄 & 제주 여행', '라이카 M6', '전시회 관람'],
    featuredPhotos: [
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=800&auto=format&fit=crop&q=80'
    ],
    joinedDate: '2023년 5월',
    followingIds: ['user_1', 'user_3'],
    followersCount: 2890,
    followingCount: 420,
    isVerified: true,
    role: '포토그래퍼 & 크리에이터',
    signupIp: '175.197.88.12',
    createdAt: '2023-05-10T14:15:00.000Z'
  },
  {
    id: 'user_3',
    name: '박서연',
    handle: 'seoyeon_foodie',
    email: 'seoyeon@pulse.io',
    password: 'password123',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80',
    bio: '성수 & 연남 디저트 카페 탐방러 🥐🍰 | 맛있는 일상과 베이킹 레시피 공유 🧁',
    phoneNumber: '010-7788-9900',
    phoneVerified: true,
    location: '서울 마포구',
    website: 'https://blog.naver.com/seoyeon_eats',
    instagramUrl: 'https://instagram.com/seoyeon_desserts',
    statusMessage: '주말 신상 베이커리 팝업 정복 완료 🥐🍰',
    interests: ['성수 디저트 투어', '홈베이킹', '크루아상 & 에그타르트', '카페 브이로그', '핸드드립'],
    featuredPhotos: [
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80'
    ],
    joinedDate: '2023년 8월',
    followingIds: ['user_1', 'user_2', 'user_4'],
    followersCount: 3120,
    followingCount: 510,
    isVerified: false,
    role: '푸드 & 라이프스타일',
    signupIp: '121.133.45.89',
    createdAt: '2023-08-20T11:20:00.000Z'
  },
  {
    id: 'user_4',
    name: '정현우',
    handle: 'hyunwoo_fit',
    email: 'hyunwoo@pulse.io',
    password: 'password123',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=1200&auto=format&fit=crop&q=80',
    bio: '오운완 매일 실천러 🏋️‍♂️ | 러닝, 크로스핏, 헬스 라이프스타일 🏃 | 건강한 습관 만들기',
    phoneNumber: '010-4455-6677',
    phoneVerified: true,
    location: '경기 성남시 판교',
    website: 'https://strava.com/hyunwoo',
    instagramUrl: 'https://instagram.com/hyunwoo_fitlife',
    statusMessage: '오늘도 상쾌하게 한강 10K 러닝 완료 🏃🔥',
    interests: ['오운완', '크로스핏', '마라톤 10K', '고단백 식단', '웨이트 트레이닝', '러닝화 수집'],
    featuredPhotos: [
      'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1538805060514-97d9cc17730c?w=800&auto=format&fit=crop&q=80'
    ],
    joinedDate: '2024년 1월',
    followingIds: ['user_1', 'user_2'],
    followersCount: 980,
    followingCount: 230,
    isVerified: false,
    role: '피트니스 트레이너',
    signupIp: '220.73.14.102',
    createdAt: '2024-01-05T08:00:00.000Z'
  },
  {
    id: 'user_today_1',
    name: '강지훈',
    handle: 'jihoon_today',
    email: 'jihoon.today@naver.com',
    password: 'password123',
    phoneNumber: '010-2233-4455',
    phoneVerified: true,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200&auto=format&fit=crop&q=80',
    bio: '오늘 막 가입했습니다! AI와 디자인에 관심 많아요 🎨',
    location: '서울 서초구',
    interests: ['AI 인터페이스', '디자인 & UI/UX', '카페 & 맛집'],
    joinedDate: '오늘 가입',
    followingIds: ['user_1', 'user_2'],
    followersCount: 3,
    followingCount: 2,
    isVerified: false,
    role: 'UI 디자이너',
    signupIp: '118.235.91.33',
    createdAt: new Date(Date.now() - 1000 * 60 * 75).toISOString() // 1시간 15분 전 오늘 가입
  },
  {
    id: 'user_today_2',
    name: '송유진',
    handle: 'yujin_daily',
    email: 'yujin.daily@gmail.com',
    password: 'password123',
    phoneNumber: '010-8899-0011',
    phoneVerified: true,
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=1200&auto=format&fit=crop&q=80',
    bio: '반가워요! 주말 베이킹과 음악 듣는 게 취미입니다 🎵',
    location: '경기 수원시 팔달구',
    interests: ['홈베이킹', '음악 & 플레이리스트', '여행 & 캠핑'],
    joinedDate: '오늘 가입',
    followingIds: ['user_3'],
    followersCount: 1,
    followingCount: 1,
    isVerified: false,
    role: '콘텐츠 에디터',
    signupIp: '210.108.64.18',
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString() // 3시간 전 오늘 가입
  }
];

export const INITIAL_POSTS: Post[] = [
  {
    id: 'post_1',
    authorId: 'user_2',
    authorName: '이지수',
    authorHandle: 'jisoo_lens',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    authorVerified: true,
    content: '주말에 다녀온 제주도 일몰 🌅 필름 카메라로 담은 바다의 따뜻한 색감이 너무 마음에 드네요. 다들 이번 주말 어떻게 보내셨나요?',
    images: [
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&auto=format&fit=crop&q=80'
    ],
    mediaItems: [
      {
        id: 'post_1_m1',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80'
      },
      {
        id: 'post_1_m2',
        type: 'video',
        url: '/videos/sample_nature.mp4',
        thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80'
      },
      {
        id: 'post_1_m3',
        type: 'image',
        url: 'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&auto=format&fit=crop&q=80'
      }
    ],
    tags: ['제주도', '필름사진', '일몰', '주말여행'],
    feeling: '✨ 행복함',
    location: '제주도 애월읍',
    bgm: PRESET_STORY_BGMS[1], // Sunny Morning Melody (100% 저작권 무료)
    createdAt: new Date(Date.now() - 1000 * 60 * 25).toISOString(), // 25분 전
    likes: ['user_1', 'user_3', 'user_4'],
    bookmarks: ['user_admin', 'user_1'],
    reposts: ['user_3'],
    commentsCount: 3,
    visibility: 'public',
    regionalScope: 'province'
  },
  {
    id: 'post_video_1',
    authorId: 'user_4',
    authorName: '정현우',
    authorHandle: 'hyunwoo_fit',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    authorVerified: false,
    content: '오늘 야외 크로스핏 & 스프린트 훈련 영상 짧게 남겨봅니다! 🔥🏃‍♂️ 날씨가 좋아서 야외 트레이닝 하기에 최고네요. 다들 득근하는 하루 보내세요!',
    video: '/videos/sample_fitness.mp4',
    videoThumbnail: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80',
    tags: ['오운완', '크로스핏', '트레이닝', '동영상', '동기부여'],
    feeling: '🔥 열정 가득',
    location: '서울 올림픽공원',
    createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(), // 45분 전
    likes: ['user_1', 'user_2'],
    bookmarks: ['user_admin', 'user_1'],
    reposts: ['user_2'],
    commentsCount: 2,
    visibility: 'public',
    regionalScope: 'city'
  },
  {
    id: 'post_2',
    authorId: 'user_1',
    authorName: '김민우',
    authorHandle: 'minwoo_dev',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    authorVerified: true,
    content: '개발자 여러분, 요즘 가장 선호하는 프론트엔드 스타일링 방식은 무엇인가요? 프로젝트 시작할 때마다 항상 고민되네요! 💻⚡️',
    poll: {
      question: '가장 선호하는 CSS 스타일링 도구는?',
      options: [
        { id: 'opt_1', text: 'Tailwind CSS (유틸리티 퍼스트)', votes: ['user_2', 'user_4'] },
        { id: 'opt_2', text: 'Styled-Components / Emotion', votes: ['user_3'] },
        { id: 'opt_3', text: 'CSS Modules / Vanilla CSS', votes: [] },
        { id: 'opt_4', text: 'Shadcn UI & Radix Primitives', votes: [] }
      ],
      totalVotes: 3
    },
    tags: ['개발자', '프론트엔드', 'TailwindCSS', '코딩'],
    feeling: '🤔 호기심 가득',
    location: '서울 강남구 역삼동',
    createdAt: new Date(Date.now() - 1000 * 60 * 80).toISOString(), // 1시간 20분 전
    likes: ['user_2', 'user_4'],
    bookmarks: ['user_admin', 'user_2'],
    reposts: ['user_4'],
    commentsCount: 2,
    visibility: 'public',
    regionalScope: 'national'
  },
  {
    id: 'post_video_2',
    authorId: 'user_2',
    authorName: '이지수',
    authorHandle: 'jisoo_lens',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    authorVerified: true,
    content: '지난 도쿄 여행 중 담아온 신주쿠의 화려한 밤거리 타임랩스 비디오 🎥✨ 반짝이는 네온사인과 지나가는 사람들의 에너지가 영상에 그대로 담겼어요.',
    video: '/videos/sample_tokyo.mp4',
    videoThumbnail: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&auto=format&fit=crop&q=80',
    tags: ['도쿄여행', '타임랩스', '야경영상', '여행스타그램', '브이로그'],
    feeling: '✨ 행복함',
    location: '일본 도쿄 신주쿠',
    createdAt: new Date(Date.now() - 1000 * 60 * 130).toISOString(), // 2시간 전
    likes: ['user_1', 'user_3'],
    bookmarks: ['user_3'],
    reposts: ['user_1'],
    commentsCount: 1,
    visibility: 'public',
    regionalScope: 'global'
  },
  {
    id: 'post_3',
    authorId: 'user_3',
    authorName: '박서연',
    authorHandle: 'seoyeon_foodie',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    authorVerified: false,
    content: '성수동 새로 오픈한 베이커리 카페 다녀왔어요! 🥐 버터 풍미 가득한 소금빵이랑 피스타치오 크루아상 진짜 인생 디저트 등극... 웨이팅 30분 한 보람이 있네요 ☕️✨',
    images: [
      'https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&auto=format&fit=crop&q=80'
    ],
    tags: ['성수동맛집', '성수카페', '베이커리', '디저트그램', '소금빵'],
    feeling: '🥐 힐링',
    location: '서울 성동구 성수동2가',
    bgm: PRESET_STORY_BGMS[0], // Late Night Coffee Lo-Fi (100% 저작권 무료)
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(), // 3시간 전
    likes: ['user_1', 'user_2'],
    bookmarks: ['user_1', 'user_4'],
    reposts: [],
    commentsCount: 1,
    visibility: 'public',
    regionalScope: 'city'
  },
  {
    id: 'post_4',
    authorId: 'user_4',
    authorName: '정현우',
    authorHandle: 'hyunwoo_fit',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    authorVerified: false,
    content: '새벽 한강 러닝 10km 완주 완료! 🏃💨 아침 공기 마시며 뛰니까 하루 시작이 상쾌하네요. 오늘 운동 완료(오운완) 하신 분들 계신가요? 💪',
    images: [
      'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=800&auto=format&fit=crop&q=80'
    ],
    tags: ['오운완', '러닝', '한강러닝', '헬스타그램', '모닝루틴'],
    feeling: '🔥 에너지 넘침',
    location: '서울 반포한강공원',
    createdAt: new Date(Date.now() - 1000 * 60 * 360).toISOString(), // 6시간 전
    likes: ['user_1', 'user_2', 'user_3'],
    bookmarks: [],
    reposts: ['user_1'],
    commentsCount: 2,
    visibility: 'public',
    regionalScope: 'city'
  },
  {
    id: 'post_5',
    authorId: 'user_1',
    authorName: '김민우',
    authorHandle: 'minwoo_dev',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    authorVerified: true,
    content: '주말 사이드 프로젝트로 개발 중인 미니멀 음악 플레이어 UI 프로토타입 🎧✨ 글래스모피즘과 부드러운 전환 효과를 적용해봤는데 어떤가요? 피드백 환영합니다!',
    images: [
      'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=80'
    ],
    tags: ['사이드프로젝트', 'UI디자인', '프론트엔드', '개발자일상', '음악'],
    feeling: '💻 집중 모드',
    location: '서울 강남구 역삼동',
    createdAt: new Date(Date.now() - 1000 * 60 * 500).toISOString(),
    likes: ['user_2', 'user_3', 'user_4'],
    bookmarks: ['user_2', 'user_3'],
    reposts: ['user_2'],
    commentsCount: 4,
    visibility: 'public',
    regionalScope: 'city'
  },
  {
    id: 'post_6',
    authorId: 'user_3',
    authorName: '박서연',
    authorHandle: 'seoyeon_foodie',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    authorVerified: false,
    content: '집에서 직접 구운 바스크 치즈 케이크 🧀💛 겉은 스모키하게 카라멜라이징되고 속은 크리미하게 녹아내려요. 아메리카노랑 환상의 짝꿍입니다!',
    images: [
      'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&auto=format&fit=crop&q=80'
    ],
    tags: ['홈베이킹', '치즈케이크', '홈카페', '디저트레시피', '베이킹'],
    feeling: '🍰 달콤함',
    location: '서울 마포구 연남동',
    createdAt: new Date(Date.now() - 1000 * 60 * 750).toISOString(),
    likes: ['user_1', 'user_2'],
    bookmarks: ['user_1', 'user_4'],
    reposts: [],
    commentsCount: 3,
    visibility: 'public',
    regionalScope: 'national'
  },
  {
    id: 'post_7',
    authorId: 'user_2',
    authorName: '이지수',
    authorHandle: 'jisoo_lens',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    authorVerified: true,
    content: '비 내리는 성수동 골목길 스냅 🌧️ 촉촉하게 젖은 아스팔트에 반사되는 네온 불빛들이 몽환적인 분위기를 만들어주네요. 비 오는 날 출사도 매력적이에요.',
    images: [
      'https://images.unsplash.com/photo-1514565131-fce0801e5785?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop&q=80'
    ],
    tags: ['성수동', '비오는날', '스냅사진', '필름감성', '거리사진'],
    feeling: '☕️ 차분함',
    location: '서울 성동구 성수동',
    createdAt: new Date(Date.now() - 1000 * 60 * 1100).toISOString(),
    likes: ['user_1', 'user_3', 'user_4'],
    bookmarks: ['user_1'],
    reposts: ['user_3'],
    commentsCount: 2,
    visibility: 'public',
    regionalScope: 'city'
  },
  {
    id: 'post_8',
    authorId: 'user_4',
    authorName: '정현우',
    authorHandle: 'hyunwoo_fit',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    authorVerified: false,
    content: '주말 헬스장 루틴: 하체 데이 스쿼트 140kg 성공! 🏋️‍♂️ 무리하지 않고 천천히 중량 올려가는 게 가장 안전하고 확실한 방법입니다. 다들 부상 조심하세요!',
    images: [
      'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&auto=format&fit=crop&q=80'
    ],
    tags: ['하체데이', '스쿼트', '오운완', '헬스', '피트니스'],
    feeling: '💪 파워풀',
    location: '경기 성남시 분당구',
    createdAt: new Date(Date.now() - 1000 * 60 * 1400).toISOString(),
    likes: ['user_1', 'user_2'],
    bookmarks: [],
    reposts: [],
    commentsCount: 1,
    visibility: 'public',
    regionalScope: 'province'
  },
  {
    id: 'post_9',
    authorId: 'user_1',
    authorName: '김민우',
    authorHandle: 'minwoo_dev',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    authorVerified: true,
    content: '새로 세팅한 데스크테리어 🖥️✨ 원목 데스크와 따뜻한 조명, 그리고 4K 모니터 조합으로 작업 몰입도가 200% 상승했습니다. 개발자에게 데스크 셋업은 곧 복지죠!',
    images: [
      'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&auto=format&fit=crop&q=80'
    ],
    tags: ['데스크테리어', '개발자데스크', '홈오피스', '장비병', '개발자'],
    feeling: '✨ 만족스러움',
    location: '서울 서초구',
    createdAt: new Date(Date.now() - 1000 * 60 * 1800).toISOString(),
    likes: ['user_2', 'user_3', 'user_4'],
    bookmarks: ['user_2', 'user_4'],
    reposts: ['user_2'],
    commentsCount: 5,
    visibility: 'public',
    regionalScope: 'national'
  },
  {
    id: 'post_10',
    authorId: 'user_2',
    authorName: '이지수',
    authorHandle: 'jisoo_lens',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    authorVerified: true,
    content: '가평 자라섬으로 떠난 주말 캠핑 & 불멍 타임 ⛺️🔥 타닥타닥 장작 타는 소리와 맑은 별빛 하늘 덕분에 한 주간의 피로가 싹 풀리네요. 경기도 근교 힐링 스팟으로 추천합니다!',
    images: [
      'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1510312305653-8ed496efae75?w=800&auto=format&fit=crop&q=80'
    ],
    tags: ['가평캠핑', '자라섬', '불멍', '주말캠핑', '차박', '경기도여행'],
    feeling: '🏕️ 힐링 캠핑',
    location: '경기 가평군 가평읍',
    createdAt: new Date(Date.now() - 1000 * 60 * 2200).toISOString(),
    likes: ['user_1', 'user_3'],
    bookmarks: ['user_1', 'user_4'],
    reposts: ['user_1'],
    commentsCount: 3,
    visibility: 'public',
    regionalScope: 'province'
  },
  {
    id: 'post_11',
    authorId: 'user_3',
    authorName: '박서연',
    authorHandle: 'seoyeon_foodie',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    authorVerified: false,
    content: '파리 센 강변을 거닐며 만난 로맨틱한 에펠탑 야경 🇫🇷✨ 정각마다 반짝이는 불빛쇼는 언제 봐도 잊지 못할 설렘을 선물해 주네요. 글로벌 여행자 여러분 모두 행복한 여행 되세요!',
    images: [
      'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?w=800&auto=format&fit=crop&q=80'
    ],
    tags: ['파리여행', '에펠탑', '유럽여행', '프랑스', '야경스냅'],
    feeling: '✨ 황홀함',
    location: '프랑스 파리 7구',
    createdAt: new Date(Date.now() - 1000 * 60 * 2800).toISOString(),
    likes: ['user_1', 'user_2', 'user_4'],
    bookmarks: ['user_2'],
    reposts: ['user_2'],
    commentsCount: 4,
    visibility: 'public',
    regionalScope: 'global'
  }
];

export const generateMoreMockPosts = (page: number): Post[] => {
  const seedThemes: Array<{
    authorId: string;
    authorName: string;
    authorHandle: string;
    authorAvatar: string;
    authorVerified: boolean;
    content: string;
    images?: string[];
    tags: string[];
    feeling: string;
    location: string;
    regionalScope: RegionalScope;
    likes: string[];
    bookmarks: string[];
    reposts: string[];
  }> = [
    {
      authorId: 'user_2',
      authorName: '이지수',
      authorHandle: 'jisoo_lens',
      authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
      authorVerified: true,
      content: `강원도 양양 서핑 비치에서 마주한 노을 🌅 시원한 파도 소리와 붉게 물드는 하늘이 마음을 편안하게 해주네요. 다음 주에도 또 오고 싶어요!`,
      images: [
        'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=800&auto=format&fit=crop&q=80',
        'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=800&auto=format&fit=crop&q=80'
      ],
      tags: ['양양서핑', '노을스냅', '바다여행', '힐링여행', '감성사진'],
      feeling: '🌊 힐링',
      location: '강원도 양양군 현남면',
      regionalScope: 'province',
      likes: ['user_1', 'user_3'],
      bookmarks: ['user_1'],
      reposts: []
    },
    {
      authorId: 'user_3',
      authorName: '박서연',
      authorHandle: 'seoyeon_foodie',
      authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
      authorVerified: false,
      content: `브런치 카페에서 즐기는 아보카도 에그 베네딕트 & 핸드드립 샌드 블렌드 🥑🍳 부드러운 수란 톡 터뜨려 먹으면 입안 가득 행복이 퍼져요 ☕️`,
      images: [
        'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&auto=format&fit=crop&q=80'
      ],
      tags: ['브런치', '에그베네딕트', '홈카페', '카페스타그램', '맛집투어'],
      feeling: '😋 행복한 한입',
      location: '서울 용산구 한남동',
      regionalScope: 'city',
      likes: ['user_1', 'user_4'],
      bookmarks: ['user_4'],
      reposts: ['user_1']
    },
    {
      authorId: 'user_4',
      authorName: '정현우',
      authorHandle: 'hyunwoo_fit',
      authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
      authorVerified: false,
      content: `가을철 트레일 러닝 북한산 코스 8km 완주 🏃‍♂️⛰️ 맑은 숲 공기 마시며 능선 따라 달리는 기분은 로드 러닝과는 또 다른 짜릿한 맛이 있네요!`,
      images: [
        'https://images.unsplash.com/photo-1452626038306-9aae5e071dd3?w=800&auto=format&fit=crop&q=80'
      ],
      tags: ['트레일러닝', '북한산', '등산러닝', '오운완', '자연속으로'],
      feeling: '⛰️ 상쾌함',
      location: '서울 북한산 국립공원',
      regionalScope: 'national',
      likes: ['user_2', 'user_3'],
      bookmarks: [],
      reposts: []
    },
    {
      authorId: 'user_2',
      authorName: '이지수',
      authorHandle: 'jisoo_lens',
      authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
      authorVerified: true,
      content: `스위스 인터라켄 융프라우요흐 설경 🏔️🇨🇭 만년설 위로 부서지는 햇살과 웅장한 알프스 산맥이 주는 경이로움에 말을 잃었습니다. 세계 각지에서 온 여행자들의 미소가 가득해요.`,
      images: [
        'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?w=800&auto=format&fit=crop&q=80'
      ],
      tags: ['스위스여행', '인터라켄', '알프스', '만년설', '해외여행', '글로벌'],
      feeling: '🏔️ 웅장함',
      location: '스위스 인터라켄',
      regionalScope: 'global',
      likes: ['user_1', 'user_3', 'user_4'],
      bookmarks: ['user_3'],
      reposts: ['user_4']
    },
    {
      authorId: 'user_3',
      authorName: '박서연',
      authorHandle: 'seoyeon_foodie',
      authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
      authorVerified: false,
      content: `우리 동네 성수동 골목길 새로 오픈한 플라워 카페 🌸☕️ 은은한 꽃향기 맡으면서 커피 한 잔 마시니 동네 쉼터로 딱이네요. 이웃 주민분들께 추천해요!`,
      images: [
        'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=800&auto=format&fit=crop&q=80'
      ],
      tags: ['동네카페', '성수동카페', '플라워카페', '우리동네', '동네생활'],
      feeling: '🌸 포근함',
      location: '서울 성동구 성수동2가',
      regionalScope: 'city',
      likes: ['user_1', 'user_2'],
      bookmarks: ['user_1'],
      reposts: []
    }
  ];

  return seedThemes.map((item, idx) => ({
    id: `dynamic_post_p${page}_${idx}_${Date.now()}`,
    ...item,
    createdAt: new Date(Date.now() - (page * 24 * 60 + (idx + 1) * 180) * 60 * 1000).toISOString(),
    commentsCount: Math.floor(Math.random() * 4) + 1,
    visibility: 'public'
  }));
};

export const INITIAL_COMMENTS: Comment[] = [
  {
    id: 'comm_1',
    postId: 'post_1',
    authorId: 'user_1',
    authorName: '김민우',
    authorHandle: 'minwoo_dev',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    content: '사진 색감이 진짜 예술이네요! 어떤 필름 쓰셨나요?',
    createdAt: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
    likes: ['user_2']
  },
  {
    id: 'comm_2',
    postId: 'post_1',
    authorId: 'user_2',
    authorName: '이지수',
    authorHandle: 'jisoo_lens',
    authorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    content: '@minwoo_dev 코닥 포트라 400 사용했습니다! 노을 빛 받을 때 특히 색감이 예쁘게 나와요 😊',
    createdAt: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
    likes: ['user_1'],
    parentId: 'comm_1'
  },
  {
    id: 'comm_3',
    postId: 'post_1',
    authorId: 'user_3',
    authorName: '박서연',
    authorHandle: 'seoyeon_foodie',
    authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    content: '우와 너무 힐링돼요.. 제주도 바다 소리 생각나네요 🌊',
    audioUrl: 'https://actions.google.com/sounds/v1/water/waves_crashing_on_rocks.ogg',
    audioDuration: 5,
    createdAt: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
    likes: []
  },
  {
    id: 'comm_4',
    postId: 'post_2',
    authorId: 'user_4',
    authorName: '정현우',
    authorHandle: 'hyunwoo_fit',
    authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    content: '저도 Tailwind CSS 한 번 써보고 나서는 다른 건 손이 잘 안 가더라구요 ㅎㅎ 생산성 최고!',
    createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    likes: ['user_1']
  },
  {
    id: 'comm_5',
    postId: 'post_3',
    authorId: 'user_1',
    authorName: '김민우',
    authorHandle: 'minwoo_dev',
    authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    content: '여기 진짜 맛있어 보이네요! 지도에 저장해뒀습니다 🥐',
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    likes: ['user_3']
  }
];

export const INITIAL_STORIES: UserStory[] = [
  {
    userId: 'user_1',
    userName: '김민우',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    hasUnseen: false,
    items: [
      {
        id: 'st_my_1',
        mediaUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&auto=format&fit=crop&q=80',
        mediaType: 'image',
        caption: '오늘 새 프로젝트 셋업 완료! 개발 환경 세팅 중 ☕️💻',
        bgColor: 'from-blue-600 to-indigo-900',
        createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
        reactions: [
          {
            id: 'react_my_1',
            userId: 'user_2',
            userName: '이지수',
            userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
            emoji: '❤️',
            label: '하트',
            createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString()
          },
          {
            id: 'react_my_2',
            userId: 'user_3',
            userName: '박서연',
            userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
            emoji: '❤️',
            label: '하트',
            createdAt: new Date(Date.now() - 1000 * 60 * 20).toISOString()
          },
          {
            id: 'react_my_3',
            userId: 'user_4',
            userName: '정현우',
            userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
            emoji: '👍',
            label: '좋아요',
            createdAt: new Date(Date.now() - 1000 * 60 * 15).toISOString()
          },
          {
            id: 'react_my_4',
            userId: 'user_5',
            userName: '강다은',
            userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
            emoji: '👍',
            label: '좋아요',
            createdAt: new Date(Date.now() - 1000 * 60 * 12).toISOString()
          },
          {
            id: 'react_my_5',
            userId: 'user_6',
            userName: '최승현',
            userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
            emoji: '😂',
            label: '웃음',
            createdAt: new Date(Date.now() - 1000 * 60 * 8).toISOString()
          },
          {
            id: 'react_my_6',
            userId: 'user_7',
            userName: '윤아린',
            userAvatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=200&auto=format&fit=crop&q=80',
            emoji: '🔥',
            label: '불꽃',
            createdAt: new Date(Date.now() - 1000 * 60 * 5).toISOString()
          },
          {
            id: 'react_my_7',
            userId: 'user_8',
            userName: '송민재',
            userAvatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&auto=format&fit=crop&q=80',
            emoji: '😍',
            label: '반함',
            createdAt: new Date(Date.now() - 1000 * 60 * 2).toISOString()
          },
          {
            id: 'react_my_8',
            userId: 'user_9',
            userName: '한지민',
            userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
            emoji: '👏',
            label: '박수',
            createdAt: new Date(Date.now() - 1000 * 60 * 1).toISOString()
          }
        ],
        viewers: [
          {
            userId: 'user_2',
            userName: '이지수',
            userHandle: 'jisoo_lens',
            userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
            viewedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
            reactionEmoji: '🔥',
            watchDurationSeconds: 4.8,
            completionRate: 96,
            deviceType: 'mobile'
          },
          {
            userId: 'user_3',
            userName: '박서연',
            userHandle: 'seoyeon_foodie',
            userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
            viewedAt: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
            reactionEmoji: '❤️',
            watchDurationSeconds: 5.0,
            completionRate: 100,
            deviceType: 'mobile'
          },
          {
            userId: 'user_4',
            userName: '정현우',
            userHandle: 'hyunwoo_fit',
            userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
            viewedAt: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
            reactionEmoji: '👏',
            watchDurationSeconds: 3.4,
            completionRate: 68,
            deviceType: 'desktop'
          }
        ]
      }
    ]
  },
  {
    userId: 'user_2',
    userName: '이지수',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    hasUnseen: true,
    items: [
      {
        id: 'st_1',
        mediaUrl: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?w=800&auto=format&fit=crop&q=80',
        mediaType: 'image',
        caption: '이탈리아 친퀘테레 골목길 풍경 🇮🇹 햇살이 눈부셔요',
        bgColor: 'from-amber-600 to-rose-700',
        bgm: PRESET_STORY_BGMS[1], // Sunny Morning Melody
        filterId: 'warm',
        textOverlays: [
          {
            id: 'txt_s1',
            text: 'Cinque Terre 🇮🇹',
            x: 50,
            y: 25,
            color: '#ffffff',
            styleType: 'badge',
            fontSize: 'xl'
          }
        ],
        stickerOverlays: [
          {
            id: 'stk_s1_1',
            content: 'VIBE ✨',
            type: 'badge',
            x: 80,
            y: 16,
            scale: 1,
            rotation: 6
          }
        ],
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
        reactions: [
          {
            id: 'react_st1_1',
            userId: 'user_1',
            userName: '김민우',
            userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
            emoji: '❤️',
            label: '하트',
            createdAt: new Date(Date.now() - 1000 * 60 * 55).toISOString()
          },
          {
            id: 'react_st1_2',
            userId: 'user_3',
            userName: '박서연',
            userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
            emoji: '👍',
            label: '좋아요',
            createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString()
          },
          {
            id: 'react_st1_3',
            userId: 'user_4',
            userName: '정현우',
            userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
            emoji: '🔥',
            label: '불꽃',
            createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString()
          },
          {
            id: 'react_st1_4',
            userId: 'user_5',
            userName: '강다은',
            userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80',
            emoji: '😂',
            label: '웃음',
            createdAt: new Date(Date.now() - 1000 * 60 * 20).toISOString()
          }
        ],
        viewers: [
          {
            userId: 'user_3',
            userName: '박서연',
            userHandle: 'seoyeon_foodie',
            userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
            viewedAt: new Date(Date.now() - 1000 * 60 * 50).toISOString()
          },
          {
            userId: 'user_4',
            userName: '정현우',
            userHandle: 'hyunwoo_fit',
            userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
            viewedAt: new Date(Date.now() - 1000 * 60 * 35).toISOString()
          }
        ]
      },
      {
        id: 'st_2',
        mediaUrl: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80',
        mediaType: 'image',
        caption: '자연이 주는 위로 🌲 조용히 걷기 좋은 날',
        bgColor: 'from-emerald-700 to-teal-900',
        createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
        viewers: [
          {
            userId: 'user_3',
            userName: '박서연',
            userHandle: 'seoyeon_foodie',
            userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
            viewedAt: new Date(Date.now() - 1000 * 60 * 20).toISOString()
          }
        ]
      }
    ]
  },
  {
    userId: 'user_3',
    userName: '박서연',
    userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    hasUnseen: true,
    items: [
      {
        id: 'st_3',
        mediaUrl: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800&auto=format&fit=crop&q=80',
        mediaType: 'image',
        caption: '오늘 구운 홈메이드 딸기 초콜릿 케이크 🍓🎂 달콤한 하루 되세요!',
        bgColor: 'from-pink-600 to-purple-800',
        bgm: PRESET_STORY_BGMS[2], // Spring Garden Whisper
        filterId: 'dreamy',
        textOverlays: [
          {
            id: 'txt_s3',
            text: 'Homemade Cake 🍰',
            x: 50,
            y: 30,
            color: '#ffffff',
            styleType: 'highlight',
            fontSize: 'lg'
          }
        ],
        stickerOverlays: [
          {
            id: 'stk_s3_1',
            content: 'YUMMY 🥐',
            type: 'badge',
            x: 78,
            y: 18,
            scale: 1,
            rotation: -5
          },
          {
            id: 'stk_s3_2',
            content: '💖',
            type: 'emoji',
            x: 22,
            y: 28,
            scale: 1.2
          }
        ],
        createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
        viewers: [
          {
            userId: 'user_2',
            userName: '이지수',
            userHandle: 'jisoo_lens',
            userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
            viewedAt: new Date(Date.now() - 1000 * 60 * 40).toISOString()
          }
        ]
      }
    ]
  },
  {
    userId: 'user_4',
    userName: '정현우',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    hasUnseen: false,
    items: [
      {
        id: 'st_4',
        mediaUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&auto=format&fit=crop&q=80',
        mediaType: 'image',
        caption: '퇴근 후 하체 루틴 클리어 💥🔥 오늘도 불태웠다',
        bgColor: 'from-blue-700 to-indigo-950',
        createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
        viewers: [
          {
            userId: 'user_1',
            userName: '김민우',
            userHandle: 'minwoo_dev',
            userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
            viewedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString()
          },
          {
            userId: 'user_2',
            userName: '이지수',
            userHandle: 'jisoo_lens',
            userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
            viewedAt: new Date(Date.now() - 1000 * 60 * 100).toISOString()
          }
        ]
      }
    ]
  }
];

export const INITIAL_MESSAGES: Message[] = [
  {
    id: 'msg_1',
    senderId: 'user_2',
    receiverId: 'user_1',
    content: '민우님 안녕하세요! 지난번 공유해주신 개발 팁 글 잘 봤습니다 🙏',
    createdAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
    isRead: true
  },
  {
    id: 'msg_2',
    senderId: 'user_1',
    receiverId: 'user_2',
    content: '안녕하세요 지수님! 도움 되셨다니 기쁩니다 ㅎㅎ 사진 피드도 항상 잘 보고 있어요!',
    createdAt: new Date(Date.now() - 1000 * 60 * 110).toISOString(),
    isRead: true
  },
  {
    id: 'msg_3',
    senderId: 'user_2',
    receiverId: 'user_1',
    content: '감사합니다! 다음에 테크 컨퍼런스나 밋업 있으면 같이 가요 ✨',
    createdAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
    isRead: false
  },
  {
    id: 'msg_3_1',
    senderId: 'user_2',
    receiverId: 'user_1',
    content: '혹시 이번 주말에 서울 코엑스 IT 박람회 가시나요? 티켓 2장이 생겨서요! 🎟️',
    createdAt: new Date(Date.now() - 1000 * 60 * 10).toISOString(),
    isRead: false
  },
  {
    id: 'msg_4',
    senderId: 'user_3',
    receiverId: 'user_1',
    content: '민우님 혹시 성수동 카페 추천 필요하시면 언제든 말씀해주세요 🥐☕️',
    createdAt: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
    isRead: true
  },
  {
    id: 'msg_5',
    senderId: 'user_3',
    receiverId: 'user_1',
    content: '오늘 새로 오픈한 성수 베이커리 다녀왔는데 소금빵 맛이 대박이에요! 사진 피드에도 올렸어요 🥨',
    createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    isRead: false
  },
  {
    id: 'msg_6',
    senderId: 'user_4',
    receiverId: 'user_1',
    content: '민우님 안녕하세요! 피드에 올리신 운동 글 보고 동기부여 많이 받고 있습니다 💪',
    createdAt: new Date(Date.now() - 1000 * 60 * 90).toISOString(),
    isRead: false
  },
  {
    id: 'msg_7',
    senderId: 'user_4',
    receiverId: 'user_1',
    content: '혹시 평소에 복근 운동 루틴 어떤 순서로 진행하시는지 여쭤봐도 될까요? 🔥',
    createdAt: new Date(Date.now() - 1000 * 60 * 20).toISOString(),
    isRead: false
  }
];

export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'notif_1',
    recipientId: 'user_1',
    actorId: 'user_2',
    actorName: '이지수',
    actorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    type: 'like',
    postId: 'post_2',
    content: '회원님의 게시물을 좋아합니다: "개발자 여러분, 요즘 가장 선호하는..."',
    createdAt: new Date(Date.now() - 1000 * 60 * 15).toISOString(),
    isRead: false
  },
  {
    id: 'notif_2',
    recipientId: 'user_1',
    actorId: 'user_4',
    actorName: '정현우',
    actorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80',
    type: 'comment',
    postId: 'post_2',
    content: '댓글을 남겼습니다: "저도 Tailwind CSS 한 번 써보고 나서는..."',
    createdAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    isRead: false
  },
  {
    id: 'notif_3',
    recipientId: 'user_1',
    actorId: 'user_3',
    actorName: '박서연',
    actorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80',
    type: 'follow',
    content: '회원님을 팔로우하기 시작했습니다.',
    createdAt: new Date(Date.now() - 1000 * 60 * 140).toISOString(),
    isRead: true
  },
  {
    id: 'notif_4',
    recipientId: 'user_1',
    actorId: 'user_2',
    actorName: '이지수',
    actorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
    type: 'mention',
    postId: 'post_1',
    content: '댓글에서 회원님을 언급했습니다: "@minwoo_dev 코닥 포트라 400 사용했습니다!"',
    createdAt: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
    isRead: true
  }
];

export const TRENDING_TOPICS: TrendingTopic[] = [
  {
    id: 't_1',
    tag: 'AI개발',
    category: '테크 & 개발',
    categoryType: 'tech',
    postCount: 24800,
    isHot: true,
    description: '최신 거대언어모델(LLM)과 프론트엔드 연동 트렌드'
  },
  {
    id: 't_2',
    tag: '오운완',
    category: '스포츠 & 헬스',
    categoryType: 'sports',
    postCount: 18900,
    isHot: true,
    description: '오늘 운동 완료! 러닝, 헬스, 필라테스 인증 릴레이'
  },
  {
    id: 't_3',
    tag: '실시간이슈',
    category: '뉴스 & 시사',
    categoryType: 'news',
    postCount: 16500,
    isHot: true,
    description: '국내외 주요 IT 테크 컨퍼런스 및 신기술 발표 뉴스'
  },
  {
    id: 't_4',
    tag: '성수동맛집',
    category: '푸드 & 미식',
    categoryType: 'food',
    postCount: 9800,
    isHot: true,
    description: '성수동 팝업스토어 및 로컬 베이커리/브런치 가이드'
  },
  {
    id: 't_5',
    tag: '사이드프로젝트',
    category: '테크 & 커리어',
    categoryType: 'tech',
    postCount: 8400,
    isHot: false,
    description: '주말 런칭 프로젝트 및 오픈소스 개발자 커뮤니티'
  },
  {
    id: 't_6',
    tag: '제주도여행',
    category: '여행 & 풍경',
    categoryType: 'travel',
    postCount: 7540,
    isHot: false,
    description: '서귀포 올레길과 애월 해변 노을 스냅 명소'
  },
  {
    id: 't_7',
    tag: '트레일러닝',
    category: '스포츠 & 아웃도어',
    categoryType: 'sports',
    postCount: 6800,
    isHot: false,
    description: '북한산과 청계산 주말 트레일 러닝 크루 코스'
  },
  {
    id: 't_8',
    tag: '홈베이킹',
    category: '푸드 & 라이프',
    categoryType: 'food',
    postCount: 6200,
    isHot: false,
    description: '바스크 치즈케이크와 사워도우 홈카페 레시피'
  },
  {
    id: 't_9',
    tag: '데스크테리어',
    category: '라이프 & 홈',
    categoryType: 'lifestyle',
    postCount: 4890,
    isHot: false,
    description: '미니멀 원목 데스크와 4K 모니터 홈오피스 셋업'
  },
  {
    id: 't_10',
    tag: '주말영화추천',
    category: '엔터테인먼트',
    categoryType: 'entertainment',
    postCount: 4320,
    isHot: false,
    description: 'OTT 신작 SF/스릴러 영화 및 다큐멘터리 리뷰'
  }
];

export const PRESET_POST_PHOTOS = [
  'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&auto=format&fit=crop&q=80'
];

export const PRESET_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=300&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517849845537-4d257902454a?w=300&auto=format&fit=crop&q=80'
];

export const PRESET_BANNERS = [
  {
    name: '모던 그라디언트',
    url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80'
  },
  {
    name: '대자연 & 풍경',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=1200&auto=format&fit=crop&q=80'
  },
  {
    name: '아늑한 카페',
    url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1200&auto=format&fit=crop&q=80'
  },
  {
    name: '피트니스 & 에너지',
    url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=1200&auto=format&fit=crop&q=80'
  },
  {
    name: '도시 야경 & 건축',
    url: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?w=1200&auto=format&fit=crop&q=80'
  },
  {
    name: '감성 바다 & 노을',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=80'
  }
];

export interface InterestCategory {
  category: string;
  icon: string;
  tags: string[];
}

export const POPULAR_INTEREST_CATEGORIES: InterestCategory[] = [
  {
    category: '테크 & 개발',
    icon: '💻',
    tags: ['React & Next.js', 'AI 인터페이스', 'TypeScript', '오픈소스', '스타트업', 'UI/UX 디자인', '모바일 앱']
  },
  {
    category: '사진 & 예술',
    icon: '📸',
    tags: ['필름 사진', '풍경 출사', '전시회 관람', '라이카 & 렌즈', '디지털 드로잉', '건축 감상', 'LP & 바이닐']
  },
  {
    category: '맛집 & 카페',
    icon: '🥐',
    tags: ['스페셜티 커피', '성수 디저트 투어', '홈베이킹', '파인다이닝', '핸드드립', '브런치 맛집', '와인 페어링']
  },
  {
    category: '운동 & 건강',
    icon: '🏃',
    tags: ['오운완', '크로스핏', '마라톤 10K', '클라이밍', '요가 & 필라테스', '홈트레이닝', '고단백 식단']
  },
  {
    category: '여행 & 아웃도어',
    icon: '✈️',
    tags: ['도쿄 & 제주 여행', '캠핑 & 차박', '백패킹', '국내 소도시 탐방', '로드트립', '바다 서핑']
  },
  {
    category: '문화 & 라이프',
    icon: '📚',
    tags: ['독서 & 서평', '영화 감상', '재즈 & 인디음악', '식물 키우기', '미니멀라이프', '보드게임']
  }
];

export const PRESET_FEATURED_PHOTOS = [
  'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800&auto=format&fit=crop&q=80'
];

export interface PresetVideo {
  id: string;
  title: string;
  category: string;
  videoUrl: string;
  thumbnailUrl: string;
  duration: string;
}

export const PRESET_POST_VIDEOS: PresetVideo[] = [
  {
    id: 'vid_1',
    title: '자연 & 캠핑 불멍',
    category: '여행 & 자연',
    videoUrl: '/videos/sample_nature.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80',
    duration: '0:15'
  },
  {
    id: 'vid_2',
    title: '신주쿠 도시 야경 타임랩스',
    category: '여행 & 도시',
    videoUrl: '/videos/sample_tokyo.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=600&auto=format&fit=crop&q=80',
    duration: '0:15'
  },
  {
    id: 'vid_3',
    title: '오운완 & 트레이닝',
    category: '운동 & 피트니스',
    videoUrl: '/videos/sample_fitness.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600&auto=format&fit=crop&q=80',
    duration: '0:15'
  },
  {
    id: 'vid_4',
    title: '해안도로 드라이브 & 로드트립',
    category: '여행 & 드라이브',
    videoUrl: '/videos/sample_drive.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=600&auto=format&fit=crop&q=80',
    duration: '0:20'
  },
  {
    id: 'vid_5',
    title: '익스트림 스포츠 & 서핑',
    category: '스포츠 & 레저',
    videoUrl: '/videos/sample_sports.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=600&auto=format&fit=crop&q=80',
    duration: '0:15'
  }
];

