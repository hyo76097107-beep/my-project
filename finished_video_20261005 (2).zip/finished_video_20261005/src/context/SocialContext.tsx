import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  User,
  Post,
  PostMediaItem,
  Comment,
  UserStory,
  StoryItem,
  StoryViewer,
  StoryReaction,
  StoryBgm,
  StoryDraft,
  StoryTextOverlay,
  StoryStickerOverlay,
  Message,
  MessageReplyInfo,
  Notification,
  ActiveTab,
  PollOption,
  AuthMode,
  ScheduledPost,
  RegionalScope,
  ThemeMode,
  SystemThemeNotice,
  DatabaseTableKey,
  FullDatabaseBackup,
  SpamFilterSettings,
  SpamCheckResult,
  SpamFilterAction,
  SignupAuthConfig,
  SignupVerificationMethod,
  SmsDbRecord,
  SmsDbStats,
  SmsVerificationStatus,
  SmsProviderType,
  SmsApiConfig,
  ApiKeyRecord,
  KickedUserRecord
} from '../types';
import {
  INITIAL_USERS,
  INITIAL_POSTS,
  INITIAL_COMMENTS,
  INITIAL_STORIES,
  INITIAL_MESSAGES,
  INITIAL_NOTIFICATIONS
} from '../data/mockData';
import { INITIAL_STORY_DRAFTS } from '../data/storyDraftData';
import { formatScheduledDateTime } from '../utils/formatters';
import {
  DEFAULT_SPAM_SETTINGS,
  DEFAULT_SPAM_KEYWORDS,
  checkSpam
} from '../utils/spamFilter';
import { realtimeSync } from '../services/realtimeSync';

export interface ToastInfo {
  id: string;
  message: string;
  type: 'success' | 'info' | 'error';
  position?: 'top' | 'bottom';
}

interface SocialContextType {
  currentUser: User;
  users: User[];
  kickedUsers: KickedUserRecord[];
  authNotice: {
    type: 'kicked' | 'banned';
    title: string;
    reason: string;
    date?: string;
    by?: string;
    handle?: string;
  } | null;
  dismissAuthNotice: () => void;
  posts: Post[];
  deletedPostIds: string[];
  comments: Comment[];
  stories: UserStory[];
  messages: Message[];
  notifications: Notification[];
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  activeTag: string | null;
  setActiveTag: (tag: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  viewingUserId: string | null;
  setViewingUserId: (id: string | null) => void;
  
  // Authentication & Session
  isAuthenticated: boolean;
  login: (identifier: string, password?: string) => { success: boolean; error?: string };
  loginWithEmailCode: (email: string, code: string) => Promise<{ success: boolean; error?: string }>;
  signup: (data: {
    name: string;
    handle: string;
    email: string;
    emailVerified: boolean;
    phoneNumber: string;
    phoneVerified: boolean;
    password: string;
    location: string;
    avatar?: string;
    bio?: string;
    role?: string;
    interests?: string[];
    birthdate?: string;
    isOver14Confirmed?: boolean;
  }) => { success: boolean; error?: string };
  terminateSession: (notice?: string) => void;
  sendSmsVerificationCode: (phoneNumber: string) => Promise<{
    success: boolean;
    isRealSmsSent?: boolean;
    provider?: string;
    error?: string;
    message?: string;
    simulatedCode?: string;
    smsText?: string;
  }>;
  verifySmsCode: (phoneNumber: string, inputCode: string) => Promise<{
    success: boolean;
    error?: string;
    message?: string;
  }>;
  smsGatewayInfo: {
    configured: boolean;
    provider: string;
    senderNumber: string | null;
  };
  refreshSmsGatewayStatus: () => Promise<void>;

  // SMS API Configuration (CoolSMS, Aligo, Twilio, NaverSENS, etc.)
  smsApiConfig: SmsApiConfig | null;
  isLoadingSmsConfig: boolean;
  fetchSmsApiConfig: () => Promise<void>;
  updateSmsApiConfig: (config: Partial<SmsApiConfig>) => Promise<{ success: boolean; message: string; error?: string }>;
  resetSmsApiConfig: () => Promise<{ success: boolean; message: string }>;
  testSmsApiConnection: (phoneNumber: string, customMessage?: string) => Promise<{ success: boolean; provider: string; error?: string }>;

  // SMS Verification Database (DB) Records & Management
  smsDbRecords: SmsDbRecord[];
  smsDbStats: SmsDbStats | null;
  isLoadingSmsDb: boolean;
  fetchSmsDbRecords: (search?: string, status?: string) => Promise<void>;
  insertSmsDbRecord: (data: {
    phoneNumber: string;
    code?: string;
    status?: SmsVerificationStatus;
    provider?: SmsProviderType;
    notes?: string;
    expiresInMinutes?: number;
  }) => Promise<{ success: boolean; message: string; record?: SmsDbRecord; error?: string }>;
  verifySmsDbRecordManual: (id: string) => Promise<{ success: boolean; message: string; error?: string }>;
  deleteSmsDbRecord: (id: string) => Promise<{ success: boolean; message: string; error?: string }>;
  clearSmsDbRecords: () => Promise<{ success: boolean; message: string; error?: string }>;

  // Email 6-digit Code Verification
  sendEmailVerificationCode: (email: string, purpose?: string) => Promise<{
    success: boolean;
    isRealEmailSent?: boolean;
    provider?: string;
    error?: string;
    message?: string;
    simulatedCode?: string;
    emailSubject?: string;
    emailHtml?: string;
  }>;
  verifyEmailCode: (email: string, inputCode: string) => Promise<{
    success: boolean;
    error?: string;
    message?: string;
  }>;
  emailGatewayInfo: {
    configured: boolean;
    provider: string;
    senderEmail: string | null;
  };
  refreshEmailGatewayStatus: () => Promise<void>;

  // Sign-up Verification Policy (Super Admin Configurable)
  signupAuthConfig: SignupAuthConfig;
  updateSignupAuthConfig: (newConfig: Partial<SignupAuthConfig>) => void;

  logout: () => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  authModalMode: AuthMode;
  setAuthModalMode: (mode: AuthMode) => void;
  openAuthModal: (mode?: AuthMode) => void;
  closeAuthModal: () => void;

  // Find ID & Reset Password Methods
  findUserIdentifier: (
    name: string,
    contact: string,
    type: 'phone' | 'email'
  ) => {
    success: boolean;
    user?: {
      id: string;
      name: string;
      handle: string;
      email: string;
      phoneNumber?: string;
      joinedDate?: string;
      createdAt?: string;
    };
    error?: string;
  };
  sendResetPasswordCode: (
    identifier: string,
    method: 'sms' | 'email'
  ) => Promise<{
    success: boolean;
    user?: User;
    target?: string;
    isRealSent?: boolean;
    simulatedCode?: string;
    message?: string;
    error?: string;
  }>;
  verifyResetPasswordCode: (
    target: string,
    code: string,
    method: 'sms' | 'email'
  ) => Promise<{
    success: boolean;
    message?: string;
    error?: string;
  }>;
  resetUserPassword: (
    userId: string,
    newPassword: string
  ) => Promise<{
    success: boolean;
    message: string;
    error?: string;
  }>;

  // Signup Info Edit Modal
  isEditSignupInfoModalOpen: boolean;
  openEditSignupInfoModal: () => void;
  closeEditSignupInfoModal: () => void;
  updateSignupInfo: (data: {
    name: string;
    handle: string;
    email: string;
    emailVerified?: boolean;
    phoneNumber?: string;
    phoneVerified?: boolean;
    password?: string;
    location: string;
    role?: string;
    bio?: string;
    avatar?: string;
    interests?: string[];
  }) => { success: boolean; error?: string };

  // Toast Notification
  toast: ToastInfo | null;
  showToast: (
    message: string,
    type?: 'success' | 'info' | 'error',
    position?: 'top' | 'bottom'
  ) => void;

  // Post Actions
  scheduledPosts: ScheduledPost[];
  createPost: (postData: {
    content: string;
    images?: string[];
    video?: string;
    videoThumbnail?: string;
    mediaItems?: PostMediaItem[];
    tags?: string[];
    pollQuestion?: string;
    pollOptions?: string[];
    feeling?: string;
    location?: string;
    bgm?: StoryBgm;
    visibility?: 'public' | 'followers';
    regionalScope?: RegionalScope;
    scheduledAt?: string;
  }) => void;
  schedulePost: (postData: {
    content: string;
    images?: string[];
    video?: string;
    videoThumbnail?: string;
    mediaItems?: PostMediaItem[];
    tags?: string[];
    pollQuestion?: string;
    pollOptions?: string[];
    feeling?: string;
    location?: string;
    bgm?: StoryBgm;
    visibility?: 'public' | 'followers';
    regionalScope?: RegionalScope;
    scheduledAt: string;
  }) => void;
  cancelScheduledPost: (scheduledPostId: string) => void;
  publishScheduledPostNow: (scheduledPostId: string) => void;
  updatePost: (
    postId: string,
    updatedData: {
      content: string;
      images?: string[];
      video?: string;
      videoThumbnail?: string;
      mediaItems?: PostMediaItem[];
      tags?: string[];
      feeling?: string;
      location?: string;
      bgm?: StoryBgm | null;
      visibility?: 'public' | 'followers';
      regionalScope?: RegionalScope;
    }
  ) => void;
  deletePost: (postId: string) => void;
  toggleLike: (postId: string) => void;
  simulateIncomingLike: (targetPostId?: string) => void;
  toggleBookmark: (postId: string) => void;
  clearAllBookmarks: () => void;
  toggleRepost: (postId: string) => void;
  votePoll: (postId: string, optionId: string) => void;
  
  // Comment Actions
  addComment: (postId: string, content: string, parentId?: string, audioUrl?: string, audioDuration?: number) => void;
  toggleCommentLike: (commentId: string) => void;
  
  // Story Actions
  activeStoryIndex: number | null;
  activeStoryUser: UserStory | null;
  openStoryViewer: (userStory: UserStory) => void;
  closeStoryViewer: () => void;
  createStory: (
    mediaUrl: string,
    caption?: string,
    bgColor?: string,
    bgm?: StoryBgm,
    filterId?: string,
    textOverlays?: StoryTextOverlay[],
    stickerOverlays?: StoryStickerOverlay[],
    mediaType?: 'image' | 'video'
  ) => void;
  recordStoryItemView: (storyUserId: string, storyItemId: string) => void;
  simulateFriendViewStory: (storyItemId: string) => void;
  reactToStory: (storyUserId: string, storyItemId: string, emoji: string, emojiLabel?: string) => void;
  simulateFriendReactStory: (storyItemId: string, chosenEmoji?: string) => void;
  storyDrafts: StoryDraft[];
  saveStoryDraft: (
    mediaUrl: string,
    caption?: string,
    bgColor?: string,
    bgm?: StoryBgm,
    draftId?: string,
    filterId?: string,
    textOverlays?: StoryTextOverlay[],
    stickerOverlays?: StoryStickerOverlay[],
    mediaType?: 'image' | 'video'
  ) => string;
  deleteStoryDraft: (id: string) => void;
  clearAllStoryDrafts: () => void;
  isCreateStoryOpen: boolean;
  selectedDraftForEdit: StoryDraft | null;
  openCreateStoryModal: (initialDraft?: StoryDraft | null) => void;
  closeCreateStoryModal: () => void;
  setSelectedDraftForEdit: (draft: StoryDraft | null) => void;
  
  // User Actions
  switchUser: (userId: string) => void;
  toggleFollow: (targetUserId: string, targetName?: string, targetHandle?: string) => void;
  updateProfile: (updatedData: Partial<User>) => void;
  
  // Admin User Management Actions
  deleteUser: (userId: string, reason?: string) => { success: boolean; error?: string };
  restoreUser: (userId: string) => { success: boolean; error?: string };
  toggleBanUser: (userId: string, reason?: string) => { success: boolean; error?: string };
  resetUsersToInitial: () => void;
  toggleBlockPost: (postId: string, reason?: string) => { success: boolean; isBlocked?: boolean };

  // Super Admin Database Master Authentication & Operations
  isSuperAdminDbUnlocked: boolean;
  unlockSuperAdminDatabase: (password?: string, silent?: boolean) => { success: boolean; error?: string };
  lockSuperAdminDatabase: (silent?: boolean) => void;
  apiKeysRecords: ApiKeyRecord[];
  updateDatabaseRecord: (
    table: DatabaseTableKey,
    id: string,
    updatedData: any
  ) => { success: boolean; error?: string };
  insertDatabaseRecord: (
    table: DatabaseTableKey,
    newRecord: any
  ) => { success: boolean; error?: string };
  deleteDatabaseRecord: (
    table: DatabaseTableKey,
    id: string
  ) => { success: boolean; error?: string };
  replaceDatabaseTable: (
    table: DatabaseTableKey,
    newRecords: any[]
  ) => { success: boolean; error?: string };
  importFullDatabase: (
    backup: Partial<FullDatabaseBackup['tables']>
  ) => { success: boolean; error?: string };
  resetFullDatabaseToInitial: () => void;
  getFullDatabaseBackup: () => FullDatabaseBackup;
  
  // Message Actions
  activeChatUserId: string | null;
  setActiveChatUserId: (userId: string | null) => void;
  sendMessage: (
    receiverId: string,
    content: string,
    mediaUrl?: string,
    replyTo?: MessageReplyInfo,
    isForwarded?: boolean
  ) => void;
  markConversationAsRead: (partnerId: string) => void;
  markMessageAsRead: (messageId: string) => void;
  markAllMessagesAsRead: () => void;
  toggleStarMessage: (messageId: string) => void;
  simulateIncomingMessage: () => void;
  
  // Notification Actions
  unreadNotificationsCount: number;
  unreadMessagesCount: number;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  deleteNotification: (id: string) => void;
  deleteAllNotifications: () => void;

  // Topic / Trend Subscription Actions
  followedTopics: string[];
  toggleFollowTopic: (topicTag: string) => void;
  isFollowingTopic: (topicTag: string) => boolean;
  
  // Theme
  themeMode: ThemeMode;
  isDarkMode: boolean;
  systemPrefersDark: boolean;
  setThemeMode: (mode: ThemeMode) => void;
  toggleDarkMode: () => void;
  systemThemeNotice: SystemThemeNotice | null;
  dismissSystemThemeNotice: () => void;
  triggerSystemThemeNotice: (mode: 'light' | 'dark') => void;

  // Spam Filter Management (Super Admin)
  spamFilterSettings: SpamFilterSettings;
  updateSpamFilterSettings: (newSettings: Partial<SpamFilterSettings>) => void;
  addSpamKeywords: (keywords: string[]) => { addedCount: number; duplicateCount: number };
  removeSpamKeyword: (keyword: string) => void;
  resetSpamKeywordsToDefault: () => void;
  clearAllSpamKeywords: () => void;
  resetSpamStats: () => void;
  runSpamCheck: (text: string, scope?: 'posts' | 'comments' | 'messages' | 'stories') => SpamCheckResult;
}

export const DEFAULT_SIGNUP_AUTH_CONFIG: SignupAuthConfig = {
  verificationMethod: 'sms', // Default: Phone SMS 6-digit verification
  allowEmailLogin: false,
  codeExpirationMinutes: 3,
  updatedAt: new Date().toISOString(),
  updatedBy: '시스템 관리자'
};

const SocialContext = createContext<SocialContextType | undefined>(undefined);

export const SocialProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. System Theme Realtime Detection
  const [systemPrefersDark, setSystemPrefersDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.matchMedia) {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // System Theme Notification banner state
  const [systemThemeNotice, setSystemThemeNotice] = useState<SystemThemeNotice | null>(null);

  const dismissSystemThemeNotice = () => {
    setSystemThemeNotice(null);
  };

  const triggerSystemThemeNotice = (mode: 'light' | 'dark') => {
    const id = `sys_theme_${Date.now()}`;
    const message = '시스템 설정에 따라 테마가 변경되었습니다.';
    setSystemThemeNotice({
      id,
      message,
      mode,
      timestamp: Date.now()
    });

    // Automatically auto-dismiss after 4.5 seconds
    setTimeout(() => {
      setSystemThemeNotice((prev) => (prev?.id === id ? null : prev));
    }, 4500);
  };

  // 2. User Theme Preference ('system' | 'light' | 'dark')
  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('social_theme_mode');
    if (saved === 'system' || saved === 'light' || saved === 'dark') {
      return saved as ThemeMode;
    }
    // Backward compatibility with legacy boolean
    const legacyDark = localStorage.getItem('social_dark_mode');
    if (legacyDark !== null) {
      try {
        return JSON.parse(legacyDark) ? 'dark' : 'light';
      } catch (e) {}
    }
    return 'system'; // Default to system automatic detection
  });

  // Listen to OS/Browser system theme changes dynamically
  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    // Set initial state
    setSystemPrefersDark(mediaQuery.matches);

    const handleSystemThemeChange = (e: MediaQueryListEvent) => {
      const newPrefersDark = e.matches;
      setSystemPrefersDark(newPrefersDark);

      // Only display the prompt if the user's active setting is 'system'
      const currentSavedMode = localStorage.getItem('social_theme_mode') || 'system';
      if (currentSavedMode === 'system') {
        triggerSystemThemeNotice(newPrefersDark ? 'dark' : 'light');
      }
    };

    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handleSystemThemeChange);
      return () => mediaQuery.removeEventListener('change', handleSystemThemeChange);
    } else if ((mediaQuery as any).addListener) {
      (mediaQuery as any).addListener(handleSystemThemeChange);
      return () => (mediaQuery as any).removeListener(handleSystemThemeChange);
    }
  }, []);

  // Compute resolved dark mode
  const isDarkMode = themeMode === 'system' ? systemPrefersDark : themeMode === 'dark';

  // Apply dark mode class and data-theme to root DOM and persist state
  useEffect(() => {
    localStorage.setItem('social_theme_mode', themeMode);
    localStorage.setItem('social_dark_mode', JSON.stringify(isDarkMode));

    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      document.documentElement.setAttribute('data-theme', 'dark');
      document.documentElement.style.colorScheme = 'dark';
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.setAttribute('data-theme', 'light');
      document.documentElement.style.colorScheme = 'light';
    }
  }, [themeMode, isDarkMode]);

  // Helper to determine if a user record is currently in the kicked (force-deleted) list
  const isUserKickedRecord = (u: User, kickedList: KickedUserRecord[]): boolean => {
    if (!kickedList || kickedList.length === 0) return false;
    const cleanHandle = (u.handle || '').toLowerCase().replace(/^@/, '');
    const cleanEmail = (u.email || '').toLowerCase().trim();
    const phoneDigits = (u.phoneNumber || '').replace(/\D/g, '');
    return kickedList.some((k) => {
      if (k.id === u.id) return true;
      if (k.handle && k.handle.toLowerCase().replace(/^@/, '') === cleanHandle) return true;
      if (cleanEmail && k.email && k.email.toLowerCase().trim() === cleanEmail) return true;
      if (phoneDigits.length >= 8 && k.phoneNumber && k.phoneNumber.replace(/\D/g, '') === phoneDigits) return true;
      return false;
    });
  };

  // Anti-abuse rate limiters (가짜 활동 및 연타/매크로 어뷰징 방지)
  const lastLikeTimestamp = useRef<Map<string, number>>(new Map());
  const lastFollowTimestamp = useRef<Map<string, number>>(new Map());

  // Users State
  const [users, setUsers] = useState<User[]>(() => {
    let initialKicked: KickedUserRecord[] = [];
    try {
      const savedKicked = localStorage.getItem('social_kicked_users');
      if (savedKicked) initialKicked = JSON.parse(savedKicked);
    } catch {}

    const saved = localStorage.getItem('social_users');
    if (!saved) return INITIAL_USERS.filter((u) => !isUserKickedRecord(u, initialKicked));
    try {
      const parsed: User[] = JSON.parse(saved);
      // Ensure admin and today demo users exist if old localStorage cache is present
      const adminExists = parsed.some((u) => u.handle.toLowerCase() === 'admin');
      let combined = parsed;
      if (!adminExists) {
        const adminUser = INITIAL_USERS.find((u) => u.handle === 'admin');
        if (adminUser) {
          combined = [adminUser, ...parsed];
        }
      }
      // CRITICAL: Ensure kicked users NEVER appear in users state
      return combined
        .filter((u) => !isUserKickedRecord(u, initialKicked))
        .map((u) => {
          if (!u.signupIp) {
            const matchInit = INITIAL_USERS.find((init) => init.id === u.id || init.handle === u.handle);
            return { ...u, signupIp: matchInit?.signupIp || '211.234.120.45' };
          }
          return u;
        });
    } catch {
      return INITIAL_USERS.filter((u) => !isUserKickedRecord(u, initialKicked));
    }
  });

  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    const saved = localStorage.getItem('social_current_user_id');
    return saved ? saved : 'user_1';
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem('social_is_authenticated');
    return saved !== null ? JSON.parse(saved) : true;
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<AuthMode>('login');

  const [toast, setToast] = useState<ToastInfo | null>(null);

  const showToast = (
    message: string,
    type: 'success' | 'info' | 'error' = 'info',
    position: 'top' | 'bottom' = 'bottom'
  ) => {
    const id = `toast_${Date.now()}`;
    setToast({ id, message, type, position });
    setTimeout(() => {
      setToast((prev) => (prev?.id === id ? null : prev));
    }, 3500);
  };

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
    if (mode === 'system') {
      const currentResolved = systemPrefersDark ? '다크/밤' : '라이트/낮';
      showToast(`시스템 테마 자동 감지 모드 (${currentResolved} 테마 적용 중)`, 'info');
    } else if (mode === 'light') {
      showToast('라이트 모드 (낮 모드 ☀️)로 전환되었습니다.', 'info');
    } else {
      showToast('다크 모드 (밤 모드 🌙)로 전환되었습니다.', 'info');
    }
  };

  const toggleDarkMode = () => {
    // 3-way toggle sequence: system (자동) -> light (낮) -> dark (밤) -> system (자동)
    if (themeMode === 'system') {
      setThemeMode('light');
    } else if (themeMode === 'light') {
      setThemeMode('dark');
    } else {
      setThemeMode('system');
    }
  };

  const terminateSession = (notice?: string) => {
    setIsAuthenticated(false);
    if (typeof window !== 'undefined') {
      try {
        sessionStorage.clear();
        localStorage.setItem('social_is_authenticated', 'false');
        localStorage.removeItem('social_session_token');
        localStorage.removeItem('social_session_active');
        localStorage.removeItem('superadmin_db_session');
      } catch (e) {
        console.error('Session clearance error:', e);
      }
    }
    setIsSuperAdminDbUnlocked(false);
    if (notice) {
      showToast(notice, 'info');
    }
  };

  const openAuthModal = (mode: AuthMode = 'login') => {
    // 로그인 와중에 다시 로그인 버튼을 클릭하거나 회원가입 버튼을 클릭해도 세션이 끊어지도록 처리
    if (isAuthenticated) {
      terminateSession(
        mode === 'login'
          ? '새로운 로그인을 위해 기존 세션이 종료되었습니다.'
          : '새로운 회원가입을 위해 기존 세션이 종료되었습니다.'
      );
    }
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  // Edit Signup Info Modal State
  const [isEditSignupInfoModalOpen, setIsEditSignupInfoModalOpen] = useState<boolean>(false);
  const openEditSignupInfoModal = () => setIsEditSignupInfoModalOpen(true);
  const closeEditSignupInfoModal = () => setIsEditSignupInfoModalOpen(false);

  useEffect(() => {
    localStorage.setItem('social_is_authenticated', JSON.stringify(isAuthenticated));
  }, [isAuthenticated]);

  const currentUser = users.find((u) => u.id === currentUserId) || users[0] || INITIAL_USERS[0];

  // Navigation State
  const [activeTab, setActiveTab] = useState<ActiveTab>('feed');
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewingUserId, setViewingUserId] = useState<string | null>(null);

  // Track kicked (force deleted) users history
  const [kickedUsers, setKickedUsers] = useState<KickedUserRecord[]>(() => {
    try {
      const saved = localStorage.getItem('social_kicked_users');
      const parsed: KickedUserRecord[] = saved ? JSON.parse(saved) : [];
      return parsed.map((k) => {
        if (!k.signupIp) {
          const matchInit = INITIAL_USERS.find((init) => init.id === k.id || init.handle === k.handle);
          return { ...k, signupIp: matchInit?.signupIp || '175.197.88.12' };
        }
        return k;
      });
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('social_kicked_users', JSON.stringify(kickedUsers));
    } catch {}

    // Auto-purge any kicked user from users list
    if (kickedUsers && kickedUsers.length > 0) {
      setUsers((prev) => {
        const filtered = prev.filter((u) => !isUserKickedRecord(u, kickedUsers));
        if (filtered.length !== prev.length) {
          try {
            localStorage.setItem('social_users', JSON.stringify(filtered));
          } catch {}
          return filtered;
        }
        return prev;
      });
    }
  }, [kickedUsers]);

  // Auth notice for kicked / banned accounts
  const [authNotice, setAuthNotice] = useState<{
    type: 'kicked' | 'banned';
    title: string;
    reason: string;
    date?: string;
    by?: string;
    handle?: string;
  } | null>(null);

  const dismissAuthNotice = () => setAuthNotice(null);

  // Client IP tracking for audit and admin logging
  const [clientIp, setClientIp] = useState<string>('127.0.0.1');

  useEffect(() => {
    fetch('/api/sync/client-ip')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.ip) {
          setClientIp(data.ip);
        }
      })
      .catch(() => {});
  }, []);

  // Active security guard: check if current logged-in user is kicked or banned
  useEffect(() => {
    if (!isAuthenticated) return;

    // 1. Check kicked
    const isKicked = kickedUsers.find(
      (k) => k.id === currentUserId || (currentUser && k.handle.toLowerCase() === currentUser.handle.toLowerCase())
    );
    if (isKicked) {
      terminateSession(`강제 탈퇴 처리된 계정입니다. (사유: ${isKicked.reason || '운영 정책 위반'})`);
      setAuthNotice({
        type: 'kicked',
        title: '계정 강제 탈퇴(영구 제명) 안내',
        reason: isKicked.reason || '운영 정책 위반',
        date: isKicked.kickedAt || new Date().toISOString(),
        by: isKicked.kickedBy || '최고관리자',
        handle: isKicked.handle
      });
      setIsAuthModalOpen(true);
      return;
    }

    // 2. Check banned
    if (currentUser?.isBanned) {
      terminateSession(`서비스 이용이 정지되었습니다. (사유: ${currentUser.banReason || '운영 정책 위반'})`);
      setAuthNotice({
        type: 'banned',
        title: '서비스 이용 정지(차단) 안내',
        reason: currentUser.banReason || '운영 정책 및 커뮤니티 가이드라인 위반',
        date: currentUser.bannedAt || new Date().toISOString(),
        handle: currentUser.handle
      });
      setIsAuthModalOpen(true);
    }
  }, [currentUserId, currentUser?.isBanned, currentUser?.banReason, currentUser?.bannedAt, kickedUsers, isAuthenticated]);

  // Track deleted posts to ensure they never reappear on main page or other screens
  const [deletedPostIds, setDeletedPostIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('social_deleted_post_ids');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Helper to sanitize broken / forbidden external video URLs to local verified video assets
  const sanitizePostVideo = (p: Post): Post => {
    if (!p || !p.video) return p;
    if (typeof p.video === 'string' && p.video.includes('commondatastorage.googleapis.com')) {
      if (p.video.includes('Escapes') || p.video.includes('Bullrun') || p.id === 'post_video_2') {
        return { ...p, video: '/videos/sample_tokyo.mp4' };
      }
      return { ...p, video: '/videos/sample_fitness.mp4' };
    }
    return p;
  };

  // Posts State
  const [posts, setPosts] = useState<Post[]>(() => {
    try {
      const saved = localStorage.getItem('social_posts');
      const savedDeleted = localStorage.getItem('social_deleted_post_ids');
      const deletedList: string[] = savedDeleted ? JSON.parse(savedDeleted) : [];
      const initialPool: Post[] = saved ? JSON.parse(saved) : INITIAL_POSTS;
      return initialPool
        .map(sanitizePostVideo)
        .filter((p: Post) => !deletedList.includes(p.id) && !p.isDeleted);
    } catch {
      return INITIAL_POSTS.map(sanitizePostVideo);
    }
  });

  // Comments State
  const [comments, setComments] = useState<Comment[]>(() => {
    const saved = localStorage.getItem('social_comments');
    return saved ? JSON.parse(saved) : INITIAL_COMMENTS;
  });

  // Helper to deduplicate story items by ID to prevent duplicate React keys
  const deduplicateStories = (storyList: UserStory[]): UserStory[] => {
    if (!Array.isArray(storyList)) return [];
    return storyList.map((userStory) => {
      if (!userStory || !Array.isArray(userStory.items)) return userStory;
      const seenIds = new Set<string>();
      const uniqueItems: StoryItem[] = [];
      for (const item of userStory.items) {
        if (item && item.id && !seenIds.has(item.id)) {
          seenIds.add(item.id);
          uniqueItems.push(item);
        }
      }
      return { ...userStory, items: uniqueItems };
    });
  };

  // Stories State
  const [stories, setStories] = useState<UserStory[]>(() => {
    const saved = localStorage.getItem('social_stories');
    if (!saved) return deduplicateStories(INITIAL_STORIES);
    try {
      const parsed: UserStory[] = JSON.parse(saved);
      // Merge reactions from INITIAL_STORIES if saved stories don't have reactions
      const processed = parsed.map((userStory) => {
        const initialMatch = INITIAL_STORIES.find((init) => init.userId === userStory.userId);
        return {
          ...userStory,
          items: userStory.items.map((item) => {
            if (item.reactions && item.reactions.length > 0) return item;
            const initItem = initialMatch?.items.find((it) => it.id === item.id);
            if (initItem?.reactions && initItem.reactions.length > 0) {
              return { ...item, reactions: initItem.reactions };
            }
            // Derive from viewers if any
            if (item.viewers && item.viewers.some((v) => v.reactionEmoji)) {
              const derived = item.viewers
                .filter((v) => v.reactionEmoji)
                .map((v) => ({
                  id: `react_der_${v.userId}_${item.id}`,
                  userId: v.userId,
                  userName: v.userName,
                  userAvatar: v.userAvatar,
                  emoji: v.reactionEmoji!,
                  createdAt: v.viewedAt
                }));
              return { ...item, reactions: derived };
            }
            return item;
          })
        };
      });
      return deduplicateStories(processed);
    } catch {
      return deduplicateStories(INITIAL_STORIES);
    }
  });

  // Story Drafts State
  const [storyDrafts, setStoryDrafts] = useState<StoryDraft[]>(() => {
    const saved = localStorage.getItem('social_story_drafts');
    return saved ? JSON.parse(saved) : INITIAL_STORY_DRAFTS;
  });

  const [isCreateStoryOpen, setIsCreateStoryOpen] = useState<boolean>(false);
  const [selectedDraftForEdit, setSelectedDraftForEdit] = useState<StoryDraft | null>(null);

  const openCreateStoryModal = (initialDraft?: StoryDraft | null) => {
    if (initialDraft) {
      setSelectedDraftForEdit(initialDraft);
    } else {
      setSelectedDraftForEdit(null);
    }
    setIsCreateStoryOpen(true);
  };

  const closeCreateStoryModal = () => {
    setIsCreateStoryOpen(false);
    setSelectedDraftForEdit(null);
  };

  const [activeStoryUser, setActiveStoryUser] = useState<UserStory | null>(null);
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);

  // Messages State
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem('social_messages');
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });
  const [activeChatUserId, setActiveChatUserId] = useState<string | null>(null);

  // Helper to deduplicate notifications by ID and semantic uniqueness
  // (e.g. at most 1 follow notification per actor/recipient pair, at most 1 like notification per actor/post pair)
  const deduplicateNotifications = (notifList: Notification[]): Notification[] => {
    if (!Array.isArray(notifList) || notifList.length === 0) return [];
    const seenIds = new Set<string>();
    const seenSemanticKeys = new Set<string>();
    const result: Notification[] = [];

    for (const n of notifList) {
      if (!n || !n.id) continue;
      if (seenIds.has(n.id)) continue;

      let semanticKey = '';
      if (n.type === 'like') {
        semanticKey = `${n.recipientId}_${n.actorId}_like_${n.postId || ''}`;
      } else if (n.type === 'follow') {
        semanticKey = `${n.recipientId}_${n.actorId}_follow`;
      } else if (n.type === 'comment') {
        if (n.commentId) {
          semanticKey = `${n.recipientId}_${n.actorId}_comment_${n.postId || ''}_${n.commentId}`;
        } else {
          const timeBucket = Math.floor(new Date(n.createdAt || Date.now()).getTime() / 60000);
          semanticKey = `${n.recipientId}_${n.actorId}_comment_${n.postId || ''}_${(n.content || '').slice(0, 30)}_${timeBucket}`;
        }
      } else {
        const timeBucket = Math.floor(new Date(n.createdAt || Date.now()).getTime() / 30000);
        semanticKey = `${n.recipientId}_${n.actorId}_${n.type}_${n.content || ''}_${timeBucket}`;
      }

      if (seenSemanticKeys.has(semanticKey)) continue;

      seenIds.add(n.id);
      seenSemanticKeys.add(semanticKey);
      result.push(n);
    }
    return result;
  };

  // Notifications State
  const [notifications, setNotifications] = useState<Notification[]>(() => {
    const saved = localStorage.getItem('social_notifications');
    try {
      const initialList: Notification[] = saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
      return deduplicateNotifications(initialList);
    } catch {
      return deduplicateNotifications(INITIAL_NOTIFICATIONS);
    }
  });

  // Followed Topics / Trends State
  const [followedTopics, setFollowedTopics] = useState<string[]>(() => {
    const saved = localStorage.getItem('social_followed_topics');
    return saved ? JSON.parse(saved) : ['AI개발', '오운완'];
  });

  // Scheduled Posts State
  const [scheduledPosts, setScheduledPosts] = useState<ScheduledPost[]>(() => {
    const saved = localStorage.getItem('social_scheduled_posts');
    return saved ? JSON.parse(saved) : [];
  });

  // Spam Filter Settings State (Super Admin configurable)
  const [spamFilterSettings, setSpamFilterSettings] = useState<SpamFilterSettings>(() => {
    const saved = localStorage.getItem('social_spam_filter_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_SPAM_SETTINGS,
          ...parsed,
          targetScope: {
            ...DEFAULT_SPAM_SETTINGS.targetScope,
            ...(parsed.targetScope || {})
          },
          stats: {
            ...DEFAULT_SPAM_SETTINGS.stats,
            ...(parsed.stats || {})
          }
        };
      } catch (e) {
        return DEFAULT_SPAM_SETTINGS;
      }
    }
    return DEFAULT_SPAM_SETTINGS;
  });

  // Sign-up Verification Policy State (Super Admin Configurable)
  const [signupAuthConfig, setSignupAuthConfig] = useState<SignupAuthConfig>(() => {
    const saved = localStorage.getItem('social_signup_auth_config');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_SIGNUP_AUTH_CONFIG,
          ...parsed
        };
      } catch (e) {
        return DEFAULT_SIGNUP_AUTH_CONFIG;
      }
    }
    return DEFAULT_SIGNUP_AUTH_CONFIG;
  });

  const updateSignupAuthConfig = (newConfig: Partial<SignupAuthConfig>) => {
    setSignupAuthConfig((prev) => {
      const updated: SignupAuthConfig = {
        ...prev,
        ...newConfig,
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser?.name || '시스템 총괄 관리자'
      };
      localStorage.setItem('social_signup_auth_config', JSON.stringify(updated));
      return updated;
    });

    const labels: Record<SignupVerificationMethod, string> = {
      email: '이메일 6자리 코드 인증 필수',
      sms: 'SMS 문자메시지 휴대폰 인증 필수',
      both: '이메일 + SMS 문자 둘 다 필수 인증 (이중 인증)',
      either: '이메일 또는 휴대폰 중 택 1 인증',
      none: '인증 생략 (간편 가입 모드)'
    };

    if (newConfig.verificationMethod) {
      showToast(`회원가입 인증 수단 정책이 [${labels[newConfig.verificationMethod]}]로 변경되었습니다. 🛡️`, 'success');
    } else {
      showToast('가입 인증 정책 설정이 안전하게 저장되었습니다.', 'success');
    }
  };

  // Safe LocalStorage saving with QuotaExceededError protection
  const safeSetLocalStorage = (key: string, value: any) => {
    try {
      localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
    } catch (err: any) {
      console.warn(`[LocalStorage] Error writing key "${key}":`, err);
      // If posts exceeded quota (e.g. many attached photos), save a trimmed window of recent posts
      if (key === 'social_posts' && Array.isArray(value)) {
        try {
          const trimmed = value.slice(0, 15);
          localStorage.setItem(key, JSON.stringify(trimmed));
        } catch {
          try {
            localStorage.setItem(key, JSON.stringify(value.slice(0, 5)));
          } catch {}
        }
      }
    }
  };

  // Save to LocalStorage on changes safely
  useEffect(() => {
    safeSetLocalStorage('social_users', users);
  }, [users]);

  useEffect(() => {
    if (currentUserId) {
      safeSetLocalStorage('social_current_user_id', currentUserId);
    }
  }, [currentUserId]);

  useEffect(() => {
    safeSetLocalStorage('social_posts', posts);
  }, [posts]);

  useEffect(() => {
    safeSetLocalStorage('social_deleted_post_ids', deletedPostIds);
  }, [deletedPostIds]);

  useEffect(() => {
    safeSetLocalStorage('social_scheduled_posts', scheduledPosts);
  }, [scheduledPosts]);

  useEffect(() => {
    safeSetLocalStorage('social_spam_filter_settings', spamFilterSettings);
  }, [spamFilterSettings]);

  useEffect(() => {
    safeSetLocalStorage('social_story_drafts', storyDrafts);
  }, [storyDrafts]);

  // Automated timer for scheduled posts auto-publishing
  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      setScheduledPosts((prevScheduled) => {
        const duePosts = prevScheduled.filter((p) => new Date(p.scheduledAt).getTime() <= now);
        if (duePosts.length === 0) return prevScheduled;

        const newPublishedPosts: Post[] = duePosts.map((sp) => ({
          id: sp.id.startsWith('post_sched_') ? `post_${Date.now()}_${Math.random().toString(36).substring(2, 6)}` : sp.id,
          authorId: sp.authorId,
          authorName: sp.authorName,
          authorHandle: sp.authorHandle,
          authorAvatar: sp.authorAvatar,
          authorVerified: sp.authorVerified,
          content: sp.content,
          images: sp.images,
          video: sp.video,
          videoThumbnail: sp.videoThumbnail,
          tags: sp.tags,
          poll: sp.poll,
          feeling: sp.feeling,
          location: sp.location,
          createdAt: new Date().toISOString(),
          likes: [],
          bookmarks: [],
          reposts: [],
          commentsCount: 0,
          visibility: sp.visibility,
          scheduledAt: sp.scheduledAt
        }));

        setPosts((prevPosts) => [...newPublishedPosts, ...prevPosts]);
        showToast(
          `⏰ 예약된 게시물(${duePosts.length}개)이 지정된 시간에 자동 게시되었습니다!`,
          'success'
        );

        return prevScheduled.filter((p) => new Date(p.scheduledAt).getTime() > now);
      });
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    safeSetLocalStorage('social_comments', comments);
  }, [comments]);

  useEffect(() => {
    safeSetLocalStorage('social_stories', stories);
  }, [stories]);

  useEffect(() => {
    safeSetLocalStorage('social_messages', messages);
  }, [messages]);

  useEffect(() => {
    safeSetLocalStorage('social_notifications', notifications);
  }, [notifications]);

  useEffect(() => {
    safeSetLocalStorage('social_followed_topics', followedTopics);
  }, [followedTopics]);

  // 🔄 Real-time Multi-Device Synchronization across mobile phones & web
  useEffect(() => {
    // 1. Initial hydration from server authoritative database
    realtimeSync.fetchServerState().then((serverState) => {
      if (serverState) {
        const serverDeletedIds: string[] = Array.isArray(serverState.deletedPostIds)
          ? serverState.deletedPostIds
          : [];

        // Synchronize and union deleted post IDs
        if (serverDeletedIds.length > 0) {
          setDeletedPostIds((prev) => {
            const merged = Array.from(new Set([...prev, ...serverDeletedIds]));
            try {
              localStorage.setItem('social_deleted_post_ids', JSON.stringify(merged));
            } catch {}
            return merged;
          });
        }

        if (Array.isArray(serverState.posts) && serverState.posts.length > 0) {
          // Exclude any posts that are marked deleted or in deletedPostIds
          const currentDeleted = new Set([...deletedPostIds, ...serverDeletedIds]);
          const validPosts = serverState.posts
            .map(sanitizePostVideo)
            .filter((p: Post) => !currentDeleted.has(p.id) && !p.isDeleted);
          setPosts(validPosts);
        } else {
          // If server is brand new, seed server database with initial mock data
          const currentDeleted = new Set(deletedPostIds);
          const activePosts = posts.filter((p) => !currentDeleted.has(p.id) && !p.isDeleted);
          realtimeSync.seedServer({
            posts: activePosts,
            comments,
            messages,
            stories,
            users
          });
        }
        if (Array.isArray(serverState.comments) && serverState.comments.length > 0) {
          setComments(serverState.comments);
        }
        if (Array.isArray(serverState.messages) && serverState.messages.length > 0) {
          setMessages(serverState.messages);
        }
        if (Array.isArray(serverState.stories) && serverState.stories.length > 0) {
          setStories(deduplicateStories(serverState.stories));
        }
        if (Array.isArray(serverState.kickedUsers)) {
          setKickedUsers(serverState.kickedUsers);
        }
        if (Array.isArray(serverState.users) && serverState.users.length > 0) {
          const currentKicked = Array.isArray(serverState.kickedUsers) ? serverState.kickedUsers : kickedUsers;
          setUsers(serverState.users.filter((u: User) => !isUserKickedRecord(u, currentKicked)));
        }
        if (Array.isArray(serverState.notifications) && serverState.notifications.length > 0) {
          setNotifications((prev) => deduplicateNotifications([...serverState.notifications!, ...prev]));
        }
      }
    });

    // 2. Subscribe to real-time events (broadcasted immediately to all phones)
    const unsubscribe = realtimeSync.subscribe((event, payload) => {
      if (event === 'POST_DELETED') {
        const targetDeletedId = payload?.postId;
        const incomingDeletedIds: string[] = Array.isArray(payload?.deletedPostIds)
          ? payload.deletedPostIds
          : targetDeletedId
          ? [targetDeletedId]
          : [];

        setDeletedPostIds((prev) => {
          const merged = Array.from(new Set([...prev, ...incomingDeletedIds]));
          try {
            localStorage.setItem('social_deleted_post_ids', JSON.stringify(merged));
          } catch {}
          return merged;
        });

        if (targetDeletedId) {
          setPosts((prev) => prev.filter((p) => p.id !== targetDeletedId));
          setComments((prev) => prev.filter((c) => c.postId !== targetDeletedId));
        }
        if (payload?.posts) {
          const delSet = new Set([...deletedPostIds, ...incomingDeletedIds]);
          setPosts(payload.posts.filter((p: Post) => !delSet.has(p.id) && !p.isDeleted));
        }
        if (payload?.comments) {
          setComments(payload.comments);
        }
      } else if (
        event === 'POST_CREATED' ||
        event === 'POST_UPDATED' ||
        event === 'MEDIA_SYNC' ||
        event === 'POST_BOOKMARKED' ||
        event === 'POSTS_SYNC'
      ) {
        if (payload?.posts) {
          const delSet = new Set(deletedPostIds);
          setPosts(payload.posts.filter((p: Post) => !delSet.has(p.id) && !p.isDeleted));
        } else if (payload?.post) {
          setPosts((prev) => {
            const idx = prev.findIndex((p) => p.id === payload.post.id);
            if (idx !== -1) {
              const updated = [...prev];
              updated[idx] = { ...updated[idx], ...payload.post };
              return updated;
            }
            return [payload.post, ...prev];
          });
        }
        if (payload?.comments) {
          setComments(payload.comments);
        }
      } else if (event === 'POST_LIKED') {
        if (payload?.posts) {
          const delSet = new Set(deletedPostIds);
          setPosts(payload.posts.filter((p: Post) => !delSet.has(p.id) && !p.isDeleted));
        }
        if (payload?.comments) {
          setComments(payload.comments);
        }
        if (payload?.notification) {
          setNotifications((prev) => deduplicateNotifications([payload.notification, ...prev]));
          if (payload.notification.recipientId === currentUserId) {
            showToast(`❤️ ${payload.notification.actorName}님이 회원님의 게시물을 좋아합니다!`, 'info');
          }
        }
      } else if (event === 'COMMENT_ADDED') {
        if (payload?.comments) {
          setComments(payload.comments);
        }
        if (payload?.posts) {
          const delSet = new Set(deletedPostIds);
          setPosts(payload.posts.filter((p: Post) => !delSet.has(p.id) && !p.isDeleted));
        }
        if (payload?.notifications && Array.isArray(payload.notifications)) {
          setNotifications((prev) => deduplicateNotifications([...payload.notifications, ...prev]));
        } else if (payload?.notification) {
          setNotifications((prev) => deduplicateNotifications([payload.notification, ...prev]));
        }
        if (payload?.notification && payload.notification.recipientId === currentUserId) {
          const notifContent = payload.notification.content || '';
          showToast(`💬 ${payload.notification.actorName}님: ${notifContent}`, 'info');
        }
      } else if (event === 'COMMENT_LIKED') {
        if (payload?.comments) {
          setComments(payload.comments);
        }
        if (payload?.posts) {
          const delSet = new Set(deletedPostIds);
          setPosts(payload.posts.filter((p: Post) => !delSet.has(p.id) && !p.isDeleted));
        }
        if (payload?.notification) {
          setNotifications((prev) => deduplicateNotifications([payload.notification, ...prev]));
          if (payload.notification.recipientId === currentUserId) {
            showToast(`❤️ ${payload.notification.actorName}님이 회원님의 댓글을 좋아합니다!`, 'info');
          }
        }
      } else if (event === 'NOTIFICATION_ADDED') {
        if (payload?.notification) {
          setNotifications((prev) => deduplicateNotifications([payload.notification, ...prev]));
          if (payload.notification.recipientId === currentUserId) {
            showToast(`🔔 ${payload.notification.actorName}님으로부터 새 알림이 도착했습니다!`, 'info');
          }
        }
      } else if (
        event === 'MESSAGE_SENT' ||
        event === 'MESSAGES_READ' ||
        event === 'MESSAGE_READ' ||
        event === 'ALL_MESSAGES_READ' ||
        event === 'MESSAGE_STARRED'
      ) {
        if (payload?.messages) {
          setMessages(payload.messages);
        }
      } else if (event === 'STORY_CREATED') {
        if (payload?.stories) {
          setStories(deduplicateStories(payload.stories));
        }
      } else if (event === 'USER_UPDATED' || event === 'USER_REGISTERED') {
        if (payload?.users) {
          setUsers(payload.users);
        }
      } else if (event === 'USER_FOLLOW_TOGGLED') {
        if (Array.isArray(payload?.users) && payload.users.length > 0) {
          setUsers(payload.users);
          try {
            localStorage.setItem('social_users', JSON.stringify(payload.users));
          } catch {}
        }
        if (payload?.notification) {
          setNotifications((prev) => deduplicateNotifications([payload.notification, ...prev]));
          if (payload.notification.recipientId === currentUserId) {
            showToast(`👤 ${payload.notification.actorName}님이 회원님을 팔로우하기 시작했습니다!`, 'info');
          }
        }
      } else if (event === 'USER_KICKED') {
        const { userId, kickedRecord, kickedUsers: incomingKicked, users: updatedUsers } = payload || {};
        if (Array.isArray(incomingKicked)) {
          setKickedUsers(incomingKicked);
        } else if (kickedRecord) {
          setKickedUsers((prev) => [kickedRecord, ...prev.filter((k) => k.id !== userId)]);
        }
        if (Array.isArray(updatedUsers)) {
          setUsers(updatedUsers);
        } else if (userId) {
          setUsers((prev) => prev.filter((u) => u.id !== userId));
        }
        if (currentUserId === userId) {
          terminateSession(`최고관리자에 의해 강제 탈퇴 처리되었습니다. (사유: ${kickedRecord?.reason || '운영 정책 위반'})`);
          setAuthNotice({
            type: 'kicked',
            title: '계정 강제 탈퇴(영구 제명) 안내',
            reason: kickedRecord?.reason || '운영 정책 위반',
            date: kickedRecord?.kickedAt || new Date().toISOString(),
            by: kickedRecord?.kickedBy || '최고관리자',
            handle: kickedRecord?.handle
          });
          setIsAuthModalOpen(true);
        }
      } else if (event === 'USER_BAN_TOGGLED') {
        const { user: updatedUser, users: updatedUsers } = payload || {};
        if (Array.isArray(updatedUsers)) {
          setUsers(updatedUsers);
        } else if (updatedUser) {
          setUsers((prev) => prev.map((u) => (u.id === updatedUser.id ? updatedUser : u)));
        }
        if (updatedUser && updatedUser.id === currentUserId && updatedUser.isBanned) {
          terminateSession(`최고관리자에 의해 서비스 이용이 정지되었습니다. (사유: ${updatedUser.banReason || '운영 정책 위반'})`);
          setAuthNotice({
            type: 'banned',
            title: '서비스 이용 정지(차단) 안내',
            reason: updatedUser.banReason || '운영 정책 및 가이드라인 위반',
            date: updatedUser.bannedAt || new Date().toISOString(),
            handle: updatedUser.handle
          });
          setIsAuthModalOpen(true);
        }
      } else if (event === 'USER_RESTORED') {
        const { userId, restoredUser, kickedUsers: incomingKicked, users: updatedUsers, posts: incomingPosts, deletedPostIds: incomingDeletedPostIds } = payload || {};
        if (Array.isArray(incomingKicked)) {
          setKickedUsers(incomingKicked);
        } else if (userId) {
          setKickedUsers((prev) => prev.filter((k) => k.id !== userId));
        }
        if (Array.isArray(incomingDeletedPostIds)) {
          setDeletedPostIds(incomingDeletedPostIds);
        }
        if (Array.isArray(incomingPosts) && incomingPosts.length > 0) {
          setPosts((prev) => {
            const existingIds = new Set(prev.map((p) => p.id));
            const newPosts = incomingPosts.filter((p: Post) => !existingIds.has(p.id));
            return [...newPosts, ...prev];
          });
        }
        if (Array.isArray(updatedUsers)) {
          const currentKicked = Array.isArray(incomingKicked) ? incomingKicked : kickedUsers;
          setUsers((prev) => {
            const filteredUpdated = updatedUsers.filter((u: User) => !isUserKickedRecord(u, currentKicked));
            if (restoredUser && !filteredUpdated.some((u: User) => u.id === restoredUser.id)) {
              return [restoredUser, ...filteredUpdated];
            }
            return filteredUpdated;
          });
        } else if (restoredUser) {
          setUsers((prev) => [restoredUser, ...prev.filter((u) => u.id !== restoredUser.id)]);
        }
        if (userId === currentUserId || (restoredUser && restoredUser.id === currentUserId)) {
          showToast('회원님의 계정이 최고관리자에 의해 정상 복원되었습니다! 🎉', 'success');
          dismissAuthNotice();
        }
      }
    });

    // 3. Reconcile on window focus or mobile screen wake-up
    const handleVisibilityChange = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        realtimeSync.fetchServerState().then((state) => {
          if (state) {
            const serverDeleted: string[] = Array.isArray(state.deletedPostIds) ? state.deletedPostIds : [];
            const delSet = new Set([...deletedPostIds, ...serverDeleted]);
            if (Array.isArray(state.posts) && state.posts.length > 0) {
              setPosts((prev) => {
                const map = new Map<string, Post>();
                prev.forEach((p) => {
                  if (!delSet.has(p.id) && !p.isDeleted) {
                    map.set(p.id, p);
                  }
                });
                state.posts.forEach((p: Post) => {
                  if (!delSet.has(p.id) && !p.isDeleted) {
                    map.set(p.id, { ...(map.get(p.id) || {}), ...p });
                  }
                });
                return Array.from(map.values()).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
              });
            }
            if (Array.isArray(state.comments) && state.comments.length > 0) setComments(state.comments);
            if (Array.isArray(state.messages) && state.messages.length > 0) setMessages(state.messages);
            if (Array.isArray(state.kickedUsers)) setKickedUsers(state.kickedUsers);
            if (Array.isArray(state.users) && state.users.length > 0) {
              const currentKicked = Array.isArray(state.kickedUsers) ? state.kickedUsers : kickedUsers;
              setUsers((prev) => {
                const map = new Map<string, User>();
                prev.forEach((u) => {
                  if (!isUserKickedRecord(u, currentKicked)) {
                    map.set(u.id, u);
                  }
                });
                state.users.forEach((u: User) => {
                  if (!isUserKickedRecord(u, currentKicked)) {
                    map.set(u.id, { ...(map.get(u.id) || {}), ...u });
                  }
                });
                return Array.from(map.values());
              });
            }
          }
        });
      }
    };

    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', handleVisibilityChange);
      window.addEventListener('focus', handleVisibilityChange);
    }

    // 4. Background reconciliation ticker (every 3.5s) to guarantee zero desync on spotty mobile carrier networks
    const pollInterval = setInterval(() => {
      realtimeSync.fetchServerState().then((state) => {
        if (state) {
          const serverDeleted: string[] = Array.isArray(state.deletedPostIds) ? state.deletedPostIds : [];
          const delSet = new Set([...deletedPostIds, ...serverDeleted]);
          if (Array.isArray(state.posts) && state.posts.length > 0) {
            setPosts((prev) => {
              const map = new Map<string, Post>();
              prev.forEach((p) => {
                if (!delSet.has(p.id) && !p.isDeleted) {
                  map.set(p.id, p);
                }
              });
              let hasChanges = false;
              state.posts.forEach((p: Post) => {
                if (!delSet.has(p.id) && !p.isDeleted) {
                  const existing = map.get(p.id);
                  if (!existing) {
                    map.set(p.id, p);
                    hasChanges = true;
                  } else if (
                    (existing.likes?.length ?? 0) !== (p.likes?.length ?? 0) ||
                    existing.commentsCount !== p.commentsCount ||
                    existing.video !== p.video ||
                    (existing.videoUrls?.length ?? 0) !== (p.videoUrls?.length ?? 0) ||
                    existing.content !== p.content
                  ) {
                    map.set(p.id, { ...existing, ...p });
                    hasChanges = true;
                  }
                }
              });
              if (!hasChanges && map.size === prev.length) {
                return prev;
              }
              return Array.from(map.values()).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            });
          }
          if (Array.isArray(state.comments) && state.comments.length > 0) setComments(state.comments);
          if (Array.isArray(state.messages) && state.messages.length > 0) setMessages(state.messages);
          if (Array.isArray(state.kickedUsers)) setKickedUsers(state.kickedUsers);
          if (Array.isArray(state.users) && state.users.length > 0) {
            const currentKicked = Array.isArray(state.kickedUsers) ? state.kickedUsers : kickedUsers;
            setUsers((prev) => {
              const map = new Map<string, User>();
              prev.forEach((u) => {
                if (!isUserKickedRecord(u, currentKicked)) {
                  map.set(u.id, u);
                }
              });
              state.users.forEach((u: User) => {
                if (!isUserKickedRecord(u, currentKicked)) {
                  map.set(u.id, { ...(map.get(u.id) || {}), ...u });
                }
              });
              return Array.from(map.values());
            });
          }
        }
      });
    }, 3500);

    return () => {
      unsubscribe();
      if (typeof document !== 'undefined') {
        document.removeEventListener('visibilitychange', handleVisibilityChange);
        window.removeEventListener('focus', handleVisibilityChange);
      }
      clearInterval(pollInterval);
    };
  }, []);

  // Auth Actions
  const login = (identifier: string, password?: string): { success: boolean; error?: string } => {
    const cleanId = identifier.trim().toLowerCase().replace(/^@/, '');
    if (!cleanId) {
      return { success: false, error: '이메일 또는 아이디를 입력해주세요.' };
    }

    // Special hardcoded admin verification check requested by user: admin / mgms7658##
    if (cleanId === 'admin') {
      if (!password || password !== 'mgms7658##') {
        return { success: false, error: '관리자 비밀번호가 일치하지 않습니다.' };
      }
      let adminUser = users.find((u) => u.handle.toLowerCase() === 'admin');
      if (!adminUser) {
        adminUser = INITIAL_USERS.find((u) => u.handle === 'admin') || {
          id: 'user_admin',
          name: '최고 관리자',
          handle: 'admin',
          email: 'admin@maeum.io',
          password: 'mgms7658##',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80',
          banner: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
          bio: '마음(Maeum) 소셜 네트워크 총괄 관리자 계정입니다 🛡️',
          location: '서울 본사 운영팀',
          website: 'https://maeum.io',
          statusMessage: '회원 보호 및 쾌적한 커뮤니티 운영 관리 중 🛡️',
          interests: ['커뮤니티 관리', '회원 보호', '보안 & 모니터링'],
          joinedDate: '2023년 1월',
          followingIds: ['user_1', 'user_2'],
          followersCount: 9999,
          followingCount: 4,
          isVerified: true,
          isAdmin: true,
          role: '서비스 총괄 관리자',
          createdAt: '2023-01-01T00:00:00.000Z'
        };
        setUsers((prev) => [adminUser!, ...prev]);
      }
      setCurrentUserId(adminUser.id);
      setIsAuthenticated(true);
      setIsAuthModalOpen(false);
      setActiveTab('admin');
      showToast('관리자(admin) 계정으로 로그인되었습니다! 🛡️ 관리자 페이지로 이동합니다.', 'success');
      return { success: true };
    }

    const cleanPhone = (identifier || '').replace(/\D/g, '');

    // 1. Check if user was kicked by super admin (강제 탈퇴된 사람)
    const kickedMatch = kickedUsers.find(
      (k) =>
        k.handle.toLowerCase().replace(/^@/, '') === cleanId ||
        (k.email && k.email.toLowerCase() === cleanId) ||
        (cleanPhone.length >= 8 && k.phoneNumber && k.phoneNumber.replace(/\D/g, '') === cleanPhone)
    );

    if (kickedMatch) {
      const kickDateStr = kickedMatch.kickedAt
        ? new Date(kickedMatch.kickedAt).toLocaleString('ko-KR')
        : '';
      return {
        success: false,
        error: `[강제 탈퇴 계정]\n최고관리자에 의해 서비스에서 강제 탈퇴(영구 제명) 처리된 계정입니다.\n\n• 강퇴 사유: ${kickedMatch.reason || '운영 정책 위반'}\n• 처리 일시: ${kickDateStr || '기록됨'}\n• 처리 담당: ${kickedMatch.kickedBy || '최고관리자'}\n\n해당 계정으로는 서비스를 이용하실 수 없습니다.`
      };
    }

    const matchedUser = users.find(
      (u) =>
        u.handle.toLowerCase().replace(/^@/, '') === cleanId ||
        (u.email && u.email.toLowerCase() === cleanId) ||
        (cleanPhone.length >= 8 && u.phoneNumber && u.phoneNumber.replace(/\D/g, '') === cleanPhone)
    );

    if (!matchedUser) {
      return { success: false, error: '등록되지 않은 계정입니다. 아이디 또는 이메일을 확인해주세요.' };
    }

    // 2. Check if user is banned by super admin (이용 정지된 사람)
    if (matchedUser.isBanned) {
      const banDateStr = matchedUser.bannedAt
        ? new Date(matchedUser.bannedAt).toLocaleString('ko-KR')
        : '';
      return {
        success: false,
        error: `[이용 정지 계정]\n최고관리자에 의해 서비스 이용이 정지(차단)된 계정입니다.\n\n• 정지 사유: ${matchedUser.banReason || '운영 정책 및 커뮤니티 가이드라인 위반'}\n• 정지 일시: ${banDateStr || '최근 처리됨'}\n\n계정 정지 상태에서는 서비스를 이용하실 수 없습니다. 관리자에게 문의하세요.`
      };
    }

    // Check password if provided and user has password
    if (password && matchedUser.password && matchedUser.password !== password) {
      return { success: false, error: '비밀번호가 일치하지 않습니다.' };
    }

    setCurrentUserId(matchedUser.id);
    setIsAuthenticated(true);
    setIsAuthModalOpen(false);
    showToast(`${matchedUser.name}님, 로그인되었습니다! 👋`, 'success');
    return { success: true };
  };

  // SMS Gateway info status
  const [smsGatewayInfo, setSmsGatewayInfo] = useState<{
    configured: boolean;
    provider: string;
    senderNumber: string | null;
  }>({
    configured: false,
    provider: '대기 중',
    senderNumber: null,
  });

  const refreshSmsGatewayStatus = async () => {
    try {
      const res = await fetch('/api/sms/gateway-status');
      if (res.ok) {
        const data = await res.json();
        setSmsGatewayInfo(data);
      }
    } catch (e) {
      console.error('Failed to fetch SMS gateway status', e);
    }
  };

  // SMS API Configuration state & management
  const [smsApiConfig, setSmsApiConfig] = useState<SmsApiConfig | null>(null);
  const [isLoadingSmsConfig, setIsLoadingSmsConfig] = useState(false);

  const fetchSmsApiConfig = async () => {
    setIsLoadingSmsConfig(true);
    try {
      const res = await fetch('/api/sms/config');
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.config) {
          setSmsApiConfig(data.config);
        }
      }
    } catch (e) {
      console.error('Failed to fetch SMS API config:', e);
    } finally {
      setIsLoadingSmsConfig(false);
    }
  };

  const updateSmsApiConfig = async (
    newConfig: Partial<SmsApiConfig>
  ): Promise<{ success: boolean; message: string; error?: string }> => {
    try {
      const res = await fetch('/api/sms/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...newConfig, updatedBy: currentUser?.name || '관리자' })
      });
      const data = await res.json();
      if (data.success) {
        setSmsApiConfig(data.config);
        await refreshSmsGatewayStatus();
        showToast(data.message || 'SMS API 설정이 저장되었습니다.', 'success');
        return { success: true, message: data.message };
      } else {
        showToast(data.error || 'SMS API 설정 저장에 실패했습니다.', 'error');
        return { success: false, message: data.error, error: data.error };
      }
    } catch (e: any) {
      showToast(e.message || '네트워크 오류가 발생했습니다.', 'error');
      return { success: false, message: e.message, error: e.message };
    }
  };

  const resetSmsApiConfig = async (): Promise<{ success: boolean; message: string }> => {
    try {
      const res = await fetch('/api/sms/config/reset', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setSmsApiConfig(data.config);
        await refreshSmsGatewayStatus();
        showToast(data.message || 'SMS API 설정이 초기화되었습니다.', 'info');
        return { success: true, message: data.message };
      } else {
        return { success: false, message: data.error || '초기화 실패' };
      }
    } catch (e: any) {
      return { success: false, message: e.message };
    }
  };

  const testSmsApiConnection = async (
    phoneNumber: string,
    customMessage?: string
  ): Promise<{ success: boolean; provider: string; error?: string; detail?: any }> => {
    try {
      const res = await fetch('/api/sms/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber, customMessage })
      });
      const data = await res.json();
      return data;
    } catch (e: any) {
      return { success: false, provider: 'Unknown', error: e.message };
    }
  };

  // SMS Verification Database state
  const [smsDbRecords, setSmsDbRecords] = useState<SmsDbRecord[]>([]);
  const [smsDbStats, setSmsDbStats] = useState<SmsDbStats | null>(null);
  const [isLoadingSmsDb, setIsLoadingSmsDb] = useState(false);

  const fetchSmsDbRecords = async (search?: string, status?: string) => {
    setIsLoadingSmsDb(true);
    try {
      const params = new URLSearchParams();
      if (search) params.append('search', search);
      if (status && status !== 'all') params.append('status', status);

      const res = await fetch(`/api/sms/db-records?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setSmsDbRecords(data.records || []);
          setSmsDbStats(data.stats || null);
        }
      }
    } catch (e) {
      console.error('Failed to fetch SMS DB records:', e);
    } finally {
      setIsLoadingSmsDb(false);
    }
  };

  const insertSmsDbRecord = async (data: {
    phoneNumber: string;
    code?: string;
    status?: SmsVerificationStatus;
    provider?: SmsProviderType;
    notes?: string;
    expiresInMinutes?: number;
  }): Promise<{ success: boolean; message: string; record?: SmsDbRecord; error?: string }> => {
    try {
      const res = await fetch('/api/sms/db-records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const result = await res.json();
      if (!res.ok || !result.success) {
        showToast(result.error || 'DB 레코드 입력 실패', 'error');
        return { success: false, message: result.error || 'DB 레코드 입력 실패', error: result.error };
      }
      showToast('SMS 인증 DB에 레코드가 성공적으로 등록되었습니다!', 'success');
      // Refresh DB list
      fetchSmsDbRecords();
      return { success: true, message: result.message, record: result.record };
    } catch (err: any) {
      showToast('서버 통신 오류', 'error');
      return { success: false, message: err.message, error: err.message };
    }
  };

  const verifySmsDbRecordManual = async (id: string): Promise<{ success: boolean; message: string; error?: string }> => {
    try {
      const res = await fetch(`/api/sms/db-records/${id}/verify`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok || !data.success) {
        showToast(data.error || 'DB 인증 처리 실패', 'error');
        return { success: false, message: data.error || 'DB 인증 처리 실패', error: data.error };
      }
      showToast('해당 레코드가 DB에서 인증완료 처리되었습니다.', 'success');
      fetchSmsDbRecords();
      return { success: true, message: data.message };
    } catch (e: any) {
      return { success: false, message: e.message, error: e.message };
    }
  };

  const deleteSmsDbRecord = async (id: string): Promise<{ success: boolean; message: string; error?: string }> => {
    try {
      const res = await fetch(`/api/sms/db-records/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (!res.ok || !data.success) {
        showToast(data.error || '삭제 실패', 'error');
        return { success: false, message: data.error || '삭제 실패', error: data.error };
      }
      showToast('DB 레코드가 삭제되었습니다.', 'info');
      fetchSmsDbRecords();
      return { success: true, message: data.message };
    } catch (e: any) {
      return { success: false, message: e.message, error: e.message };
    }
  };

  const clearSmsDbRecords = async (): Promise<{ success: boolean; message: string; error?: string }> => {
    try {
      const res = await fetch('/api/sms/db-records/clear', { method: 'POST' });
      const data = await res.json();
      showToast('DB 테스트 기록이 초기화되었습니다.', 'info');
      fetchSmsDbRecords();
      return { success: true, message: data.message };
    } catch (e: any) {
      return { success: false, message: e.message, error: e.message };
    }
  };

  useEffect(() => {
    refreshSmsGatewayStatus();
    fetchSmsApiConfig();
    fetchSmsDbRecords();
  }, []);

  const sendSmsVerificationCode = async (
    phoneNumber: string
  ): Promise<{
    success: boolean;
    isRealSmsSent?: boolean;
    provider?: string;
    error?: string;
    message?: string;
    simulatedCode?: string;
    smsText?: string;
  }> => {
    const digits = phoneNumber.replace(/\D/g, '');
    if (!digits) {
      return { success: false, error: '휴대폰 번호를 입력해주세요.' };
    }
    if (!/^01[016789]\d{7,8}$/.test(digits)) {
      return {
        success: false,
        error: '유효한 휴대폰 번호 형식이 아닙니다. (예: 010-1234-5678)'
      };
    }

    // Check if phone number is already registered by another user
    const phoneExists = users.some((u) => {
      const uDigits = (u.phoneNumber || '').replace(/\D/g, '');
      return uDigits === digits;
    });

    if (phoneExists) {
      return {
        success: false,
        error: '이미 등록된 휴대폰 번호입니다. 기존 계정으로 로그인해주세요.'
      };
    }

    try {
      const res = await fetch('/api/sms/send-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber: digits }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || data.message || '인증번호 전송에 실패했습니다.',
        };
      }

      if (data.isRealSmsSent) {
        showToast(
          `📱 [${phoneNumber}] 본인 휴대폰으로 SMS 인증 문자가 발송되었습니다.`,
          'info'
        );
      } else {
        showToast(
          `📱 [${phoneNumber}] 번호로 인증 문자가 발송되었습니다.`,
          'info'
        );
      }

      return {
        success: true,
        isRealSmsSent: data.isRealSmsSent,
        provider: data.provider,
        message: data.message,
        simulatedCode: data.simulatedCode,
        smsText: data.smsText,
      };
    } catch (err: any) {
      console.error('sendSmsVerificationCode network error:', err);
      const fallbackCode = Math.floor(100000 + Math.random() * 900000).toString();
      showToast(`📱 [${phoneNumber}] 번호로 인증 문자가 발송되었습니다.`, 'info');
      return {
        success: true,
        isRealSmsSent: false,
        provider: 'Fallback',
        simulatedCode: fallbackCode,
        smsText: `[마음(Maeum)] 본인확인 인증번호 [${fallbackCode}]`,
        message: `${phoneNumber} 번호로 인증 문자가 요청되었습니다.`,
      };
    }
  };

  const verifySmsCode = async (
    phoneNumber: string,
    inputCode: string
  ): Promise<{ success: boolean; error?: string; message?: string }> => {
    const digits = phoneNumber.replace(/\D/g, '');
    if (!digits || !inputCode.trim()) {
      return { success: false, error: '휴대폰 번호와 인증번호를 입력해주세요.' };
    }

    try {
      const res = await fetch('/api/sms/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber: digits, code: inputCode.trim() }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || data.message || '인증번호가 일치하지 않습니다.',
        };
      }

      showToast('휴대폰 번호 본인인증이 완료되었습니다! ✅', 'success');
      return { success: true, message: data.message };
    } catch (err: any) {
      console.error('verifySmsCode network error:', err);
      return { success: false, error: '인증 서버와의 통신 중 오류가 발생했습니다.' };
    }
  };

  // Email Gateway info status
  const [emailGatewayInfo, setEmailGatewayInfo] = useState<{
    configured: boolean;
    provider: string;
    senderEmail: string | null;
  }>({
    configured: false,
    provider: '대기 중',
    senderEmail: null,
  });

  const refreshEmailGatewayStatus = async () => {
    try {
      const res = await fetch('/api/email/gateway-status');
      if (res.ok) {
        const data = await res.json();
        setEmailGatewayInfo(data);
      }
    } catch (e) {
      console.error('Failed to fetch Email gateway status', e);
    }
  };

  useEffect(() => {
    refreshEmailGatewayStatus();
  }, []);

  const sendEmailVerificationCode = async (
    email: string,
    purpose: string = '본인확인'
  ): Promise<{
    success: boolean;
    isRealEmailSent?: boolean;
    provider?: string;
    error?: string;
    message?: string;
    simulatedCode?: string;
    emailSubject?: string;
    emailHtml?: string;
  }> => {
    const cleanEmail = (email || '').trim().toLowerCase();
    if (!cleanEmail) {
      return { success: false, error: '이메일 주소를 입력해주세요.' };
    }
    if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(cleanEmail)) {
      return { success: false, error: '유효한 이메일 주소 형식(예: user@example.com)을 입력해주세요.' };
    }

    try {
      const res = await fetch('/api/email/send-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, purpose }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || data.message || '이메일 인증번호 전송에 실패했습니다.',
        };
      }

      if (data.isRealEmailSent) {
        showToast(
          `✉️ [${cleanEmail}] 주소로 6자리 인증번호가 실제 발송되었습니다. 수신함을 확인해주세요.`,
          'info'
        );
      } else {
        showToast(
          `✉️ [${cleanEmail}] 주소로 6자리 인증번호가 발송되었습니다.`,
          'info'
        );
      }

      return {
        success: true,
        isRealEmailSent: data.isRealEmailSent,
        provider: data.provider,
        message: data.message,
        simulatedCode: data.simulatedCode,
        emailSubject: data.emailSubject,
        emailHtml: data.emailHtml,
      };
    } catch (err: any) {
      console.error('sendEmailVerificationCode network error:', err);
      const fallbackCode = Math.floor(100000 + Math.random() * 900000).toString();
      showToast(`✉️ [${cleanEmail}] 주소로 6자리 인증번호가 발송되었습니다.`, 'info');
      return {
        success: true,
        isRealEmailSent: false,
        provider: 'Fallback',
        simulatedCode: fallbackCode,
        emailSubject: `[마음(Maeum)] ${purpose} 인증번호 [${fallbackCode}]`,
        message: `${cleanEmail} 주소로 6자리 인증번호가 발송되었습니다.`,
      };
    }
  };

  const verifyEmailCode = async (
    email: string,
    inputCode: string
  ): Promise<{ success: boolean; error?: string; message?: string }> => {
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanCode = (inputCode || '').trim();

    if (!cleanEmail || !cleanCode) {
      return { success: false, error: '이메일 주소와 6자리 인증번호를 모두 입력해주세요.' };
    }

    try {
      const res = await fetch('/api/email/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, code: cleanCode }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || data.message || '인증번호가 일치하지 않습니다.',
        };
      }

      showToast('이메일 주소 본인인증이 완료되었습니다! ✅', 'success');
      return { success: true, message: data.message };
    } catch (err: any) {
      console.error('verifyEmailCode network error:', err);
      return { success: false, error: '인증 서버와의 통신 중 오류가 발생했습니다.' };
    }
  };

  const loginWithEmailCode = async (
    email: string,
    code: string
  ): Promise<{ success: boolean; error?: string }> => {
    const cleanEmail = (email || '').trim().toLowerCase();
    const verifyResult = await verifyEmailCode(cleanEmail, code);
    if (!verifyResult.success) {
      return { success: false, error: verifyResult.error || '인증번호가 일치하지 않습니다.' };
    }

    // Check if email was kicked by super admin
    const kickedMatch = kickedUsers.find(
      (k) => k.email && k.email.toLowerCase() === cleanEmail
    );
    if (kickedMatch) {
      const kickDateStr = kickedMatch.kickedAt ? new Date(kickedMatch.kickedAt).toLocaleString('ko-KR') : '';
      return {
        success: false,
        error: `[강제 탈퇴 계정]\n최고관리자에 의해 서비스에서 강제 탈퇴(영구 제명) 처리된 이메일 계정입니다.\n\n• 강퇴 사유: ${kickedMatch.reason || '운영 정책 위반'}\n• 처리 일시: ${kickDateStr || '기록됨'}\n• 처리 담당: ${kickedMatch.kickedBy || '최고관리자'}\n\n해당 계정으로는 서비스를 이용하실 수 없습니다.`,
      };
    }

    const matchedUser = users.find(
      (u) => u.email && u.email.toLowerCase() === cleanEmail
    );

    if (!matchedUser) {
      return {
        success: false,
        error: '해당 이메일로 가입된 계정이 없습니다. 회원가입을 먼저 진행해주세요.',
      };
    }

    if (matchedUser.isBanned) {
      const banDateStr = matchedUser.bannedAt ? new Date(matchedUser.bannedAt).toLocaleString('ko-KR') : '';
      return {
        success: false,
        error: `[이용 정지 계정]\n최고관리자에 의해 서비스 이용이 정지(차단)된 계정입니다.\n\n• 정지 사유: ${matchedUser.banReason || '운영 정책 및 커뮤니티 가이드라인 위반'}\n• 정지 일시: ${banDateStr || '최근 처리됨'}\n\n계정 정지 상태에서는 서비스를 이용하실 수 없습니다. 관리자에게 문의하세요.`,
      };
    }

    setCurrentUserId(matchedUser.id);
    setIsAuthenticated(true);
    setIsAuthModalOpen(false);
    showToast(`${matchedUser.name}님, 이메일 인증으로 로그인되었습니다! 👋`, 'success');
    return { success: true };
  };

  // 1. 아이디 찾기 (Find User ID / Handle by name and contact)
  const findUserIdentifier = (
    name: string,
    contact: string,
    type: 'phone' | 'email'
  ): {
    success: boolean;
    user?: {
      id: string;
      name: string;
      handle: string;
      email: string;
      phoneNumber?: string;
      joinedDate?: string;
      createdAt?: string;
    };
    error?: string;
  } => {
    const cleanName = (name || '').trim().toLowerCase();
    if (!cleanName) {
      return { success: false, error: '가입 시 등록한 이름을 입력해주세요.' };
    }

    if (type === 'phone') {
      const cleanPhone = (contact || '').replace(/\D/g, '');
      if (!cleanPhone || cleanPhone.length < 8) {
        return { success: false, error: '올바른 휴대폰 번호를 입력해주세요. (예: 010-1234-5678)' };
      }
      const matched = users.find(
        (u) =>
          u.name.trim().toLowerCase() === cleanName &&
          (u.phoneNumber || '').replace(/\D/g, '') === cleanPhone
      );
      if (!matched) {
        return {
          success: false,
          error: '입력하신 이름과 휴대폰 번호에 해당하는 계정을 찾을 수 없습니다.'
        };
      }
      return {
        success: true,
        user: {
          id: matched.id,
          name: matched.name,
          handle: matched.handle,
          email: matched.email,
          phoneNumber: matched.phoneNumber,
          joinedDate: matched.joinedDate,
          createdAt: matched.createdAt,
        }
      };
    } else {
      const cleanEmail = (contact || '').trim().toLowerCase();
      if (!cleanEmail || !cleanEmail.includes('@')) {
        return { success: false, error: '올바른 이메일 주소를 입력해주세요.' };
      }
      const matched = users.find(
        (u) =>
          u.name.trim().toLowerCase() === cleanName &&
          (u.email || '').trim().toLowerCase() === cleanEmail
      );
      if (!matched) {
        return {
          success: false,
          error: '입력하신 이름과 이메일 주소에 해당하는 계정을 찾을 수 없습니다.'
        };
      }
      return {
        success: true,
        user: {
          id: matched.id,
          name: matched.name,
          handle: matched.handle,
          email: matched.email,
          phoneNumber: matched.phoneNumber,
          joinedDate: matched.joinedDate,
          createdAt: matched.createdAt,
        }
      };
    }
  };

  // 2. 비밀번호 재설정 인증코드 발송 (Send Reset Password Code - 휴대폰 SMS 전용)
  const sendResetPasswordCode = async (
    identifier: string,
    method: 'sms' | 'email' = 'sms'
  ): Promise<{
    success: boolean;
    user?: User;
    target?: string;
    isRealSent?: boolean;
    simulatedCode?: string;
    message?: string;
    error?: string;
  }> => {
    const cleanId = (identifier || '').trim().toLowerCase().replace(/^@/, '');

    if (!cleanId) {
      return { success: false, error: '비밀번호를 재설정할 계정 아이디를 입력해주세요.' };
    }

    const matchedUser = users.find(
      (u) => u.handle.toLowerCase().replace(/^@/, '') === cleanId
    );

    if (!matchedUser) {
      return {
        success: false,
        error: '입력하신 계정 아이디와 일치하는 등록된 계정을 찾을 수 없습니다.'
      };
    }

    const phoneDigits = (matchedUser.phoneNumber || '').replace(/\D/g, '');
    if (!phoneDigits) {
      return {
        success: false,
        error: '해당 계정에 등록된 휴대폰 번호가 없습니다. 관리자에게 문의해주세요.'
      };
    }

    try {
      const res = await fetch('/api/sms/send-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber: phoneDigits }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return {
          success: false,
          error: data.error || data.message || '인증번호 발송에 실패했습니다.'
        };
      }
      showToast(`📱 등록된 휴대폰(${matchedUser.phoneNumber})으로 비밀번호 재설정 인증문자가 발송되었습니다.`, 'info');
      return {
        success: true,
        user: matchedUser,
        target: matchedUser.phoneNumber,
        isRealSent: data.isRealSmsSent,
        simulatedCode: data.simulatedCode,
        message: data.message
      };
    } catch (err: any) {
      const fallbackCode = Math.floor(100000 + Math.random() * 900000).toString();
      showToast(`📱 등록된 휴대폰 번호로 인증문자가 발송되었습니다.`, 'info');
      return {
        success: true,
        user: matchedUser,
        target: matchedUser.phoneNumber,
        isRealSent: false,
        simulatedCode: fallbackCode,
        message: '인증번호가 발송되었습니다.'
      };
    }
  };

  // 3. 비밀번호 재설정 인증코드 검증 (Verify Reset Password Code - 휴대폰 SMS 전용)
  const verifyResetPasswordCode = async (
    target: string,
    code: string,
    method: 'sms' | 'email' = 'sms'
  ): Promise<{ success: boolean; message?: string; error?: string }> => {
    const cleanCode = (code || '').trim();
    if (!cleanCode) {
      return { success: false, error: '6자리 SMS 인증번호를 입력해주세요.' };
    }

    const digits = (target || '').replace(/\D/g, '');
    try {
      const res = await fetch('/api/sms/verify-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber: digits, code: cleanCode }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || '인증번호가 일치하지 않습니다.' };
      }
      return { success: true, message: data.message || '인증이 완료되었습니다.' };
    } catch (e: any) {
      return { success: false, error: '인증 서버 통신 오류가 발생했습니다.' };
    }
  };

  // 4. 비밀번호 최종 재설정/업데이트 (Reset User Password)
  const resetUserPassword = async (
    userId: string,
    newPassword: string
  ): Promise<{ success: boolean; message: string; error?: string }> => {
    if (!newPassword || newPassword.length < 4) {
      return { success: false, message: '비밀번호는 최소 4자 이상이어야 합니다.', error: '비밀번호는 최소 4자 이상이어야 합니다.' };
    }

    const targetUser = users.find((u) => u.id === userId);
    if (!targetUser) {
      return { success: false, message: '해당 사용자를 찾을 수 없습니다.', error: '사용자를 찾을 수 없습니다.' };
    }

    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, password: newPassword } : u))
    );

    realtimeSync.updateUser(userId, { password: newPassword });

    showToast(`🔑 ${targetUser.name}님의 비밀번호가 안전하게 변경되었습니다! 새로운 비밀번호로 로그인해주세요.`, 'success');
    return { success: true, message: '비밀번호가 성공적으로 변경되었습니다.' };
  };

  const signup = (data: {
    name: string;
    handle: string;
    email: string;
    emailVerified: boolean;
    phoneNumber: string;
    phoneVerified: boolean;
    password: string;
    location: string;
    avatar?: string;
    bio?: string;
    role?: string;
    interests?: string[];
    birthdate?: string;
    isOver14Confirmed?: boolean;
  }): { success: boolean; error?: string } => {
    const cleanHandle = data.handle.trim().toLowerCase().replace(/^@/, '');
    const cleanEmail = data.email.trim().toLowerCase();
    const cleanName = data.name.trim();
    const cleanLocation = data.location?.trim();
    const phoneDigits = (data.phoneNumber || '').replace(/\D/g, '');

    // 만 14세 이상 확인 검증 (개인정보 보호법 제22조의2)
    if (data.isOver14Confirmed === false) {
      return {
        success: false,
        error: '만 14세 이상만 서비스에 가입할 수 있습니다. (개인정보 보호법 제22조의2에 따라 만 14세 미만 가입 제한)'
      };
    }

    if (data.birthdate) {
      const birth = new Date(data.birthdate);
      if (!isNaN(birth.getTime())) {
        const today = new Date();
        let calculatedAge = today.getFullYear() - birth.getFullYear();
        const m = today.getMonth() - birth.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
          calculatedAge--;
        }
        if (calculatedAge < 14) {
          return {
            success: false,
            error: `만 14세 미만(현재 만 ${calculatedAge}세)은 법률 및 운영 정책상 가입이 제한됩니다. 만 14세 이상만 회원가입이 가능합니다.`
          };
        }
      }
    }

    if (!cleanName) {
      return { success: false, error: '이름을 입력해주세요.' };
    }
    if (!cleanHandle || cleanHandle.length < 2) {
      return { success: false, error: '아이디(핸들)는 최소 2자 이상이어야 합니다.' };
    }
    if (!/^[a-zA-Z0-9_.]+$/.test(cleanHandle)) {
      return { success: false, error: '아이디는 영문, 숫자, 밑줄(_), 마침표(.)만 사용 가능합니다.' };
    }
    if (!cleanEmail || !cleanEmail.includes('@')) {
      return { success: false, error: '올바른 이메일 주소를 입력해주세요.' };
    }

    const method = signupAuthConfig.verificationMethod;

    // Phone / SMS verification check (Dedicated verification system)
    if (method !== 'none') {
      if (!phoneDigits) {
        return { success: false, error: '휴대폰 번호는 필수 입력 항목입니다.' };
      }
      if (!/^01[016789]\d{7,8}$/.test(phoneDigits)) {
        return { success: false, error: '올바른 휴대폰 번호(010-XXXX-XXXX)를 입력해주세요.' };
      }
      if (!data.phoneVerified) {
        return { success: false, error: '휴대폰 SMS 문자메시지 본인인증(6자리 코드 입력)을 완료해주세요.' };
      }
    }

    if (!data.password || data.password.length < 4) {
      return { success: false, error: '비밀번호는 최소 4자 이상이어야 합니다.' };
    }
    if (!cleanLocation) {
      return { success: false, error: '주소(거주/활동 지역)는 필수 입력 항목입니다.' };
    }

    // Check if previously kicked user is trying to re-register
    const kickedMatch = kickedUsers.find(
      (k) =>
        k.handle.toLowerCase().replace(/^@/, '') === cleanHandle ||
        (k.email && k.email.toLowerCase() === cleanEmail) ||
        (phoneDigits.length >= 8 && k.phoneNumber && k.phoneNumber.replace(/\D/g, '') === phoneDigits)
    );
    if (kickedMatch) {
      return {
        success: false,
        error: `해당 계정 정보(아이디/이메일/연락처)는 최고관리자에 의해 강제 탈퇴(영구 제명) 처리된 이력이 있어 재가입이 제한됩니다.\n• 강퇴 사유: ${kickedMatch.reason || '운영 정책 위반'}\n• 처리 일시: ${kickedMatch.kickedAt ? new Date(kickedMatch.kickedAt).toLocaleString('ko-KR') : '기록됨'}`
      };
    }

    // Check duplicates
    const handleExists = users.some((u) => u.handle.toLowerCase() === cleanHandle);
    if (handleExists) {
      return { success: false, error: '이미 사용 중인 아이디(핸들)입니다. 다른 아이디를 선택해주세요.' };
    }

    const emailExists = users.some((u) => u.email && u.email.toLowerCase() === cleanEmail);
    if (emailExists) {
      return { success: false, error: '이미 가입된 이메일 주소입니다. 로그인을 진행해주세요.' };
    }

    const phoneExists = users.some((u) => {
      const uDigits = (u.phoneNumber || '').replace(/\D/g, '');
      return uDigits === phoneDigits;
    });
    if (phoneExists) {
      return { success: false, error: '이미 등록된 휴대폰 번호입니다. 기존 계정으로 로그인해주세요.' };
    }

    // Format phone number nicely e.g. 010-1234-5678
    const formattedPhone =
      phoneDigits.length === 11
        ? `${phoneDigits.slice(0, 3)}-${phoneDigits.slice(3, 7)}-${phoneDigits.slice(7, 11)}`
        : `${phoneDigits.slice(0, 3)}-${phoneDigits.slice(3, 6)}-${phoneDigits.slice(6)}`;

    const now = new Date();
    const joinedFormatted = `${now.getFullYear()}년 ${now.getMonth() + 1}월`;
    const newUserId = `user_${Date.now()}`;

    const defaultAvatar =
      data.avatar ||
      `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&auto=format&fit=crop&q=80`;

    const newUser: User = {
      id: newUserId,
      name: cleanName,
      handle: cleanHandle,
      email: cleanEmail,
      emailVerified: data.emailVerified !== undefined ? data.emailVerified : (method === 'sms' || method === 'none'),
      phoneNumber: formattedPhone,
      phoneVerified: data.phoneVerified !== undefined ? data.phoneVerified : (method === 'email' || method === 'none'),
      password: data.password,
      avatar: defaultAvatar,
      banner: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
      bio: data.bio?.trim() || '안녕하세요! 마음에서 일상을 공유합니다 ✨',
      location: cleanLocation,
      joinedDate: joinedFormatted,
      followingIds: [], // 가짜/강제 팔로우 방지: 신규 가입 시 0명으로 시작
      followersCount: 0,
      followingCount: 0,
      role: data.role || '소셜 크리에이터',
      interests: data.interests && data.interests.length > 0 ? data.interests : ['일상', '소셜'],
      birthdate: data.birthdate,
      isOver14Confirmed: true,
      isVerified: false,
      signupIp: clientIp || '127.0.0.1',
      createdAt: now.toISOString()
    };

    setUsers((prev) => [newUser, ...prev]);
    realtimeSync.registerUser(newUser).then((res) => {
      if (res && res.user && res.user.signupIp && res.user.signupIp !== newUser.signupIp) {
        setUsers((prev) =>
          prev.map((u) => (u.id === newUser.id ? { ...u, signupIp: res.user.signupIp } : u))
        );
      }
    });
    
    // 회원가입 완료 시 관리자 및 기존 계정의 세션이 자동으로 끊어지고 로그아웃되도록 처리
    terminateSession();
    if (activeTab === 'admin' || activeTab === 'database' || activeTab === 'profile') {
      setActiveTab('feed');
      setViewingUserId(null);
    }
    setAuthModalMode('login');
    setIsAuthModalOpen(true);

    // Link SMS verification record in DB if phone verified
    if (data.phoneVerified && phoneDigits) {
      fetch('/api/sms/link-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phoneNumber: phoneDigits,
          userId: newUserId,
          userHandle: cleanHandle,
        }),
      }).then(() => fetchSmsDbRecords()).catch(() => {});
    }

    // Create welcome notification (가짜 팔로우 알림 방지: system 타입으로 설정)
    const welcomeNotif: Notification = {
      id: `notif_welcome_${Date.now()}`,
      recipientId: newUserId,
      actorId: 'user_admin',
      actorName: '마음(Maeum)',
      actorAvatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80',
      type: 'system',
      content: '마음에 오신 것을 환영합니다! 🎉 첫 글을 작성하고 소통을 시작해보세요.',
      createdAt: new Date().toISOString(),
      isRead: false
    };
    setNotifications((prev) => [welcomeNotif, ...prev]);

    // Create welcome intro post (가짜 좋아요 방지: 빈 배열로 초기화)
    const welcomePost: Post = {
      id: `post_${Date.now()}`,
      authorId: newUserId,
      authorName: cleanName,
      authorHandle: cleanHandle,
      authorAvatar: defaultAvatar,
      authorVerified: false,
      content: `안녕하세요! 마음에 새로 가입했습니다 🎉 앞으로 좋은 일상과 소식 많이 나눌게요! #반가워요 #첫게시물 #${cleanName}`,
      tags: ['반가워요', '첫게시물', cleanName],
      location: cleanLocation,
      createdAt: new Date().toISOString(),
      likes: [],
      bookmarks: [],
      reposts: [],
      commentsCount: 0,
      visibility: 'public'
    };
    setPosts((prev) => [welcomePost, ...prev]);

    showToast(
      `${cleanName}님, 회원가입이 완료되었습니다! 기존 세션이 자동으로 종료(로그아웃)되었습니다. 새로운 계정으로 로그인해주세요. 🎉`,
      'success'
    );
    return { success: true };
  };

  const logout = () => {
    terminateSession();
    if (activeTab === 'admin' || activeTab === 'database' || activeTab === 'profile') {
      setActiveTab('feed');
      setViewingUserId(null);
    }
    showToast('로그아웃되었습니다. 세션이 안전하게 종료되었습니다.', 'info');
  };

  // Actions
  const switchUser = (userId: string) => {
    // Check kicked
    const kicked = kickedUsers.find((k) => k.id === userId);
    if (kicked) {
      showToast(`최고관리자에 의해 강제 탈퇴된 계정입니다. (사유: ${kicked.reason})`, 'error');
      return;
    }
    const target = users.find((u) => u.id === userId);
    if (!target) {
      showToast('해당 회원을 찾을 수 없습니다.', 'error');
      return;
    }
    if (target.isBanned) {
      showToast(`이용 정지된 계정입니다. (사유: ${target.banReason || '운영 정책 위반'})`, 'error');
      return;
    }
    setCurrentUserId(userId);
    setIsAuthenticated(true);
    setViewingUserId(null);
    showToast(`${target.name} 계정으로 전환되었습니다.`, 'info');
  };

  const updateProfile = (updatedData: Partial<User>) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? { ...u, ...updatedData } : u))
    );
    // Also update author info on existing posts
    if (updatedData.name || updatedData.avatar || updatedData.handle) {
      setPosts((prev) =>
        prev.map((p) =>
          p.authorId === currentUser.id
            ? {
                ...p,
                authorName: updatedData.name || p.authorName,
                authorAvatar: updatedData.avatar || p.authorAvatar,
                authorHandle: updatedData.handle || p.authorHandle
              }
            : p
        )
      );
    }
  };

  // Admin User Actions: 강제 탈퇴 (삭제) 및 정지/차단
  const deleteUser = (userId: string, reason?: string): { success: boolean; error?: string } => {
    const target = users.find((u) => u.id === userId);
    if (!target) {
      return { success: false, error: '해당 회원을 찾을 수 없습니다.' };
    }
    if (target.isAdmin || target.handle === 'admin') {
      return { success: false, error: '시스템 총괄 관리자 계정은 강제 탈퇴시킬 수 없습니다.' };
    }

    const finalReason = reason?.trim() || '운영 정책 및 커뮤니티 가이드라인 위반';
    const userPosts = posts.filter((p) => p.authorId === userId);
    const kickRecord: KickedUserRecord = {
      id: target.id,
      name: target.name,
      handle: target.handle,
      email: target.email,
      phoneNumber: target.phoneNumber,
      signupIp: target.signupIp || '211.234.120.45',
      kickedAt: new Date().toISOString(),
      reason: finalReason,
      kickedBy: currentUser.name || '최고 관리자',
      userData: target,
      userPosts: userPosts,
    };

    // Save kicked record
    setKickedUsers((prev) => {
      const filtered = prev.filter((k) => k.id !== userId && k.handle !== target.handle);
      const updated = [kickRecord, ...filtered];
      try {
        localStorage.setItem('social_kicked_users', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    // Sync kick to server
    realtimeSync.kickUser(userId, finalReason, currentUser.name || '최고 관리자', target, userPosts);

    // Remove user
    setUsers((prev) => {
      const updated = prev.filter((u) => u.id !== userId);
      try {
        localStorage.setItem('social_users', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    // Remove user's posts, comments, stories and sync deleted posts
    const userPostIds = userPosts.map((p) => p.id);
    if (userPostIds.length > 0) {
      setDeletedPostIds((prev) => {
        const merged = Array.from(new Set([...prev, ...userPostIds]));
        try {
          localStorage.setItem('social_deleted_post_ids', JSON.stringify(merged));
        } catch {}
        return merged;
      });
      userPostIds.forEach((pid) => realtimeSync.deletePost(pid));
    }

    setPosts((prev) => prev.filter((p) => p.authorId !== userId));
    setComments((prev) => prev.filter((c) => c.authorId !== userId));
    setStories((prev) => prev.filter((s) => s.userId !== userId));

    // If the deleted user was currently active, switch back to admin or default
    if (currentUserId === userId) {
      const adminUser = users.find((u) => u.handle === 'admin') || INITIAL_USERS[0];
      setCurrentUserId(adminUser.id);
    }

    showToast(`회원 [${target.name} (@${target.handle})]님이 강제 탈퇴 처리되었습니다. (사유: ${finalReason})`, 'success');
    return { success: true };
  };

  // Admin Action: 강퇴된 회원 계정 정상 복원
  const restoreUser = (userId: string): { success: boolean; error?: string } => {
    const targetKicked = kickedUsers.find((k) => k.id === userId);
    if (!targetKicked) {
      return { success: false, error: '해당 회원의 강퇴 기록을 찾을 수 없습니다.' };
    }

    const cleanKickedHandle = (targetKicked.handle || '').toLowerCase().replace(/^@/, '');
    const cleanKickedEmail = (targetKicked.email || '').toLowerCase().trim();
    const cleanPhoneDigits = (targetKicked.phoneNumber || '').replace(/\D/g, '');

    // 1. Remove from kickedUsers history completely
    const updatedKicked = kickedUsers.filter((k) => {
      if (k.id === userId) return false;
      if (k.handle && k.handle.toLowerCase().replace(/^@/, '') === cleanKickedHandle) return false;
      if (cleanKickedEmail && k.email && k.email.toLowerCase().trim() === cleanKickedEmail) return false;
      if (cleanPhoneDigits.length >= 8 && k.phoneNumber && k.phoneNumber.replace(/\D/g, '') === cleanPhoneDigits) return false;
      return true;
    });
    setKickedUsers(updatedKicked);
    try {
      localStorage.setItem('social_kicked_users', JSON.stringify(updatedKicked));
    } catch {}

    // 2. Reconstitute user object
    let restoredUser: User = targetKicked.userData as User;
    if (!restoredUser) {
      const initMatch = INITIAL_USERS.find(
        (u) => u.id === userId || u.handle.toLowerCase().replace(/^@/, '') === cleanKickedHandle
      );
      if (initMatch) {
        restoredUser = { ...initMatch, isBanned: false };
      } else {
        restoredUser = {
          id: targetKicked.id,
          name: targetKicked.name,
          handle: targetKicked.handle,
          email: targetKicked.email || `${cleanKickedHandle}@maeum.io`,
          phoneNumber: targetKicked.phoneNumber,
          avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
          banner: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
          bio: '관리자에 의해 정상 복원된 계정입니다.',
          joinedDate: '2024년 1월',
          followersCount: 0,
          followingCount: 0,
          followingIds: [],
          followerIds: [],
          isBanned: false,
          isAdmin: false,
          createdAt: targetKicked.kickedAt || new Date().toISOString(),
        };
      }
    }
    restoredUser = {
      ...restoredUser,
      id: targetKicked.id || restoredUser.id,
      name: targetKicked.name || restoredUser.name,
      handle: targetKicked.handle || restoredUser.handle,
      signupIp: restoredUser.signupIp || targetKicked.signupIp || '211.234.120.45',
      isBanned: false,
      banReason: undefined,
      bannedAt: undefined,
    };

    // 3. Put restored user back into users list
    setUsers((prev) => {
      const cleanPrev = prev.filter(
        (u) => u.id !== userId && u.handle.toLowerCase().replace(/^@/, '') !== cleanKickedHandle
      );
      const updated = [restoredUser, ...cleanPrev];
      try {
        localStorage.setItem('social_users', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    // 4. Restore user's posts and unblock their IDs
    if (Array.isArray(targetKicked.userPosts) && targetKicked.userPosts.length > 0) {
      const restoredPostIds = new Set(targetKicked.userPosts.map((p) => p.id));
      setDeletedPostIds((prev) => {
        const next = prev.filter((pid) => !restoredPostIds.has(pid));
        try {
          localStorage.setItem('social_deleted_post_ids', JSON.stringify(next));
        } catch {}
        return next;
      });
      setPosts((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const postsToAdd = targetKicked.userPosts!.filter((p) => !existingIds.has(p.id));
        return [...postsToAdd, ...prev];
      });
    }

    // 5. Sync with server
    realtimeSync.restoreUser(userId, restoredUser, targetKicked.userPosts || []);

    showToast(`회원 [${targetKicked.name} (@${targetKicked.handle})]님이 정상 활동 계정으로 복원되었습니다! ✨`, 'success');
    return { success: true };
  };

  const toggleBanUser = (userId: string, reason: string = '운영 정책 위반'): { success: boolean; error?: string } => {
    const target = users.find((u) => u.id === userId);
    if (!target) {
      return { success: false, error: '해당 회원을 찾을 수 없습니다.' };
    }
    if (target.isAdmin || target.handle === 'admin') {
      return { success: false, error: '시스템 총괄 관리자 계정은 정지 처리할 수 없습니다.' };
    }

    const isNowBanned = !target.isBanned;
    const finalReason = isNowBanned ? (reason?.trim() || '운영 정책 및 커뮤니티 가이드라인 위반') : undefined;

    setUsers((prev) => {
      const updated = prev.map((u) =>
        u.id === userId
          ? {
              ...u,
              isBanned: isNowBanned,
              bannedAt: isNowBanned ? new Date().toISOString() : undefined,
              banReason: finalReason
            }
          : u
      );
      try {
        localStorage.setItem('social_users', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    realtimeSync.toggleBanUser(userId, finalReason);

    // If current logged-in user is the one banned
    if (isNowBanned && currentUserId === userId) {
      terminateSession(`계정이 정지되었습니다. (사유: ${finalReason})`);
      setAuthNotice({
        type: 'banned',
        title: '서비스 이용 정지(차단) 안내',
        reason: finalReason || '운영 정책 위반',
        date: new Date().toISOString(),
        handle: target.handle
      });
      setIsAuthModalOpen(true);
    }

    if (isNowBanned) {
      showToast(`회원 [${target.name}]님의 계정이 서비스 이용 정지(차단) 처리되었습니다. (사유: ${finalReason})`, 'info');
    } else {
      showToast(`회원 [${target.name}]님의 계정 정지가 해제되었습니다.`, 'success');
    }
    return { success: true };
  };

  const resetUsersToInitial = () => {
    setUsers(INITIAL_USERS);
    localStorage.setItem('social_users', JSON.stringify(INITIAL_USERS));
    showToast('회원 데이터가 초기 데모 상태로 초기화되었습니다.', 'info');
  };

  // Super Admin Database Master Authentication & Operations
  const [isSuperAdminDbUnlocked, setIsSuperAdminDbUnlocked] = useState<boolean>(() => {
    return typeof window !== 'undefined' && sessionStorage.getItem('superadmin_db_session') === 'true';
  });

  const unlockSuperAdminDatabase = (password?: string, silent?: boolean): { success: boolean; error?: string } => {
    const isAdminAccount = currentUser.isAdmin || currentUser.handle === 'admin';
    if (isAdminAccount && (!password || password === 'mgms7658##')) {
      setIsSuperAdminDbUnlocked(true);
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('superadmin_db_session', 'true');
      }
      if (!silent) {
        showToast('최고관리자 데이터베이스 마스터 세션이 활성화되었습니다! 🗄️', 'success');
      }
      return { success: true };
    }

    if (password === 'mgms7658##') {
      const adminUser = users.find((u) => u.handle === 'admin') || INITIAL_USERS[0];
      setCurrentUserId(adminUser.id);
      setIsAuthenticated(true);
      setIsSuperAdminDbUnlocked(true);
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('superadmin_db_session', 'true');
      }
      if (!silent) {
        showToast('최고관리자(admin) 계정으로 인증되어 DB 직접 수정 권한이 승인되었습니다! 🗄️', 'success');
      }
      return { success: true };
    }

    return { success: false, error: '최고관리자 마스터 비밀번호가 올바르지 않습니다.' };
  };

  const lockSuperAdminDatabase = (silent?: boolean) => {
    setIsSuperAdminDbUnlocked(false);
    if (typeof window !== 'undefined') {
      sessionStorage.removeItem('superadmin_db_session');
    }
    if (!silent) {
      showToast('데이터베이스 마스터 세션이 잠금 처리되었습니다.', 'info');
    }
  };

  // Persistent API Keys & Secrets Database Records
  const [apiKeysRecords, setApiKeysRecords] = useState<ApiKeyRecord[]>([]);

  useEffect(() => {
    const records: ApiKeyRecord[] = [
      {
        id: 'api_coolsms',
        serviceName: 'CoolSMS (Solapi)',
        provider: 'CoolSMS',
        keyName: 'CoolSMS API Key',
        apiKey: smsApiConfig?.coolsmsApiKey || '',
        secretName: 'CoolSMS API SECRET',
        apiSecret: smsApiConfig?.coolsmsApiSecret || '',
        senderNumber: smsApiConfig?.senderNumber || '010-1234-5678',
        status: smsApiConfig?.provider === 'CoolSMS' ? (smsApiConfig?.testMode ? 'sandbox' : 'active') : 'inactive',
        description: '대한민국 SKT/KT/LGU+ 통신망 실시간 6자리 SMS/LMS 본인인증 발송 API',
        updatedAt: smsApiConfig?.updatedAt || new Date().toISOString(),
        updatedBy: smsApiConfig?.updatedBy || '시스템 관리자'
      },
      {
        id: 'api_aligo',
        serviceName: '알리고 (Aligo SMS)',
        provider: 'Aligo',
        keyName: '알리고 API Key',
        apiKey: smsApiConfig?.aligoApiKey || '',
        secretName: '알리고 API SECRET / User ID',
        apiSecret: smsApiConfig?.aligoUserId || '',
        senderNumber: smsApiConfig?.senderNumber || '010-1234-5678',
        status: smsApiConfig?.provider === 'Aligo' ? (smsApiConfig?.testMode ? 'sandbox' : 'active') : 'inactive',
        description: '국내 알리고(Aligo) SMS 단문 및 장문 문자 발송 API',
        updatedAt: smsApiConfig?.updatedAt || new Date().toISOString(),
        updatedBy: smsApiConfig?.updatedBy || '시스템 관리자'
      },
      {
        id: 'api_naver',
        serviceName: '네이버 클라우드 SENS',
        provider: 'NaverSENS',
        keyName: 'NCP Access Key',
        apiKey: smsApiConfig?.naverAccessKey || '',
        secretName: 'NCP Secret Key (SECRET)',
        apiSecret: smsApiConfig?.naverSecretKey || '',
        senderNumber: smsApiConfig?.senderNumber || '010-1234-5678',
        extraParam: smsApiConfig?.naverServiceId || '',
        status: smsApiConfig?.provider === 'NaverSENS' ? (smsApiConfig?.testMode ? 'sandbox' : 'active') : 'inactive',
        description: '네이버 클라우드 플랫폼 SENS SMS 알림 발송 서비스',
        updatedAt: smsApiConfig?.updatedAt || new Date().toISOString(),
        updatedBy: smsApiConfig?.updatedBy || '시스템 관리자'
      },
      {
        id: 'api_twilio',
        serviceName: 'Twilio SMS',
        provider: 'Twilio',
        keyName: 'Twilio Account SID',
        apiKey: smsApiConfig?.twilioAccountSid || '',
        secretName: 'Twilio Auth Token (SECRET)',
        apiSecret: smsApiConfig?.twilioAuthToken || '',
        senderNumber: smsApiConfig?.senderNumber || '+1234567890',
        status: smsApiConfig?.provider === 'Twilio' ? (smsApiConfig?.testMode ? 'sandbox' : 'active') : 'inactive',
        description: '글로벌 해외 번호 및 국제 문자메시지 게이트웨이 API',
        updatedAt: smsApiConfig?.updatedAt || new Date().toISOString(),
        updatedBy: smsApiConfig?.updatedBy || '시스템 관리자'
      },
      {
        id: 'api_gemini',
        serviceName: 'Google Gemini AI',
        provider: 'GeminiAI',
        keyName: 'GEMINI_API_KEY',
        apiKey: 'AIzaSy' + '•'.repeat(24),
        secretName: 'GEMINI_API_SECRET',
        apiSecret: '••••••••••••••••',
        status: 'active',
        description: '게시물 감성 분석 및 AI 스마트 피드 생성 모델 API',
        updatedAt: new Date().toISOString(),
        updatedBy: '시스템 환경변수'
      },
      {
        id: 'api_custom',
        serviceName: 'Custom REST API',
        provider: 'Custom',
        keyName: 'Custom Endpoint URL',
        apiKey: smsApiConfig?.customApiUrl || '',
        secretName: 'Authorization Header (SECRET)',
        apiSecret: smsApiConfig?.customAuthHeader || '',
        senderNumber: smsApiConfig?.senderNumber || '',
        status: smsApiConfig?.provider === 'Custom' ? 'active' : 'inactive',
        description: '사용자 지정 웹훅 및 사내 SMS 발송 서버 연동 API',
        updatedAt: smsApiConfig?.updatedAt || new Date().toISOString(),
        updatedBy: smsApiConfig?.updatedBy || '시스템 관리자'
      }
    ];
    setApiKeysRecords(records);
  }, [smsApiConfig]);

  const updateDatabaseRecord = (
    table: DatabaseTableKey,
    id: string,
    updatedData: any
  ): { success: boolean; error?: string } => {
    try {
      if (table === 'users') {
        setUsers((prev) =>
          prev.map((u) => (u.id === id ? { ...u, ...updatedData } : u))
        );
      } else if (table === 'posts') {
        setPosts((prev) =>
          prev.map((p) => (p.id === id ? { ...p, ...updatedData } : p))
        );
      } else if (table === 'comments') {
        setComments((prev) =>
          prev.map((c) => (c.id === id ? { ...c, ...updatedData } : c))
        );
      } else if (table === 'stories') {
        setStories((prev) =>
          prev.map((s) => (s.userId === id ? { ...s, ...updatedData } : s))
        );
      } else if (table === 'messages') {
        setMessages((prev) =>
          prev.map((m) => (m.id === id ? { ...m, ...updatedData } : m))
        );
      } else if (table === 'api_keys') {
        setApiKeysRecords((prev) =>
          prev.map((k) => (k.id === id ? { ...k, ...updatedData, updatedAt: new Date().toISOString() } : k))
        );
        const target = apiKeysRecords.find((k) => k.id === id);
        const merged = { ...target, ...updatedData };
        if (merged.provider === 'CoolSMS') {
          updateSmsApiConfig({
            coolsmsApiKey: merged.apiKey,
            coolsmsApiSecret: merged.apiSecret,
            senderNumber: merged.senderNumber,
            provider: merged.status === 'active' || merged.status === 'sandbox' ? 'CoolSMS' : undefined
          });
        } else if (merged.provider === 'Aligo') {
          updateSmsApiConfig({
            aligoApiKey: merged.apiKey,
            aligoUserId: merged.apiSecret,
            senderNumber: merged.senderNumber,
            provider: merged.status === 'active' || merged.status === 'sandbox' ? 'Aligo' : undefined
          });
        } else if (merged.provider === 'Twilio') {
          updateSmsApiConfig({
            twilioAccountSid: merged.apiKey,
            twilioAuthToken: merged.apiSecret,
            senderNumber: merged.senderNumber,
            provider: merged.status === 'active' || merged.status === 'sandbox' ? 'Twilio' : undefined
          });
        } else if (merged.provider === 'NaverSENS') {
          updateSmsApiConfig({
            naverAccessKey: merged.apiKey,
            naverSecretKey: merged.apiSecret,
            naverServiceId: merged.extraParam,
            senderNumber: merged.senderNumber,
            provider: merged.status === 'active' || merged.status === 'sandbox' ? 'NaverSENS' : undefined
          });
        } else if (merged.provider === 'Custom') {
          updateSmsApiConfig({
            customApiUrl: merged.apiKey,
            customAuthHeader: merged.apiSecret,
            senderNumber: merged.senderNumber,
            provider: merged.status === 'active' || merged.status === 'sandbox' ? 'Custom' : undefined
          });
        } else if (merged.provider === 'GeminiAI') {
          if (merged.apiKey && !merged.apiKey.includes('•')) {
            localStorage.setItem('custom_gemini_api_key', merged.apiKey);
          }
        }
      }
      showToast(`[${table.toUpperCase()}] 레코드(ID: ${id})가 성공적으로 수정되었습니다.`, 'success');
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || '레코드 수정에 실패했습니다.' };
    }
  };

  const insertDatabaseRecord = (
    table: DatabaseTableKey,
    newRecord: any
  ): { success: boolean; error?: string } => {
    try {
      const recordWithId = {
        ...newRecord,
        id: newRecord.id || `${table.slice(0, 4)}_${Date.now()}`
      };
      if (table === 'users') {
        setUsers((prev) => [recordWithId, ...prev]);
      } else if (table === 'posts') {
        setPosts((prev) => [recordWithId, ...prev]);
      } else if (table === 'comments') {
        setComments((prev) => [recordWithId, ...prev]);
      } else if (table === 'stories') {
        setStories((prev) => [recordWithId, ...prev]);
      } else if (table === 'messages') {
        setMessages((prev) => [recordWithId, ...prev]);
      } else if (table === 'api_keys') {
        setApiKeysRecords((prev) => [recordWithId, ...prev]);
        if (recordWithId.provider === 'CoolSMS') {
          updateSmsApiConfig({
            coolsmsApiKey: recordWithId.apiKey,
            coolsmsApiSecret: recordWithId.apiSecret,
            senderNumber: recordWithId.senderNumber
          });
        } else if (recordWithId.provider === 'Aligo') {
          updateSmsApiConfig({
            aligoApiKey: recordWithId.apiKey,
            aligoUserId: recordWithId.apiSecret,
            senderNumber: recordWithId.senderNumber
          });
        } else if (recordWithId.provider === 'Twilio') {
          updateSmsApiConfig({
            twilioAccountSid: recordWithId.apiKey,
            twilioAuthToken: recordWithId.apiSecret,
            senderNumber: recordWithId.senderNumber
          });
        } else if (recordWithId.provider === 'NaverSENS') {
          updateSmsApiConfig({
            naverAccessKey: recordWithId.apiKey,
            naverSecretKey: recordWithId.apiSecret,
            naverServiceId: recordWithId.extraParam,
            senderNumber: recordWithId.senderNumber
          });
        } else if (recordWithId.provider === 'Custom') {
          updateSmsApiConfig({
            customApiUrl: recordWithId.apiKey,
            customAuthHeader: recordWithId.apiSecret,
            senderNumber: recordWithId.senderNumber
          });
        }
      }
      showToast(`[${table.toUpperCase()}] 새 레코드가 데이터베이스에 성공적으로 삽입되었습니다.`, 'success');
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || '레코드 추가에 실패했습니다.' };
    }
  };

  const deleteDatabaseRecord = (
    table: DatabaseTableKey,
    id: string
  ): { success: boolean; error?: string } => {
    try {
      if (table === 'users') {
        const target = users.find((u) => u.id === id);
        if (target && (target.isAdmin || target.handle === 'admin')) {
          return { success: false, error: '최고 관리자 계정은 보호되어 삭제할 수 없습니다.' };
        }
        setUsers((prev) => prev.filter((u) => u.id !== id));
      } else if (table === 'posts') {
        setDeletedPostIds((prev) => {
          const updated = prev.includes(id) ? prev : [...prev, id];
          try {
            localStorage.setItem('social_deleted_post_ids', JSON.stringify(updated));
          } catch {}
          return updated;
        });
        setPosts((prev) => {
          const filtered = prev.filter((p) => p.id !== id);
          try {
            localStorage.setItem('social_posts', JSON.stringify(filtered));
          } catch {}
          return filtered;
        });
        setComments((prev) => prev.filter((c) => c.postId !== id));
        realtimeSync.deletePost(id);
      } else if (table === 'comments') {
        setComments((prev) => prev.filter((c) => c.id !== id));
      } else if (table === 'stories') {
        setStories((prev) => prev.filter((s) => s.userId !== id));
      } else if (table === 'messages') {
        setMessages((prev) => prev.filter((m) => m.id !== id));
      } else if (table === 'api_keys') {
        setApiKeysRecords((prev) => prev.filter((k) => k.id !== id));
      }
      showToast(`[${table.toUpperCase()}] 레코드(ID: ${id})가 삭제되었습니다.`, 'info');
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || '레코드 삭제에 실패했습니다.' };
    }
  };

  const replaceDatabaseTable = (
    table: DatabaseTableKey,
    newRecords: any[]
  ): { success: boolean; error?: string } => {
    try {
      if (!Array.isArray(newRecords)) {
        return { success: false, error: '데이터는 반드시 배열(Array) 형식이어야 합니다.' };
      }
      if (table === 'users') {
        const hasAdmin = newRecords.some((u) => u.handle === 'admin' || u.isAdmin);
        const finalList = hasAdmin ? newRecords : [INITIAL_USERS[0], ...newRecords];
        setUsers(finalList);
      } else if (table === 'posts') {
        setPosts(newRecords);
      } else if (table === 'comments') {
        setComments(newRecords);
      } else if (table === 'stories') {
        setStories(newRecords);
      } else if (table === 'messages') {
        setMessages(newRecords);
      } else if (table === 'api_keys') {
        setApiKeysRecords(newRecords);
      }
      showToast(`[${table.toUpperCase()}] 테이블(${newRecords.length}개)이 성공적으로 반영되었습니다.`, 'success');
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || '테이블 갱신에 실패했습니다.' };
    }
  };

  const importFullDatabase = (
    backup: Partial<FullDatabaseBackup['tables']>
  ): { success: boolean; error?: string } => {
    try {
      if (backup.users && Array.isArray(backup.users)) {
        const hasAdmin = backup.users.some((u) => u.handle === 'admin' || u.isAdmin);
        setUsers(hasAdmin ? backup.users : [INITIAL_USERS[0], ...backup.users]);
      }
      if (backup.posts && Array.isArray(backup.posts)) {
        setPosts(backup.posts);
      }
      if (backup.comments && Array.isArray(backup.comments)) {
        setComments(backup.comments);
      }
      if (backup.stories && Array.isArray(backup.stories)) {
        setStories(backup.stories);
      }
      if (backup.messages && Array.isArray(backup.messages)) {
        setMessages(backup.messages);
      }
      if (backup.api_keys && Array.isArray(backup.api_keys)) {
        setApiKeysRecords(backup.api_keys);
      }
      showToast('전체 데이터베이스가 백업본으로 안전하게 복원되었습니다! 🗄️✨', 'success');
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || '데이터베이스 복원에 실패했습니다.' };
    }
  };

  const resetFullDatabaseToInitial = () => {
    setUsers(INITIAL_USERS);
    setPosts(INITIAL_POSTS);
    setComments(INITIAL_COMMENTS);
    setStories(INITIAL_STORIES);
    setMessages(INITIAL_MESSAGES);
    setNotifications(INITIAL_NOTIFICATIONS);
    localStorage.setItem('social_users', JSON.stringify(INITIAL_USERS));
    localStorage.setItem('social_posts', JSON.stringify(INITIAL_POSTS));
    localStorage.setItem('social_comments', JSON.stringify(INITIAL_COMMENTS));
    localStorage.setItem('social_stories', JSON.stringify(INITIAL_STORIES));
    localStorage.setItem('social_messages', JSON.stringify(INITIAL_MESSAGES));
    localStorage.setItem('social_notifications', JSON.stringify(INITIAL_NOTIFICATIONS));
    showToast('전체 데이터베이스가 초기 데모 상태로 초기화되었습니다.', 'info');
  };

  const getFullDatabaseBackup = (): FullDatabaseBackup => {
    return {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      exportedBy: currentUser.name || '최고 관리자',
      tables: {
        users,
        posts,
        comments,
        stories,
        messages,
        api_keys: apiKeysRecords
      }
    };
  };

  // ============================================================
  // SPAM FILTERING SYSTEM MANAGEMENT (Super Admin)
  // ============================================================
  const updateSpamFilterSettings = (newSettings: Partial<SpamFilterSettings>) => {
    setSpamFilterSettings((prev) => {
      const updated: SpamFilterSettings = {
        ...prev,
        ...newSettings,
        targetScope: {
          ...prev.targetScope,
          ...(newSettings.targetScope || {})
        },
        stats: {
          ...prev.stats,
          ...(newSettings.stats || {})
        }
      };
      return updated;
    });
  };

  const addSpamKeywords = (keywordsToAdd: string[]): { addedCount: number; duplicateCount: number } => {
    let addedCount = 0;
    let duplicateCount = 0;

    setSpamFilterSettings((prev) => {
      const currentSet = new Set((prev.keywords || []).map((k) => k.toLowerCase().trim()));
      const nextKeywords = [...(prev.keywords || [])];

      for (const kw of keywordsToAdd) {
        const clean = kw.trim();
        if (!clean) continue;
        if (currentSet.has(clean.toLowerCase())) {
          duplicateCount++;
        } else {
          currentSet.add(clean.toLowerCase());
          nextKeywords.push(clean);
          addedCount++;
        }
      }

      return {
        ...prev,
        keywords: nextKeywords
      };
    });

    return { addedCount, duplicateCount };
  };

  const removeSpamKeyword = (keywordToRemove: string) => {
    const clean = keywordToRemove.trim().toLowerCase();
    setSpamFilterSettings((prev) => ({
      ...prev,
      keywords: (prev.keywords || []).filter((kw) => kw.toLowerCase().trim() !== clean)
    }));
    showToast(`스팸 키워드 '${keywordToRemove}'이(가) 삭제되었습니다.`, 'info');
  };

  const resetSpamKeywordsToDefault = () => {
    setSpamFilterSettings((prev) => ({
      ...prev,
      keywords: DEFAULT_SPAM_KEYWORDS
    }));
    showToast(`스팸 키워드 사전이 기본 추천 세트(${DEFAULT_SPAM_KEYWORDS.length}개)로 복원되었습니다.`, 'success');
  };

  const clearAllSpamKeywords = () => {
    setSpamFilterSettings((prev) => ({
      ...prev,
      keywords: []
    }));
    showToast('등록된 모든 스팸 키워드가 비워졌습니다.', 'info');
  };

  const resetSpamStats = () => {
    setSpamFilterSettings((prev) => ({
      ...prev,
      stats: {
        totalBlockedCount: 0,
        totalMaskedCount: 0,
        totalAutoBlindedCount: 0,
        lastDetectedKeyword: undefined,
        lastDetectedAt: undefined
      }
    }));
    showToast('스팸 차단 및 감지 통계가 초기화되었습니다.', 'info');
  };

  const runSpamCheck = (
    text: string,
    scope: 'posts' | 'comments' | 'messages' | 'stories' = 'posts'
  ): SpamCheckResult => {
    return checkSpam(text, spamFilterSettings, scope);
  };

  const updateSignupInfo = (data: {
    name: string;
    handle: string;
    email: string;
    emailVerified?: boolean;
    phoneNumber?: string;
    phoneVerified?: boolean;
    password?: string;
    location: string;
    role?: string;
    bio?: string;
    avatar?: string;
    interests?: string[];
  }): { success: boolean; error?: string } => {
    const cleanName = data.name.trim();
    const cleanHandle = data.handle.trim().replace(/^@/, '');
    const cleanEmail = data.email.trim().toLowerCase();
    const cleanLocation = data.location.trim();
    const phoneDigits = data.phoneNumber ? data.phoneNumber.replace(/\D/g, '') : undefined;

    if (!cleanName) {
      return { success: false, error: '이름을 입력해주세요.' };
    }
    if (!cleanHandle) {
      return { success: false, error: '아이디(핸들)를 입력해주세요.' };
    }
    if (!/^[a-zA-Z0-9_.]+$/.test(cleanHandle)) {
      return { success: false, error: '아이디는 영문, 숫자, 밑줄(_), 마침표(.)만 사용 가능합니다.' };
    }
    if (!cleanEmail || !cleanEmail.includes('@')) {
      return { success: false, error: '올바른 이메일 주소를 입력해주세요.' };
    }
    if (phoneDigits !== undefined && phoneDigits.length > 0 && !/^01[016789]\d{7,8}$/.test(phoneDigits)) {
      return { success: false, error: '유효한 휴대폰 번호 형식을 입력해주세요.' };
    }
    if (data.password && data.password.trim().length > 0 && data.password.trim().length < 4) {
      return { success: false, error: '비밀번호는 최소 4자 이상이어야 합니다.' };
    }
    if (!cleanLocation) {
      return { success: false, error: '거주/활동 지역을 입력하거나 위치 자동 감지를 사용해주세요.' };
    }

    // Check duplicate handle
    const handleExists = users.some(
      (u) => u.id !== currentUser.id && u.handle.toLowerCase() === cleanHandle.toLowerCase()
    );
    if (handleExists) {
      return { success: false, error: '이미 다른 회원이 사용 중인 아이디입니다. 다른 아이디를 입력해주세요.' };
    }

    // Check duplicate email
    const emailExists = users.some(
      (u) => u.id !== currentUser.id && u.email && u.email.toLowerCase() === cleanEmail
    );
    if (emailExists) {
      return { success: false, error: '이미 다른 회원이 등록한 이메일 주소입니다. 다른 이메일을 입력해주세요.' };
    }

    // Check duplicate phone if provided
    if (phoneDigits) {
      const phoneExists = users.some((u) => {
        if (u.id === currentUser.id) return false;
        const uDigits = (u.phoneNumber || '').replace(/\D/g, '');
        return uDigits === phoneDigits;
      });
      if (phoneExists) {
        return { success: false, error: '이미 다른 회원이 등록한 휴대폰 번호입니다.' };
      }
    }

    const newPassword =
      data.password && data.password.trim().length >= 4
        ? data.password.trim()
        : currentUser.password;

    const formattedPhone = phoneDigits
      ? phoneDigits.length === 11
        ? `${phoneDigits.slice(0, 3)}-${phoneDigits.slice(3, 7)}-${phoneDigits.slice(7, 11)}`
        : `${phoneDigits.slice(0, 3)}-${phoneDigits.slice(3, 6)}-${phoneDigits.slice(6)}`
      : currentUser.phoneNumber;

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === currentUser.id) {
          return {
            ...u,
            name: cleanName,
            handle: cleanHandle,
            email: cleanEmail,
            emailVerified: data.emailVerified !== undefined ? data.emailVerified : u.emailVerified,
            phoneNumber: formattedPhone,
            phoneVerified: data.phoneVerified !== undefined ? data.phoneVerified : u.phoneVerified,
            password: newPassword,
            location: cleanLocation,
            role: data.role !== undefined ? data.role.trim() : u.role,
            bio: data.bio !== undefined ? data.bio.trim() : u.bio,
            avatar: data.avatar || u.avatar,
            interests: data.interests !== undefined ? data.interests : u.interests
          };
        }
        return u;
      })
    );

    realtimeSync.updateUser(currentUser.id, {
      name: cleanName,
      handle: cleanHandle,
      email: cleanEmail,
      emailVerified: data.emailVerified !== undefined ? data.emailVerified : currentUser.emailVerified,
      phoneNumber: formattedPhone,
      phoneVerified: data.phoneVerified !== undefined ? data.phoneVerified : currentUser.phoneVerified,
      password: newPassword,
      location: cleanLocation,
      role: data.role !== undefined ? data.role.trim() : currentUser.role,
      bio: data.bio !== undefined ? data.bio.trim() : currentUser.bio,
      avatar: data.avatar || currentUser.avatar,
      interests: data.interests !== undefined ? data.interests : currentUser.interests
    });

    // Update author info in posts
    setPosts((prev) =>
      prev.map((p) =>
        p.authorId === currentUser.id
          ? {
              ...p,
              authorName: cleanName,
              authorHandle: cleanHandle,
              authorAvatar: data.avatar || p.authorAvatar
            }
          : p
      )
    );

    // Update author info in comments
    setComments((prev) =>
      prev.map((c) =>
        c.authorId === currentUser.id
          ? {
              ...c,
              authorName: cleanName,
              authorHandle: cleanHandle,
              authorAvatar: data.avatar || c.authorAvatar
            }
          : c
      )
    );

    showToast('회원가입 정보가 성공적으로 수정되었습니다! ✨', 'success');
    return { success: true };
  };

  const toggleFollow = (targetUserId: string, targetName?: string, targetHandle?: string) => {
    if (!isAuthenticated) {
      showToast('로그인한 회원만 팔로우할 수 있습니다.', 'info');
      setIsAuthModalOpen(true);
      return;
    }

    if (currentUser.isBanned) {
      showToast('이용 정지된 회원은 팔로우 기능을 이용할 수 없습니다.', 'error');
      return;
    }

    if (!targetUserId) return;
    const cleanTargetId = targetUserId.trim();
    const cleanTargetHandle = (targetHandle || '').toLowerCase().replace(/^@/, '');

    // 1. Prevent self-follow (자기 자신 팔로우 금지)
    if (
      cleanTargetId === currentUser.id ||
      (currentUser.handle && cleanTargetId.toLowerCase() === currentUser.handle.toLowerCase().replace(/^@/, ''))
    ) {
      showToast('자기 자신은 팔로우할 수 없습니다.', 'info');
      return;
    }

    // 2. Anti-spam / Rapid click rate limiting (연타 매크로 어뷰징 방지)
    const now = Date.now();
    const lastFollow = lastFollowTimestamp.current.get(cleanTargetId) || 0;
    if (now - lastFollow < 600) {
      showToast('요청이 너무 빠릅니다. 잠시 후 다시 시도해주세요.', 'info');
      return;
    }
    lastFollowTimestamp.current.set(cleanTargetId, now);

    // 3. Prevent following kicked / terminated accounts (탈퇴/강퇴 회원 가짜 팔로우 방지)
    const isKicked = isUserKickedRecord({ id: cleanTargetId, handle: cleanTargetHandle } as User, kickedUsers);
    if (isKicked) {
      showToast('강제 탈퇴(강퇴) 처리된 회원은 팔로우할 수 없습니다.', 'error');
      return;
    }

    // Multi-tier target user lookup to guarantee accurate identification even if restored or desynced
    let targetUser = users.find(
      (u) =>
        u.id === cleanTargetId ||
        (u.handle && u.handle.toLowerCase().replace(/^@/, '') === cleanTargetId.toLowerCase().replace(/^@/, '')) ||
        (cleanTargetHandle && u.handle && u.handle.toLowerCase().replace(/^@/, '') === cleanTargetHandle)
    );

    // Look in posts (author information - especially critical when viewing restored member posts)
    const matchPost = posts.find(
      (p) =>
        p.authorId === cleanTargetId ||
        (p.authorHandle && p.authorHandle.toLowerCase().replace(/^@/, '') === cleanTargetId.toLowerCase().replace(/^@/, '')) ||
        (cleanTargetHandle && p.authorHandle && p.authorHandle.toLowerCase().replace(/^@/, '') === cleanTargetHandle)
    );

    // If targetUser found but has missing/generic name or default avatar, enhance from post or supplied params
    if (targetUser) {
      const bestName =
        (targetUser.name && targetUser.name.trim() !== '회원' ? targetUser.name.trim() : '') ||
        (targetName && targetName.trim() !== '회원' ? targetName.trim() : '') ||
        (matchPost?.authorName && matchPost.authorName.trim() !== '회원' ? matchPost.authorName.trim() : '') ||
        targetUser.name ||
        '회원';
      const bestHandle = targetUser.handle || targetHandle?.replace(/^@/, '') || matchPost?.authorHandle || cleanTargetId;
      const bestAvatar = targetUser.avatar || matchPost?.authorAvatar;
      targetUser = {
        ...targetUser,
        name: bestName,
        handle: bestHandle,
        ...(bestAvatar ? { avatar: bestAvatar } : {}),
      };
    } else if (matchPost) {
      targetUser = {
        id: matchPost.authorId,
        name:
          (matchPost.authorName && matchPost.authorName.trim() !== '회원' ? matchPost.authorName.trim() : '') ||
          (targetName && targetName.trim() !== '회원' ? targetName.trim() : '') ||
          '회원',
        handle: matchPost.authorHandle || targetHandle?.replace(/^@/, '') || cleanTargetId,
        avatar: matchPost.authorAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
        banner: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
        bio: '마음 회원입니다 ✨',
        joinedDate: '2024년 1월',
        followersCount: 0,
        followingCount: 0,
        followingIds: [],
        followerIds: [],
      };
    }

    // Check INITIAL_USERS
    if (!targetUser) {
      const matchInit = INITIAL_USERS.find(
        (u) =>
          u.id === cleanTargetId ||
          u.handle.toLowerCase().replace(/^@/, '') === cleanTargetId.toLowerCase().replace(/^@/, '') ||
          (cleanTargetHandle && u.handle.toLowerCase().replace(/^@/, '') === cleanTargetHandle)
      );
      if (matchInit) targetUser = matchInit;
    }

    // Check kickedUsers history (in case restoration was partial or just completed)
    if (!targetUser) {
      const matchKicked = kickedUsers.find(
        (k) =>
          k.id === cleanTargetId ||
          (k.handle && k.handle.toLowerCase().replace(/^@/, '') === cleanTargetId.toLowerCase().replace(/^@/, '')) ||
          (cleanTargetHandle && k.handle && k.handle.toLowerCase().replace(/^@/, '') === cleanTargetHandle)
      );
      if (matchKicked) {
        targetUser = {
          id: matchKicked.id,
          name: matchKicked.name,
          handle: matchKicked.handle,
          avatar: (matchKicked.userData && matchKicked.userData.avatar) || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
          banner: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
          bio: '마음 회원입니다 ✨',
          joinedDate: '2024년 1월',
          followersCount: 0,
          followingCount: 0,
          followingIds: [],
          followerIds: [],
        };
      }
    }

    // If targetUser is still null, construct fallback object from supplied targetName/targetHandle/matchPost
    if (!targetUser) {
      const fallbackName =
        (targetName && targetName.trim() !== '회원' ? targetName.trim() : '') ||
        (matchPost?.authorName && matchPost.authorName.trim() !== '회원' ? matchPost.authorName.trim() : '') ||
        (targetHandle ? `@${targetHandle.replace(/^@/, '')}` : '') ||
        (matchPost?.authorHandle ? `@${matchPost.authorHandle.replace(/^@/, '')}` : '') ||
        '회원';

      const fallbackHandle = targetHandle?.replace(/^@/, '') || matchPost?.authorHandle || cleanTargetId;

      targetUser = {
        id: cleanTargetId,
        name: fallbackName,
        handle: fallbackHandle,
        avatar: matchPost?.authorAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
        banner: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=1200&auto=format&fit=crop&q=80',
        bio: '마음 회원입니다 ✨',
        joinedDate: '2024년 1월',
        followersCount: 0,
        followingCount: 0,
        followingIds: [],
        followerIds: [],
      };
    }

    const resolvedTargetId = targetUser?.id || cleanTargetId;
    const isCurrentlyFollowing = (currentUser.followingIds || []).includes(resolvedTargetId) ||
      (targetUser?.handle && (currentUser.followingIds || []).includes(targetUser.handle.toLowerCase().replace(/^@/, '')));

    const displayName =
      (targetName && targetName.trim() !== '회원' ? targetName.trim() : '') ||
      (matchPost?.authorName && matchPost.authorName.trim() !== '회원' ? matchPost.authorName.trim() : '') ||
      (targetUser?.name && targetUser.name.trim() !== '회원' ? targetUser.name.trim() : '') ||
      (targetHandle ? `@${targetHandle.replace(/^@/, '')}` : '') ||
      (matchPost?.authorHandle ? `@${matchPost.authorHandle.replace(/^@/, '')}` : '') ||
      (targetUser?.handle ? `@${targetUser.handle.replace(/^@/, '')}` : '') ||
      (targetUser?.name || targetName || matchPost?.authorName || '회원');

    // 1. Optimistic Local State Update
    setUsers((prev) => {
      const current = prev.find((u) => u.id === currentUser.id);
      const currentFollowing = current?.followingIds || [];
      const willFollow = !isCurrentlyFollowing;
      const updatedFollowing = willFollow
        ? Array.from(new Set([...currentFollowing, resolvedTargetId]))
        : currentFollowing.filter((id) => id !== resolvedTargetId && (!targetUser?.handle || id !== targetUser.handle.toLowerCase().replace(/^@/, '')));

      let targetUserFoundInPrev = false;
      const updatedUsers = prev.map((user) => {
        if (user.id === currentUser.id) {
          return {
            ...user,
            followingIds: updatedFollowing,
            followingCount: updatedFollowing.length,
          };
        }
        if (user.id === resolvedTargetId || (targetUser?.handle && user.handle.toLowerCase().replace(/^@/, '') === targetUser.handle.toLowerCase().replace(/^@/, ''))) {
          targetUserFoundInPrev = true;
          const curFollowers = user.followerIds || [];
          const updatedFollowers = willFollow
            ? Array.from(new Set([...curFollowers, currentUser.id]))
            : curFollowers.filter((id) => id !== currentUser.id);
          const curCount = typeof user.followersCount === 'number' ? user.followersCount : 0;
          const resolvedName = displayName !== '회원' ? displayName : (targetUser?.name || user.name);
          return {
            ...user,
            name: resolvedName,
            followerIds: updatedFollowers,
            followersCount: willFollow ? curCount + 1 : Math.max(0, curCount - 1),
          };
        }
        return user;
      });

      // If targetUser was not present in users state (e.g., restored user not yet loaded), prepend targetUser
      let finalUsers = updatedUsers;
      if (!targetUserFoundInPrev && targetUser) {
        const curFollowers = targetUser.followerIds || [];
        const updatedFollowers = willFollow
          ? Array.from(new Set([...curFollowers, currentUser.id]))
          : curFollowers.filter((id) => id !== currentUser.id);
        const curCount = typeof targetUser.followersCount === 'number' ? targetUser.followersCount : 0;
        const newTargetEntry: User = {
          ...targetUser,
          id: resolvedTargetId,
          name: displayName !== '회원' ? displayName : targetUser.name,
          followerIds: updatedFollowers,
          followersCount: willFollow ? curCount + 1 : Math.max(0, curCount - 1),
        };
        finalUsers = [newTargetEntry, ...updatedUsers];
      }

      try {
        localStorage.setItem('social_users', JSON.stringify(finalUsers));
      } catch {}

      return finalUsers;
    });

    // 2. Real-time Multi-Device Sync Call to Server
    realtimeSync.toggleFollow(resolvedTargetId, currentUser.id, currentUser, displayName, targetUser?.handle || targetHandle).catch((err) => {
      console.warn('Realtime follow sync error:', err);
    });

    // 3. User feedback toast
    if (!isCurrentlyFollowing) {
      showToast(`${displayName}님을 팔로우했습니다. ✨`, 'success');
    } else {
      showToast(`${displayName}님 팔로우를 취소했습니다.`, 'info');
    }
  };

  const schedulePost = ({
    content,
    images,
    video,
    videoThumbnail,
    mediaItems,
    tags,
    pollQuestion,
    pollOptions,
    feeling,
    location,
    bgm,
    visibility = 'public',
    regionalScope = 'national',
    scheduledAt
  }: {
    content: string;
    images?: string[];
    video?: string;
    videoThumbnail?: string;
    mediaItems?: PostMediaItem[];
    tags?: string[];
    pollQuestion?: string;
    pollOptions?: string[];
    feeling?: string;
    location?: string;
    bgm?: StoryBgm;
    visibility?: 'public' | 'followers';
    regionalScope?: RegionalScope;
    scheduledAt: string;
  }) => {
    // 🛡️ Check Spam Filter for Scheduled Post
    const spamCheck = checkSpam(content, spamFilterSettings, 'posts');
    if (spamCheck.hasSpam) {
      setSpamFilterSettings((prev) => ({
        ...prev,
        stats: {
          ...prev.stats,
          totalBlockedCount:
            spamCheck.actionTaken === 'block'
              ? prev.stats.totalBlockedCount + 1
              : prev.stats.totalBlockedCount,
          totalMaskedCount:
            spamCheck.actionTaken === 'mask'
              ? prev.stats.totalMaskedCount + 1
              : prev.stats.totalMaskedCount,
          totalAutoBlindedCount:
            spamCheck.actionTaken === 'auto_blind'
              ? prev.stats.totalAutoBlindedCount + 1
              : prev.stats.totalAutoBlindedCount,
          lastDetectedKeyword: spamCheck.detectedWords[0],
          lastDetectedAt: new Date().toISOString()
        }
      }));

      if (spamCheck.actionTaken === 'block') {
        showToast(
          spamCheck.noticeMessage ||
            `🚫 스팸 키워드 [${spamCheck.detectedWords.join(', ')}]이(가) 포함되어 있어 예약할 수 없습니다.`,
          'error'
        );
        return;
      }
    }

    const finalContent = spamCheck.actionTaken === 'mask' ? spamCheck.cleanText : content;

    let pollData = undefined;
    if (pollQuestion && pollOptions && pollOptions.length >= 2) {
      pollData = {
        question: pollQuestion,
        options: pollOptions
          .filter((opt) => opt.trim().length > 0)
          .map((opt, idx) => ({
            id: `opt_${Date.now()}_${idx}`,
            text: opt.trim(),
            votes: []
          })),
        totalVotes: 0
      };
    }

    const resolvedImages = images && images.length > 0 ? images : (mediaItems ? mediaItems.filter(m => m.type === 'image').map(m => m.url) : undefined);
    const resolvedVideo = video || (mediaItems ? mediaItems.find(m => m.type === 'video')?.url : undefined);
    const resolvedVideoThumbnail = videoThumbnail || (mediaItems ? mediaItems.find(m => m.type === 'video')?.thumbnail : undefined);

    const newScheduledPost: ScheduledPost = {
      id: `post_sched_${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorHandle: currentUser.handle,
      authorAvatar: currentUser.avatar,
      authorVerified: currentUser.isVerified,
      content: finalContent,
      images: resolvedImages && resolvedImages.length > 0 ? resolvedImages : undefined,
      video: resolvedVideo && resolvedVideo.trim().length > 0 ? resolvedVideo : undefined,
      videoThumbnail: resolvedVideoThumbnail && resolvedVideoThumbnail.trim().length > 0 ? resolvedVideoThumbnail : undefined,
      mediaItems: mediaItems && mediaItems.length > 0 ? mediaItems : undefined,
      tags: tags && tags.length > 0 ? tags : undefined,
      poll: pollData,
      feeling,
      location,
      bgm,
      scheduledAt,
      visibility,
      regionalScope: regionalScope || 'national',
      createdAt: new Date().toISOString()
    };

    setScheduledPosts((prev) => [newScheduledPost, ...prev]);
    const formatted = formatScheduledDateTime(scheduledAt);
    if (spamCheck.actionTaken === 'mask') {
      showToast(`스팸 단어가 마스킹(***) 처리되어 ${formatted}에 예약되었습니다.`, 'info');
    } else {
      showToast(`게시물이 ${formatted}에 예약되었습니다.`, 'success');
    }
  };

  const cancelScheduledPost = (scheduledPostId: string) => {
    setScheduledPosts((prev) => prev.filter((p) => p.id !== scheduledPostId));
    showToast('게시물 예약이 취소되었습니다.', 'info');
  };

  const publishScheduledPostNow = (scheduledPostId: string) => {
    const sp = scheduledPosts.find((p) => p.id === scheduledPostId);
    if (!sp) return;

    const newPost: Post = {
      id: sp.id.startsWith('post_sched_') ? `post_${Date.now()}` : sp.id,
      authorId: sp.authorId,
      authorName: sp.authorName,
      authorHandle: sp.authorHandle,
      authorAvatar: sp.authorAvatar,
      authorVerified: sp.authorVerified,
      content: sp.content,
      images: sp.images,
      video: sp.video,
      videoThumbnail: sp.videoThumbnail,
      mediaItems: sp.mediaItems,
      tags: sp.tags,
      poll: sp.poll,
      feeling: sp.feeling,
      location: sp.location,
      bgm: sp.bgm,
      createdAt: new Date().toISOString(),
      likes: [],
      bookmarks: [],
      reposts: [],
      commentsCount: 0,
      visibility: sp.visibility,
      regionalScope: sp.regionalScope || 'national',
      scheduledAt: sp.scheduledAt
    };

    setScheduledPosts((prev) => prev.filter((p) => p.id !== scheduledPostId));
    setPosts((prev) => [newPost, ...prev]);
    showToast('예약된 게시물이 지금 즉시 게시되었습니다.', 'success');
  };

  const createPost = ({
    content,
    images,
    video,
    videoThumbnail,
    mediaItems,
    tags,
    pollQuestion,
    pollOptions,
    feeling,
    location,
    bgm,
    visibility = 'public',
    regionalScope = 'national',
    scheduledAt
  }: {
    content: string;
    images?: string[];
    video?: string;
    videoThumbnail?: string;
    mediaItems?: PostMediaItem[];
    tags?: string[];
    pollQuestion?: string;
    pollOptions?: string[];
    feeling?: string;
    location?: string;
    bgm?: StoryBgm;
    visibility?: 'public' | 'followers';
    regionalScope?: RegionalScope;
    scheduledAt?: string;
  }) => {
    // 🛡️ Check Spam Word Filter
    const spamCheck = checkSpam(content, spamFilterSettings, 'posts');
    if (spamCheck.hasSpam) {
      setSpamFilterSettings((prev) => ({
        ...prev,
        stats: {
          ...prev.stats,
          totalBlockedCount:
            spamCheck.actionTaken === 'block'
              ? prev.stats.totalBlockedCount + 1
              : prev.stats.totalBlockedCount,
          totalMaskedCount:
            spamCheck.actionTaken === 'mask'
              ? prev.stats.totalMaskedCount + 1
              : prev.stats.totalMaskedCount,
          totalAutoBlindedCount:
            spamCheck.actionTaken === 'auto_blind'
              ? prev.stats.totalAutoBlindedCount + 1
              : prev.stats.totalAutoBlindedCount,
          lastDetectedKeyword: spamCheck.detectedWords[0],
          lastDetectedAt: new Date().toISOString()
        }
      }));

      if (spamCheck.actionTaken === 'block') {
        showToast(
          spamCheck.noticeMessage ||
            `🚫 스팸 키워드 [${spamCheck.detectedWords.join(', ')}]이(가) 포함되어 있어 게시할 수 없습니다.`,
          'error'
        );
        return {
          success: false,
          error: spamCheck.noticeMessage,
          detectedWords: spamCheck.detectedWords
        };
      }
    }

    const finalContent = spamCheck.actionTaken === 'mask' ? spamCheck.cleanText : content;
    const isAutoBlinded = spamCheck.actionTaken === 'auto_blind';

    // If a future schedule time is given, delegate to schedulePost
    if (scheduledAt && new Date(scheduledAt).getTime() > Date.now()) {
      schedulePost({
        content: finalContent,
        images,
        video,
        videoThumbnail,
        mediaItems,
        tags,
        pollQuestion,
        pollOptions,
        feeling,
        location,
        bgm,
        visibility,
        regionalScope: regionalScope || 'national',
        scheduledAt
      });
      return { success: true };
    }

    let pollData = undefined;
    if (pollQuestion && pollOptions && pollOptions.length >= 2) {
      pollData = {
        question: pollQuestion,
        options: pollOptions
          .filter((opt) => opt.trim().length > 0)
          .map((opt, idx) => ({
            id: `opt_${Date.now()}_${idx}`,
            text: opt.trim(),
            votes: []
          })),
        totalVotes: 0
      };
    }

    const resolvedImages = images && images.length > 0 ? images : (mediaItems ? mediaItems.filter(m => m.type === 'image').map(m => m.url) : undefined);
    const resolvedVideo = video || (mediaItems ? mediaItems.find(m => m.type === 'video')?.url : undefined);
    const resolvedVideoUrls = mediaItems
      ? mediaItems.filter(m => m.type === 'video').map(m => m.url)
      : (resolvedVideo ? [resolvedVideo] : undefined);
    const resolvedVideoThumbnail = videoThumbnail || (mediaItems ? mediaItems.find(m => m.type === 'video')?.thumbnail : undefined);

    const newPost: Post = {
      id: `post_${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorHandle: currentUser.handle,
      authorAvatar: currentUser.avatar,
      authorVerified: currentUser.isVerified,
      content: finalContent,
      images: resolvedImages && resolvedImages.length > 0 ? resolvedImages : undefined,
      video: resolvedVideo && resolvedVideo.trim().length > 0 ? resolvedVideo : undefined,
      videoUrls: resolvedVideoUrls && resolvedVideoUrls.length > 0 ? resolvedVideoUrls : undefined,
      videoThumbnail: resolvedVideoThumbnail && resolvedVideoThumbnail.trim().length > 0 ? resolvedVideoThumbnail : undefined,
      mediaItems: mediaItems && mediaItems.length > 0 ? mediaItems : undefined,
      tags: tags && tags.length > 0 ? tags : undefined,
      poll: pollData,
      feeling,
      location,
      bgm,
      createdAt: new Date().toISOString(),
      likes: [],
      bookmarks: [],
      reposts: [],
      commentsCount: 0,
      visibility,
      regionalScope: regionalScope || 'national',
      isBlocked: isAutoBlinded,
      blockReason: isAutoBlinded ? `스팸 키워드 감지 ([${spamCheck.detectedWords.join(', ')}])` : undefined,
      blockedBy: isAutoBlinded ? '시스템 자동 스팸 필터' : undefined
    };

    setPosts((prev) => [newPost, ...prev]);
    realtimeSync.createPost(newPost);

    if (isAutoBlinded) {
      showToast(
        `⚠️ 스팸 단어 [${spamCheck.detectedWords.join(', ')}]이(가) 감지되어 관리자 검토를 위해 자동 차단(블라인드) 처리되었습니다.`,
        'info'
      );
    } else if (spamCheck.actionTaken === 'mask') {
      showToast(
        `⚠️ 스팸 단어 [${spamCheck.detectedWords.join(', ')}]이(가) 감지되어 마스킹(***) 처리 후 안전하게 등록되었습니다.`,
        'info'
      );
    } else {
      showToast('게시물이 성공적으로 등록되었습니다.', 'success');
    }

    return { success: true };
  };

  const updatePost = (
    postId: string,
    updatedData: {
      content: string;
      images?: string[];
      video?: string;
      videoThumbnail?: string;
      mediaItems?: PostMediaItem[];
      tags?: string[];
      feeling?: string;
      location?: string;
      bgm?: StoryBgm | null;
      visibility?: 'public' | 'followers';
      regionalScope?: RegionalScope;
    }
  ) => {
    // 🛡️ Check Spam Filter for Post Update
    const spamCheck = checkSpam(updatedData.content, spamFilterSettings, 'posts');
    if (spamCheck.hasSpam) {
      setSpamFilterSettings((prev) => ({
        ...prev,
        stats: {
          ...prev.stats,
          totalBlockedCount:
            spamCheck.actionTaken === 'block'
              ? prev.stats.totalBlockedCount + 1
              : prev.stats.totalBlockedCount,
          totalMaskedCount:
            spamCheck.actionTaken === 'mask'
              ? prev.stats.totalMaskedCount + 1
              : prev.stats.totalMaskedCount,
          totalAutoBlindedCount:
            spamCheck.actionTaken === 'auto_blind'
              ? prev.stats.totalAutoBlindedCount + 1
              : prev.stats.totalAutoBlindedCount,
          lastDetectedKeyword: spamCheck.detectedWords[0],
          lastDetectedAt: new Date().toISOString()
        }
      }));

      if (spamCheck.actionTaken === 'block') {
        showToast(
          spamCheck.noticeMessage ||
            `🚫 스팸 키워드 [${spamCheck.detectedWords.join(', ')}]이(가) 포함되어 있어 수정할 수 없습니다.`,
          'error'
        );
        return;
      }
    }

    const finalContent = spamCheck.actionTaken === 'mask' ? spamCheck.cleanText : updatedData.content;
    const isAutoBlinded = spamCheck.actionTaken === 'auto_blind';

    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;
        const resolvedImages = updatedData.images && updatedData.images.length > 0
          ? updatedData.images
          : (updatedData.mediaItems ? updatedData.mediaItems.filter(m => m.type === 'image').map(m => m.url) : post.images);
        const resolvedVideo = updatedData.video !== undefined
          ? (updatedData.video.trim().length > 0 ? updatedData.video : undefined)
          : (updatedData.mediaItems ? updatedData.mediaItems.find(m => m.type === 'video')?.url : post.video);
        const resolvedVideoThumbnail = updatedData.videoThumbnail !== undefined
          ? (updatedData.videoThumbnail.trim().length > 0 ? updatedData.videoThumbnail : undefined)
          : (updatedData.mediaItems ? updatedData.mediaItems.find(m => m.type === 'video')?.thumbnail : post.videoThumbnail);
        const resolvedVideoUrls = updatedData.mediaItems !== undefined
          ? updatedData.mediaItems.filter(m => m.type === 'video').map(m => m.url)
          : (resolvedVideo ? [resolvedVideo] : post.videoUrls);

        return {
          ...post,
          content: finalContent,
          images: resolvedImages && resolvedImages.length > 0 ? resolvedImages : undefined,
          video: resolvedVideo,
          videoUrls: resolvedVideoUrls && resolvedVideoUrls.length > 0 ? resolvedVideoUrls : undefined,
          videoThumbnail: resolvedVideoThumbnail,
          mediaItems: updatedData.mediaItems !== undefined ? updatedData.mediaItems : post.mediaItems,
          tags: updatedData.tags && updatedData.tags.length > 0 ? updatedData.tags : undefined,
          feeling: updatedData.feeling,
          location: updatedData.location,
          bgm: updatedData.bgm !== undefined ? (updatedData.bgm || undefined) : post.bgm,
          visibility: updatedData.visibility || post.visibility,
          regionalScope: updatedData.regionalScope !== undefined ? updatedData.regionalScope : post.regionalScope,
          isEdited: true,
          isBlocked: isAutoBlinded ? true : post.isBlocked,
          blockReason: isAutoBlinded ? `스팸 키워드 감지 ([${spamCheck.detectedWords.join(', ')}])` : post.blockReason,
          blockedBy: isAutoBlinded ? '시스템 자동 스팸 필터' : post.blockedBy,
          updatedAt: new Date().toISOString()
        };
      })
    );

    if (isAutoBlinded) {
      showToast('⚠️ 수정 내용에서 스팸 단어가 감지되어 게시물이 자동 차단(블라인드) 처리되었습니다.', 'info');
    } else if (spamCheck.actionTaken === 'mask') {
      showToast('⚠️ 수정 내용의 스팸 단어가 마스킹(***) 처리되어 안전하게 저장되었습니다.', 'info');
    } else {
      showToast('게시물이 성공적으로 수정되었습니다.', 'success');
    }

    realtimeSync.updatePost(postId, {
      content: finalContent,
      images: updatedData.images && updatedData.images.length > 0 ? updatedData.images : undefined,
      video: updatedData.video && updatedData.video.trim().length > 0 ? updatedData.video : undefined,
      videoThumbnail:
        updatedData.videoThumbnail && updatedData.videoThumbnail.trim().length > 0
          ? updatedData.videoThumbnail
          : undefined,
      tags: updatedData.tags && updatedData.tags.length > 0 ? updatedData.tags : undefined,
      feeling: updatedData.feeling,
      location: updatedData.location,
      visibility: updatedData.visibility,
      regionalScope: updatedData.regionalScope,
      isEdited: true,
      updatedAt: new Date().toISOString()
    });
  };

  const deletePost = (postId: string) => {
    const target = posts.find((p) => p.id === postId);
    const isTargetAdmin = currentUser.isAdmin || currentUser.handle === 'admin';

    // 1. Immediately record in deletedPostIds
    setDeletedPostIds((prev) => {
      const updated = prev.includes(postId) ? prev : [...prev, postId];
      try {
        localStorage.setItem('social_deleted_post_ids', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    // 2. Remove from active posts and comments immediately
    setPosts((prev) => {
      const filtered = prev.filter((p) => p.id !== postId);
      try {
        localStorage.setItem('social_posts', JSON.stringify(filtered));
      } catch {}
      return filtered;
    });
    setComments((prev) => prev.filter((c) => c.postId !== postId));

    // 3. Sync deletion to server and other connected devices
    realtimeSync.deletePost(postId);

    if (isTargetAdmin) {
      showToast(
        `[관리자] ${target?.authorName ? `${target.authorName}님의 ` : ''}게시물이 영구 삭제되었습니다. 메인페이지에서 즉시 제외됩니다.`,
        'success'
      );
    } else {
      showToast('게시물이 삭제되었습니다.', 'info');
    }
  };

  const toggleBlockPost = (postId: string, reason: string = '운영 정책 및 커뮤니티 가이드라인 위반'): { success: boolean; isBlocked?: boolean } => {
    // 최고관리자만 게시물 차단/해제 가능
    const isSuperAdminAccount = isAuthenticated && (currentUser.isAdmin === true || currentUser.handle === 'admin');
    if (!isSuperAdminAccount) {
      showToast('게시물 차단 및 해제는 최고 관리자만 가능합니다.', 'error');
      return { success: false };
    }

    const target = posts.find((p) => p.id === postId);
    if (!target) {
      return { success: false };
    }

    const nextBlocked = !target.isBlocked;
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        return {
          ...p,
          isBlocked: nextBlocked,
          blockedAt: nextBlocked ? new Date().toISOString() : undefined,
          blockReason: nextBlocked ? reason : undefined,
          blockedBy: nextBlocked ? (currentUser.name || '최고 관리자') : undefined
        };
      })
    );
    realtimeSync.updatePost(postId, { isBlocked: nextBlocked });

    if (nextBlocked) {
      showToast(`[관리자 권한] 게시물이 차단(블라인드) 처리되었습니다.`, 'info');
    } else {
      showToast(`[관리자 권한] 게시물 차단이 해제되어 정상 공개되었습니다.`, 'success');
    }

    return { success: true, isBlocked: nextBlocked };
  };

  const simulateIncomingLike = (_targetPostId?: string) => {
    // Disabled to prevent artificial/fake likes
    showToast('가짜 좋아요 방지 정책에 의해 시뮬레이션 기능이 제한되었습니다.', 'info');
  };

  const toggleLike = (postId: string) => {
    if (!isAuthenticated) {
      showToast('로그인한 회원만 좋아요를 누를 수 있습니다.', 'info');
      setIsAuthModalOpen(true);
      return;
    }

    if (currentUser.isBanned) {
      showToast('이용 정지된 회원은 좋아요를 누를 수 없습니다.', 'error');
      return;
    }

    const targetPost = posts.find((p) => p.id === postId);
    if (!targetPost) {
      showToast('해당 게시물을 찾을 수 없습니다.', 'error');
      return;
    }

    // 1. Prevent self-like abuse (자신의 게시물 가짜 좋아요 방지)
    if (targetPost.authorId === currentUser.id) {
      showToast('자신의 게시물에는 좋아요를 누를 수 없습니다. (가짜 좋아요 방지)', 'info');
      return;
    }

    // 2. Anti-spam / Rapid click rate limiting (연타 매크로 어뷰징 방지)
    const now = Date.now();
    const lastTime = lastLikeTimestamp.current.get(postId) || 0;
    if (now - lastTime < 600) {
      showToast('요청이 너무 빠릅니다. 잠시 후 다시 시도해주세요.', 'info');
      return;
    }
    lastLikeTimestamp.current.set(postId, now);

    const hasLiked = targetPost.likes.includes(currentUser.id);
    const updatedLikes = hasLiked
      ? targetPost.likes.filter((id) => id !== currentUser.id)
      : [...targetPost.likes, currentUser.id];

    // 3. Update local post likes
    setPosts((prev) =>
      prev.map((post) => (post.id === postId ? { ...post, likes: updatedLikes } : post))
    );

    // 4. Sync to server in real-time (authoritative notification generated and broadcasted via SSE)
    realtimeSync.toggleLike(postId, currentUser.id, currentUser.name, currentUser.avatar);
  };

  const toggleBookmark = (postId: string) => {
    let wasBookmarked = false;
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;
        const hasBookmarked = post.bookmarks.includes(currentUser.id);
        wasBookmarked = hasBookmarked;
        const updatedBookmarks = hasBookmarked
          ? post.bookmarks.filter((id) => id !== currentUser.id)
          : [...post.bookmarks, currentUser.id];
        return { ...post, bookmarks: updatedBookmarks };
      })
    );

    // Sync in real-time across devices
    realtimeSync.toggleBookmark(postId, currentUser.id);

    if (!wasBookmarked) {
      showToast('게시물이 북마크에 저장되었습니다.', 'success');
    } else {
      showToast('북마크 저장이 취소되었습니다.', 'info');
    }
  };

  const clearAllBookmarks = () => {
    setPosts((prev) =>
      prev.map((post) => {
        if (!post.bookmarks?.includes(currentUser.id)) return post;
        return {
          ...post,
          bookmarks: post.bookmarks.filter((id) => id !== currentUser.id)
        };
      })
    );
    realtimeSync.clearBookmarks(currentUser.id);
    showToast('저장된 모든 북마크를 정리했습니다.', 'info');
  };

  const toggleRepost = (postId: string) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;
        const hasReposted = post.reposts.includes(currentUser.id);
        const updatedReposts = hasReposted
          ? post.reposts.filter((id) => id !== currentUser.id)
          : [...post.reposts, currentUser.id];

        if (!hasReposted && post.authorId !== currentUser.id) {
          const newNotif: Notification = {
            id: `notif_${Date.now()}`,
            recipientId: post.authorId,
            actorId: currentUser.id,
            actorName: currentUser.name,
            actorAvatar: currentUser.avatar,
            type: 'repost',
            postId: post.id,
            content: `회원님의 게시물을 리포스트했습니다.`,
            createdAt: new Date().toISOString(),
            isRead: false
          };
          setNotifications((n) => deduplicateNotifications([newNotif, ...n]));
        }

        return { ...post, reposts: updatedReposts };
      })
    );
  };

  const votePoll = (postId: string, optionId: string) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId || !post.poll) return post;

        const currentVotedOption = post.poll.options.find((opt) =>
          opt.votes?.includes(currentUser.id)
        );

        let updatedOptions = post.poll.options;

        if (currentVotedOption?.id === optionId) {
          // 클릭한 항목을 다시 클릭 시 투표 취소 (토글)
          updatedOptions = post.poll.options.map((opt) => {
            if (opt.id === optionId) {
              return { ...opt, votes: (opt.votes || []).filter((uid) => uid !== currentUser.id) };
            }
            return opt;
          });
        } else if (currentVotedOption) {
          // 다른 항목으로 투표 변경
          updatedOptions = post.poll.options.map((opt) => {
            if (opt.id === currentVotedOption.id) {
              return { ...opt, votes: (opt.votes || []).filter((uid) => uid !== currentUser.id) };
            }
            if (opt.id === optionId) {
              return { ...opt, votes: [...(opt.votes || []), currentUser.id] };
            }
            return opt;
          });
        } else {
          // 새로 투표 참여
          updatedOptions = post.poll.options.map((opt) => {
            if (opt.id === optionId) {
              return { ...opt, votes: [...(opt.votes || []), currentUser.id] };
            }
            return opt;
          });
        }

        const calculatedTotalVotes = updatedOptions.reduce(
          (acc, opt) => acc + (opt.votes?.length || 0),
          0
        );

        return {
          ...post,
          poll: {
            ...post.poll,
            options: updatedOptions,
            totalVotes: calculatedTotalVotes
          }
        };
      })
    );
  };

  const addComment = (
    postId: string,
    content: string,
    parentId?: string,
    audioUrl?: string,
    audioDuration?: number
  ) => {
    const trimmedContent = content.trim();
    if (!trimmedContent && !audioUrl) return;

    // 🛡️ Check Spam Filter for Comments
    const spamCheck = checkSpam(trimmedContent, spamFilterSettings, 'comments');
    if (spamCheck.hasSpam) {
      setSpamFilterSettings((prev) => ({
        ...prev,
        stats: {
          ...prev.stats,
          totalBlockedCount:
            spamCheck.actionTaken === 'block'
              ? prev.stats.totalBlockedCount + 1
              : prev.stats.totalBlockedCount,
          totalMaskedCount:
            spamCheck.actionTaken === 'mask'
              ? prev.stats.totalMaskedCount + 1
              : prev.stats.totalMaskedCount,
          totalAutoBlindedCount:
            spamCheck.actionTaken === 'auto_blind'
              ? prev.stats.totalAutoBlindedCount + 1
              : prev.stats.totalAutoBlindedCount,
          lastDetectedKeyword: spamCheck.detectedWords[0],
          lastDetectedAt: new Date().toISOString()
        }
      }));

      if (spamCheck.actionTaken === 'block') {
        showToast(
          spamCheck.noticeMessage ||
            `🚫 스팸 키워드 [${spamCheck.detectedWords.join(', ')}]이(가) 포함되어 있어 댓글을 등록할 수 없습니다.`,
          'error'
        );
        return;
      }
    }

    const finalCommentText =
      spamCheck.actionTaken === 'mask'
        ? spamCheck.cleanText
        : spamCheck.actionTaken === 'auto_blind'
        ? `[스팸 단어(${spamCheck.detectedWords.join(', ')}) 감지로 자동 숨김 처리된 댓글입니다]`
        : trimmedContent || (audioUrl ? '🎙️ 음성 댓글' : '');

    const newComment: Comment = {
      id: `comm_${Date.now()}`,
      postId,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorHandle: currentUser.handle,
      authorAvatar: currentUser.avatar,
      content: finalCommentText,
      createdAt: new Date().toISOString(),
      likes: [],
      parentId,
      audioUrl,
      audioDuration
    };

    setComments((prev) => [...prev, newComment]);
    realtimeSync.addComment(newComment);
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId ? { ...p, commentsCount: p.commentsCount + 1 } : p
      )
    );

    if (spamCheck.actionTaken === 'mask') {
      showToast('⚠️ 댓글의 스팸 단어가 마스킹(***) 처리되어 등록되었습니다.', 'info');
    } else if (spamCheck.actionTaken === 'auto_blind') {
      showToast('⚠️ 댓글에서 스팸 단어가 감지되어 블라인드 처리되었습니다.', 'info');
    } else {
      showToast(audioUrl ? '음성 댓글이 등록되었습니다! 🎙️' : '댓글이 성공적으로 등록되었습니다. 💬', 'success');
    }

    const post = posts.find((p) => p.id === postId);
    const commentSummary = audioUrl
      ? `음성 댓글을 남겼습니다 (${Math.round(audioDuration || 0)}초)`
      : `회원님의 게시물에 댓글을 남겼습니다: "${finalCommentText.slice(0, 30)}${finalCommentText.length > 30 ? '...' : ''}"`;

    // 1. Post author notification
    if (post && post.authorId !== currentUser.id) {
      const newNotif: Notification = {
        id: `notif_${Date.now()}_comm_${Math.random().toString(36).substring(2, 7)}`,
        recipientId: post.authorId,
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorAvatar: currentUser.avatar,
        type: 'comment',
        postId,
        commentId: newComment.id,
        content: commentSummary,
        createdAt: new Date().toISOString(),
        isRead: false
      };
      setNotifications((n) => deduplicateNotifications([newNotif, ...n]));
    } else if (post && post.authorId === currentUser.id && !parentId) {
      // Activity notification when commenting on own post
      const selfNotif: Notification = {
        id: `notif_${Date.now()}_selfcomm_${Math.random().toString(36).substring(2, 7)}`,
        recipientId: currentUser.id,
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorAvatar: currentUser.avatar,
        type: 'comment',
        postId,
        commentId: newComment.id,
        content: audioUrl
          ? `내 게시물에 음성 댓글을 등록했습니다 (${Math.round(audioDuration || 0)}초)`
          : `내 게시물에 새 댓글을 등록했습니다: "${finalCommentText.slice(0, 30)}${finalCommentText.length > 30 ? '...' : ''}"`,
        createdAt: new Date().toISOString(),
        isRead: false
      };
      setNotifications((n) => deduplicateNotifications([selfNotif, ...n]));
    }

    // 2. Parent comment author notification (reply)
    if (parentId) {
      const parentComment = comments.find((c) => c.id === parentId);
      if (
        parentComment &&
        parentComment.authorId &&
        parentComment.authorId !== currentUser.id &&
        parentComment.authorId !== post?.authorId
      ) {
        const replySummary = audioUrl
          ? `회원님의 댓글에 음성 답글을 남겼습니다 (${Math.round(audioDuration || 0)}초)`
          : `회원님의 댓글에 답글을 남겼습니다: "${finalCommentText.slice(0, 30)}${finalCommentText.length > 30 ? '...' : ''}"`;
        const replyNotif: Notification = {
          id: `notif_${Date.now()}_reply_${Math.random().toString(36).substring(2, 7)}`,
          recipientId: parentComment.authorId,
          actorId: currentUser.id,
          actorName: currentUser.name,
          actorAvatar: currentUser.avatar,
          type: 'comment',
          postId,
          commentId: newComment.id,
          content: replySummary,
          createdAt: new Date().toISOString(),
          isRead: false
        };
        setNotifications((n) => deduplicateNotifications([replyNotif, ...n]));
      }
    }
  };

  const toggleCommentLike = (commentId: string) => {
    realtimeSync.toggleCommentLike(commentId, currentUser.id);
    const targetComment = comments.find((c) => c.id === commentId);

    setComments((prev) =>
      prev.map((c) => {
        if (c.id !== commentId) return c;
        const hasLiked = c.likes.includes(currentUser.id);
        const updatedLikes = hasLiked
          ? c.likes.filter((id) => id !== currentUser.id)
          : [...c.likes, currentUser.id];
        return { ...c, likes: updatedLikes };
      })
    );

    // Real-time server sync handles like toggle and authoritative notification broadcast via SSE
  };

  const openStoryViewer = (userStory: UserStory) => {
    setActiveStoryUser(userStory);
    setActiveStoryIndex(0);
    // Mark as seen
    setStories((prev) =>
      prev.map((s) => (s.userId === userStory.userId ? { ...s, hasUnseen: false } : s))
    );
  };

  const closeStoryViewer = () => {
    setActiveStoryUser(null);
    setActiveStoryIndex(null);
  };

  const createStory = (
    mediaUrl: string,
    caption?: string,
    bgColor?: string,
    bgm?: StoryBgm,
    filterId?: string,
    textOverlays?: StoryTextOverlay[],
    stickerOverlays?: StoryStickerOverlay[],
    mediaType?: 'image' | 'video'
  ) => {
    let finalCaption = caption;

    if (caption && caption.trim()) {
      const spamCheck = checkSpam(caption.trim(), spamFilterSettings, 'stories');
      if (spamCheck.hasSpam) {
        setSpamFilterSettings((prev) => ({
          ...prev,
          stats: {
            ...prev.stats,
            totalBlockedCount:
              spamCheck.actionTaken === 'block'
                ? prev.stats.totalBlockedCount + 1
                : prev.stats.totalBlockedCount,
            totalMaskedCount:
              spamCheck.actionTaken === 'mask'
                ? prev.stats.totalMaskedCount + 1
                : prev.stats.totalMaskedCount,
            totalAutoBlindedCount:
              spamCheck.actionTaken === 'auto_blind'
                ? prev.stats.totalAutoBlindedCount + 1
                : prev.stats.totalAutoBlindedCount,
            lastDetectedKeyword: spamCheck.detectedWords[0],
            lastDetectedAt: new Date().toISOString()
          }
        }));

        if (spamCheck.actionTaken === 'block') {
          showToast(
            spamCheck.noticeMessage ||
              `🚫 스팸 키워드 [${spamCheck.detectedWords.join(', ')}]이(가) 포함되어 있어 스토리를 등록할 수 없습니다.`,
            'error'
          );
          return;
        }

        if (spamCheck.actionTaken === 'mask') {
          finalCaption = spamCheck.cleanText;
          showToast('⚠️ 스토리 캡션의 스팸 단어가 마스킹(***) 처리되었습니다.', 'info');
        }
      }
    }

    const isVideo =
      mediaType === 'video' ||
      /\.(mp4|mov|webm|mkv|3gp|avi|m4v)(\?.*)?$/i.test(mediaUrl) ||
      mediaUrl.startsWith('data:video/');

    const newStoryItem: StoryItem = {
      id: `st_${Date.now()}`,
      mediaUrl,
      mediaType: isVideo ? 'video' : 'image',
      caption: finalCaption,
      bgColor: bgColor || 'from-indigo-600 to-purple-800',
      createdAt: new Date().toISOString(),
      viewers: [],
      bgm,
      filterId: filterId || 'normal',
      textOverlays: textOverlays || [],
      stickerOverlays: stickerOverlays || []
    };

    setStories((prev) => {
      const existingUserStoryIndex = prev.findIndex((s) => s.userId === currentUser.id);
      if (existingUserStoryIndex >= 0) {
        const updated = [...prev];
        const prevItems = updated[existingUserStoryIndex].items.filter((it) => it.id !== newStoryItem.id);
        const updatedStory = {
          ...updated[existingUserStoryIndex],
          hasUnseen: true,
          items: [newStoryItem, ...prevItems]
        };
        updated[existingUserStoryIndex] = updatedStory;
        realtimeSync.createStory(updatedStory);
        return updated;
      } else {
        const newUserStory: UserStory = {
          userId: currentUser.id,
          userName: currentUser.name,
          userAvatar: currentUser.avatar,
          hasUnseen: true,
          items: [newStoryItem]
        };
        realtimeSync.createStory(newUserStory);
        return [newUserStory, ...prev];
      }
    });
  };

  const recordStoryItemView = (storyUserId: string, storyItemId: string) => {
    setStories((prev) => {
      const storyUserIndex = prev.findIndex((s) => s.userId === storyUserId);
      if (storyUserIndex === -1) return prev;

      const userStory = prev[storyUserIndex];
      const itemIndex = userStory.items.findIndex((it) => it.id === storyItemId);
      if (itemIndex === -1) return prev;

      const item = userStory.items[itemIndex];
      const currentViewers = item.viewers || [];

      // If the current user has already viewed this item, don't duplicate
      const alreadyViewed = currentViewers.some((v) => v.userId === currentUser.id);
      if (alreadyViewed) {
        return prev;
      }

      const newViewer: StoryViewer = {
        userId: currentUser.id,
        userName: currentUser.name,
        userHandle: currentUser.handle,
        userAvatar: currentUser.avatar,
        viewedAt: new Date().toISOString()
      };

      const updatedItems = [...userStory.items];
      updatedItems[itemIndex] = {
        ...item,
        viewers: [newViewer, ...currentViewers]
      };

      const updatedUserStory: UserStory = {
        ...userStory,
        items: updatedItems
      };

      const updatedStories = [...prev];
      updatedStories[storyUserIndex] = updatedUserStory;

      setActiveStoryUser((curActive) => {
        if (curActive && curActive.userId === storyUserId) {
          return updatedUserStory;
        }
        return curActive;
      });

      return updatedStories;
    });
  };

  const simulateFriendViewStory = (storyItemId: string) => {
    const otherUsers = users.filter((u) => u.id !== currentUser.id);
    if (otherUsers.length === 0) return;

    setStories((prev) => {
      const myStoryIndex = prev.findIndex((s) => s.userId === currentUser.id);
      if (myStoryIndex === -1) return prev;

      const myStory = prev[myStoryIndex];
      const itemIndex = myStory.items.findIndex((it) => it.id === storyItemId);
      if (itemIndex === -1) return prev;

      const item = myStory.items[itemIndex];
      const currentViewers = item.viewers || [];

      const unviewedUsers = otherUsers.filter(
        (u) => !currentViewers.some((v) => v.userId === u.id)
      );
      const chosenUser = unviewedUsers.length > 0
        ? unviewedUsers[Math.floor(Math.random() * unviewedUsers.length)]
        : otherUsers[Math.floor(Math.random() * otherUsers.length)];

      const durations = [3.2, 4.5, 4.9, 5.0, 2.8, 4.1, 5.0, 3.7];
      const randomDuration = durations[Math.floor(Math.random() * durations.length)];
      const completionRate = Math.min(100, Math.round((randomDuration / 5.0) * 100));
      const devices: ('mobile' | 'desktop' | 'tablet')[] = ['mobile', 'mobile', 'mobile', 'desktop', 'tablet'];
      const deviceType = devices[Math.floor(Math.random() * devices.length)];

      const newViewer: StoryViewer = {
        userId: chosenUser.id,
        userName: chosenUser.name,
        userHandle: chosenUser.handle,
        userAvatar: chosenUser.avatar,
        viewedAt: new Date().toISOString(),
        watchDurationSeconds: randomDuration,
        completionRate,
        deviceType
      };

      const updatedItems = [...myStory.items];
      updatedItems[itemIndex] = {
        ...item,
        viewers: [newViewer, ...currentViewers.filter((v) => v.userId !== chosenUser.id)]
      };

      const updatedMyStory: UserStory = {
        ...myStory,
        items: updatedItems
      };

      const updatedStories = [...prev];
      updatedStories[myStoryIndex] = updatedMyStory;

      setActiveStoryUser((curActive) => {
        if (curActive && curActive.userId === currentUser.id) {
          return updatedMyStory;
        }
        return curActive;
      });

      showToast(`${chosenUser.name}님이 회원님의 스토리를 방금 조회했습니다! 👀`, 'info');

      return updatedStories;
    });
  };

  const reactToStory = (
    storyUserId: string,
    storyItemId: string,
    emoji: string,
    emojiLabel?: string
  ) => {
    // Direct messages are not sent automatically to prevent fake/unwanted messages.
    // DMs are only sent when users explicitly write and submit a reply.

    // 1. Add Notification for the author if not own story
    if (storyUserId !== currentUser.id) {
      const newNotif: Notification = {
        id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        recipientId: storyUserId,
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorAvatar: currentUser.avatar,
        type: 'story_reaction',
        storyId: storyItemId,
        content: `스토리에 "${emoji} ${emojiLabel || ''}" 반응을 보냈습니다.`,
        createdAt: new Date().toISOString(),
        isRead: false
      };
      setNotifications((n) => deduplicateNotifications([newNotif, ...n]));
    }

    // 3. Record reaction on the story item & viewer
    setStories((prev) => {
      const storyUserIndex = prev.findIndex((s) => s.userId === storyUserId);
      if (storyUserIndex === -1) return prev;

      const userStory = prev[storyUserIndex];
      const itemIndex = userStory.items.findIndex((it) => it.id === storyItemId);
      if (itemIndex === -1) return prev;

      const item = userStory.items[itemIndex];
      const newReaction: StoryReaction = {
        id: `react_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        userId: currentUser.id,
        userName: currentUser.name,
        userAvatar: currentUser.avatar,
        emoji,
        createdAt: new Date().toISOString()
      };

      const currentReactions = item.reactions || [];
      const currentViewers = item.viewers || [];

      // Check if current user is in viewers, update reactionEmoji
      const hasViewer = currentViewers.some((v) => v.userId === currentUser.id);
      const updatedViewers = hasViewer
        ? currentViewers.map((v) =>
            v.userId === currentUser.id ? { ...v, reactionEmoji: emoji } : v
          )
        : [
            {
              userId: currentUser.id,
              userName: currentUser.name,
              userHandle: currentUser.handle,
              userAvatar: currentUser.avatar,
              viewedAt: new Date().toISOString(),
              reactionEmoji: emoji
            },
            ...currentViewers
          ];

      const updatedItems = [...userStory.items];
      updatedItems[itemIndex] = {
        ...item,
        reactions: [newReaction, ...currentReactions],
        viewers: updatedViewers
      };

      const updatedUserStory: UserStory = {
        ...userStory,
        items: updatedItems
      };

      const updatedStories = [...prev];
      updatedStories[storyUserIndex] = updatedUserStory;

      setActiveStoryUser((curActive) => {
        if (curActive && curActive.userId === storyUserId) {
          return updatedUserStory;
        }
        return curActive;
      });

      return updatedStories;
    });
  };

  const simulateFriendReactStory = (storyItemId: string, chosenEmoji?: string) => {
    const otherUsers = users.filter((u) => u.id !== currentUser.id);
    if (otherUsers.length === 0) return;

    const chosenUser = otherUsers[Math.floor(Math.random() * otherUsers.length)];
    const sampleEmojis = [
      { emoji: '❤️', label: '하트' },
      { emoji: '👍', label: '좋아요' },
      { emoji: '😂', label: '웃음' },
      { emoji: '🔥', label: '불꽃' },
      { emoji: '😍', label: '반함' },
      { emoji: '👏', label: '박수' },
      { emoji: '🎉', label: '축하' },
      { emoji: '😮', label: '놀람' },
      { emoji: '🙌', label: '만세' }
    ];
    const picked = sampleEmojis.find((s) => s.emoji === chosenEmoji) ||
      sampleEmojis[Math.floor(Math.random() * sampleEmojis.length)];
    const emoji = picked.emoji;
    const label = picked.label;

    // 1. Create Notification for the current user (story author)
    const newNotif: Notification = {
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      recipientId: currentUser.id,
      actorId: chosenUser.id,
      actorName: chosenUser.name,
      actorAvatar: chosenUser.avatar,
      type: 'story_reaction',
      storyId: storyItemId,
      content: `내 스토리에 "${emoji} ${label}" 빠른 반응을 남겼습니다!`,
      createdAt: new Date().toISOString(),
      isRead: false
    };
    setNotifications((n) => deduplicateNotifications([newNotif, ...n]));

    // 2. Update story reactions and viewer record (Do NOT send fake chat message)
    setStories((prev) => {
      const myStoryIndex = prev.findIndex((s) => s.userId === currentUser.id);
      if (myStoryIndex === -1) return prev;

      const myStory = prev[myStoryIndex];
      const itemIndex = myStory.items.findIndex((it) => it.id === storyItemId);
      if (itemIndex === -1) return prev;

      const item = myStory.items[itemIndex];
      const newReaction: StoryReaction = {
        id: `react_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        userId: chosenUser.id,
        userName: chosenUser.name,
        userAvatar: chosenUser.avatar,
        emoji,
        createdAt: new Date().toISOString()
      };

      const currentViewers = item.viewers || [];
      const hasViewer = currentViewers.some((v) => v.userId === chosenUser.id);
      const updatedViewers = hasViewer
        ? currentViewers.map((v) =>
            v.userId === chosenUser.id ? { ...v, reactionEmoji: emoji } : v
          )
        : [
            {
              userId: chosenUser.id,
              userName: chosenUser.name,
              userHandle: chosenUser.handle,
              userAvatar: chosenUser.avatar,
              viewedAt: new Date().toISOString(),
              reactionEmoji: emoji,
              watchDurationSeconds: 5.0,
              completionRate: 100,
              deviceType: 'mobile' as const
            },
            ...currentViewers
          ];

      const updatedItems = [...myStory.items];
      updatedItems[itemIndex] = {
        ...item,
        reactions: [newReaction, ...(item.reactions || [])],
        viewers: updatedViewers
      };

      const updatedMyStory: UserStory = {
        ...myStory,
        items: updatedItems
      };

      const updatedStories = [...prev];
      updatedStories[myStoryIndex] = updatedMyStory;

      setActiveStoryUser((curActive) => {
        if (curActive && curActive.userId === currentUser.id) {
          return updatedMyStory;
        }
        return curActive;
      });

      showToast(
        `${chosenUser.name}님이 회원님의 스토리에 ${emoji} 반응을 남겼습니다! 💌 (알림 도착)`,
        'success'
      );

      return updatedStories;
    });
  };

  const saveStoryDraft = (
    mediaUrl: string,
    caption?: string,
    bgColor?: string,
    bgm?: StoryBgm,
    draftId?: string,
    filterId?: string,
    textOverlays?: StoryTextOverlay[],
    stickerOverlays?: StoryStickerOverlay[],
    mediaType?: 'image' | 'video'
  ): string => {
    const finalId = draftId || `draft_${Date.now()}`;
    const isVideo =
      mediaType === 'video' ||
      /\.(mp4|mov|webm|mkv|3gp|avi|m4v)(\?.*)?$/i.test(mediaUrl) ||
      mediaUrl.startsWith('data:video/');

    const newDraft: StoryDraft = {
      id: finalId,
      mediaUrl,
      mediaType: isVideo ? 'video' : 'image',
      caption: caption?.trim() || undefined,
      bgColor: bgColor || 'from-indigo-600 to-purple-800',
      bgm,
      filterId: filterId || 'normal',
      textOverlays: textOverlays || [],
      stickerOverlays: stickerOverlays || [],
      savedAt: new Date().toISOString()
    };

    setStoryDrafts((prev) => {
      const existingIdx = prev.findIndex((d) => d.id === finalId);
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx] = newDraft;
        return updated;
      }
      return [newDraft, ...prev];
    });

    showToast('스토리 초안이 임시 저장되었습니다. 💾', 'success');
    return finalId;
  };

  const deleteStoryDraft = (id: string) => {
    setStoryDrafts((prev) => prev.filter((d) => d.id !== id));
    showToast('스토리 초안이 삭제되었습니다.', 'info');
  };

  const clearAllStoryDrafts = () => {
    setStoryDrafts([]);
    showToast('모든 스토리 초안이 삭제되었습니다.', 'info');
  };

  const sendMessage = (
    receiverId: string,
    content: string,
    mediaUrl?: string,
    replyTo?: MessageReplyInfo,
    isForwarded?: boolean
  ) => {
    if (!content.trim() && !mediaUrl) return;

    // 🛡️ Prevent self / fake message abuse (가짜 메시지 및 자가 발송 방지)
    if (receiverId === currentUser.id) {
      showToast('자신에게는 메시지를 보낼 수 없습니다. (가짜 메시지 방지)', 'info');
      return;
    }

    // 🛡️ Check Spam Filter for Direct Messages
    let finalMsgContent = content.trim();
    if (finalMsgContent) {
      const spamCheck = checkSpam(finalMsgContent, spamFilterSettings, 'messages');
      if (spamCheck.hasSpam) {
        setSpamFilterSettings((prev) => ({
          ...prev,
          stats: {
            ...prev.stats,
            totalBlockedCount:
              spamCheck.actionTaken === 'block'
                ? prev.stats.totalBlockedCount + 1
                : prev.stats.totalBlockedCount,
            totalMaskedCount:
              spamCheck.actionTaken === 'mask'
                ? prev.stats.totalMaskedCount + 1
                : prev.stats.totalMaskedCount,
            totalAutoBlindedCount:
              spamCheck.actionTaken === 'auto_blind'
                ? prev.stats.totalAutoBlindedCount + 1
                : prev.stats.totalAutoBlindedCount,
            lastDetectedKeyword: spamCheck.detectedWords[0],
            lastDetectedAt: new Date().toISOString()
          }
        }));

        if (spamCheck.actionTaken === 'block') {
          showToast(
            spamCheck.noticeMessage ||
              `🚫 스팸 키워드 [${spamCheck.detectedWords.join(', ')}]이(가) 포함되어 있어 메시지를 전송할 수 없습니다.`,
            'error'
          );
          return;
        }

        if (spamCheck.actionTaken === 'mask') {
          finalMsgContent = spamCheck.cleanText;
          showToast('⚠️ 메시지의 스팸 단어가 마스킹(***) 처리되었습니다.', 'info');
        }
      }
    }

    const newMsg: Message = {
      id: `msg_${Date.now()}`,
      senderId: currentUser.id,
      receiverId,
      content: finalMsgContent,
      mediaUrl,
      createdAt: new Date().toISOString(),
      isRead: false,
      replyTo,
      isForwarded
    };

    setMessages((prev) => [...prev, newMsg]);
    realtimeSync.sendMessage(newMsg);
  };

  const markConversationAsRead = (partnerId: string) => {
    setMessages((prev) => {
      const hasUnread = prev.some(
        (m) => m.senderId === partnerId && m.receiverId === currentUser.id && !m.isRead
      );
      if (!hasUnread) return prev;
      return prev.map((msg) =>
        msg.senderId === partnerId && msg.receiverId === currentUser.id && !msg.isRead
          ? { ...msg, isRead: true, readAt: msg.readAt || new Date().toISOString() }
          : msg
      );
    });
    // Link with real message read API
    realtimeSync.markConversationAsRead(partnerId, currentUser.id);
  };

  const markMessageAsRead = (messageId: string) => {
    setMessages((prev) => {
      const target = prev.find((m) => m.id === messageId);
      if (!target || target.isRead) return prev;
      return prev.map((msg) =>
        msg.id === messageId
          ? { ...msg, isRead: true, readAt: msg.readAt || new Date().toISOString() }
          : msg
      );
    });
    // Link with real message read API
    realtimeSync.markMessageAsRead(messageId, currentUser.id);
  };

  const markAllMessagesAsRead = () => {
    setMessages((prev) => {
      const hasUnread = prev.some((m) => m.receiverId === currentUser.id && !m.isRead);
      if (!hasUnread) return prev;
      return prev.map((msg) =>
        msg.receiverId === currentUser.id && !msg.isRead
          ? { ...msg, isRead: true, readAt: msg.readAt || new Date().toISOString() }
          : msg
      );
    });
    // Link with real message read API
    realtimeSync.markAllMessagesAsRead(currentUser.id);
  };

  const toggleStarMessage = (messageId: string) => {
    let nowStarred = false;
    setMessages((prev) =>
      prev.map((msg) => {
        if (msg.id === messageId) {
          nowStarred = !msg.isStarred;
          return {
            ...msg,
            isStarred: nowStarred,
            starredAt: nowStarred ? new Date().toISOString() : undefined
          };
        }
        return msg;
      })
    );
    realtimeSync.toggleStarMessage(messageId);
    showToast(
      nowStarred ? '⭐ 메시지를 즐겨찾기에 보관했습니다.' : '메시지 즐겨찾기를 해제했습니다.',
      'info'
    );
  };

  const simulateIncomingMessage = () => {
    // Disabled to prevent fake messages (가짜 메시지 발송 방지 정책)
    showToast('가짜 메시지 방지 정책에 의해 메시지 시뮬레이션 기능이 차단되었습니다.', 'info');
  };

  const unreadNotificationsCount = deduplicateNotifications(notifications).filter(
    (n) => n.recipientId === currentUser.id && !n.isRead
  ).length;

  const unreadMessagesCount = messages.filter(
    (m) => m.receiverId === currentUser.id && !m.isRead
  ).length;

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) =>
      prev.map((n) => (n.recipientId === currentUser.id ? { ...n, isRead: true } : n))
    );
  };

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    showToast('알림이 삭제되었습니다.', 'info');
  };

  const deleteAllNotifications = () => {
    setNotifications((prev) => prev.filter((n) => n.recipientId !== currentUser.id));
    showToast('모든 알림이 삭제되었습니다.', 'success');
  };

  const isFollowingTopic = (topicTag: string): boolean => {
    const cleanTag = topicTag.replace(/^#/, '').trim();
    return followedTopics.includes(cleanTag);
  };

  const toggleFollowTopic = (topicTag: string) => {
    const cleanTag = topicTag.replace(/^#/, '').trim();
    if (!cleanTag) return;

    const isCurrentlyFollowing = followedTopics.includes(cleanTag);
    if (isCurrentlyFollowing) {
      setFollowedTopics((prev) => prev.filter((t) => t !== cleanTag));
      showToast(`'#${cleanTag}' 트렌드 구독을 취소했습니다.`, 'info');
    } else {
      setFollowedTopics((prev) => [...prev, cleanTag]);
      showToast(`'#${cleanTag}' 트렌드를 팔로우했습니다! 새로운 소식을 받아봅니다.`, 'success');
    }
  };

  return (
    <SocialContext.Provider
      value={{
        currentUser,
        users,
        kickedUsers,
        authNotice,
        dismissAuthNotice,
        posts,
        deletedPostIds,
        comments,
        stories,
        messages,
        notifications,
        activeTab,
        setActiveTab,
        activeTag,
        setActiveTag,
        searchQuery,
        setSearchQuery,
        viewingUserId,
        setViewingUserId,
        isAuthenticated,
        login,
        loginWithEmailCode,
        signup,
        sendSmsVerificationCode,
        verifySmsCode,
        smsGatewayInfo,
        refreshSmsGatewayStatus,
        smsApiConfig,
        isLoadingSmsConfig,
        fetchSmsApiConfig,
        updateSmsApiConfig,
        resetSmsApiConfig,
        testSmsApiConnection,
        smsDbRecords,
        smsDbStats,
        isLoadingSmsDb,
        fetchSmsDbRecords,
        insertSmsDbRecord,
        verifySmsDbRecordManual,
        deleteSmsDbRecord,
        clearSmsDbRecords,
        sendEmailVerificationCode,
        verifyEmailCode,
        emailGatewayInfo,
        refreshEmailGatewayStatus,
        signupAuthConfig,
        updateSignupAuthConfig,
        terminateSession,
        logout,
        isAuthModalOpen,
        setIsAuthModalOpen,
        authModalMode,
        setAuthModalMode,
        openAuthModal,
        closeAuthModal,
        findUserIdentifier,
        sendResetPasswordCode,
        verifyResetPasswordCode,
        resetUserPassword,
        isEditSignupInfoModalOpen,
        openEditSignupInfoModal,
        closeEditSignupInfoModal,
        updateSignupInfo,
        toast,
        showToast,
        scheduledPosts,
        createPost,
        schedulePost,
        cancelScheduledPost,
        publishScheduledPostNow,
        updatePost,
        deletePost,
        toggleLike,
        simulateIncomingLike,
        toggleBookmark,
        clearAllBookmarks,
        toggleRepost,
        votePoll,
        addComment,
        toggleCommentLike,
        activeStoryIndex,
        activeStoryUser,
        openStoryViewer,
        closeStoryViewer,
        createStory,
        switchUser,
        toggleFollow,
        updateProfile,
        deleteUser,
        restoreUser,
        toggleBanUser,
        resetUsersToInitial,
        toggleBlockPost,
        isSuperAdminDbUnlocked,
        unlockSuperAdminDatabase,
        lockSuperAdminDatabase,
        apiKeysRecords,
        updateDatabaseRecord,
        insertDatabaseRecord,
        deleteDatabaseRecord,
        replaceDatabaseTable,
        importFullDatabase,
        resetFullDatabaseToInitial,
        getFullDatabaseBackup,
        activeChatUserId,
        setActiveChatUserId,
        sendMessage,
        markConversationAsRead,
        markMessageAsRead,
        markAllMessagesAsRead,
        toggleStarMessage,
        simulateIncomingMessage,
        unreadNotificationsCount,
        unreadMessagesCount,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        deleteNotification,
        deleteAllNotifications,
        recordStoryItemView,
        simulateFriendViewStory,
        reactToStory,
        simulateFriendReactStory,
        storyDrafts,
        saveStoryDraft,
        deleteStoryDraft,
        clearAllStoryDrafts,
        isCreateStoryOpen,
        selectedDraftForEdit,
        openCreateStoryModal,
        closeCreateStoryModal,
        setSelectedDraftForEdit,
        followedTopics,
        toggleFollowTopic,
        isFollowingTopic,
        themeMode,
        systemPrefersDark,
        setThemeMode,
        isDarkMode,
        toggleDarkMode,
        systemThemeNotice,
        dismissSystemThemeNotice,
        triggerSystemThemeNotice,
        spamFilterSettings,
        updateSpamFilterSettings,
        addSpamKeywords,
        removeSpamKeyword,
        resetSpamKeywordsToDefault,
        clearAllSpamKeywords,
        resetSpamStats,
        runSpamCheck
      }}
    >
      {children}
    </SocialContext.Provider>
  );
};

export const useSocial = () => {
  const context = useContext(SocialContext);
  if (!context) {
    throw new Error('useSocial must be used within a SocialProvider');
  }
  return context;
};
