import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { useSocial } from '../context/SocialContext';
import { User, Post, KickedUserRecord } from '../types';
import { EditPostModal } from './EditPostModal';
import { DatabaseManagementView } from './DatabaseManagementView';
import { SpamFilterManagementView } from './SpamFilterManagementView';
import { SignupAuthSettingsView } from './SignupAuthSettingsView';
import {
  ShieldAlert,
  UserX,
  Calendar,
  Search,
  Filter,
  Users,
  AlertTriangle,
  CheckCircle2,
  Trash2,
  Ban,
  RotateCcw,
  Sparkles,
  MapPin,
  Mail,
  Smartphone,
  AtSign,
  Clock,
  ShieldCheck,
  Eye,
  Info,
  FileText,
  ExternalLink,
  Edit3,
  Database,
  Shield,
  Zap,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  ArrowLeftRight,
  Globe
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    users,
    kickedUsers,
    posts,
    currentUser,
    deleteUser,
    restoreUser,
    toggleBanUser,
    resetUsersToInitial,
    deletePost,
    toggleBlockPost,
    setViewingUserId,
    setActiveTab,
    showToast,
    spamFilterSettings,
    signupAuthConfig,
    updateSignupAuthConfig,
    smsDbStats
  } = useSocial();

  const [dashboardTab, setDashboardTab] = useState<'users' | 'posts' | 'auth_policy' | 'spam_filter' | 'database'>('users');
  const [postSearchTerm, setPostSearchTerm] = useState('');
  const [postFilter, setPostFilter] = useState<'all' | 'blocked' | 'normal'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'today' | 'active' | 'banned' | 'kicked'>('today');
  const [selectedUserForKick, setSelectedUserForKick] = useState<User | null>(null);
  const [selectedUserForRestore, setSelectedUserForRestore] = useState<KickedUserRecord | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);
  const [kickReason, setKickReason] = useState('커뮤니티 가이드라인 및 운영 정책 위반');
  const [customKickReason, setCustomKickReason] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [selectedUserForBan, setSelectedUserForBan] = useState<User | null>(null);
  const [banReason, setBanReason] = useState('스팸 및 불법 광고 홍보');
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [editingPost, setEditingPost] = useState<Post | null>(null);
  const [postForBlock, setPostForBlock] = useState<Post | null>(null);
  const [blockReasonInput, setBlockReasonInput] = useState('운영 정책 및 커뮤니티 가이드라인 위반');
  const [postForDelete, setPostForDelete] = useState<Post | null>(null);
  const [isDeletingPost, setIsDeletingPost] = useState(false);

  // Horizontal scroll ref and handler for top admin dashboard tabs
  const tabsScrollRef = useRef<HTMLDivElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const updateScrollState = () => {
    if (tabsScrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = tabsScrollRef.current;
      const maxScroll = scrollWidth - clientWidth;
      if (maxScroll > 0) {
        setScrollProgress(Math.min(100, Math.max(0, Math.round((scrollLeft / maxScroll) * 100))));
        setCanScrollLeft(scrollLeft > 4);
        setCanScrollRight(scrollLeft < maxScroll - 4);
      } else {
        setScrollProgress(0);
        setCanScrollLeft(false);
        setCanScrollRight(false);
      }
    }
  };

  useEffect(() => {
    updateScrollState();
    const el = tabsScrollRef.current;
    if (el) {
      el.addEventListener('scroll', updateScrollState, { passive: true });
      window.addEventListener('resize', updateScrollState);
      return () => {
        el.removeEventListener('scroll', updateScrollState);
        window.removeEventListener('resize', updateScrollState);
      };
    }
  }, []);

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setScrollProgress(val);
    if (tabsScrollRef.current) {
      const { scrollWidth, clientWidth } = tabsScrollRef.current;
      const maxScroll = scrollWidth - clientWidth;
      if (maxScroll > 0) {
        tabsScrollRef.current.scrollLeft = (val / 100) * maxScroll;
      }
    }
  };

  const scrollTabs = (direction: 'left' | 'right') => {
    if (tabsScrollRef.current) {
      tabsScrollRef.current.scrollBy({
        left: direction === 'left' ? -320 : 320,
        behavior: 'smooth',
      });
      setTimeout(updateScrollState, 150);
    }
  };

  // Helper to test if a user signed up "Today"
  const isSignedUpToday = (user: User): boolean => {
    if (!user.createdAt) {
      // Check joinedDate string
      return user.joinedDate?.includes('오늘') || false;
    }
    const createdDate = new Date(user.createdAt);
    if (isNaN(createdDate.getTime())) {
      return user.joinedDate?.includes('오늘') || false;
    }
    const today = new Date();
    return (
      createdDate.getFullYear() === today.getFullYear() &&
      createdDate.getMonth() === today.getMonth() &&
      createdDate.getDate() === today.getDate()
    );
  };

  // Memoized check to guarantee kicked users never appear in active lists
  const kickedSet = useMemo(() => {
    const ids = new Set((kickedUsers || []).map((k) => k.id));
    const handles = new Set((kickedUsers || []).map((k) => (k.handle || '').toLowerCase().replace(/^@/, '')));
    const emails = new Set((kickedUsers || []).map((k) => (k.email || '').toLowerCase().trim()).filter(Boolean));
    return { ids, handles, emails };
  }, [kickedUsers]);

  const isUserKicked = useCallback(
    (u: User) => {
      if (kickedSet.ids.has(u.id)) return true;
      if (kickedSet.handles.has((u.handle || '').toLowerCase().replace(/^@/, ''))) return true;
      if (u.email && kickedSet.emails.has(u.email.toLowerCase().trim())) return true;
      return false;
    },
    [kickedSet]
  );

  // Pure non-kicked members list
  const activeMembers = useMemo(() => {
    return users.filter((u) => !isUserKicked(u));
  }, [users, isUserKicked]);

  // Filtered and searched users
  const todayUsers = useMemo(() => {
    return activeMembers.filter((u) => !u.isAdmin && u.handle !== 'admin' && isSignedUpToday(u));
  }, [activeMembers]);

  const normalActiveUsers = useMemo(() => {
    return activeMembers.filter((u) => !u.isBanned);
  }, [activeMembers]);

  const bannedUsers = useMemo(() => {
    return activeMembers.filter((u) => !!u.isBanned);
  }, [activeMembers]);

  const filteredUsers = useMemo(() => {
    return activeMembers.filter((user) => {
      // Search filter
      const matchesSearch =
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.handle.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (user.email && user.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (user.location && user.location.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (user.role && user.role.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (user.signupIp && user.signupIp.toLowerCase().includes(searchTerm.toLowerCase()));

      if (!matchesSearch) return false;

      if (filterType === 'today') {
        return isSignedUpToday(user) && !user.isAdmin && user.handle !== 'admin';
      }
      if (filterType === 'active') {
        return !user.isBanned;
      }
      if (filterType === 'banned') {
        return !!user.isBanned;
      }
      return true; // 'all'
    });
  }, [activeMembers, searchTerm, filterType]);

  // Filtered kicked users
  const filteredKickedUsers = useMemo(() => {
    return (kickedUsers || []).filter((k) => {
      return (
        k.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        k.handle.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (k.email && k.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (k.reason && k.reason.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (k.signupIp && k.signupIp.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    });
  }, [kickedUsers, searchTerm]);

  // Filtered and searched posts for moderation
  const filteredPosts = useMemo(() => {
    return posts.filter((p) => {
      const matchesSearch =
        p.content.toLowerCase().includes(postSearchTerm.toLowerCase()) ||
        p.authorName.toLowerCase().includes(postSearchTerm.toLowerCase()) ||
        p.authorHandle.toLowerCase().includes(postSearchTerm.toLowerCase()) ||
        (p.tags && p.tags.some((t) => t.toLowerCase().includes(postSearchTerm.toLowerCase())));

      if (!matchesSearch) return false;

      if (postFilter === 'blocked') {
        return !!p.isBlocked;
      }
      if (postFilter === 'normal') {
        return !p.isBlocked;
      }
      return true; // 'all'
    });
  }, [posts, postSearchTerm, postFilter]);

  // Handle Execute Kick (Force Delete)
  const handleConfirmKick = () => {
    if (!selectedUserForKick) return;
    setIsDeleting(true);

    const finalReason = kickReason === 'custom' ? customKickReason.trim() : kickReason;

    setTimeout(() => {
      const res = deleteUser(selectedUserForKick.id, finalReason);
      setIsDeleting(false);
      if (res.success) {
        setSelectedUserForKick(null);
        setCustomKickReason('');
      } else {
        showToast(res.error || '탈퇴 처리에 실패했습니다.', 'error');
      }
    }, 400);
  };

  // Handle Execute Restore for Kicked Member
  const handleConfirmRestore = () => {
    if (!selectedUserForRestore) return;
    setIsRestoring(true);

    setTimeout(() => {
      const res = restoreUser(selectedUserForRestore.id);
      setIsRestoring(false);
      if (res.success) {
        setSelectedUserForRestore(null);
      } else {
        showToast(res.error || '계정 복원에 실패했습니다.', 'error');
      }
    }, 300);
  };

  // Handle Toggle Ban
  const handleConfirmBan = () => {
    if (!selectedUserForBan) return;
    const res = toggleBanUser(selectedUserForBan.id, banReason);
    if (res.success) {
      setSelectedUserForBan(null);
    }
  };

  const formatRegistrationDate = (user: User) => {
    if (user.createdAt) {
      const d = new Date(user.createdAt);
      if (!isNaN(d.getTime())) {
        return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
      }
    }
    return user.joinedDate || '기록 없음';
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Admin Banner Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 md:p-8 text-white shadow-xl border border-indigo-900/40">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-bold border border-indigo-400/30">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>시스템 관리자 전용 포털</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
              회원 관리 및 보안 대시보드
            </h1>
            <p className="text-slate-300 text-xs md:text-sm max-w-xl">
              오늘 가입한 신규 회원 현황을 확인하고, 불량 이용자나 스팸 계정을 즉시 <strong>강제 탈퇴</strong> 및 <strong>이용 정지</strong> 처리할 수 있습니다.
            </p>
          </div>

          {/* Quick Stats Widget */}
          <div className="flex items-center gap-3 overflow-x-auto pb-2 max-w-full admin-horizontal-scroll">
            <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-center min-w-24 shrink-0">
              <span className="text-xs text-slate-300 font-medium block">오늘 가입 회원</span>
              <span className="text-2xl font-black text-amber-300 mt-0.5 block">{todayUsers.length}명</span>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-center min-w-24 shrink-0">
              <span className="text-xs text-slate-300 font-medium block">전체 가입자</span>
              <span className="text-2xl font-black text-white mt-0.5 block">{users.length}명</span>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-center min-w-24 shrink-0">
              <span className="text-xs text-slate-300 font-medium block">차단된 게시물</span>
              <span className="text-2xl font-black text-rose-300 mt-0.5 block">
                {posts.filter(p => p.isBlocked).length}개
              </span>
            </div>
          </div>
        </div>

        {/* Dashboard Section Tabs: 회원 관리 vs 게시물 모니터링/관리 (좌우 가로 스크롤바 지원) */}
        <div className="mt-6 pt-4 border-t border-indigo-800/40 space-y-3">
          {/* Scroll Guide & Left/Right Action Buttons */}
          <div className="flex items-center justify-between gap-2 text-xs text-indigo-200">
            <div className="flex items-center gap-2 font-bold text-xs text-indigo-300">
              <ArrowLeftRight className="w-4 h-4 text-indigo-400 shrink-0" />
              <span>대시보드 기능 메뉴 (좌우 스크롤바 ◀ ▶)</span>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-indigo-500/20 text-[10px] text-indigo-300 border border-indigo-400/20">
                스크롤 위치 {scrollProgress}%
              </span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => scrollTabs('left')}
                disabled={!canScrollLeft}
                title="왼쪽 메뉴 보기 (320px 이동)"
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-xs active:scale-95 ${
                  canScrollLeft
                    ? 'bg-indigo-600 hover:bg-indigo-500 text-white border border-indigo-400/40'
                    : 'bg-indigo-950/60 text-slate-500 border border-indigo-900/30 opacity-60 cursor-not-allowed'
                }`}
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>◀ 이전</span>
              </button>
              <button
                type="button"
                onClick={() => scrollTabs('right')}
                disabled={!canScrollRight}
                title="오른쪽 메뉴 보기 (320px 이동)"
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shadow-xs active:scale-95 ${
                  canScrollRight
                    ? 'bg-indigo-600 hover:bg-indigo-500 text-white border border-indigo-400/40'
                    : 'bg-indigo-950/60 text-slate-500 border border-indigo-900/30 opacity-60 cursor-not-allowed'
                }`}
              >
                <span>다음 ▶</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Horizontal Scrollable Tabs Track with customized visible scrollbar */}
          <div
            ref={tabsScrollRef}
            className="admin-horizontal-scroll pb-2.5 pt-1 scroll-smooth focus:outline-none"
          >
            <div className="flex items-center gap-2.5 min-w-max pr-4">
              <button
                type="button"
                onClick={() => setDashboardTab('users')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  dashboardTab === 'users'
                    ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/40'
                    : 'bg-white/10 text-slate-300 hover:bg-white/15'
                }`}
              >
                <Users className="w-4 h-4 shrink-0" />
                <span>회원 관리 & 당일 가입 ({users.length})</span>
              </button>
              <button
                type="button"
                onClick={() => setDashboardTab('posts')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  dashboardTab === 'posts'
                    ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/40'
                    : 'bg-white/10 text-slate-300 hover:bg-white/15'
                }`}
              >
                <FileText className="w-4 h-4 shrink-0" />
                <span>게시물 수정 · 차단 · 삭제 관리 ({posts.length})</span>
                {posts.filter(p => p.isBlocked).length > 0 && (
                  <span className="px-1.5 py-0.2 bg-amber-400 text-slate-950 text-[10px] font-black rounded-full shrink-0">
                    {posts.filter(p => p.isBlocked).length}건 차단됨
                  </span>
                )}
              </button>
              <button
                type="button"
                id="admin-tab-auth-policy"
                onClick={() => setDashboardTab('auth_policy')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  dashboardTab === 'auth_policy'
                    ? 'bg-emerald-600 text-white shadow-md ring-2 ring-emerald-400/40'
                    : 'bg-white/10 text-slate-300 hover:bg-white/15'
                }`}
              >
                <Smartphone className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>휴대폰 SMS 본인인증 & API · DB 설정</span>
                <span className="px-1.5 py-0.2 bg-emerald-400 text-slate-950 text-[10px] font-black rounded-full shrink-0">
                  {signupAuthConfig?.verificationMethod === 'none' ? '간편 가입' : 'SMS 문자 인증'}
                  {smsDbStats && ` · DB ${smsDbStats.total}건`}
                </span>
              </button>
              <button
                type="button"
                onClick={() => setDashboardTab('spam_filter')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  dashboardTab === 'spam_filter'
                    ? 'bg-rose-600 text-white shadow-md ring-2 ring-rose-400/40'
                    : 'bg-white/10 text-slate-300 hover:bg-white/15'
                }`}
              >
                <Shield className="w-4 h-4 text-rose-300 shrink-0" />
                <span>스팸단어 필터링 설정</span>
                {spamFilterSettings?.isEnabled ? (
                  <span className="px-1.5 py-0.2 bg-rose-500/80 text-white text-[10px] font-black rounded-full shrink-0">
                    {spamFilterSettings.keywords.length}개 키워드 작동중
                  </span>
                ) : (
                  <span className="px-1.5 py-0.2 bg-slate-500 text-slate-200 text-[10px] font-bold rounded-full shrink-0">
                    비활성
                  </span>
                )}
              </button>
              <button
                type="button"
                onClick={() => setDashboardTab('database')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  dashboardTab === 'database'
                    ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/40'
                    : 'bg-white/10 text-slate-300 hover:bg-white/15'
                }`}
              >
                <Database className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>데이타베이스(DB) 직접 수정 콘솔</span>
                <span className="px-1.5 py-0.2 bg-emerald-400 text-slate-950 text-[10px] font-black rounded-full shrink-0">
                  마스터
                </span>
              </button>
              <button
                type="button"
                id="admin-tab-bookmarks-link"
                onClick={() => setActiveTab('bookmarks')}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer bg-white/10 text-indigo-300 hover:bg-white/15 border border-indigo-400/30"
              >
                <Bookmark className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>북마크 관리 & 전체 회원 보관함 ↗</span>
              </button>
            </div>
          </div>

          {/* Interactive Dedicated Horizontal Scrollbar Slider Bar */}
          <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-slate-950/50 border border-indigo-500/20 backdrop-blur-xs">
            <span className="text-[11px] font-bold text-indigo-300 whitespace-nowrap flex items-center gap-1 shrink-0">
              <ChevronLeft className="w-3.5 h-3.5 text-indigo-400" />
              <span>좌우 스크롤바:</span>
            </span>
            <div className="flex-1 relative flex items-center">
              <input
                type="range"
                min="0"
                max="100"
                value={scrollProgress}
                onChange={handleSliderChange}
                aria-label="상단 메뉴 가로 스크롤 조절 바"
                title={`메뉴 좌우 스크롤 (현재: ${scrollProgress}%)`}
                className="w-full h-2 bg-indigo-950 rounded-full appearance-none cursor-ew-resize accent-indigo-400 focus:outline-none focus:ring-2 focus:ring-indigo-400/50 transition-all hover:bg-indigo-900/80"
              />
            </div>
            <span className="text-[11px] font-bold text-indigo-300 whitespace-nowrap flex items-center gap-1 shrink-0">
              <span className="text-[10px] text-indigo-400 font-mono">[{scrollProgress}%]</span>
              <ChevronRight className="w-3.5 h-3.5 text-indigo-400" />
            </span>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* TAB 1: USER MANAGEMENT (회원 관리 & 오늘 가입 회원)            */}
      {/* ============================================================ */}
      {dashboardTab === 'users' && (
        <>
          {/* Quick Verification Policy Switcher Widget for Admin */}
          <div className="rounded-2xl border border-emerald-200/80 bg-gradient-to-r from-emerald-50/90 via-slate-50/60 to-white dark:from-slate-900 dark:via-emerald-950/40 dark:to-slate-900 p-4 shadow-xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-xs shrink-0">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-black text-slate-900 dark:text-white">
                      회원가입 본인인증 수단 정책
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-600 text-white shadow-xs">
                      {signupAuthConfig?.verificationMethod === 'none'
                        ? '⚡ 간편 가입 모드 (인증 생략)'
                        : '📱 휴대폰 SMS 문자 본인인증 [적용 중]'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    이메일 인증을 없애고 <strong>휴대폰 SMS 문자 6자리 코드 본인인증</strong>을 단독 인증 수단으로 설정하여 운영 중입니다.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap shrink-0">
                <button
                  type="button"
                  id="admin-quick-switch-sms-btn"
                  onClick={() => updateSignupAuthConfig({ verificationMethod: 'sms' })}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    signupAuthConfig?.verificationMethod !== 'none'
                      ? 'bg-emerald-600 text-white shadow-xs ring-2 ring-emerald-500/30'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>SMS 본인인증 활성화</span>
                </button>
                <button
                  type="button"
                  id="admin-quick-switch-none-btn"
                  onClick={() => updateSignupAuthConfig({ verificationMethod: 'none' })}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    signupAuthConfig?.verificationMethod === 'none'
                      ? 'bg-slate-700 text-white shadow-xs ring-2 ring-slate-500/30'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>간편 가입 모드</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDashboardTab('auth_policy')}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-100/70 dark:bg-emerald-950/60 hover:bg-emerald-200 transition-colors cursor-pointer"
                >
                  SMS API · DB 상세 설정 ⚙️
                </button>
              </div>
            </div>
          </div>

          {/* Primary Highlights: Today's New Registrations Banner */}
          <div className="rounded-2xl border border-amber-200 bg-amber-50/70 p-4 sm:p-5 dark:border-amber-900/50 dark:bg-amber-950/20 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-200/60 dark:border-amber-900/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500 text-white rounded-xl shadow-xs">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-amber-950 dark:text-amber-200 flex items-center gap-2">
                오늘 신규 회원가입자 현황
                <span className="px-2 py-0.5 text-xs font-extrabold bg-amber-500 text-white rounded-full">
                  {todayUsers.length}명
                </span>
              </h2>
              <p className="text-xs text-amber-800/80 dark:text-amber-300/80 mt-0.5">
                당일 가입한 회원들의 계정 활동 및 프로필 정보를 신속하게 모니터링하세요.
              </p>
            </div>
          </div>

          <button
            onClick={() => setFilterType('today')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterType === 'today'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-800 text-amber-900 dark:text-amber-200 border border-amber-200 dark:border-amber-800 hover:bg-amber-100'
            }`}
          >
            오늘 가입자만 필터링
          </button>
        </div>

        {todayUsers.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
            오늘 새롭게 가입한 회원이 없습니다.
          </div>
        ) : (
          <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3">
            {todayUsers.map((u) => (
              <div
                key={u.id}
                className="flex items-center justify-between gap-3 p-3 bg-white dark:bg-slate-900 rounded-xl border border-amber-200/80 dark:border-amber-900/40 shadow-xs"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <img
                    src={u.avatar}
                    alt={u.name}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-bold text-slate-900 dark:text-white truncate">
                        {u.name}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300 font-bold rounded">
                        NEW 오늘가입
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 truncate">@{u.handle} • {u.email || '이메일 미기재'}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                      <Clock className="w-3 h-3 text-amber-500" />
                      <span>가입: {formatRegistrationDate(u)}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => {
                      setViewingUserId(u.id);
                      setActiveTab('profile');
                    }}
                    title="프로필 보기"
                    className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setSelectedUserForKick(u)}
                    title="강제 탈퇴"
                    className="px-2.5 py-1.5 bg-rose-50 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-900/60 rounded-lg text-xs font-bold transition-colors flex items-center gap-1 border border-rose-200 dark:border-rose-900/60"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>강제탈퇴</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main Filter & Search Control Toolbar */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="이름, 아이디(@handle), 이메일, 지역 또는 역할 검색..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                filterType === 'all'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                  : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              전체 ({activeMembers.length})
            </button>
            <button
              onClick={() => setFilterType('today')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap flex items-center gap-1 ${
                filterType === 'today'
                  ? 'bg-amber-600 text-white'
                  : 'bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400 hover:bg-amber-100'
              }`}
            >
              <Sparkles className="w-3 h-3" />
              오늘 가입 ({todayUsers.length})
            </button>
            <button
              onClick={() => setFilterType('active')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                filterType === 'active'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 hover:bg-emerald-100'
              }`}
            >
              정상 계정 ({normalActiveUsers.length})
            </button>
            <button
              onClick={() => setFilterType('banned')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap ${
                filterType === 'banned'
                  ? 'bg-rose-600 text-white'
                  : 'bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400 hover:bg-rose-100'
              }`}
            >
              정지/차단 ({bannedUsers.length})
            </button>
            <button
              onClick={() => setFilterType('kicked')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap flex items-center gap-1 ${
                filterType === 'kicked'
                  ? 'bg-red-700 text-white shadow-xs'
                  : 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400 hover:bg-red-100'
              }`}
            >
              <Trash2 className="w-3 h-3" />
              강퇴 이력 ({kickedUsers.length})
            </button>
          </div>
        </div>

        {/* Informative Sub-header */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-400">
          <span>
            검색 및 필터 결과:{' '}
            <strong className="text-slate-700 dark:text-slate-300">
              {filterType === 'kicked' ? filteredKickedUsers.length : filteredUsers.length}명
            </strong>
          </span>
          <button
            onClick={() => setShowResetConfirm(true)}
            className="text-[11px] text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1 transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            데모 회원 목록 초기화
          </button>
        </div>
      </div>

      {/* User Management List / Table */}
      <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-slate-900 shadow-xs">
        {/* Mobile Dedicated Card View for Kicked Members (sm:hidden) - Move Restore Button to Left */}
        {filterType === 'kicked' && (
          <div className="block sm:hidden divide-y divide-slate-100 dark:divide-slate-800">
            {filteredKickedUsers.length === 0 ? (
              <div className="py-12 px-4 text-center text-slate-400 text-sm">
                강제 탈퇴(강퇴) 처리된 회원이 없습니다.
              </div>
            ) : (
              filteredKickedUsers.map((kicked) => (
                <div
                  key={`mobile-kicked-${kicked.id}`}
                  className="p-4 bg-white dark:bg-slate-900 hover:bg-rose-50/20 dark:hover:bg-rose-950/20 transition-colors space-y-3"
                >
                  {/* Top: Avatar, Name, Handle, Badges */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-11 h-11 rounded-full bg-rose-100 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 flex items-center justify-center text-rose-700 dark:text-rose-300 font-bold shrink-0 text-base">
                        {kicked.name ? kicked.name.slice(0, 1) : '?'}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-slate-800 dark:text-slate-200 line-through text-sm">
                            {kicked.name}
                          </span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-rose-600 text-white">
                            강퇴 처리됨
                          </span>
                        </div>
                        <div className="text-xs text-rose-600 dark:text-rose-400 font-mono">
                          @{kicked.handle}
                        </div>
                      </div>
                    </div>

                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300 dark:border-rose-800 shrink-0">
                      <Ban className="w-3 h-3" />
                      영구 차단
                    </span>
                  </div>

                  {/* Left-Aligned Prominent Restore Button for Mobile Screen */}
                  <div className="flex items-center justify-start gap-2 pt-0.5">
                    <button
                      type="button"
                      id={`mobile-admin-restore-btn-${kicked.id}`}
                      onClick={() => setSelectedUserForRestore(kicked)}
                      title="회원 계정 정상 복원"
                      className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-xl text-xs font-black shadow-xs transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>계정 복원</span>
                    </button>
                    <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                      클릭시 정상 계정으로 즉시 복구
                    </span>
                  </div>

                  {/* Info details */}
                  <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs space-y-1.5">
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-slate-400 shrink-0">강퇴 사유:</span>
                      <span className="font-semibold text-rose-600 dark:text-rose-400 text-right">
                        {kicked.reason || '운영 정책 위반'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center gap-2">
                      <span className="text-slate-400 shrink-0">강퇴 일시:</span>
                      <span className="text-slate-600 dark:text-slate-300">
                        {kicked.kickedAt ? new Date(kicked.kickedAt).toLocaleString('ko-KR') : '기록 없음'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center gap-2">
                      <span className="text-slate-400 shrink-0">가입 IP:</span>
                      <span className="font-mono text-indigo-600 dark:text-indigo-400 font-semibold px-1.5 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] select-all">
                        {kicked.signupIp || (kicked.userData && kicked.userData.signupIp) || '127.0.0.1'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center gap-2">
                      <span className="text-slate-400 shrink-0">조치자:</span>
                      <span className="text-slate-600 dark:text-slate-300">
                        {kicked.kickedBy || '최고관리자'}
                      </span>
                    </div>
                    {kicked.email && (
                      <div className="flex justify-between items-center gap-2">
                        <span className="text-slate-400 shrink-0">이메일:</span>
                        <span className="text-slate-600 dark:text-slate-300 truncate">
                          {kicked.email}
                        </span>
                      </div>
                    )}
                    {kicked.phoneNumber && (
                      <div className="flex justify-between items-center gap-2">
                        <span className="text-slate-400 shrink-0">연락처:</span>
                        <span className="text-slate-600 dark:text-slate-300">
                          {kicked.phoneNumber}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        <div className={`overflow-x-auto ${filterType === 'kicked' ? 'hidden sm:block' : 'block'}`}>
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50/80 dark:bg-slate-800/60 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                {filterType === 'kicked' ? (
                  <>
                    <th className="py-3 px-4">강퇴 회원 정보</th>
                    <th className="py-3 px-4">관리자 복원 조치</th>
                    <th className="py-3 px-4">강퇴 사유 및 담당자</th>
                    <th className="py-3 px-4">강퇴 일시 / 가입 IP</th>
                    <th className="py-3 px-4">연락처 및 위치</th>
                  </>
                ) : (
                  <>
                    <th className="py-3 px-4">회원 정보</th>
                    <th className="py-3 px-4">연락처 및 위치</th>
                    <th className="py-3 px-4">가입 일시 / 가입 IP</th>
                    <th className="py-3 px-4">계정 상태</th>
                    <th className="py-3 px-4 text-right">
                      관리자 조치 (강제탈퇴/정지)
                    </th>
                  </>
                )}
              </tr>
            </thead>
            {filterType === 'kicked' ? (
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredKickedUsers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-400 text-sm">
                      강제 탈퇴(강퇴) 처리된 회원이 없습니다.
                    </td>
                  </tr>
                ) : (
                  filteredKickedUsers.map((kicked) => (
                    <tr key={kicked.id} className="hover:bg-rose-50/30 dark:hover:bg-rose-950/20 transition-colors">
                      {/* Column 1: 강퇴 회원 정보 */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-950/60 border border-rose-300 dark:border-rose-800 flex items-center justify-center text-rose-700 dark:text-rose-300 font-bold shrink-0">
                            {kicked.name ? kicked.name.slice(0, 1) : '?'}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-slate-700 dark:text-slate-300 line-through">
                                {kicked.name}
                              </span>
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-rose-600 text-white">
                                강퇴 처리됨
                              </span>
                            </div>
                            <div className="text-xs text-rose-600 dark:text-rose-400 font-mono">@{kicked.handle}</div>
                          </div>
                        </div>
                      </td>

                      {/* Column 2: 관리자 복원 조치 (좌측 2번째 컬럼으로 이동!) */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            id={`admin-restore-btn-${kicked.id}`}
                            onClick={() => setSelectedUserForRestore(kicked)}
                            title="회원 계정 정상 복원"
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-lg text-xs font-bold shadow-xs transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>계정 복원</span>
                          </button>
                          <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300 dark:border-rose-800 whitespace-nowrap">
                            <Ban className="w-3 h-3" />
                            영구 차단됨
                          </span>
                        </div>
                      </td>

                      {/* Column 3: 강퇴 사유 및 담당자 */}
                      <td className="py-3.5 px-4">
                        <div className="space-y-0.5">
                          <span className="text-xs font-bold text-rose-600 dark:text-rose-400">
                            {kicked.reason || '운영 정책 위반'}
                          </span>
                          <p className="text-[10px] text-slate-400">조치자: {kicked.kickedBy || '최고관리자'}</p>
                        </div>
                      </td>

                      {/* Column 4: 강퇴 일시 및 가입 IP */}
                      <td className="py-3.5 px-4 text-xs whitespace-nowrap">
                        <div className="space-y-1">
                          <div className="text-slate-600 dark:text-slate-300">
                            {kicked.kickedAt ? new Date(kicked.kickedAt).toLocaleString('ko-KR') : '기록 없음'}
                          </div>
                          <div className="flex items-center gap-1 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                            <Globe className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400 shrink-0" />
                            <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 font-medium select-all">
                              IP: {kicked.signupIp || (kicked.userData && kicked.userData.signupIp) || '127.0.0.1'}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Column 5: 연락처 및 위치 */}
                      <td className="py-3.5 px-4 text-xs text-slate-600 dark:text-slate-300">
                        <div className="space-y-0.5">
                          <p className="truncate text-slate-700 dark:text-slate-300">{kicked.email || '이메일 정보 없음'}</p>
                          {kicked.phoneNumber && <p className="text-slate-400">{kicked.phoneNumber}</p>}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            ) : (
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-12 text-center text-slate-400 text-sm">
                      조건에 해당하는 회원이 존재하지 않습니다.
                    </td>
                  </tr>
                ) : (
                filteredUsers.map((user) => {
                  const isToday = isSignedUpToday(user);
                  const isMainAdmin = user.handle === 'admin' || user.isAdmin;

                  return (
                    <tr
                      key={user.id}
                      className={`hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors ${
                        user.isBanned ? 'bg-rose-50/30 dark:bg-rose-950/10' : ''
                      }`}
                    >
                      {/* User Info Column */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={user.avatar}
                            alt={user.name}
                            className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-bold text-slate-900 dark:text-white">
                                {user.name}
                              </span>
                              {user.isVerified && (
                                <CheckCircle2 className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                              )}
                              {isMainAdmin && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-indigo-600 text-white">
                                  최고관리자
                                </span>
                              )}
                              {isToday && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-extrabold bg-amber-500 text-white">
                                  오늘가입
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-slate-400 truncate">@{user.handle}</div>
                            {user.role && (
                              <div className="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium truncate mt-0.5">
                                {user.role}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Contact & Location Column */}
                      <td className="py-3.5 px-4 text-xs text-slate-600 dark:text-slate-300">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-200">
                            <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span className="truncate">{user.email || '미등록'}</span>
                            {user.emailVerified ? (
                              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.2 rounded-full border border-emerald-200 dark:border-emerald-800">
                                이메일인증
                              </span>
                            ) : null}
                          </div>
                          {user.phoneNumber && (
                            <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                              <Smartphone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span className="truncate">{user.phoneNumber}</span>
                              {user.phoneVerified ? (
                                <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold bg-indigo-50 dark:bg-indigo-950/40 px-1.5 py-0.2 rounded-full border border-indigo-200 dark:border-indigo-800">
                                  SMS인증
                                </span>
                              ) : null}
                            </div>
                          )}
                          <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
                            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span className="truncate">{user.location || '위치 정보 없음'}</span>
                          </div>
                        </div>
                      </td>

                      {/* Registration Date & Signup IP Column */}
                      <td className="py-3.5 px-4 text-xs whitespace-nowrap">
                        <div className="space-y-1">
                          <div className={`font-semibold ${isToday ? 'text-amber-600 dark:text-amber-400 font-bold' : 'text-slate-700 dark:text-slate-300'}`}>
                            {formatRegistrationDate(user)}
                          </div>
                          <div className="flex items-center gap-1 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                            <Globe className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400 shrink-0" />
                            <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 font-medium select-all">
                              IP: {user.signupIp || '127.0.0.1'}
                            </span>
                          </div>
                          {isToday && (
                            <span className="block text-[10px] text-amber-500 font-bold">
                              ✨ 오늘 신규 유입
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Status Column */}
                      <td className="py-3.5 px-4">
                        {user.isBanned ? (
                          <div className="space-y-0.5">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                              <Ban className="w-3 h-3" />
                              이용 정지 (차단)
                            </span>
                            {user.banReason && (
                              <p className="text-[10px] text-rose-500 truncate max-w-[140px]">
                                {user.banReason}
                              </p>
                            )}
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                            <CheckCircle2 className="w-3 h-3" />
                            정상 활동 중
                          </span>
                        )}
                      </td>

                      {/* Actions Column */}
                      <td className="py-3.5 px-4 text-right">
                        {isMainAdmin ? (
                          <span className="text-xs text-slate-400 italic">보호된 시스템 계정</span>
                        ) : (
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Profile inspection */}
                            <button
                              type="button"
                              onClick={() => {
                                setViewingUserId(user.id);
                                setActiveTab('profile');
                              }}
                              title="회원 프로필 보기"
                              className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition-colors"
                            >
                              <Eye className="w-4 h-4" />
                            </button>

                            {/* Ban / Unban Toggle */}
                            <button
                              type="button"
                              onClick={() => {
                                if (user.isBanned) {
                                  toggleBanUser(user.id);
                                } else {
                                  setSelectedUserForBan(user);
                                }
                              }}
                              title={user.isBanned ? '계정 정지 해제' : '계정 이용 정지'}
                              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                                user.isBanned
                                  ? 'bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200'
                                  : 'bg-amber-50 text-amber-700 hover:bg-amber-100 dark:bg-amber-950/50 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                              }`}
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>{user.isBanned ? '정지 해제' : '정지'}</span>
                            </button>

                            {/* Force Delete (Kick) Button */}
                            <button
                              type="button"
                              id={`admin-kick-btn-${user.id}`}
                              onClick={() => setSelectedUserForKick(user)}
                              title="강제 탈퇴 (계정 영구 삭제)"
                              className="px-2.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold shadow-xs transition-all flex items-center gap-1 active:scale-95 cursor-pointer"
                            >
                              <UserX className="w-3.5 h-3.5" />
                              <span>강제탈퇴</span>
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          )}
          </table>
        </div>
      </div>
        </>
      )}

      {/* ============================================================ */}
      {/* TAB 2: POST MODERATION (게시물 수정 · 차단 · 삭제 관리)       */}
      {/* ============================================================ */}
      {dashboardTab === 'posts' && (
        <div className="space-y-4">
          {/* Post Filter & Search Toolbar */}
          <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-3">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              {/* Search input */}
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={postSearchTerm}
                  onChange={(e) => setPostSearchTerm(e.target.value)}
                  placeholder="게시물 본문 내용, 작성자 이름, 아이디(@handle), 해시태그 검색..."
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                />
              </div>

              {/* Filter pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto">
                <button
                  type="button"
                  onClick={() => setPostFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                    postFilter === 'all'
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 hover:bg-slate-200'
                  }`}
                >
                  전체 게시물 ({posts.length})
                </button>
                <button
                  type="button"
                  onClick={() => setPostFilter('blocked')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1 ${
                    postFilter === 'blocked'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-amber-50 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300 border border-amber-200 dark:border-amber-800 hover:bg-amber-100'
                  }`}
                >
                  <Ban className="w-3 h-3" />
                  <span>차단(블라인드)됨 ({posts.filter((p) => p.isBlocked).length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPostFilter('normal')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                    postFilter === 'normal'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100'
                  }`}
                >
                  정상 노출 ({posts.filter((p) => !p.isBlocked).length})
                </button>
              </div>
            </div>
          </div>

          {/* Posts List Cards */}
          <div className="space-y-3">
            {filteredPosts.length === 0 ? (
              <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center dark:border-slate-800 dark:bg-slate-900">
                <FileText className="mx-auto h-12 w-12 text-slate-300 dark:text-slate-600 mb-3" />
                <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
                  해당 조건에 부합하는 게시물이 없습니다.
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  검색어 또는 필터 조건을 변경해 보세요.
                </p>
              </div>
            ) : (
              filteredPosts.map((post) => (
                <div
                  key={post.id}
                  className={`rounded-2xl border p-4 sm:p-5 transition-all bg-white dark:bg-slate-900 ${
                    post.isBlocked
                      ? 'border-amber-300 dark:border-amber-800/80 bg-amber-50/30 dark:bg-amber-950/10'
                      : 'border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-800'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    {/* Author & Meta */}
                    <div className="flex items-start gap-3 min-w-0">
                      <img
                        src={post.authorAvatar}
                        alt={post.authorName}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0 mt-0.5"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="font-bold text-slate-900 dark:text-white text-sm">
                            {post.authorName}
                          </span>
                          <span className="text-xs text-slate-400">@{post.authorHandle}</span>
                          <span className="text-xs text-slate-300 dark:text-slate-600">•</span>
                          <span className="text-xs text-slate-400">{post.createdAt}</span>

                          {post.isEdited && (
                            <span className="text-[10px] px-1.5 py-0.2 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded">
                              수정됨
                            </span>
                          )}

                          {post.isBlocked && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300 border border-amber-300 dark:border-amber-700">
                              <Ban className="w-2.5 h-2.5" />
                              차단(블라인드) 중
                            </span>
                          )}
                        </div>

                        {/* Post Content Snippet */}
                        <p className="mt-2 text-xs sm:text-sm text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed line-clamp-3">
                          {post.content || '(본문 내용 없음)'}
                        </p>

                        {/* Attachments indicator */}
                        <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-400">
                          {post.images && post.images.length > 0 && (
                            <span className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                              🖼️ 이미지 {post.images.length}장
                            </span>
                          )}
                          {post.video && (
                            <span className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                              🎬 동영상 첨부
                            </span>
                          )}
                          {post.poll && (
                            <span className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">
                              📊 투표 ({post.poll.totalVotes}명 참여)
                            </span>
                          )}
                          <span>좋아요 {post.likes?.length || 0}</span>
                          <span>•</span>
                          <span>댓글 {post.commentsCount || 0}</span>
                        </div>

                        {/* Block Reason Note if Blocked */}
                        {post.isBlocked && (
                          <div className="mt-2 p-2.5 rounded-xl bg-amber-100/70 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2">
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                            <div>
                              <span className="font-bold">차단 사유:</span> {post.blockReason || '운영 정책 위반'}
                              {post.blockedBy && (
                                <span className="ml-1 text-[11px] text-slate-500 dark:text-slate-400">
                                  (처리자: {post.blockedBy})
                                </span>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Admin Action Buttons: Edit, Block/Unblock, Delete */}
                    <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-start pt-2 sm:pt-0">
                      {/* Edit Button */}
                      <button
                        type="button"
                        onClick={() => setEditingPost(post)}
                        title="최고관리자 권한으로 내용 수정"
                        className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 dark:bg-slate-800 dark:hover:bg-indigo-950/40 dark:hover:text-indigo-400 text-slate-700 dark:text-slate-300 text-xs font-bold transition-all flex items-center gap-1 border border-slate-200 dark:border-slate-700 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>수정</span>
                      </button>

                      {/* Block / Unblock Toggle Button */}
                      <button
                        type="button"
                        onClick={() => {
                          if (post.isBlocked) {
                            toggleBlockPost(post.id);
                          } else {
                            setPostForBlock(post);
                          }
                        }}
                        title={post.isBlocked ? '게시물 차단 해제' : '게시물 블라인드 차단'}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 border cursor-pointer ${
                          post.isBlocked
                            ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                            : 'bg-amber-50 text-amber-700 hover:bg-amber-100 dark:bg-amber-950/50 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                        }`}
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>{post.isBlocked ? '차단 해제' : '차단'}</span>
                      </button>

                      {/* Delete Button */}
                      <button
                        type="button"
                        id={`admin-delete-post-btn-${post.id}`}
                        onClick={() => setPostForDelete(post)}
                        title="게시물 영구 삭제"
                        className="px-2.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all flex items-center gap-1 shadow-xs active:scale-95 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>삭제</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* TAB 3: SIGNUP AUTH VERIFICATION METHOD (가입 인증 수단 설정)  */}
      {/* ============================================================ */}
      {dashboardTab === 'auth_policy' && (
        <SignupAuthSettingsView />
      )}

      {/* ============================================================ */}
      {/* TAB 4: SPAM FILTER MANAGEMENT CONSOLE (스팸단어 필터링 설정)  */}
      {/* ============================================================ */}
      {dashboardTab === 'spam_filter' && (
        <SpamFilterManagementView />
      )}

      {/* ============================================================ */}
      {/* TAB 4: DATABASE DIRECT MANAGEMENT CONSOLE                    */}
      {/* ============================================================ */}
      {dashboardTab === 'database' && (
        <DatabaseManagementView />
      )}

      {/* MODAL: Force Delete (Kick) Confirmation */}
      {selectedUserForKick && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-rose-600 dark:text-rose-400">
              <div className="p-3 rounded-2xl bg-rose-100 dark:bg-rose-950/60">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  회원 강제 탈퇴 처리
                </h3>
                <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                  이 작업은 되돌릴 수 없으며 회원의 모든 데이터가 삭제됩니다.
                </p>
              </div>
            </div>

            {/* Target User Card */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center gap-3">
              <img
                src={selectedUserForKick.avatar}
                alt={selectedUserForKick.name}
                className="w-12 h-12 rounded-full object-cover border border-slate-300 dark:border-slate-600"
                referrerPolicy="no-referrer"
              />
              <div className="min-w-0 flex-1">
                <div className="font-bold text-sm text-slate-900 dark:text-white truncate">
                  {selectedUserForKick.name}
                </div>
                <div className="text-xs text-slate-400 truncate">@{selectedUserForKick.handle}</div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-2 flex-wrap">
                  <span>가입일: {formatRegistrationDate(selectedUserForKick)}</span>
                  <span>•</span>
                  <span className="font-mono text-indigo-600 dark:text-indigo-400 font-semibold select-all">
                    IP: {selectedUserForKick.signupIp || '127.0.0.1'}
                  </span>
                </div>
              </div>
            </div>

            {/* Select Reason */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                강제 탈퇴 사유 선택
              </label>
              <select
                value={kickReason}
                onChange={(e) => setKickReason(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
              >
                <option value="커뮤니티 가이드라인 및 운영 정책 위반">커뮤니티 가이드라인 및 운영 정책 위반</option>
                <option value="불법 광고 홍보 및 악성 스팸 계정">불법 광고 홍보 및 악성 스팸 계정</option>
                <option value="타 회원에 대한 비방, 욕설 및 사이버 괴롭힘">타 회원에 대한 비방, 욕설 및 사이버 괴롭힘</option>
                <option value="사칭 및 허위 정보 유포">사칭 및 허위 정보 유포</option>
                <option value="음란물 및 유해 콘텐츠 게시">음란물 및 유해 콘텐츠 게시</option>
                <option value="custom">직접 사유 입력...</option>
              </select>

              {kickReason === 'custom' && (
                <input
                  type="text"
                  value={customKickReason}
                  onChange={(e) => setCustomKickReason(e.target.value)}
                  placeholder="구체적인 강제 탈퇴 사유를 입력하세요"
                  className="w-full mt-2 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500"
                />
              )}
            </div>

            <div className="p-3 bg-rose-50/80 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-900 text-[11px] text-rose-700 dark:text-rose-300 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                강제 탈퇴 시 해당 계정은 즉시 로그아웃되며, 작성한 모든 피드 게시글, 댓글, 스토리 및 회원 프로필 정보가 데이터베이스에서 영구 소멸됩니다.
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedUserForKick(null)}
                disabled={isDeleting}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors"
              >
                취소
              </button>
              <button
                type="button"
                id="admin-confirm-kick-btn"
                onClick={handleConfirmKick}
                disabled={isDeleting}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 active:scale-95 text-xs font-bold text-white shadow-md shadow-rose-600/25 transition-all flex items-center justify-center gap-1.5"
              >
                {isDeleting ? (
                  <span>탈퇴 처리 중...</span>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>강제 탈퇴 확정</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Restore Kicked User Confirmation */}
      {selectedUserForRestore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-emerald-600 dark:text-emerald-400">
              <div className="p-3 rounded-2xl bg-emerald-100 dark:bg-emerald-950/60">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  강퇴 회원 계정 복원
                </h3>
                <p className="text-xs text-emerald-700 dark:text-emerald-400 font-medium">
                  강제 탈퇴 제재를 해제하고 정상 활동 계정으로 복원합니다.
                </p>
              </div>
            </div>

            {/* Target Kicked User Summary */}
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 flex items-center justify-center text-emerald-700 dark:text-emerald-300 font-bold shrink-0 text-base">
                  {selectedUserForRestore.name ? selectedUserForRestore.name.slice(0, 1) : '?'}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-bold text-sm text-slate-900 dark:text-white truncate">
                    {selectedUserForRestore.name}
                  </div>
                  <div className="text-xs text-emerald-600 dark:text-emerald-400 font-mono truncate">
                    @{selectedUserForRestore.handle}
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 text-xs space-y-1 text-slate-600 dark:text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">강퇴 사유:</span>
                  <span className="font-semibold text-rose-600 dark:text-rose-400 truncate max-w-[200px]">
                    {selectedUserForRestore.reason || '운영 정책 위반'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">강퇴 조치일:</span>
                  <span>{selectedUserForRestore.kickedAt ? new Date(selectedUserForRestore.kickedAt).toLocaleString('ko-KR') : '기록 없음'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">가입 IP:</span>
                  <span className="font-mono font-semibold text-indigo-600 dark:text-indigo-400 select-all">
                    {selectedUserForRestore.signupIp || (selectedUserForRestore.userData && selectedUserForRestore.userData.signupIp) || '127.0.0.1'}
                  </span>
                </div>
                {selectedUserForRestore.email && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">이메일:</span>
                    <span className="truncate max-w-[200px]">{selectedUserForRestore.email}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="p-3 bg-emerald-50/80 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-900 text-[11px] text-emerald-800 dark:text-emerald-300 flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
              <span>
                계정 복원 즉시 강퇴 제재가 해제되며, 회원은 다시 정상 로그인하여 피드 활동을 할 수 있습니다. 관리자 페이지의 <strong>[정상 계정]</strong> 목록에 다시 표시됩니다.
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedUserForRestore(null)}
                disabled={isRestoring}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                id="admin-confirm-restore-btn"
                onClick={handleConfirmRestore}
                disabled={isRestoring}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-xs font-bold text-white shadow-md shadow-emerald-600/25 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {isRestoring ? (
                  <span>복원 처리 중...</span>
                ) : (
                  <>
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>정상 계정으로 복원</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Ban Confirmation */}
      {selectedUserForBan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-amber-600 dark:text-amber-400">
              <div className="p-3 rounded-2xl bg-amber-100 dark:bg-amber-950/60">
                <Ban className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  계정 이용 정지 (차단)
                </h3>
                <p className="text-xs text-amber-700 dark:text-amber-400 font-medium">
                  회원의 데이터는 유지되나 로그인이 차단됩니다.
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center gap-3">
              <img
                src={selectedUserForBan.avatar}
                alt={selectedUserForBan.name}
                className="w-12 h-12 rounded-full object-cover border border-slate-300 dark:border-slate-600"
                referrerPolicy="no-referrer"
              />
              <div className="min-w-0 flex-1">
                <div className="font-bold text-sm text-slate-900 dark:text-white truncate">
                  {selectedUserForBan.name}
                </div>
                <div className="text-xs text-slate-400 truncate">@{selectedUserForBan.handle}</div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-2 flex-wrap">
                  <span>가입일: {formatRegistrationDate(selectedUserForBan)}</span>
                  <span>•</span>
                  <span className="font-mono text-indigo-600 dark:text-indigo-400 font-semibold select-all">
                    IP: {selectedUserForBan.signupIp || '127.0.0.1'}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                정지 사유
              </label>
              <input
                type="text"
                value={banReason}
                onChange={(e) => setBanReason(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedUserForBan(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors"
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleConfirmBan}
                className="flex-1 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-xs font-bold text-white shadow-md shadow-amber-600/25 transition-all flex items-center justify-center gap-1.5"
              >
                <Ban className="w-3.5 h-3.5" />
                <span>정지 처리</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Edit Post Modal for Admin */}
      {editingPost && (
        <EditPostModal
          post={editingPost}
          isOpen={true}
          onClose={() => setEditingPost(null)}
        />
      )}

      {/* MODAL: Block Reason Confirmation for Post */}
      {postForBlock && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setPostForBlock(null)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400">
                <Ban className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900 dark:text-white">
                  게시물 차단(블라인드) 설정
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {postForBlock.authorName} (@{postForBlock.authorHandle})님의 게시물
                </p>
              </div>
            </div>

            <div className="mt-4 space-y-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                차단 사유 선택 또는 직접 입력
              </label>

              <div className="flex flex-wrap gap-1.5">
                {[
                  '운영 정책 및 커뮤니티 가이드라인 위반',
                  '부적절한 홍보 / 스팸성 게시물',
                  '욕설, 비방 및 혐오 표현 포함',
                  '허위 사실 유포 및 사칭 의심',
                  '음란물 및 유해 콘텐츠 포함'
                ].map((reasonOption) => (
                  <button
                    key={reasonOption}
                    type="button"
                    onClick={() => setBlockReasonInput(reasonOption)}
                    className={`rounded-lg px-2.5 py-1 text-xs transition-colors cursor-pointer ${
                      blockReasonInput === reasonOption
                        ? 'bg-amber-500 text-white font-bold'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {reasonOption}
                  </button>
                ))}
              </div>

              <textarea
                value={blockReasonInput}
                onChange={(e) => setBlockReasonInput(e.target.value)}
                placeholder="차단 사유를 상세하게 작성해주세요..."
                rows={3}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-900 placeholder:text-slate-400 focus:border-amber-500 focus:bg-white focus:text-slate-900 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-amber-500"
              />

              <p className="text-[11px] text-slate-400 dark:text-slate-500">
                ⚠️ 차단된 게시물은 일반 피드에서 내용이 블라인드 처리되며, 차단 사유가 표시됩니다. 언제든 다시 차단 해제할 수 있습니다.
              </p>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setPostForBlock(null)}
                className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                onClick={() => {
                  toggleBlockPost(postForBlock.id, blockReasonInput.trim() || '운영 정책 및 커뮤니티 가이드라인 위반');
                  setPostForBlock(null);
                }}
                className="rounded-xl bg-amber-600 px-4 py-2 text-xs font-bold text-white hover:bg-amber-700 transition-colors shadow-sm cursor-pointer"
              >
                게시물 차단 적용
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Delete Post Confirmation (Administrator Power) */}
      {postForDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  게시물 영구 삭제 확인
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  최고 관리자 권한으로 게시물을 영구 삭제합니다.
                </p>
              </div>
            </div>

            {/* Post Target Preview */}
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-slate-800 dark:bg-slate-800/40 space-y-2">
              <div className="flex items-center gap-2">
                <img
                  src={postForDelete.authorAvatar}
                  alt={postForDelete.authorName}
                  className="w-6 h-6 rounded-full object-cover"
                />
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {postForDelete.authorName}
                </span>
                <span className="text-[11px] text-slate-400">
                  @{postForDelete.authorHandle}
                </span>
                <span className="text-[11px] text-slate-400 ml-auto">
                  {postForDelete.createdAt?.slice(0, 10)}
                </span>
              </div>
              <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-3 leading-relaxed bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200/60 dark:border-slate-800">
                "{postForDelete.content}"
              </p>
            </div>

            {/* Warning Callout */}
            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              <p className="text-xs text-rose-700 dark:text-rose-300 leading-relaxed font-medium">
                삭제된 게시물은 <strong>메인페이지(피드)</strong>, <strong>탐색</strong>, <strong>북마크</strong>, <strong>프로필</strong> 등 서비스 전체 화면에서 즉시 완전히 제외되어 보이지 않게 되며, 복구할 수 없습니다.
              </p>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={isDeletingPost}
                onClick={() => setPostForDelete(null)}
                className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer disabled:opacity-50"
              >
                취소
              </button>
              <button
                type="button"
                id="admin-confirm-delete-post-btn"
                disabled={isDeletingPost}
                onClick={() => {
                  setIsDeletingPost(true);
                  deletePost(postForDelete.id);
                  setTimeout(() => {
                    setIsDeletingPost(false);
                    setPostForDelete(null);
                  }, 200);
                }}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-700 transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeletingPost ? '삭제 처리 중...' : '게시물 영구 삭제'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Reset Users to Initial Confirmation */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-indigo-600" />
              데모 회원 데이터 초기화
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              회원 목록과 오늘 가입자 테스트 계정들을 초기 데모 상태로 복원합니다. 진행하시겠습니까?
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300"
              >
                취소
              </button>
              <button
                onClick={() => {
                  resetUsersToInitial();
                  setShowResetConfirm(false);
                }}
                className="flex-1 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-xs font-bold text-white shadow-xs"
              >
                초기화 확인
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
