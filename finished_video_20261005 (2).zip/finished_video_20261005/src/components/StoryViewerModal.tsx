import React, { useState, useEffect, useRef } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Heart,
  Send,
  Sparkles,
  Eye,
  CheckCheck,
  Users,
  Check,
  Clock,
  UserCheck,
  MessageCircle,
  Plus,
  Info,
  ChevronDown,
  Share2,
  MoveHorizontal,
  ArrowDown,
  Bell,
  Pause,
  Play,
  Music,
  Volume2,
  VolumeX,
  Disc,
  FolderOpen,
  Wand2,
  Sun,
  Moon,
  Laptop,
  BarChart3,
  Smile,
  ShieldCheck
} from 'lucide-react';
import { formatRelativeTime } from '../utils/formatters';
import { StoryViewer, UserStory, StoryReaction } from '../types';
import { StoryShareModal } from './StoryShareModal';
import { StoryCanvasView } from './StoryCanvasView';
import { StoryAnalyticsDashboard } from './StoryAnalyticsDashboard';
import { getStoryFilterName } from '../data/storyFiltersData';
import { resolveBgmAudioUrl } from '../data/storyBgmData';

interface FloatingEmoji {
  id: number;
  emoji: string;
  x: number; // percentage from left
  size: number;
}

const QUICK_EMOJIS = [
  { emoji: '❤️', label: '하트' },
  { emoji: '👍', label: '좋아요' },
  { emoji: '😂', label: '웃음' },
  { emoji: '🔥', label: '불꽃' },
  { emoji: '😍', label: '반함' },
  { emoji: '👏', label: '박수' },
  { emoji: '😮', label: '놀람' },
  { emoji: '🎉', label: '축하' },
  { emoji: '💯', label: '최고' }
];

export const StoryViewerModal: React.FC = () => {
  const {
    activeStoryUser,
    openStoryViewer,
    closeStoryViewer,
    stories,
    sendMessage,
    currentUser,
    showToast,
    recordStoryItemView,
    simulateFriendViewStory,
    reactToStory,
    simulateFriendReactStory,
    storyDrafts,
    openCreateStoryModal,
    isDarkMode,
    themeMode,
    systemPrefersDark,
    toggleDarkMode
  } = useSocial();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [reactionSent, setReactionSent] = useState<string | null>(null);
  const [activeCelebration, setActiveCelebration] = useState<{ emoji: string; label: string } | null>(null);
  const [floatingEmojis, setFloatingEmojis] = useState<FloatingEmoji[]>([]);
  const [showViewersDrawer, setShowViewersDrawer] = useState(false);
  const [showReadInfoCard, setShowReadInfoCard] = useState(false);
  const [activeDmViewer, setActiveDmViewer] = useState<StoryViewer | null>(null);
  const [dmText, setDmText] = useState('');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [showSwipeHint, setShowSwipeHint] = useState(true);
  const [videoDurationOverride, setVideoDurationOverride] = useState<number | null>(null);
  
  // Background Music (BGM) Audio States
  const [isBgmPlaying, setIsBgmPlaying] = useState(false);
  const [isBgmUserMuted, setIsBgmUserMuted] = useState(false);
  const bgmAudioRef = useRef<HTMLAudioElement | null>(null);

  // Touch / Swipe Gesture States
  const [dragOffset, setDragOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isSwiping, setIsSwiping] = useState(false);
  const touchStartRef = useRef<{ x: number; y: number; time: number } | null>(null);
  const isMouseDownRef = useRef(false);

  const nextParticleId = useRef(0);

  // Reset states when viewing user changes
  useEffect(() => {
    setCurrentIndex(0);
    setProgress(0);
    setFloatingEmojis([]);
    setActiveCelebration(null);
    setShowViewersDrawer(false);
    setShowReadInfoCard(false);
    setActiveDmViewer(null);
    setIsShareModalOpen(false);
    setDragOffset({ x: 0, y: 0 });
    setIsSwiping(false);
    setVideoDurationOverride(null);
  }, [activeStoryUser?.userId]);

  useEffect(() => {
    setVideoDurationOverride(null);
  }, [currentIndex]);

  // Automatically fade out the swipe guide hint after 4 seconds
  useEffect(() => {
    const hintTimer = setTimeout(() => {
      setShowSwipeHint(false);
    }, 4000);
    return () => clearTimeout(hintTimer);
  }, [activeStoryUser?.userId]);

  const currentItem = activeStoryUser?.items[currentIndex];

  const isItemVideo =
    currentItem?.mediaType === 'video' ||
    Boolean(
      currentItem?.mediaUrl &&
        (/\.(mp4|mov|webm|mkv|3gp|avi|m4v)(\?.*)?$/i.test(currentItem.mediaUrl) ||
          currentItem.mediaUrl.startsWith('data:video/'))
    );
  const duration = isItemVideo
    ? Math.max(3000, (videoDurationOverride || currentItem?.duration || 15) * 1000)
    : 5000;

  // Story progress timer & pause condition
  const isTimerEffectivelyPaused =
    isPaused ||
    isSwiping ||
    showViewersDrawer ||
    showReadInfoCard ||
    activeDmViewer !== null ||
    isShareModalOpen;

  // Synchronize BGM audio playback with current active story item
  useEffect(() => {
    let isCancelled = false;
    const bgm = currentItem?.bgm;

    if (!activeStoryUser || !bgm) {
      if (bgmAudioRef.current) {
        bgmAudioRef.current.pause();
        bgmAudioRef.current = null;
      }
      setIsBgmPlaying(false);
      return;
    }

    const startPlayingBgm = async () => {
      let resolvedUrl = bgm.audioUrl;
      if (!resolvedUrl || (!resolvedUrl.startsWith('blob:') && !resolvedUrl.startsWith('data:') && !resolvedUrl.startsWith('http'))) {
        resolvedUrl = await resolveBgmAudioUrl(bgm);
      }
      if (isCancelled || !resolvedUrl) return;

      // Initialize or switch audio track
      if (!bgmAudioRef.current || bgmAudioRef.current.src !== resolvedUrl) {
        if (bgmAudioRef.current) {
          bgmAudioRef.current.pause();
        }
        const audio = new Audio(resolvedUrl);
        audio.loop = true;
        audio.volume = 0.5;
        bgmAudioRef.current = audio;
      }

      // Auto-play when entering/switching story if not manually muted and not paused
      if (!isBgmUserMuted && !isTimerEffectivelyPaused) {
        bgmAudioRef.current
          ?.play()
          .then(() => {
            if (!isCancelled) setIsBgmPlaying(true);
          })
          .catch(() => {
            // Autoplay policy limitation fallback
            if (!isCancelled) setIsBgmPlaying(false);
          });
      }
    };

    startPlayingBgm();

    return () => {
      isCancelled = true;
    };
  }, [currentItem?.id, currentItem?.bgm?.id, currentItem?.bgm?.audioUrl, activeStoryUser?.userId]);

  // Pause BGM when story timer/view is paused, resume when unpaused
  useEffect(() => {
    if (!bgmAudioRef.current || !currentItem?.bgm) return;

    if (isTimerEffectivelyPaused) {
      bgmAudioRef.current.pause();
      setIsBgmPlaying(false);
    } else if (!isBgmUserMuted) {
      bgmAudioRef.current
        .play()
        .then(() => {
          setIsBgmPlaying(true);
        })
        .catch(() => {
          setIsBgmPlaying(false);
        });
    }
  }, [isTimerEffectivelyPaused, isBgmUserMuted]);

  // Stop BGM when modal unmounts
  useEffect(() => {
    return () => {
      if (bgmAudioRef.current) {
        bgmAudioRef.current.pause();
        bgmAudioRef.current = null;
      }
    };
  }, []);

  const toggleBgmPlay = async (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!currentItem?.bgm) return;

    if (isBgmPlaying) {
      bgmAudioRef.current?.pause();
      setIsBgmPlaying(false);
      setIsBgmUserMuted(true);
      return;
    }

    let resolvedUrl = currentItem.bgm.audioUrl;
    if (!resolvedUrl || (!resolvedUrl.startsWith('blob:') && !resolvedUrl.startsWith('data:') && !resolvedUrl.startsWith('http'))) {
      resolvedUrl = await resolveBgmAudioUrl(currentItem.bgm);
    }
    if (!resolvedUrl) return;

    if (!bgmAudioRef.current || bgmAudioRef.current.src !== resolvedUrl) {
      const audio = new Audio(resolvedUrl);
      audio.loop = true;
      audio.volume = 0.5;
      bgmAudioRef.current = audio;
    }

    bgmAudioRef.current
      .play()
      .then(() => {
        setIsBgmPlaying(true);
        setIsBgmUserMuted(false);
      })
      .catch(() => {});
  };

  // Auto record view when current user views a friend's story
  useEffect(() => {
    if (!activeStoryUser || !currentItem) return;
    if (activeStoryUser.userId !== currentUser.id) {
      recordStoryItemView(activeStoryUser.userId, currentItem.id);
    }
  }, [activeStoryUser?.userId, currentItem?.id, currentIndex, currentUser.id]);

  // Calculate neighboring user stories in the stories queue
  const storyUserIndex = stories.findIndex((s) => s.userId === activeStoryUser?.userId);
  const prevStoryUser: UserStory | null =
    storyUserIndex > 0 ? stories[storyUserIndex - 1] : null;
  const nextStoryUser: UserStory | null =
    storyUserIndex >= 0 && storyUserIndex < stories.length - 1
      ? stories[storyUserIndex + 1]
      : null;

  useEffect(() => {
    if (!activeStoryUser || isTimerEffectivelyPaused) return;

    const interval = 50; // update progress every 50ms
    const step = (interval / duration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          // Advance to next story item
          if (currentIndex < activeStoryUser.items.length - 1) {
            setCurrentIndex((c) => c + 1);
            return 0;
          } else if (nextStoryUser) {
            // Auto advance to next user's story!
            openStoryViewer(nextStoryUser);
            setCurrentIndex(0);
            return 0;
          } else {
            closeStoryViewer();
            return 100;
          }
        }
        return prev + step;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [activeStoryUser, currentIndex, isTimerEffectivelyPaused, nextStoryUser, duration]);

  if (!activeStoryUser || !currentItem) return null;

  const isOwnStory = activeStoryUser.userId === currentUser.id;
  const viewers = currentItem.viewers || [];
  const directReactions = currentItem.reactions || [];

  // Combine direct reactions and viewer-level reactions safely
  const allReactions: StoryReaction[] = [...directReactions];
  viewers.forEach((v) => {
    if (
      v.reactionEmoji &&
      !allReactions.some((r) => r.userId === v.userId && r.emoji === v.reactionEmoji)
    ) {
      allReactions.push({
        id: `react_v_${v.userId}_${currentItem.id}`,
        userId: v.userId,
        userName: v.userName,
        userAvatar: v.userAvatar,
        emoji: v.reactionEmoji,
        createdAt: v.viewedAt
      });
    }
  });

  const myViewRecord = viewers.find((v) => v.userId === currentUser.id);

  const handlePrev = (e?: React.MouseEvent | React.TouchEvent) => {
    e?.stopPropagation?.();
    if (currentIndex > 0) {
      setCurrentIndex((c) => c - 1);
      setProgress(0);
      setShowViewersDrawer(false);
      setShowReadInfoCard(false);
      setActiveDmViewer(null);
    } else if (prevStoryUser) {
      openStoryViewer(prevStoryUser);
      setTimeout(() => {
        setCurrentIndex(prevStoryUser.items.length - 1);
        setProgress(0);
      }, 0);
      setShowViewersDrawer(false);
      setShowReadInfoCard(false);
      setActiveDmViewer(null);
    }
  };

  const handleNext = (e?: React.MouseEvent | React.TouchEvent) => {
    e?.stopPropagation?.();
    if (currentIndex < activeStoryUser.items.length - 1) {
      setCurrentIndex((c) => c + 1);
      setProgress(0);
      setShowViewersDrawer(false);
      setShowReadInfoCard(false);
      setActiveDmViewer(null);
    } else if (nextStoryUser) {
      openStoryViewer(nextStoryUser);
      setCurrentIndex(0);
      setProgress(0);
      setShowViewersDrawer(false);
      setShowReadInfoCard(false);
      setActiveDmViewer(null);
    } else {
      closeStoryViewer();
    }
  };

  const handleJumpToStory = (index: number, e?: React.MouseEvent) => {
    e?.stopPropagation?.();
    if (index === currentIndex || !activeStoryUser) return;
    setCurrentIndex(index);
    setProgress(0);
    setShowViewersDrawer(false);
    setShowReadInfoCard(false);
    setActiveDmViewer(null);
  };

  // --- Touch & Mouse Swipe Gesture Event Handlers ---
  const handleGestureStart = (clientX: number, clientY: number, target: HTMLElement) => {
    // Ignore swipe initiation if clicking on interactive controls
    if (
      target.closest(
        'button, input, textarea, a, form, #story-progress-bar-container, #story-viewers-drawer, #story-share-modal, #story-read-info-card'
      )
    ) {
      return;
    }

    touchStartRef.current = { x: clientX, y: clientY, time: Date.now() };
    setIsPaused(true);
  };

  const handleGestureMove = (clientX: number, clientY: number) => {
    if (!touchStartRef.current) return;
    const dx = clientX - touchStartRef.current.x;
    const dy = clientY - touchStartRef.current.y;

    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
      setIsSwiping(true);
      // Horizontal drag with smooth resistance
      // Vertical drag (downward pull to dismiss)
      setDragOffset({
        x: dx,
        y: dy > 0 ? dy : dy * 0.2
      });
    }
  };

  const handleGestureEnd = () => {
    setIsPaused(false);
    if (!touchStartRef.current) {
      setDragOffset({ x: 0, y: 0 });
      setIsSwiping(false);
      return;
    }

    const { x: startX, y: startY, time: startTime } = touchStartRef.current;
    const duration = Date.now() - startTime;
    const dx = dragOffset.x;
    const dy = dragOffset.y;
    touchStartRef.current = null;
    isMouseDownRef.current = false;

    // Gesture Classification
    const isSwipeDown = dy > 85 && Math.abs(dy) > Math.abs(dx) * 1.1;
    const isSwipeLeft = dx < -40 || (dx < -20 && duration < 250);
    const isSwipeRight = dx > 40 || (dx > 20 && duration < 250);

    if (isSwipeDown) {
      closeStoryViewer();
    } else if (isSwipeLeft) {
      handleNext();
    } else if (isSwipeRight) {
      handlePrev();
    }

    // Reset drag offset
    setDragOffset({ x: 0, y: 0 });
    setIsSwiping(false);
  };

  const spawnFloatingEmojis = (emoji: string) => {
    const newParticles: FloatingEmoji[] = [];
    const count = 10;
    for (let i = 0; i < count; i++) {
      newParticles.push({
        id: ++nextParticleId.current,
        emoji,
        x: 12 + Math.random() * 76,
        size: 26 + Math.random() * 22
      });
    }

    setFloatingEmojis((prev) => [...prev, ...newParticles]);

    setTimeout(() => {
      setFloatingEmojis((prev) =>
        prev.filter((p) => !newParticles.some((np) => np.id === p.id))
      );
    }, 2000);
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || isOwnStory) return;
    sendMessage(
      activeStoryUser.userId,
      `[스토리 답장]: ${replyText}`,
      currentItem.mediaUrl
    );
    setReactionSent('답장을 보냈습니다!');
    showToast(`${activeStoryUser.userName}님에게 답장을 보냈습니다.`, 'success');
    setReplyText('');
    setTimeout(() => setReactionSent(null), 2000);
  };

  const handleQuickReaction = (emoji: string, label?: string) => {
    if (isOwnStory) return;

    const emojiObj = QUICK_EMOJIS.find((e) => e.emoji === emoji);
    const resolvedLabel = label || emojiObj?.label || '좋아요';

    // 1. Spawn ascending floating emoji particles
    spawnFloatingEmojis(emoji);

    // 2. Trigger center-screen celebration pop animation
    setActiveCelebration({ emoji, label: resolvedLabel });
    setTimeout(() => {
      setActiveCelebration(null);
    }, 1800);

    // 3. Dispatch to SocialContext (sends DM, records reaction, and creates notification for story author)
    reactToStory(activeStoryUser.userId, currentItem.id, emoji, resolvedLabel);

    setReactionSent(`${emoji} ${resolvedLabel} 반응 전달됨!`);
    showToast(`${activeStoryUser.userName}님에게 ${emoji} 반응과 알림을 전송했습니다.`, 'success');
    setTimeout(() => setReactionSent(null), 2500);
  };

  const handleSendDmToViewer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDmViewer || !dmText.trim()) return;
    sendMessage(activeDmViewer.userId, dmText.trim(), currentItem.mediaUrl);
    showToast(`${activeDmViewer.userName}님에게 메시지를 전송했습니다.`, 'success');
    setDmText('');
    setActiveDmViewer(null);
  };

  // Visual cues during swipe
  const isDraggingLeft = dragOffset.x < -25;
  const isDraggingRight = dragOffset.x > 25;
  const isDraggingDown = dragOffset.y > 35;

  return (
    <div
      id="story-viewer-modal"
      className={`fixed inset-0 z-50 flex items-center justify-center p-0 md:p-4 backdrop-blur-xl md:backdrop-blur-2xl transition-all duration-500 select-none ${
        isDarkMode
          ? 'bg-black/92 md:bg-slate-950/92'
          : 'bg-slate-900/55 md:bg-slate-800/40'
      }`}
      // Desktop Mouse Drag Handlers
      onMouseDown={(e) => {
        isMouseDownRef.current = true;
        handleGestureStart(e.clientX, e.clientY, e.target as HTMLElement);
      }}
      onMouseMove={(e) => {
        if (!isMouseDownRef.current) return;
        handleGestureMove(e.clientX, e.clientY);
      }}
      onMouseUp={() => {
        if (isMouseDownRef.current) {
          handleGestureEnd();
        }
      }}
      // Touch Gesture Handlers
      onTouchStart={(e) => {
        if (e.touches.length === 1) {
          const t = e.touches[0];
          handleGestureStart(t.clientX, t.clientY, e.target as HTMLElement);
        }
      }}
      onTouchMove={(e) => {
        if (e.touches.length === 1) {
          const t = e.touches[0];
          handleGestureMove(t.clientX, t.clientY);
        }
      }}
      onTouchEnd={handleGestureEnd}
      onTouchCancel={handleGestureEnd}
    >
      {/* Ambient Theme-Adaptive Backlight Glow */}
      <div
        className={`absolute inset-0 pointer-events-none transition-opacity duration-700 flex items-center justify-center ${
          isDarkMode
            ? 'opacity-35 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.18)_0%,transparent_70%)]'
            : 'opacity-85 bg-[radial-gradient(circle_at_center,rgba(241,245,249,0.35)_0%,rgba(148,163,184,0.15)_50%,transparent_80%)]'
        }`}
      />

      {/* Outer Action Buttons: Theme Status, Drafts & Close */}
      <div className="absolute top-4 right-4 z-50 flex items-center gap-2">
        {/* Dynamic Theme Mode Badge */}
        <div
          id="story-theme-mode-indicator"
          className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold backdrop-blur-md transition-all shadow-md border bg-white/85 text-slate-800 border-slate-200/80 dark:bg-neutral-900/80 dark:text-slate-200 dark:border-white/15 ring-1 ring-black/5 dark:ring-white/10"
          title={
            themeMode === 'system'
              ? `시스템 테마 (${systemPrefersDark ? '다크 모드' : '라이트 모드'})에 맞춰 배경 밝기가 동적으로 동기화됨`
              : `현재 테마: ${isDarkMode ? '다크 모드' : '라이트 모드'}`
          }
        >
          {themeMode === 'system' ? (
            <Laptop className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
          ) : isDarkMode ? (
            <Moon className="w-3.5 h-3.5 text-indigo-400" />
          ) : (
            <Sun className="w-3.5 h-3.5 text-amber-500" />
          )}
          <span className="text-[11px]">
            {isDarkMode ? '밤(다크) 배경' : '낮(라이트) 배경'}
          </span>
        </div>

        <button
          id="story-open-dashboard-btn"
          onClick={(e) => {
            e.stopPropagation();
            setIsPaused(true);
            setShowViewersDrawer(true);
          }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-white/85 text-slate-800 hover:bg-white dark:bg-neutral-900/80 dark:text-white dark:hover:bg-neutral-800 transition-all backdrop-blur-md cursor-pointer shadow-lg text-xs font-semibold border border-slate-200/80 dark:border-white/15 hover:scale-105 active:scale-95"
          title="스토리 감정 반응 분석 및 통계 대시보드"
        >
          <BarChart3 className="w-3.5 h-3.5 text-rose-500 dark:text-rose-400" />
          <span className="hidden sm:inline">감정 반응 분석</span>
          {allReactions.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[10px] font-bold">
              {allReactions.length}
            </span>
          )}
        </button>

        <button
          id="story-drafts-shortcut-btn"
          onClick={(e) => {
            e.stopPropagation();
            if (bgmAudioRef.current) {
              bgmAudioRef.current.pause();
            }
            closeStoryViewer();
            openCreateStoryModal();
          }}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full bg-white/85 text-slate-800 hover:bg-white dark:bg-neutral-900/80 dark:text-white dark:hover:bg-neutral-800 transition-all backdrop-blur-md cursor-pointer shadow-lg text-xs font-semibold border border-slate-200/80 dark:border-white/15"
          title="스토리 초안 보관함 열기"
        >
          <FolderOpen className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
          <span className="hidden sm:inline">초안 보관함</span>
          <span className="px-1.5 py-0.2 rounded-full bg-amber-500/90 text-[10px] font-bold text-white">
            {storyDrafts.length}
          </span>
        </button>

        <button
          id="story-close-btn"
          onClick={closeStoryViewer}
          className="flex h-10 w-10 items-center justify-center rounded-full bg-white/85 text-slate-800 hover:bg-white dark:bg-neutral-900/80 dark:text-white dark:hover:bg-neutral-800 transition-all backdrop-blur-md cursor-pointer shadow-lg border border-slate-200/80 dark:border-white/15"
          title="스토리 닫기"
        >
          <X className="h-6 w-6" />
        </button>
      </div>

      {/* Swipe Down Dismiss Cue Overlay */}
      {isDraggingDown && (
        <div className="absolute top-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-black/80 border border-white/20 text-xs font-semibold text-white backdrop-blur-md animate-in fade-in zoom-in-90 duration-150 shadow-xl">
          <ArrowDown className="w-3.5 h-3.5 text-blue-400 animate-bounce" />
          <span>아래로 당겨서 스토리 닫기</span>
        </div>
      )}

      {/* Dynamic Left/Right Swipe Destination Hints */}
      {isDraggingLeft && (
        <div className="absolute right-4 md:right-8 top-1/2 -translate-y-1/2 z-50 flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-blue-600/90 text-white text-xs font-bold backdrop-blur-md shadow-2xl border border-blue-400/40 animate-in fade-in slide-in-from-right-4 duration-150">
          {currentIndex < activeStoryUser.items.length - 1 ? (
            <>
              <span>다음 스토리</span>
              <ChevronRight className="w-4 h-4 animate-pulse" />
            </>
          ) : nextStoryUser ? (
            <div className="flex items-center gap-2">
              <img
                src={nextStoryUser.userAvatar}
                alt={nextStoryUser.userName}
                className="h-6 w-6 rounded-full ring-1 ring-white object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="text-left leading-tight">
                <p className="text-[10px] text-blue-200">다음 사람</p>
                <p className="text-xs font-bold">{nextStoryUser.userName}</p>
              </div>
              <ChevronRight className="w-4 h-4 animate-pulse ml-0.5" />
            </div>
          ) : (
            <>
              <span>마지막 스토리 (닫기)</span>
              <X className="w-3.5 h-3.5 ml-1" />
            </>
          )}
        </div>
      )}

      {isDraggingRight && (
        <div className="absolute left-4 md:left-8 top-1/2 -translate-y-1/2 z-50 flex items-center gap-2 px-3.5 py-2 rounded-2xl bg-slate-800/90 text-white text-xs font-bold backdrop-blur-md shadow-2xl border border-white/20 animate-in fade-in slide-in-from-left-4 duration-150">
          {currentIndex > 0 ? (
            <>
              <ChevronLeft className="w-4 h-4 animate-pulse" />
              <span>이전 스토리</span>
            </>
          ) : prevStoryUser ? (
            <div className="flex items-center gap-2">
              <ChevronLeft className="w-4 h-4 animate-pulse mr-0.5" />
              <img
                src={prevStoryUser.userAvatar}
                alt={prevStoryUser.userName}
                className="h-6 w-6 rounded-full ring-1 ring-white object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="text-left leading-tight">
                <p className="text-[10px] text-slate-300">이전 사람</p>
                <p className="text-xs font-bold">{prevStoryUser.userName}</p>
              </div>
            </div>
          ) : (
            <span>첫 번째 스토리입니다</span>
          )}
        </div>
      )}

      {/* Main Story Container with Touch Swipe Transform */}
      <div
        id="story-container"
        className={`relative flex h-full w-full max-w-md flex-col justify-between overflow-hidden md:rounded-2xl transition-[box-shadow,border-color] duration-500 will-change-transform ${
          isDarkMode
            ? 'bg-slate-950 shadow-[0_25px_80px_rgba(0,0,0,0.95)] border border-white/15 ring-1 ring-white/5'
            : 'bg-slate-950 shadow-[0_25px_80px_rgba(15,23,42,0.45)] border border-slate-700/60 ring-1 ring-black/10'
        }`}
        style={{
          transform: `translate3d(${dragOffset.x * 0.85}px, ${Math.max(0, dragOffset.y * 0.75)}px, 0) rotate(${dragOffset.x * 0.025}deg) scale(${
            dragOffset.y > 0 ? Math.max(0.85, 1 - dragOffset.y / 800) : 1
          })`,
          transition: isSwiping
            ? 'none'
            : 'transform 0.28s cubic-bezier(0.18, 0.9, 0.26, 1), opacity 0.2s ease',
          opacity: dragOffset.y > 0 ? Math.max(0.4, 1 - dragOffset.y / 450) : 1
        }}
      >
        {/* Floating Emoji Particles Layer */}
        <div className="absolute inset-0 pointer-events-none z-40 overflow-hidden">
          {floatingEmojis.map((particle) => (
            <div
              key={particle.id}
              className="absolute bottom-16 animate-float-up text-center select-none"
              style={{
                left: `${particle.x}%`,
                fontSize: `${particle.size}px`
              }}
            >
              {particle.emoji}
            </div>
          ))}
        </div>

        {/* Quick Reaction Center-Screen Celebration Pop & Shockwave Overlay */}
        {activeCelebration && (
          <div className="absolute inset-0 pointer-events-none z-40 flex items-center justify-center">
            {/* Shockwave Rings */}
            <div className="absolute h-36 w-36 rounded-full border-2 border-amber-400/70 animate-shockwave" />
            <div className="absolute h-36 w-36 rounded-full border border-rose-400/60 animate-shockwave [animation-delay:150ms]" />

            {/* Center Celebration Card */}
            <div className="relative flex flex-col items-center justify-center px-6 py-5 rounded-2xl bg-black/80 backdrop-blur-xl border border-white/25 shadow-2xl animate-reaction-pop select-none">
              <div className="text-6xl drop-shadow-[0_10px_25px_rgba(0,0,0,0.6)] transform hover:scale-110 transition-transform">
                {activeCelebration.emoji}
              </div>
              <div className="mt-2.5 flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-600/90 text-white text-xs font-bold shadow-md">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>{activeCelebration.label} 반응 전송됨</span>
              </div>
              <p className="mt-1 text-[11px] text-slate-300 flex items-center gap-1">
                <Bell className="w-3 h-3 text-emerald-400" />
                <span>{activeStoryUser.userName}님에게 알림 전달 완료</span>
              </p>
            </div>
          </div>
        )}

        {/* Story Progress Bars (상단 스토리 진행 상태 게이지) */}
        <div
          id="story-progress-bar-container"
          className="absolute top-2.5 left-3 right-3 z-30 flex items-center gap-1.5"
        >
          {activeStoryUser.items.map((item, idx) => {
            const isCompleted = idx < currentIndex;
            const isCurrent = idx === currentIndex;
            const widthPercentage = isCompleted ? 100 : isCurrent ? progress : 0;

            return (
              <button
                key={`${item.id || 'story-item'}_${idx}`}
                type="button"
                id={`story-progress-segment-${idx}`}
                onClick={(e) => handleJumpToStory(idx, e)}
                title={`스토리 ${idx + 1}/${activeStoryUser.items.length} 바로 보기`}
                className="group relative h-1.5 sm:h-2 flex-1 overflow-hidden rounded-full bg-black/40 backdrop-blur-md shadow-[0_1px_4px_rgba(0,0,0,0.6)] cursor-pointer focus:outline-none transition-all hover:h-2.5"
              >
                {/* Background Track */}
                <div className="absolute inset-0 bg-white/30 group-hover:bg-white/40 transition-colors" />

                {/* Animated Filled Progress Bar */}
                <div
                  className={`relative h-full rounded-full bg-white ${
                    isCurrent
                      ? 'shadow-[0_0_8px_rgba(255,255,255,0.95)] transition-[width] duration-75 ease-linear'
                      : isCompleted
                      ? 'shadow-xs'
                      : 'transition-none'
                  }`}
                  style={{
                    width: `${widthPercentage}%`
                  }}
                />

                {/* Hover Story Index Tooltip */}
                <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none text-[10px] font-bold bg-slate-900/95 text-white px-1.5 py-0.5 rounded shadow-lg whitespace-nowrap border border-white/10 z-40">
                  {idx + 1} / {activeStoryUser.items.length}
                </span>
              </button>
            );
          })}
        </div>

        {/* Story Author & Read Indicator Header */}
        <div className="absolute top-6 left-3 right-3 z-30 flex items-center justify-between gap-2">
          {/* Author Info */}
          <div className="flex items-center gap-2.5 min-w-0">
            <img
              src={activeStoryUser.userAvatar}
              alt={activeStoryUser.userName}
              className="h-9 w-9 rounded-full object-cover ring-2 ring-white/80 shrink-0 shadow-md"
              referrerPolicy="no-referrer"
            />
            <div className="text-white drop-shadow-md truncate">
              <div className="flex items-center gap-1.5 truncate">
                <p className="text-sm font-bold leading-tight truncate">
                  {activeStoryUser.userName}
                </p>
                {isOwnStory && (
                  <span className="text-[10px] bg-blue-500/90 text-white px-1.5 py-0.5 rounded-full font-medium shrink-0 shadow-xs">
                    내 스토리
                  </span>
                )}
                <span className="text-[10px] text-white/70 bg-black/40 px-1.5 py-0.5 rounded-full backdrop-blur-xs font-mono">
                  {currentIndex + 1}/{activeStoryUser.items.length}
                </span>
                {isTimerEffectivelyPaused && (
                  <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-amber-500/80 text-white text-[9px] font-bold backdrop-blur-xs animate-pulse">
                    <Pause className="w-2 h-2 fill-current" />
                    일시정지
                  </span>
                )}
              </div>
              <p className="text-[11px] text-white/80 leading-none mt-0.5 flex items-center gap-1">
                <Clock className="w-2.5 h-2.5 inline" />
                {formatRelativeTime(currentItem.createdAt)}
              </p>
            </div>
          </div>

          {/* '조회 확인' Indicator */}
          <div className="flex items-center gap-1.5 shrink-0">
            {isOwnStory ? (
              /* Case 1: My Own Story -> Shows how many friends have read my story */
              <button
                type="button"
                id="story-read-receipts-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowViewersDrawer((prev) => !prev);
                  setShowReadInfoCard(false);
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold backdrop-blur-md transition-all cursor-pointer shadow-sm ${
                  viewers.length > 0
                    ? 'bg-blue-600/80 hover:bg-blue-600 text-white ring-1 ring-blue-400/50 hover:scale-105'
                    : 'bg-black/50 hover:bg-black/70 text-slate-200 ring-1 ring-white/20'
                }`}
                title="스토리를 조회한 친구 목록 확인"
              >
                {/* Overlapping Avatar Stack of Viewers */}
                {viewers.length > 0 ? (
                  <div className="flex -space-x-2 overflow-hidden py-0.5">
                    {viewers.slice(0, 3).map((v) => (
                      <img
                        key={v.userId}
                        src={v.userAvatar}
                        alt={v.userName}
                        className="inline-block h-4.5 w-4.5 rounded-full ring-1 ring-white object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ))}
                  </div>
                ) : (
                  <Eye className="w-3.5 h-3.5 text-blue-300" />
                )}

                <div className="flex items-center gap-1">
                  <span className="text-[11px] font-bold">
                    {viewers.length > 0 ? `친구 ${viewers.length}명 읽음` : '조회 0명'}
                  </span>
                  <ChevronDown
                    className={`w-3 h-3 text-white/80 transition-transform duration-200 ${
                      showViewersDrawer ? 'rotate-180' : ''
                    }`}
                  />
                </div>
              </button>
            ) : (
              /* Case 2: Friend's Story -> Shows that I have read this story */
              <div className="relative">
                <button
                  type="button"
                  id="story-my-view-status-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowReadInfoCard((prev) => !prev);
                  }}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/70 hover:bg-emerald-900/90 text-emerald-300 ring-1 ring-emerald-500/50 text-xs font-semibold backdrop-blur-md transition-all cursor-pointer shadow-sm"
                  title="내가 읽음 확인됨 (상세보기)"
                >
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[11px] font-bold">내가 읽음 ✓</span>
                </button>

                {/* Popover detail card for friend's story */}
                {showReadInfoCard && (
                  <div
                    id="story-read-info-card"
                    className="absolute right-0 top-9 w-64 z-50 rounded-xl bg-white/95 dark:bg-slate-900/95 border border-slate-200/90 dark:border-slate-700/80 p-3 shadow-2xl backdrop-blur-xl text-left animate-in fade-in slide-in-from-top-2 duration-150 text-slate-700 dark:text-slate-300 ring-1 ring-black/5 dark:ring-white/10"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                        <CheckCheck className="w-4 h-4" />
                        조회 확인 완료
                      </div>
                      <button
                        onClick={() => setShowReadInfoCard(false)}
                        className="text-slate-400 hover:text-slate-700 dark:hover:text-white text-xs p-1 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="mt-2 space-y-2 text-xs">
                      <p className="leading-relaxed">
                        내가 이 스토리를 확인한 기록이 게시자{' '}
                        <strong className="text-slate-900 dark:text-white font-semibold">{activeStoryUser.userName}</strong>
                        님에게 실시간으로 전달되었습니다.
                      </p>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-600 dark:text-slate-400 bg-slate-100/90 dark:bg-slate-800/80 px-2 py-1 rounded-md border border-slate-200/50 dark:border-transparent">
                        <Clock className="w-3 h-3 text-emerald-500 dark:text-emerald-400" />
                        <span>확인 시간: {myViewRecord ? formatRelativeTime(myViewRecord.viewedAt) : '방금 전'}</span>
                      </div>
                      {viewers.length > 1 && (
                        <div className="pt-1 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                          <Users className="w-3 h-3 text-blue-500 dark:text-blue-400" />
                          <span>나를 포함해 총 {viewers.length}명이 조회했습니다.</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Media / Background */}
        <div className="relative flex h-full w-full items-center justify-center bg-black overflow-hidden">
          {currentItem.mediaUrl ? (
            <StoryCanvasView
              mediaUrl={currentItem.mediaUrl}
              mediaType={currentItem.mediaType}
              filterId={currentItem.filterId}
              textOverlays={currentItem.textOverlays}
              stickerOverlays={currentItem.stickerOverlays}
              interactive={false}
              isPaused={isTimerEffectivelyPaused}
              className="h-full w-full pointer-events-none"
              imageClassName="object-cover"
              onDurationLoaded={(d) => {
                if (d && isFinite(d) && d > 0) {
                  setVideoDurationOverride(d);
                }
              }}
            />
          ) : (
            <div
              className={`flex h-full w-full items-center justify-center bg-gradient-to-tr ${
                currentItem.bgColor || 'from-blue-600 to-indigo-800'
              } p-8 text-center text-xl font-bold text-white`}
            >
              {currentItem.caption}
            </div>
          )}

          {/* Dark gradient overlay for text readability */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/50 pointer-events-none" />

          {/* Filter Badge Pill on Top Right of story viewer if filter applied */}
          {currentItem.filterId && currentItem.filterId !== 'normal' && (
            <div className="absolute top-18 right-3 z-30 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-purple-950/70 backdrop-blur-md border border-purple-500/40 text-purple-200 text-xs font-semibold shadow-lg pointer-events-none">
              <Wand2 className="w-3 h-3 text-purple-300" />
              <span>{getStoryFilterName(currentItem.filterId)} 필터</span>
            </div>
          )}

          {/* Floating BGM Playback Controller Badge */}
          {currentItem.bgm && (
            <div
              id="story-bgm-controller"
              onClick={(e) => {
                e.stopPropagation();
                toggleBgmPlay(e);
              }}
              className="absolute top-18 left-3 z-30 flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/65 hover:bg-black/85 backdrop-blur-md border border-white/20 text-white shadow-xl cursor-pointer group transition-all max-w-[82%]"
              title={isBgmPlaying ? '배경음악 일시정지 (클릭)' : '배경음악 재생 (클릭)'}
            >
              {/* Animated Sound Equalizer Bars */}
              <div className="flex items-end gap-0.5 h-3.5 shrink-0">
                <span className={`w-0.5 rounded-full bg-amber-400 transition-all duration-150 ${isBgmPlaying ? 'h-3 animate-pulse' : 'h-1.5 opacity-60'}`} />
                <span className={`w-0.5 rounded-full bg-amber-400 transition-all duration-150 ${isBgmPlaying ? 'h-3.5 animate-pulse [animation-delay:150ms]' : 'h-2 opacity-60'}`} />
                <span className={`w-0.5 rounded-full bg-amber-400 transition-all duration-150 ${isBgmPlaying ? 'h-2 animate-pulse [animation-delay:300ms]' : 'h-1 opacity-60'}`} />
                <span className={`w-0.5 rounded-full bg-amber-400 transition-all duration-150 ${isBgmPlaying ? 'h-3 animate-pulse [animation-delay:450ms]' : 'h-2.5 opacity-60'}`} />
              </div>

              <Music className={`w-3.5 h-3.5 text-amber-300 shrink-0 ${isBgmPlaying ? 'animate-spin [animation-duration:8s]' : 'opacity-75'}`} />

              <div className="flex items-center gap-1.5 min-w-0 truncate text-xs">
                <span className="font-semibold text-amber-100 truncate">{currentItem.bgm.title}</span>
                <span className="text-[10px] text-white/70 truncate hidden sm:inline">• {currentItem.bgm.artist}</span>
              </div>

              {/* Interactive Play/Pause Button Indicator */}
              <div className="h-5 w-5 rounded-full bg-white/20 group-hover:bg-amber-500 group-hover:text-black flex items-center justify-center shrink-0 transition-colors ml-0.5">
                {isBgmPlaying ? (
                  <Pause className="w-2.5 h-2.5 fill-current text-white group-hover:text-black" />
                ) : (
                  <Play className="w-2.5 h-2.5 fill-current ml-0.5 text-white group-hover:text-black" />
                )}
              </div>
            </div>
          )}

          {/* Story Caption Overlay */}
          {currentItem.caption && currentItem.mediaUrl && (
            <div className="absolute bottom-28 left-4 right-4 z-20 rounded-xl bg-black/50 backdrop-blur-md p-3.5 text-center text-sm font-medium text-white shadow-lg border border-white/10">
              {currentItem.caption}
            </div>
          )}

          {/* Left/Right Tap Zones (for quick tap navigation) */}
          <div
            id="story-tap-prev"
            onClick={(e) => {
              if (!isSwiping) handlePrev(e);
            }}
            className="absolute left-0 top-16 bottom-24 w-1/4 z-10 cursor-pointer"
          />
          <div
            id="story-tap-next"
            onClick={(e) => {
              if (!isSwiping) handleNext(e);
            }}
            className="absolute right-0 top-16 bottom-24 w-1/4 z-10 cursor-pointer"
          />

          {/* Subtle Swipe Gesture Guide Hint Pill (fades away after a few seconds) */}
          {showSwipeHint && (
            <div className="absolute top-20 left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/60 border border-white/15 text-[11px] font-medium text-slate-200 backdrop-blur-md animate-in fade-in duration-300">
              <MoveHorizontal className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
              <span>좌우 스와이프로 이동</span>
            </div>
          )}

          {/* Left / Right arrow buttons on desktop hover */}
          {(currentIndex > 0 || prevStoryUser) && (
            <button
              onClick={handlePrev}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 z-20 hidden md:flex h-8 w-8 items-center justify-center rounded-full bg-white/85 text-slate-800 hover:bg-white hover:scale-110 dark:bg-black/60 dark:text-white dark:hover:bg-black/85 transition-all cursor-pointer shadow-lg border border-slate-200/80 dark:border-white/15 backdrop-blur-sm"
              title="이전 스토리 (스와이프 가능)"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
          )}
          <button
            onClick={handleNext}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 z-20 hidden md:flex h-8 w-8 items-center justify-center rounded-full bg-white/85 text-slate-800 hover:bg-white hover:scale-110 dark:bg-black/60 dark:text-white dark:hover:bg-black/85 transition-all cursor-pointer shadow-lg border border-slate-200/80 dark:border-white/15 backdrop-blur-sm"
            title="다음 스토리 (스와이프 가능)"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>

        {/* Reaction Notice / Feedback Badge */}
        {reactionSent && (
          <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-30 rounded-full bg-blue-600/90 backdrop-blur-md px-4 py-1.5 text-xs font-semibold text-white shadow-lg animate-bounce flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            {reactionSent}
          </div>
        )}

        {/* Bottom Reaction & Reply Bar OR Own Story Info Bar */}
        {!isOwnStory ? (
          <div className="relative z-30 flex flex-col gap-2.5 p-3.5 bg-slate-950/85 backdrop-blur-md border-t border-white/10">
            {/* Quick Emoji Reaction Buttons Bar */}
            <div className="flex items-center justify-between px-1 gap-1">
              {QUICK_EMOJIS.map(({ emoji, label }) => (
                <button
                  key={emoji}
                  type="button"
                  id={`story-reaction-btn-${label}`}
                  onClick={() => handleQuickReaction(emoji, label)}
                  title={`${label} (${emoji}) 빠른 반응 보내기`}
                  className="group relative flex flex-col items-center justify-center h-10 w-10 rounded-full bg-white/10 hover:bg-white/20 active:scale-90 hover:scale-125 transition-all duration-150 cursor-pointer shadow-xs text-xl focus:outline-none focus:ring-2 focus:ring-blue-400"
                >
                  <span className="transform group-hover:scale-110 transition-transform">{emoji}</span>
                  <span className="absolute -top-7 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none text-[10px] font-bold bg-slate-900/90 text-white px-1.5 py-0.5 rounded-md shadow-md whitespace-nowrap border border-white/10">
                    {label}
                  </span>
                </button>
              ))}
            </div>

            {/* Direct Message Input with Heart Like Button and DM Share Button */}
            <form onSubmit={handleSendReply} className="flex items-center gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder={`${activeStoryUser.userName}님에게 답장 보내기...`}
                className="flex-1 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-xs md:text-sm text-white placeholder-white/50 focus:border-blue-400 focus:bg-white/15 focus:outline-none transition-all"
              />
              <button
                type="button"
                onClick={() => handleQuickReaction('❤️')}
                title="좋아요 반응"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-rose-500/20 text-rose-400 hover:bg-rose-500 hover:text-white transition-all cursor-pointer shrink-0"
              >
                <Heart className="h-4 w-4 fill-current" />
              </button>
              <button
                type="button"
                id="story-share-dm-btn"
                onClick={() => setIsShareModalOpen(true)}
                title="친구에게 다이렉트 메시지로 공유"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-slate-800/80 text-blue-400 hover:bg-blue-600 hover:text-white transition-all cursor-pointer shrink-0 ring-1 ring-white/10 shadow-xs"
              >
                <Share2 className="h-4 w-4" />
              </button>
              <button
                type="submit"
                disabled={!replyText.trim()}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-600 text-white disabled:opacity-40 hover:bg-blue-700 transition-all cursor-pointer shrink-0"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        ) : (
          <div className="relative z-30 p-3 bg-slate-950/85 backdrop-blur-md border-t border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-slate-300 font-medium">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>내가 게시한 스토리</span>
            </div>

            <div className="flex items-center gap-2">
              {/* Story Drafts Storage Shortcut */}
              <button
                type="button"
                id="story-own-drafts-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  if (bgmAudioRef.current) {
                    bgmAudioRef.current.pause();
                  }
                  closeStoryViewer();
                  openCreateStoryModal();
                }}
                className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full bg-amber-500/20 hover:bg-amber-500/40 text-amber-300 hover:text-white text-xs font-semibold transition-colors cursor-pointer ring-1 ring-amber-500/40"
                title="스토리 초안 보관함 열기"
              >
                <FolderOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>초안 ({storyDrafts.length})</span>
              </button>

              {/* Own Story Share Button */}
              <button
                type="button"
                id="story-own-share-btn"
                onClick={() => setIsShareModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 hover:text-white text-xs font-semibold transition-colors cursor-pointer ring-1 ring-blue-500/40"
                title="내 스토리 친구에게 DM으로 공유"
              >
                <Share2 className="w-3.5 h-3.5 text-blue-400" />
                <span>공유</span>
              </button>

              {/* Quick Viewers & Emotion Analytics Trigger in Bottom Bar */}
              <button
                type="button"
                id="story-bottom-viewers-toggle"
                onClick={() => {
                  setIsPaused(true);
                  setShowViewersDrawer(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-500/25 hover:bg-rose-500/40 text-rose-200 hover:text-white text-xs font-semibold transition-colors cursor-pointer ring-1 ring-rose-400/40 shadow-xs"
                title="스토리 감정 반응 분석 & 조회 대시보드 열기"
              >
                <Smile className="w-3.5 h-3.5 text-rose-400" />
                <span>
                  감정 반응 분석 ({allReactions.length > 0 ? `${allReactions.length}건` : `${viewers.length}명`})
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Viewers & Emotion Analytics Dashboard Drawer */}
        {showViewersDrawer && (
          <div
            id="story-analytics-drawer"
            className="absolute inset-x-0 bottom-0 z-50 max-h-[85%] flex flex-col rounded-t-2xl overflow-hidden shadow-2xl animate-in slide-in-from-bottom duration-200 ring-1 ring-black/10 dark:ring-white/10"
            onClick={(e) => e.stopPropagation()}
          >
            <StoryAnalyticsDashboard
              viewers={viewers}
              reactions={allReactions}
              totalStoryDurationSeconds={(currentItem as any)?.duration || 5}
              onSimulateView={() => simulateFriendViewStory(currentItem.id)}
              onSimulateReaction={(emoji) => simulateFriendReactStory(currentItem.id, emoji)}
              onSendDm={(viewer) => {
                setActiveDmViewer(viewer);
                setDmText(`안녕하세요 ${viewer.userName}님! 스토리 봐주셔서 감사합니다 😊`);
              }}
              onClose={() => {
                setShowViewersDrawer(false);
                setIsPaused(false);
              }}
            />

            {/* Quick DM Form Overlay */}
            {activeDmViewer && (
              <div className="absolute inset-x-0 bottom-0 z-60 p-3 bg-white/95 dark:bg-slate-900/95 border-t border-slate-200 dark:border-slate-800 backdrop-blur-xl shadow-2xl animate-in slide-in-from-bottom-2 duration-150">
                <form
                  onSubmit={handleSendDmToViewer}
                  className="flex items-center gap-2"
                >
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <img
                      src={activeDmViewer.userAvatar}
                      alt={activeDmViewer.userName}
                      className="w-7 h-7 rounded-full object-cover shrink-0 ring-1 ring-slate-200 dark:ring-slate-700"
                    />
                    <input
                      type="text"
                      value={dmText}
                      onChange={(e) => setDmText(e.target.value)}
                      placeholder={`${activeDmViewer.userName}님에게 보낼 메시지...`}
                      className="flex-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:border-blue-500 focus:outline-none"
                      autoFocus
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={!dmText.trim()}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white text-xs font-semibold transition-colors cursor-pointer shrink-0"
                  >
                    전송
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveDmViewer(null)}
                    className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-white transition-colors shrink-0"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </form>
              </div>
            )}
          </div>
        )}

        {/* Story DM Share Modal */}
        <StoryShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          storyUser={activeStoryUser}
          storyItem={currentItem}
        />
      </div>
    </div>
  );
};
