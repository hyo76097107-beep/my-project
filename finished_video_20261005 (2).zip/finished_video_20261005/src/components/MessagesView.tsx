import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  Search,
  Send,
  Image as ImageIcon,
  Smile,
  Check,
  CheckCheck,
  Info,
  ArrowLeft,
  MessageCircle,
  Sparkles,
  Upload,
  ChevronUp,
  ChevronDown,
  X,
  CornerUpLeft,
  Forward,
  Copy,
  MoreHorizontal,
  Share2,
  Star
} from 'lucide-react';
import { Message, MessageReplyInfo } from '../types';
import { formatRelativeTime } from '../utils/formatters';

export const MessagesView: React.FC = () => {
  const {
    currentUser,
    users,
    messages,
    sendMessage,
    markConversationAsRead,
    markMessageAsRead,
    markAllMessagesAsRead,
    toggleStarMessage,
    activeChatUserId,
    setActiveChatUserId,
    showToast
  } = useSocial();

  const [messageText, setMessageText] = useState('');
  const [chatSearch, setChatSearch] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'unread' | 'starred'>('all');
  const [isStarredFilterActive, setIsStarredFilterActive] = useState(false);
  const [showPhotoPicker, setShowPhotoPicker] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [customPhotoUrl, setCustomPhotoUrl] = useState('');
  const photoInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Message popup menu (Reply / Forward / Long-press) state
  const [selectedMessageForMenu, setSelectedMessageForMenu] = useState<Message | null>(null);
  const [replyingToMessage, setReplyingToMessage] = useState<Message | null>(null);
  const [forwardingMessage, setForwardingMessage] = useState<Message | null>(null);
  const [forwardSearch, setForwardSearch] = useState('');
  const [forwardSentUserIds, setForwardSentUserIds] = useState<string[]>([]);
  const [highlightedMessageId, setHighlightedMessageId] = useState<string | null>(null);

  // Touch & Mouse Long-press tracking
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const touchStartPosRef = useRef<{ x: number; y: number } | null>(null);

  // In-chat message keyword search state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [messageSearchKeyword, setMessageSearchKeyword] = useState('');
  const [currentSearchIndex, setCurrentSearchIndex] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const availableContacts = useMemo(
    () => users.filter((u) => u.id !== currentUser.id),
    [users, currentUser.id]
  );

  const targetUser = useMemo(
    () => (activeChatUserId ? users.find((u) => u.id === activeChatUserId) || null : null),
    [users, activeChatUserId]
  );

  // Auto-mark conversation messages as read when viewing targetUser
  useEffect(() => {
    if (activeChatUserId) {
      const hasUnread = messages.some(
        (m) => m.senderId === activeChatUserId && m.receiverId === currentUser.id && !m.isRead
      );
      if (hasUnread) {
        markConversationAsRead(activeChatUserId);
      }
    }
  }, [activeChatUserId, messages, currentUser.id, markConversationAsRead]);

  // Pre-calculate per-contact message metadata
  const contactDetails = useMemo(() => {
    return availableContacts.map((user) => {
      const userMsgs = messages.filter(
        (m) =>
          (m.senderId === currentUser.id && m.receiverId === user.id) ||
          (m.senderId === user.id && m.receiverId === currentUser.id)
      );
      const lastMsg = userMsgs[userMsgs.length - 1];
      // Number of unread messages sent by this user to current user
      const unreadCount = userMsgs.filter(
        (m) => m.senderId === user.id && m.receiverId === currentUser.id && !m.isRead
      ).length;
      // Number of starred messages in conversation with this user
      const starredCount = userMsgs.filter((m) => m.isStarred).length;

      return {
        user,
        userMsgs,
        lastMsg,
        unreadCount,
        starredCount,
        lastMsgTime: lastMsg ? new Date(lastMsg.createdAt).getTime() : 0
      };
    });
  }, [availableContacts, messages, currentUser.id]);

  // Total unread count across all contacts
  const totalUnreadCount = useMemo(() => {
    return contactDetails.reduce((sum, item) => sum + item.unreadCount, 0);
  }, [contactDetails]);

  // Contacts that have at least 1 unread message
  const unreadContactsCount = useMemo(() => {
    return contactDetails.filter((item) => item.unreadCount > 0).length;
  }, [contactDetails]);

  // Contacts that have at least 1 starred message
  const starredContactsCount = useMemo(() => {
    return contactDetails.filter((item) => item.starredCount > 0).length;
  }, [contactDetails]);

  // Sort and filter contacts: unread first, then by last message time
  const sortedAndFilteredContacts = useMemo(() => {
    let list = [...contactDetails];

    if (chatSearch.trim()) {
      const query = chatSearch.toLowerCase().trim();
      list = list.filter(
        (item) =>
          item.user.name.toLowerCase().includes(query) ||
          item.user.handle.toLowerCase().includes(query)
      );
    }

    if (filterMode === 'unread') {
      list = list.filter((item) => item.unreadCount > 0);
    } else if (filterMode === 'starred') {
      list = list.filter((item) => item.starredCount > 0);
    }

    return list.sort((a, b) => {
      // 1. Contacts with unread messages first
      if (a.unreadCount > 0 && b.unreadCount === 0) return -1;
      if (a.unreadCount === 0 && b.unreadCount > 0) return 1;
      // 2. Latest message timestamp next
      return b.lastMsgTime - a.lastMsgTime;
    });
  }, [contactDetails, chatSearch, filterMode]);

  // Filter messages between currentUser and targetUser
  const currentConversationMessages = useMemo(() => {
    if (!targetUser) return [];
    return messages.filter(
      (m) =>
        (m.senderId === currentUser.id && m.receiverId === targetUser.id) ||
        (m.senderId === targetUser.id && m.receiverId === currentUser.id)
    );
  }, [messages, currentUser.id, targetUser]);

  // Starred messages in the active conversation
  const starredConversationMessages = useMemo(() => {
    return currentConversationMessages.filter((m) => m.isStarred);
  }, [currentConversationMessages]);

  const conversationStarredCount = starredConversationMessages.length;

  // Final displayed messages in conversation (switches to starred only if filter active)
  const displayedConversationMessages = useMemo(() => {
    if (isStarredFilterActive) {
      return starredConversationMessages;
    }
    return currentConversationMessages;
  }, [isStarredFilterActive, starredConversationMessages, currentConversationMessages]);

  // Messages matching keyword in the active conversation
  const matchingMessageIds = useMemo(() => {
    const q = messageSearchKeyword.trim().toLowerCase();
    if (!q) return [];
    return displayedConversationMessages
      .filter((m) => m.content && m.content.toLowerCase().includes(q))
      .map((m) => m.id);
  }, [displayedConversationMessages, messageSearchKeyword]);

  // Reset or bound search index
  useEffect(() => {
    if (matchingMessageIds.length === 0) {
      setCurrentSearchIndex(0);
    } else if (currentSearchIndex >= matchingMessageIds.length) {
      setCurrentSearchIndex(matchingMessageIds.length - 1);
    }
  }, [matchingMessageIds.length, currentSearchIndex]);

  // Reset search and filter when active contact changes
  useEffect(() => {
    setMessageSearchKeyword('');
    setCurrentSearchIndex(0);
    setIsSearchOpen(false);
    setIsStarredFilterActive(false);
  }, [activeChatUserId]);

  // Focus input when search bar opens
  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    }
  }, [isSearchOpen]);

  // Current focused search result message ID
  const currentTargetMessageId = matchingMessageIds[currentSearchIndex] || null;

  // Scroll to focused search result
  useEffect(() => {
    if (currentTargetMessageId) {
      const el = document.getElementById(`chat-msg-${currentTargetMessageId}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [currentTargetMessageId, currentSearchIndex]);

  const handleNextSearchResult = () => {
    if (matchingMessageIds.length === 0) return;
    setCurrentSearchIndex((prev) => (prev + 1) % matchingMessageIds.length);
  };

  const handlePrevSearchResult = () => {
    if (matchingMessageIds.length === 0) return;
    setCurrentSearchIndex((prev) => (prev - 1 + matchingMessageIds.length) % matchingMessageIds.length);
  };

  // Helper to render keyword highlighted message content
  const renderHighlightedContent = (text: string, query: string, isCurrentTarget: boolean) => {
    if (!query.trim()) return text;
    const escaped = query.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${escaped})`, 'gi');
    const parts = text.split(regex);
    return (
      <>
        {parts.map((part, i) =>
          part.toLowerCase() === query.trim().toLowerCase() ? (
            <mark
              key={i}
              className={`rounded-xs px-1 py-0.5 font-bold transition-all ${
                isCurrentTarget
                  ? 'bg-amber-400 text-slate-950 ring-2 ring-amber-500 shadow-xs'
                  : 'bg-yellow-200 text-slate-900 dark:bg-yellow-400/90 dark:text-slate-950'
              }`}
            >
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </>
    );
  };

  // Long-press detection helpers
  const startLongPress = (msg: Message, e: React.TouchEvent | React.MouseEvent) => {
    cancelLongPress();
    let clientX = 0;
    let clientY = 0;
    if ('touches' in e && e.touches.length > 0) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else if ('clientX' in e) {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    touchStartPosRef.current = { x: clientX, y: clientY };

    longPressTimerRef.current = setTimeout(() => {
      if (typeof window !== 'undefined' && window.navigator && 'vibrate' in window.navigator) {
        try {
          window.navigator.vibrate(40);
        } catch (_) {}
      }
      setSelectedMessageForMenu(msg);
      longPressTimerRef.current = null;
    }, 450);
  };

  const cancelLongPress = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    touchStartPosRef.current = null;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchStartPosRef.current && e.touches.length > 0) {
      const dx = Math.abs(e.touches[0].clientX - touchStartPosRef.current.x);
      const dy = Math.abs(e.touches[0].clientY - touchStartPosRef.current.y);
      if (dx > 10 || dy > 10) {
        cancelLongPress();
      }
    }
  };

  // Scroll smoothly to a specific message and flash highlight
  const scrollToMessage = (msgId: string) => {
    const el = document.getElementById(`chat-msg-${msgId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setHighlightedMessageId(msgId);
      setTimeout(() => {
        setHighlightedMessageId((curr) => (curr === msgId ? null : curr));
      }, 2500);
    } else {
      showToast('이전 메시지를 대화창에서 찾을 수 없습니다.', 'info');
    }
  };

  // Forward message to selected contact
  const handleForwardMessage = (recipientId: string) => {
    if (!forwardingMessage) return;
    const recipient = users.find((u) => u.id === recipientId);
    sendMessage(
      recipientId,
      forwardingMessage.content,
      forwardingMessage.mediaUrl,
      undefined,
      true // isForwarded
    );
    setForwardSentUserIds((prev) => [...prev, recipientId]);
    showToast('성공적으로 전달되었습니다', 'success', 'top');
  };

  // Copy message text to clipboard
  const handleCopyText = (content: string) => {
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(content);
    }
    showToast('메시지가 클립보드에 복사되었습니다.', 'info');
    setSelectedMessageForMenu(null);
  };

  useEffect(() => {
    // Only auto-scroll to bottom if not actively navigating search results or highlighted quote
    if (!currentTargetMessageId && !highlightedMessageId) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [currentConversationMessages, currentTargetMessageId, highlightedMessageId]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !targetUser) return;

    let replyInfo: MessageReplyInfo | undefined;
    if (replyingToMessage) {
      const sender = users.find((u) => u.id === replyingToMessage.senderId);
      const senderName =
        replyingToMessage.senderId === currentUser.id
          ? '나'
          : sender?.name || targetUser.name;
      replyInfo = {
        messageId: replyingToMessage.id,
        senderName,
        content: replyingToMessage.content,
        mediaUrl: replyingToMessage.mediaUrl
      };
    }

    sendMessage(targetUser.id, messageText.trim(), undefined, replyInfo);
    setMessageText('');
    setReplyingToMessage(null);
  };

  const handleSendPhoto = (url: string) => {
    if (!targetUser) return;
    sendMessage(targetUser.id, '', url);
    setShowPhotoPicker(false);
  };

  const handlePhotoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          handleSendPhoto(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddEmoji = (emoji: string) => {
    setMessageText((prev) => prev + emoji);
    setShowEmojiPicker(false);
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] md:h-[calc(100vh-6rem)] rounded-2xl border border-slate-200 bg-white shadow-sm ring-1 ring-slate-200/50 overflow-hidden dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
      {/* 1. Conversations Sidebar */}
      <div
        className={`w-full md:w-80 lg:w-88 border-r border-slate-200 dark:border-slate-800 flex flex-col ${
          activeChatUserId ? 'hidden md:flex' : 'flex'
        }`}
      >
        {/* Chat Sidebar Header */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">메시지함</h2>
              {totalUnreadCount > 0 && (
                <span
                  id="messages-total-unread-badge"
                  className="flex h-5 min-w-[20px] items-center justify-center rounded-full bg-blue-600 px-1.5 text-[11px] font-bold text-white shadow-xs animate-in zoom-in-75"
                  title={`읽지 않은 메시지 총 ${totalUnreadCount}개`}
                >
                  {totalUnreadCount > 99 ? '99+' : totalUnreadCount}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              {totalUnreadCount > 0 && (
                <button
                  id="messages-mark-all-read-btn"
                  onClick={markAllMessagesAsRead}
                  className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors"
                  title="모든 메시지 읽음 처리"
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  <span>모두 읽음</span>
                </button>
              )}
            </div>
          </div>

          {/* Search bar */}
          <div className="relative mb-2.5">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={chatSearch}
              onChange={(e) => setChatSearch(e.target.value)}
              placeholder="대화 상대 검색..."
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
            />
          </div>

          {/* Filter Tabs: 전체 / 안 읽음 / ⭐ 보관함 */}
          <div className="flex items-center gap-1 pt-1">
            <button
              id="chat-filter-all-btn"
              onClick={() => setFilterMode('all')}
              className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold transition-colors text-center ${
                filterMode === 'all'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              전체 ({availableContacts.length})
            </button>
            <button
              id="chat-filter-unread-btn"
              onClick={() => setFilterMode('unread')}
              className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold transition-colors flex items-center justify-center gap-1 ${
                filterMode === 'unread'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <span>안 읽음</span>
              {unreadContactsCount > 0 && (
                <span
                  id="chat-filter-unread-count-badge"
                  className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${
                    filterMode === 'unread'
                      ? 'bg-white text-blue-600'
                      : 'bg-blue-600 text-white'
                  }`}
                >
                  {unreadContactsCount}
                </span>
              )}
            </button>
            <button
              id="chat-filter-starred-btn"
              onClick={() => setFilterMode('starred')}
              className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-semibold transition-colors flex items-center justify-center gap-1 ${
                filterMode === 'starred'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <Star className={`w-3 h-3 ${filterMode === 'starred' ? 'fill-white text-white' : 'text-amber-500 fill-amber-400'}`} />
              <span>보관함</span>
              {starredContactsCount > 0 && (
                <span
                  id="chat-filter-starred-count-badge"
                  className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${
                    filterMode === 'starred'
                      ? 'bg-white text-amber-600'
                      : 'bg-amber-500 text-white'
                  }`}
                >
                  {starredContactsCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Contacts List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60">
          {sortedAndFilteredContacts.length === 0 ? (
            <div className="p-8 text-center text-slate-400">
              {filterMode === 'unread' ? (
                <div className="flex flex-col items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <CheckCheck className="w-5 h-5" />
                  </div>
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    읽지 않은 메시지가 없습니다
                  </p>
                  <button
                    onClick={() => setFilterMode('all')}
                    className="mt-1 text-xs text-blue-600 dark:text-blue-400 underline"
                  >
                    전체 대화 보기
                  </button>
                </div>
              ) : filterMode === 'starred' ? (
                <div className="flex flex-col items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-amber-50 dark:bg-amber-950/50 flex items-center justify-center text-amber-500">
                    <Star className="w-5 h-5 fill-amber-400 text-amber-500" />
                  </div>
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    즐겨찾기 보관된 대화가 없습니다
                  </p>
                  <p className="text-[11px] text-slate-400 max-w-xs">
                    중요한 메시지를 길게 눌러 &apos;즐겨찾기 보관&apos;을 해보세요.
                  </p>
                  <button
                    onClick={() => setFilterMode('all')}
                    className="mt-1 text-xs text-amber-600 dark:text-amber-400 underline font-semibold"
                  >
                    전체 대화 보기
                  </button>
                </div>
              ) : (
                <p className="text-xs">검색된 대화 상대가 없습니다.</p>
              )}
            </div>
          ) : (
            sortedAndFilteredContacts.map(({ user, lastMsg, unreadCount }) => {
              const isSelected = user.id === targetUser?.id;
              const isLastMsgMine = lastMsg && lastMsg.senderId === currentUser.id;

              return (
                <button
                  key={user.id}
                  id={`chat-contact-btn-${user.id}`}
                  onClick={() => {
                    setActiveChatUserId(user.id);
                    markConversationAsRead(user.id);
                  }}
                  className={`group relative flex w-full items-center gap-3 p-3.5 text-left transition-all ${
                    isSelected
                      ? 'bg-blue-50/80 dark:bg-blue-950/50 border-r-2 border-blue-600'
                      : unreadCount > 0
                      ? 'bg-blue-50/30 dark:bg-blue-950/20 hover:bg-blue-50/60 dark:hover:bg-blue-950/40'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="relative flex-shrink-0">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className={`h-11 w-11 rounded-full object-cover border transition-all ${
                        unreadCount > 0
                          ? 'border-blue-500 ring-2 ring-blue-500/25'
                          : 'border-slate-200 dark:border-slate-700'
                      }`}
                      referrerPolicy="no-referrer"
                    />
                    <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-0.5 -right-0.5 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-600"></span>
                      </span>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <span
                        className={`text-xs truncate transition-colors ${
                          unreadCount > 0
                            ? 'font-extrabold text-slate-900 dark:text-white'
                            : isSelected
                            ? 'font-bold text-blue-600 dark:text-blue-400'
                            : 'font-semibold text-slate-800 dark:text-slate-200'
                        }`}
                      >
                        {user.name}
                      </span>
                      {lastMsg && (
                        <span
                          className={`text-[10px] flex-shrink-0 ${
                            unreadCount > 0
                              ? 'font-bold text-blue-600 dark:text-blue-400'
                              : 'text-slate-400'
                          }`}
                        >
                          {formatRelativeTime(lastMsg.createdAt)}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between gap-1.5">
                      <div
                        className={`flex items-center gap-1.5 text-xs truncate ${
                          unreadCount > 0
                            ? 'font-semibold text-slate-900 dark:text-slate-100'
                            : 'text-slate-500 dark:text-slate-400'
                        }`}
                      >
                        {lastMsg && isLastMsgMine && (
                          <span
                            className="shrink-0 flex items-center"
                            title={lastMsg.isRead ? '상대방이 읽음' : '전송됨 (상대방 미확인)'}
                          >
                            {lastMsg.isRead ? (
                              <CheckCheck className="w-3.5 h-3.5 text-blue-500" />
                            ) : (
                              <Check className="w-3.5 h-3.5 text-slate-400" />
                            )}
                          </span>
                        )}
                        <p className="truncate">
                          {lastMsg ? (
                            <>
                              {isLastMsgMine ? '나: ' : ''}
                              {lastMsg.content || '📷 사진'}
                            </>
                          ) : (
                            '새로운 대화를 시작해보세요'
                          )}
                        </p>
                      </div>

                      {/* Right indicator: Unread Badge or Read/Sent text */}
                      <div className="flex items-center gap-1 shrink-0">
                        {lastMsg && isLastMsgMine && (
                          <span
                            className={`text-[10px] font-medium ${
                              lastMsg.isRead
                                ? 'text-blue-600 dark:text-blue-400 font-semibold'
                                : 'text-slate-400'
                            }`}
                          >
                            {lastMsg.isRead ? '읽음' : '전송됨'}
                          </span>
                        )}

                        {/* Number Badge for Unread Messages from Partner */}
                        {unreadCount > 0 && (
                          <span
                            id={`chat-unread-badge-${user.id}`}
                            className="flex h-5 min-w-[20px] items-center justify-center rounded-full bg-blue-600 px-1.5 text-[10px] font-bold text-white shadow-xs animate-in zoom-in-75 duration-150 ring-2 ring-white dark:ring-slate-900"
                            title={`상대방이 보낸 읽지 않은 메시지 ${unreadCount}개`}
                          >
                            {unreadCount > 99 ? '99+' : unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* 2. Active Chat Conversation Window */}
      {targetUser ? (
        <div
          className={`flex-1 flex flex-col bg-slate-50/50 dark:bg-slate-950/40 ${
            !activeChatUserId ? 'hidden md:flex' : 'flex'
          }`}
        >
          {/* Active Chat Header */}
          <div className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center gap-3">
              <button
                id="mobile-back-to-chat-list"
                onClick={() => setActiveChatUserId(null)}
                className="p-1 rounded-lg text-slate-500 md:hidden hover:bg-slate-100 dark:hover:bg-slate-800"
                title="대화 목록으로 돌아가기"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>

              <div className="relative">
                <img
                  src={targetUser.avatar}
                  alt={targetUser.name}
                  className="h-10 w-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
              </div>

              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  {targetUser.name}
                </h3>
                <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
                  현재 활동 중
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1 text-slate-400">
              {/* Starred Messages Filter Toggle */}
              <button
                id="toggle-starred-filter-btn"
                onClick={() => {
                  setIsStarredFilterActive((prev) => !prev);
                  if (isSearchOpen) setIsSearchOpen(false);
                }}
                title={
                  isStarredFilterActive
                    ? '전체 대화로 돌아가기'
                    : conversationStarredCount > 0
                    ? `즐겨찾기 보관된 메시지 (${conversationStarredCount}개) 필터링`
                    : '이 대화방에 즐겨찾기 보관된 메시지 없음'
                }
                className={`p-2 rounded-full transition-all relative cursor-pointer ${
                  isStarredFilterActive
                    ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300 ring-2 ring-amber-400'
                    : conversationStarredCount > 0
                    ? 'text-amber-500 hover:bg-amber-50 dark:hover:bg-amber-950/40'
                    : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-300'
                }`}
              >
                <Star
                  className={`h-4 w-4 ${
                    isStarredFilterActive || conversationStarredCount > 0
                      ? 'fill-amber-400 text-amber-500'
                      : 'text-slate-400'
                  }`}
                />
                {conversationStarredCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-amber-500 px-1 text-[9px] font-bold text-white shadow-xs">
                    {conversationStarredCount}
                  </span>
                )}
              </button>

              <button
                id="toggle-chat-search-btn"
                onClick={() => {
                  setIsSearchOpen((prev) => {
                    const next = !prev;
                    if (!next) {
                      setMessageSearchKeyword('');
                    }
                    return next;
                  });
                }}
                title={isSearchOpen ? '대화 검색 닫기' : '대화 내용 검색 (키워드 찾기)'}
                className={`p-2 rounded-full transition-colors ${
                  isSearchOpen
                    ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/60 dark:text-blue-300'
                    : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-300'
                }`}
              >
                <Search className="h-4 w-4" />
              </button>

              <button
                title="상대방 프로필 정보"
                className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-300"
              >
                <Info className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Starred Messages Active Filter Banner */}
          {isStarredFilterActive && (
            <div
              id="starred-messages-filter-banner"
              className="border-b border-amber-200 bg-amber-50/95 px-3 py-2 flex items-center justify-between gap-3 backdrop-blur-xs text-xs dark:border-amber-900/60 dark:bg-amber-950/60 animate-in slide-in-from-top-2 duration-150"
            >
              <div className="flex items-center gap-2 text-amber-900 dark:text-amber-100 min-w-0">
                <Star className="w-4 h-4 fill-amber-400 text-amber-500 shrink-0" />
                <span className="font-bold truncate">
                  ⭐ 즐겨찾기 보관 메시지만 필터링하여 보는 중 ({conversationStarredCount}개)
                </span>
              </div>
              <button
                type="button"
                id="exit-starred-filter-btn"
                onClick={() => setIsStarredFilterActive(false)}
                className="px-2.5 py-1 rounded-lg bg-amber-200/90 hover:bg-amber-300/90 text-amber-950 dark:bg-amber-900/80 dark:hover:bg-amber-800 dark:text-amber-100 font-bold text-[11px] shrink-0 transition-colors cursor-pointer"
              >
                전체 대화 보기
              </button>
            </div>
          )}

          {/* In-Chat Message Keyword Search Bar */}
          {isSearchOpen && (
            <div
              id="chat-search-toolbar"
              className="border-b border-slate-200 bg-white/95 px-3 py-2 flex items-center gap-2 backdrop-blur-xs shadow-xs dark:border-slate-800 dark:bg-slate-900/95 animate-in slide-in-from-top-2 duration-150"
            >
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                <input
                  ref={searchInputRef}
                  type="text"
                  id="in-chat-search-input"
                  value={messageSearchKeyword}
                  onChange={(e) => {
                    setMessageSearchKeyword(e.target.value);
                    setCurrentSearchIndex(0);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      if (e.shiftKey) {
                        handlePrevSearchResult();
                      } else {
                        handleNextSearchResult();
                      }
                    } else if (e.key === 'Escape') {
                      setIsSearchOpen(false);
                      setMessageSearchKeyword('');
                    }
                  }}
                  placeholder="대화 내용 검색... (Enter로 다음 결과 이동)"
                  className="w-full rounded-xl border border-slate-200 bg-slate-50 py-1.5 pl-8.5 pr-8 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                />
                {messageSearchKeyword && (
                  <button
                    onClick={() => {
                      setMessageSearchKeyword('');
                      searchInputRef.current?.focus();
                    }}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Match Counter & Prev/Next Navigation */}
              {messageSearchKeyword.trim() && (
                <div className="flex items-center gap-1.5 shrink-0">
                  <span
                    className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                      matchingMessageIds.length > 0
                        ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                        : 'bg-rose-50 text-rose-600 dark:bg-rose-950/50 dark:text-rose-400'
                    }`}
                  >
                    {matchingMessageIds.length > 0
                      ? `${currentSearchIndex + 1} / ${matchingMessageIds.length}개`
                      : '일치 없음'}
                  </span>
                  <button
                    id="search-prev-btn"
                    disabled={matchingMessageIds.length === 0}
                    onClick={handlePrevSearchResult}
                    title="이전 결과 (Shift+Enter)"
                    className="p-1 rounded-md border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-30 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  >
                    <ChevronUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    id="search-next-btn"
                    disabled={matchingMessageIds.length === 0}
                    onClick={handleNextSearchResult}
                    title="다음 결과 (Enter)"
                    className="p-1 rounded-md border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 disabled:opacity-30 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  >
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <button
                id="close-chat-search-btn"
                onClick={() => {
                  setIsSearchOpen(false);
                  setMessageSearchKeyword('');
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-medium"
                title="검색 닫기 (Esc)"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Messages Bubble Area */}
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
            {/* Conversation Introduction */}
            <div className="text-center my-4">
              <img
                src={targetUser.avatar}
                alt={targetUser.name}
                className="h-16 w-16 rounded-full object-cover mx-auto mb-2 border-2 border-blue-200 dark:border-blue-900"
                referrerPolicy="no-referrer"
              />
              <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                {targetUser.name}
              </h4>
              <p className="text-xs text-slate-400">@{targetUser.handle}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                {targetUser.bio}
              </p>
            </div>

            {/* Starred Messages Filter Empty State */}
            {isStarredFilterActive && displayedConversationMessages.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center my-auto">
                <div className="w-16 h-16 rounded-2xl bg-amber-50 dark:bg-amber-950/60 flex items-center justify-center text-amber-500 mb-3 shadow-xs">
                  <Star className="w-8 h-8 fill-amber-400 text-amber-500" />
                </div>
                <h4 className="font-bold text-base text-slate-800 dark:text-slate-100 mb-1">
                  보관된 즐겨찾기 메시지가 없습니다
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mb-4 leading-relaxed">
                  중요한 대화 메시지를 길게 누르거나 더보기(···)를 클릭하여 &apos;즐겨찾기 보관&apos;을 설정하면 언제든지 이곳에서 모아볼 수 있습니다.
                </p>
                <button
                  type="button"
                  onClick={() => setIsStarredFilterActive(false)}
                  className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold hover:bg-blue-700 shadow-xs transition-colors cursor-pointer"
                >
                  전체 대화로 돌아가기
                </button>
              </div>
            ) : (
              displayedConversationMessages.map((msg) => {
                const isMine = msg.senderId === currentUser.id;
                const isUnreadReceived = !isMine && !msg.isRead;
                const isMatch = matchingMessageIds.includes(msg.id);
                const isCurrentTarget = msg.id === currentTargetMessageId;
                const isHighlighted = highlightedMessageId === msg.id;

                return (
                  <div
                    key={msg.id}
                    id={`chat-msg-${msg.id}`}
                    onClick={() => {
                      if (isUnreadReceived) {
                        markMessageAsRead(msg.id);
                      }
                    }}
                    onTouchStart={(e) => startLongPress(msg, e)}
                    onTouchEnd={cancelLongPress}
                    onTouchMove={handleTouchMove}
                    onMouseDown={(e) => {
                      if (e.button === 0) startLongPress(msg, e);
                    }}
                    onMouseUp={cancelLongPress}
                    onMouseLeave={cancelLongPress}
                    onContextMenu={(e) => {
                      e.preventDefault();
                      cancelLongPress();
                      setSelectedMessageForMenu(msg);
                    }}
                    className={`group relative flex flex-col transition-all duration-200 ${
                      isMine ? 'items-end' : 'items-start'
                    } ${isUnreadReceived ? 'cursor-pointer' : ''} ${
                      isCurrentTarget || isHighlighted ? 'scale-[1.01]' : ''
                    }`}
                    title={isUnreadReceived ? '클릭하여 읽음 처리' : '길게 누르면 답장, 전달, 즐겨찾기 메뉴 표시'}
                  >
                    {/* Bubble wrapper with quick action hover trigger */}
                    <div
                      className={`flex items-center gap-1.5 max-w-[85%] md:max-w-md ${
                        isMine ? 'flex-row-reverse' : 'flex-row'
                      }`}
                    >
                      <div
                        className={`relative rounded-2xl p-3 shadow-xs transition-all duration-200 select-text ${
                          isHighlighted
                            ? 'ring-4 ring-amber-400 dark:ring-amber-400 shadow-lg shadow-amber-500/25 animate-pulse'
                            : isCurrentTarget
                            ? 'ring-3 ring-amber-400 dark:ring-amber-400 shadow-md shadow-amber-500/20'
                            : isMatch
                            ? 'ring-2 ring-yellow-400/80 dark:ring-yellow-400/60'
                            : ''
                        } ${
                          msg.isStarred
                            ? isMine
                              ? 'ring-2 ring-amber-300 dark:ring-amber-400/80 shadow-xs'
                              : 'ring-2 ring-amber-400/80 border-amber-300 dark:border-amber-500 shadow-xs'
                            : ''
                        } ${
                          isMine
                            ? 'bg-blue-600 text-white rounded-br-xs'
                            : isUnreadReceived
                            ? 'bg-blue-50 dark:bg-slate-800 text-slate-900 dark:text-white border-2 border-blue-400 dark:border-blue-500 rounded-bl-xs hover:border-blue-600'
                            : 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 rounded-bl-xs'
                        }`}
                      >
                        {/* Forwarded message label */}
                        {msg.isForwarded && (
                          <div
                            className={`flex items-center gap-1 text-[10px] mb-1.5 font-medium select-none ${
                              isMine ? 'text-blue-100' : 'text-slate-400 dark:text-slate-400'
                            }`}
                          >
                            <Share2 className="w-3 h-3" />
                            <span>전달된 메시지</span>
                          </div>
                        )}

                        {/* Starred badge label in bubble */}
                        {msg.isStarred && (
                          <div
                            className={`flex items-center gap-1 text-[10px] mb-1.5 font-bold select-none ${
                              isMine ? 'text-amber-200' : 'text-amber-600 dark:text-amber-400'
                            }`}
                          >
                            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                            <span>즐겨찾기 보관됨</span>
                          </div>
                        )}

                        {/* Replying quote preview card */}
                        {msg.replyTo && (
                          <div
                            onClick={(e) => {
                              e.stopPropagation();
                              scrollToMessage(msg.replyTo!.messageId);
                            }}
                            className={`mb-2 p-2 rounded-xl border-l-3 text-xs cursor-pointer transition-all ${
                              isMine
                                ? 'bg-blue-700/70 border-white text-white/95 hover:bg-blue-700'
                                : 'bg-slate-100 dark:bg-slate-750 border-blue-500 text-slate-700 dark:text-slate-200 hover:bg-slate-200/80 dark:hover:bg-slate-700'
                            }`}
                            title="답장한 원본 메시지로 이동"
                          >
                            <div className="font-bold text-[11px] flex items-center gap-1 opacity-90 mb-0.5">
                              <CornerUpLeft className="w-3 h-3 shrink-0" />
                              <span className="truncate">{msg.replyTo.senderName}에게 답장</span>
                            </div>
                            <p className="truncate text-[11px] opacity-80">
                              {msg.replyTo.content || (msg.replyTo.mediaUrl ? '📷 사진' : '')}
                            </p>
                          </div>
                        )}

                        {msg.mediaUrl && (
                          <img
                            src={msg.mediaUrl}
                            alt="Shared media"
                            className="rounded-xl max-h-48 object-cover mb-1.5"
                            referrerPolicy="no-referrer"
                          />
                        )}
                        {msg.content && (
                          <p className="text-xs md:text-sm leading-relaxed whitespace-pre-wrap">
                            {renderHighlightedContent(msg.content, messageSearchKeyword, isCurrentTarget)}
                          </p>
                        )}
                      </div>

                      {/* Quick message options hover trigger button */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedMessageForMenu(msg);
                        }}
                        className="opacity-0 group-hover:opacity-100 focus:opacity-100 p-1.5 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-all shrink-0 cursor-pointer"
                        title="답장 / 전달 / 즐겨찾기 메뉴 열기 (길게 누르기도 가능)"
                      >
                        <MoreHorizontal className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Timestamp Details & Read / Checkmark / Star Status */}
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mt-1 px-1">
                      <span>{formatRelativeTime(msg.createdAt)}</span>

                      {/* Star icon badge in timestamp line */}
                      {msg.isStarred && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleStarMessage(msg.id);
                          }}
                          className="flex items-center gap-0.5 text-amber-500 hover:text-amber-600 dark:text-amber-400 font-semibold cursor-pointer"
                          title="즐겨찾기 보관됨 (클릭 시 즐겨찾기 해제)"
                        >
                          <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                          <span className="text-[9px]">보관됨</span>
                        </button>
                      )}

                      {/* Read status & checkmarks for current user's sent messages */}
                      {isMine && (
                        <span className="flex items-center gap-1">
                          {msg.isRead ? (
                            <span
                              className="flex items-center gap-0.5 text-blue-600 dark:text-blue-400 font-semibold"
                              title={msg.readAt ? `${formatRelativeTime(msg.readAt)}에 읽음` : '상대방이 읽음'}
                            >
                              <CheckCheck className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                              <span>읽음</span>
                            </span>
                          ) : (
                            <span
                              className="flex items-center gap-0.5 text-slate-400 dark:text-slate-500 font-medium"
                              title="전송됨 (상대방이 아직 읽지 않음)"
                            >
                              <Check className="w-3.5 h-3.5 text-slate-400" />
                              <span className="text-[9px] font-bold text-amber-500 dark:text-amber-400">1</span>
                            </span>
                          )}
                        </span>
                      )}

                      {/* Unread badge for received messages */}
                      {isUnreadReceived && (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300">
                          <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse" />
                          안 읽음
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Photo Picker Drawer */}
          {showPhotoPicker && (
            <div className="border-t border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900 animate-in slide-in-from-bottom-2 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                  <ImageIcon className="h-4 w-4 text-emerald-500" />
                  사진 전송
                </span>
                <button
                  type="button"
                  onClick={() => setShowPhotoPicker(false)}
                  className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  닫기
                </button>
              </div>

              <input
                ref={photoInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoFileUpload}
                className="hidden"
              />

              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={() => photoInputRef.current?.click()}
                  className="flex items-center justify-center gap-1.5 px-3.5 py-1.5 rounded-lg border border-dashed border-emerald-400 bg-emerald-50/50 text-xs font-bold text-emerald-600 hover:bg-emerald-100 dark:border-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 transition-colors cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>내 기기에서 사진 선택</span>
                </button>
                <div className="flex-1 flex gap-2">
                  <input
                    type="url"
                    value={customPhotoUrl}
                    onChange={(e) => setCustomPhotoUrl(e.target.value)}
                    placeholder="또는 이미지 URL 직접 입력..."
                    className="flex-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (customPhotoUrl.trim()) {
                        handleSendPhoto(customPhotoUrl.trim());
                        setCustomPhotoUrl('');
                      }
                    }}
                    disabled={!customPhotoUrl.trim()}
                    className="px-3 py-1 bg-emerald-600 disabled:opacity-40 text-white rounded-lg text-xs font-bold hover:bg-emerald-700 transition-colors cursor-pointer"
                  >
                    전송
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Emoji Picker Drawer */}
          {showEmojiPicker && (
            <div className="border-t border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900 flex flex-wrap gap-2 animate-in slide-in-from-bottom-2">
              {['👍', '❤️', '😊', '🔥', '👏', '🎉', '☕️', '💻', '🥐', '✨', '🙌', '🚀'].map((em) => (
                <button
                  key={em}
                  onClick={() => handleAddEmoji(em)}
                  className="text-xl p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg hover:scale-125 transition-transform"
                >
                  {em}
                </button>
              ))}
            </div>
          )}

          {/* Reply Preview Banner (When replying to a specific message) */}
          {replyingToMessage && (
            <div
              id="chat-reply-preview-banner"
              className="border-t border-slate-200 bg-blue-50/80 px-4 py-2 flex items-center justify-between gap-3 backdrop-blur-xs dark:border-slate-800 dark:bg-slate-850 animate-in slide-in-from-bottom-2 duration-150"
            >
              <div className="flex items-center gap-2.5 min-w-0 border-l-2 border-blue-600 pl-2.5">
                <CornerUpLeft className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                <div className="min-w-0">
                  <p className="text-[11px] font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1">
                    <span>
                      {replyingToMessage.senderId === currentUser.id
                        ? '나'
                        : users.find((u) => u.id === replyingToMessage.senderId)?.name || targetUser?.name}
                    </span>
                    <span>님에게 답장</span>
                  </p>
                  <p className="text-xs text-slate-700 dark:text-slate-300 truncate mt-0.5">
                    {replyingToMessage.content || (replyingToMessage.mediaUrl ? '📷 사진' : '')}
                  </p>
                </div>
              </div>
              <button
                type="button"
                id="cancel-reply-btn"
                onClick={() => setReplyingToMessage(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
                title="답장 취소"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Chat Message Input Bar */}
          <form
            onSubmit={handleSend}
            className="flex items-center gap-2 border-t border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900"
          >
            <button
              type="button"
              onClick={() => setShowPhotoPicker((prev) => !prev)}
              className="p-2 rounded-full text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800"
            >
              <ImageIcon className="h-5 w-5" />
            </button>

            <button
              type="button"
              onClick={() => setShowEmojiPicker((prev) => !prev)}
              className="p-2 rounded-full text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800"
            >
              <Smile className="h-5 w-5" />
            </button>

            <input
              type="text"
              id="chat-message-input"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder={replyingToMessage ? '답장 메시지를 입력하세요...' : '메시지를 입력하세요...'}
              className="flex-1 rounded-full border border-slate-200 bg-slate-50 px-4 py-2 text-xs md:text-sm text-slate-900 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:text-slate-900 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder-slate-400 dark:focus:bg-slate-800 dark:focus:text-white dark:focus:border-blue-400"
            />

            <button
              type="submit"
              disabled={!messageText.trim()}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-600 text-white disabled:opacity-40 hover:bg-blue-700 transition-colors cursor-pointer"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      ) : (
        <div className="flex-1 hidden md:flex flex-col items-center justify-center p-8 text-center bg-slate-50/40 dark:bg-slate-950/40">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 dark:bg-blue-950/60 flex items-center justify-center text-blue-600 dark:text-blue-400 mb-4 shadow-xs">
            <MessageCircle className="w-8 h-8" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
            대화를 선택해주세요
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mb-4">
            왼쪽 대화 목록에서 상대방을 선택하면 대화 내용을 확인하고 새 메시지를 주고받을 수 있습니다.
          </p>
          {totalUnreadCount > 0 ? (
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 text-xs font-semibold">
              <span className="h-2 w-2 rounded-full bg-blue-600 animate-pulse" />
              <span>읽지 않은 메시지 총 {totalUnreadCount}개 대기 중</span>
            </div>
          ) : (
            <span className="text-xs text-slate-400">모든 메시지를 확인했습니다 ✨</span>
          )}
        </div>
      )}

      {/* Message Action Popup Menu (Triggered on long-press, context menu, or action button) */}
      {selectedMessageForMenu && (
        <div
          id="message-action-popup-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/40 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setSelectedMessageForMenu(null)}
        >
          <div
            id="message-action-popup-card"
            className="w-full max-w-xs rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-4 space-y-3.5 animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Quick Emoji Reaction Row */}
            <div className="flex items-center justify-around py-1.5 px-2 bg-slate-100 dark:bg-slate-800/80 rounded-xl">
              {['❤️', '👍', '😂', '🔥', '🙏', '👏'].map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => {
                    if (targetUser) {
                      const sender = users.find((u) => u.id === selectedMessageForMenu.senderId);
                      const senderName =
                        selectedMessageForMenu.senderId === currentUser.id
                          ? '나'
                          : sender?.name || targetUser.name;
                      sendMessage(targetUser.id, emoji, undefined, {
                        messageId: selectedMessageForMenu.id,
                        senderName,
                        content: selectedMessageForMenu.content,
                        mediaUrl: selectedMessageForMenu.mediaUrl
                      });
                      showToast(`${emoji} 리액션을 전송했습니다.`, 'success');
                    }
                    setSelectedMessageForMenu(null);
                  }}
                  className="text-lg p-1 hover:scale-130 active:scale-95 transition-transform cursor-pointer"
                  title={`${emoji} 빠른 답장`}
                >
                  {emoji}
                </button>
              ))}
            </div>

            {/* Selected Message Snippet Preview */}
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 text-xs">
              <span className="font-bold text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">
                {selectedMessageForMenu.senderId === currentUser.id
                  ? '내가 보낸 메시지'
                  : `${users.find((u) => u.id === selectedMessageForMenu.senderId)?.name || targetUser?.name || '상대방'}의 메시지`}
              </span>
              <p className="text-slate-800 dark:text-slate-200 line-clamp-2 leading-relaxed">
                {selectedMessageForMenu.content || (selectedMessageForMenu.mediaUrl ? '📷 사진' : '')}
              </p>
            </div>

            {/* Menu Options: 직접 답장(Reply), 메시지 전달(Forward), 텍스트 복사(Copy) */}
            <div className="space-y-1">
              <button
                type="button"
                id="msg-popup-reply-btn"
                onClick={() => {
                  setReplyingToMessage(selectedMessageForMenu);
                  setSelectedMessageForMenu(null);
                  setTimeout(() => {
                    const input = document.getElementById('chat-message-input') as HTMLInputElement | null;
                    input?.focus();
                  }, 100);
                }}
                className="flex w-full items-center gap-3 px-3 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-blue-50 hover:text-blue-600 dark:hover:bg-blue-950/50 dark:hover:text-blue-300 rounded-xl transition-colors cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                  <CornerUpLeft className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span>직접 답장 (Reply)</span>
                  <p className="text-[10px] text-slate-400 font-normal">이 메시지를 인용하여 답장합니다</p>
                </div>
              </button>

              <button
                type="button"
                id="msg-popup-forward-btn"
                onClick={() => {
                  setForwardingMessage(selectedMessageForMenu);
                  setForwardSentUserIds([]);
                  setSelectedMessageForMenu(null);
                }}
                className="flex w-full items-center gap-3 px-3 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/50 dark:hover:text-indigo-300 rounded-xl transition-colors cursor-pointer"
              >
                <div className="w-7 h-7 rounded-lg bg-indigo-100 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
                  <Forward className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <span>메시지 전달 (Forward)</span>
                  <p className="text-[10px] text-slate-400 font-normal">다른 대화 상대에게 메시지를 공유합니다</p>
                </div>
              </button>

              {/* 즐겨찾기(Star) 토글 버튼 */}
              <button
                type="button"
                id="msg-popup-star-btn"
                onClick={() => {
                  toggleStarMessage(selectedMessageForMenu.id);
                  setSelectedMessageForMenu(null);
                }}
                className={`flex w-full items-center gap-3 px-3 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
                  selectedMessageForMenu.isStarred
                    ? 'text-amber-600 dark:text-amber-400 bg-amber-50/80 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/60'
                    : 'text-slate-800 dark:text-slate-200 hover:bg-amber-50 hover:text-amber-600 dark:hover:bg-amber-950/40 dark:hover:text-amber-300'
                }`}
              >
                <div
                  className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                    selectedMessageForMenu.isStarred
                      ? 'bg-amber-100 dark:bg-amber-900/80 text-amber-500'
                      : 'bg-amber-50 dark:bg-amber-950/70 text-amber-500'
                  }`}
                >
                  <Star
                    className={`w-4 h-4 ${
                      selectedMessageForMenu.isStarred ? 'fill-amber-400 text-amber-500' : 'text-amber-500'
                    }`}
                  />
                </div>
                <div className="text-left">
                  <span>{selectedMessageForMenu.isStarred ? '즐겨찾기 해제 (Unstar)' : '즐겨찾기 보관 (Star)'}</span>
                  <p className="text-[10px] text-slate-400 font-normal">
                    {selectedMessageForMenu.isStarred
                      ? '보관된 즐겨찾기 목록에서 제외합니다'
                      : '중요한 메시지로 보관하여 나중에 모아봅니다'}
                  </p>
                </div>
              </button>

              {selectedMessageForMenu.content && (
                <button
                  type="button"
                  id="msg-popup-copy-btn"
                  onClick={() => handleCopyText(selectedMessageForMenu.content)}
                  className="flex w-full items-center gap-3 px-3 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
                >
                  <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center shrink-0">
                    <Copy className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <span>텍스트 복사 (Copy)</span>
                    <p className="text-[10px] text-slate-400 font-normal">메시지 본문을 클립보드에 복사합니다</p>
                  </div>
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={() => setSelectedMessageForMenu(null)}
              className="w-full py-1.5 text-center text-xs font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 transition-colors cursor-pointer"
            >
              닫기
            </button>
          </div>
        </div>
      )}

      {/* Message Forward Modal (Select contact & Forward) */}
      {forwardingMessage && (
        <div
          id="message-forward-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/50 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setForwardingMessage(null)}
        >
          <div
            id="message-forward-modal-card"
            className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-4.5 space-y-3.5 animate-in zoom-in-95 duration-150 flex flex-col max-h-[85vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                  <Forward className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">메시지 전달하기</h3>
              </div>
              <button
                type="button"
                onClick={() => setForwardingMessage(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Message Preview */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 text-xs">
              <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider block mb-1">
                전달할 메시지 내용
              </span>
              {forwardingMessage.mediaUrl && (
                <img
                  src={forwardingMessage.mediaUrl}
                  alt="Forward media"
                  className="w-full max-h-32 object-cover rounded-lg mb-2"
                />
              )}
              <p className="text-slate-800 dark:text-slate-200 leading-relaxed max-h-24 overflow-y-auto">
                {forwardingMessage.content || '📷 사진'}
              </p>
            </div>

            {/* Search Input for Contacts */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                value={forwardSearch}
                onChange={(e) => setForwardSearch(e.target.value)}
                placeholder="전달할 대화 상대 검색..."
                className="w-full rounded-xl border border-slate-200 bg-slate-50 py-1.5 pl-8.5 pr-3 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
              />
            </div>

            {/* Contacts List */}
            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 max-h-56 pr-1">
              {availableContacts
                .filter(
                  (c) =>
                    !forwardSearch.trim() ||
                    c.name.toLowerCase().includes(forwardSearch.toLowerCase()) ||
                    c.handle.toLowerCase().includes(forwardSearch.toLowerCase())
                )
                .map((contact) => {
                  const hasSent = forwardSentUserIds.includes(contact.id);
                  return (
                    <div
                      key={contact.id}
                      className="flex items-center justify-between py-2 px-1 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-lg transition-colors"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={contact.avatar}
                          alt={contact.name}
                          className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                            {contact.name}
                          </p>
                          <p className="text-[10px] text-slate-400 truncate">@{contact.handle}</p>
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={hasSent}
                        onClick={() => handleForwardMessage(contact.id)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                          hasSent
                            ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400'
                            : 'bg-blue-600 text-white hover:bg-blue-700 shadow-xs cursor-pointer'
                        }`}
                      >
                        {hasSent ? '전달됨 ✓' : '전달'}
                      </button>
                    </div>
                  );
                })}
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setForwardingMessage(null)}
                className="px-4 py-1.5 rounded-lg text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
