import React, { useState, useMemo } from 'react';
import { useSocial } from '../context/SocialContext';
import { PostCard } from './PostCard';
import { Post, User } from '../types';
import {
  Bookmark,
  BookmarkCheck,
  Search,
  Filter,
  Sparkles,
  Trash2,
  Users,
  ShieldCheck,
  Image as ImageIcon,
  FileText,
  BarChart2,
  Mic,
  ArrowUpDown,
  Compass,
  CheckCircle2,
  Eye,
  TrendingUp,
  AlertCircle,
  FolderHeart,
  ChevronDown
} from 'lucide-react';

export const BookmarksView: React.FC = () => {
  const {
    currentUser,
    posts,
    users,
    switchUser,
    setActiveTab,
    toggleBookmark,
    clearAllBookmarks,
    showToast,
    deletedPostIds
  } = useSocial();

  // Admin view mode: 'my' (My own bookmarks) or 'all_members' (Member bookmarks overview)
  const isAdmin = currentUser.isAdmin || currentUser.handle === 'admin';
  const [adminMode, setAdminMode] = useState<'my' | 'all_members'>('my');
  const [selectedMemberId, setSelectedMemberId] = useState<string>('all');

  // Search & Filter States
  const [searchTerm, setSearchTerm] = useState('');
  const [contentType, setContentType] = useState<'all' | 'media' | 'text' | 'poll' | 'voice'>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'newest_post' | 'likes' | 'comments'>('recent');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  // Current active user's saved posts
  const mySavedPosts = useMemo(() => {
    return posts.filter(
      (p) =>
        p.bookmarks?.includes(currentUser.id) &&
        !(deletedPostIds || []).includes(p.id) &&
        !(p as any).isDeleted
    );
  }, [posts, currentUser.id, deletedPostIds]);

  // For Admin: Calculate platform-wide bookmark statistics
  const adminStats = useMemo(() => {
    let totalBookmarkSaves = 0;
    const bookmarkerUserIds = new Set<string>();
    const postsWithBookmarks = posts.filter((p) => {
      if ((deletedPostIds || []).includes(p.id) || (p as any).isDeleted) return false;
      const count = p.bookmarks?.length || 0;
      totalBookmarkSaves += count;
      p.bookmarks?.forEach((uid) => bookmarkerUserIds.add(uid));
      return count > 0;
    });

    // Top saved posts sorted by bookmark count
    const topSavedPosts = [...postsWithBookmarks].sort(
      (a, b) => (b.bookmarks?.length || 0) - (a.bookmarks?.length || 0)
    );

    return {
      totalBookmarkSaves,
      activeBookmarkersCount: bookmarkerUserIds.size,
      savedPostsCount: postsWithBookmarks.length,
      topSavedPosts
    };
  }, [posts, deletedPostIds]);

  // Determine the base set of posts to display based on mode
  const basePosts = useMemo(() => {
    const validPosts = posts.filter(
      (p) => !(deletedPostIds || []).includes(p.id) && !(p as any).isDeleted
    );
    if (isAdmin && adminMode === 'all_members') {
      if (selectedMemberId === 'all') {
        // Show all posts that have at least 1 bookmark across platform
        return validPosts.filter((p) => p.bookmarks && p.bookmarks.length > 0);
      } else {
        // Show posts bookmarked by the specific selected member
        return validPosts.filter((p) => p.bookmarks?.includes(selectedMemberId));
      }
    }
    // Default / Member view: show current user's bookmarks
    return mySavedPosts;
  }, [isAdmin, adminMode, selectedMemberId, posts, mySavedPosts, deletedPostIds]);

  // Filter & Sort the posts
  const filteredPosts = useMemo(() => {
    let result = [...basePosts];

    // 1. Search Filter (keyword in content, author, tags, location)
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      result = result.filter((post) => {
        const matchContent = post.content?.toLowerCase().includes(q);
        const matchAuthor =
          post.authorName?.toLowerCase().includes(q) ||
          post.authorHandle?.toLowerCase().includes(q);
        const matchTags = post.tags?.some((t) => t.toLowerCase().includes(q));
        const matchLocation = post.location?.toLowerCase().includes(q);
        return matchContent || matchAuthor || matchTags || matchLocation;
      });
    }

    // 2. Content Type Filter
    if (contentType === 'media') {
      result = result.filter(
        (p) => (p.images && p.images.length > 0) || Boolean(p.video)
      );
    } else if (contentType === 'text') {
      result = result.filter(
        (p) => (!p.images || p.images.length === 0) && !p.video && !p.poll
      );
    } else if (contentType === 'poll') {
      result = result.filter((p) => Boolean(p.poll));
    } else if (contentType === 'voice') {
      result = result.filter((p) => p.feeling?.includes('음성') || p.feeling?.includes('voice'));
    }

    // 3. Sorting
    result.sort((a, b) => {
      if (sortBy === 'newest_post') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      if (sortBy === 'likes') {
        return (b.likes?.length || 0) - (a.likes?.length || 0);
      }
      if (sortBy === 'comments') {
        return (b.commentsCount || 0) - (a.commentsCount || 0);
      }
      // 'recent' default
      return 0;
    });

    return result;
  }, [basePosts, searchTerm, contentType, sortBy]);

  // Content type counts for filter pills
  const typeCounts = useMemo(() => {
    const media = basePosts.filter(
      (p) => (p.images && p.images.length > 0) || Boolean(p.video)
    ).length;
    const text = basePosts.filter(
      (p) => (!p.images || p.images.length === 0) && !p.video && !p.poll
    ).length;
    const poll = basePosts.filter((p) => Boolean(p.poll)).length;
    return {
      all: basePosts.length,
      media,
      text,
      poll
    };
  }, [basePosts]);

  // Selected member name for admin inspector
  const selectedMemberName = useMemo(() => {
    if (selectedMemberId === 'all') return '모든 회원';
    const found = users.find((u) => u.id === selectedMemberId);
    return found ? `${found.name} (@${found.handle})` : '선택된 회원';
  }, [selectedMemberId, users]);

  const handleClearAll = () => {
    clearAllBookmarks();
    setShowClearConfirm(false);
  };

  return (
    <div className="flex flex-col gap-5">
      {/* 1. Header Banner & Profile Status */}
      <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-xs dark:border-slate-800 dark:bg-slate-900 transition-colors">
        {/* Decorative Top Accent Glow */}
        <div className="absolute -top-12 -right-12 h-36 w-36 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/10 blur-2xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-600/20">
              <Bookmark className="h-6 w-6 stroke-[2.2px]" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">
                  북마크 보관함
                </h2>
                <span className="inline-flex items-center gap-1 rounded-full bg-indigo-50 px-2.5 py-0.5 text-xs font-bold text-indigo-600 dark:bg-indigo-950/70 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                  <BookmarkCheck className="h-3.5 w-3.5" />
                  {mySavedPosts.length}개 저장됨
                </span>
                {isAdmin && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-purple-50 px-2.5 py-0.5 text-xs font-bold text-purple-600 dark:bg-purple-950/70 dark:text-purple-400 border border-purple-200/60 dark:border-purple-800/60">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    관리자 권한
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                관리자와 모든 회원이 각자 저장한 소중한 게시물들을 모아보고 관리하는 보관함입니다.
              </p>
            </div>
          </div>

          {/* Quick Account Switcher for Testing (Admin <-> Member) */}
          <div className="relative">
            <button
              id="bookmark-user-switch-btn"
              onClick={() => setShowUserDropdown((prev) => !prev)}
              className="flex items-center justify-between gap-2.5 rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors w-full sm:w-auto"
              title="회원 및 관리자 계정 전환"
            >
              <div className="flex items-center gap-2">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="h-6 w-6 rounded-full object-cover ring-1 ring-slate-300 dark:ring-slate-700"
                  referrerPolicy="no-referrer"
                />
                <span className="truncate max-w-[120px]">
                  {currentUser.name}
                  {currentUser.isAdmin ? ' (관리자)' : ' (회원)'}
                </span>
              </div>
              <ChevronDown className="h-3.5 w-3.5 text-slate-400 shrink-0" />
            </button>

            {/* User Switcher Dropdown */}
            {showUserDropdown && (
              <div
                className="absolute right-0 top-full mt-2 w-64 rounded-2xl border border-slate-200 bg-white p-2 shadow-xl dark:border-slate-800 dark:bg-slate-900 z-50 animate-in fade-in zoom-in-95 duration-150"
                onClick={() => setShowUserDropdown(false)}
              >
                <div className="px-2 py-1.5 text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  계정별 북마크 테스트 전환
                </div>
                <div className="max-h-60 overflow-y-auto space-y-1">
                  {users.map((user) => {
                    const isSelected = user.id === currentUser.id;
                    const userBookmarkCount = posts.filter((p) =>
                      p.bookmarks?.includes(user.id)
                    ).length;

                    return (
                      <button
                        key={user.id}
                        onClick={() => {
                          switchUser(user.id);
                          showToast(`${user.name} 계정으로 전환되었습니다.`, 'info');
                        }}
                        className={`w-full flex items-center justify-between px-2.5 py-2 rounded-xl text-xs font-semibold transition-colors ${
                          isSelected
                            ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400 font-bold'
                            : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <img
                            src={user.avatar}
                            alt={user.name}
                            className="h-5 w-5 rounded-full object-cover shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <span className="truncate">{user.name}</span>
                          {user.isAdmin && (
                            <span className="text-[10px] bg-purple-100 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 px-1 py-0.2 rounded font-normal shrink-0">
                              관리자
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-1.5 py-0.5 rounded-full font-bold shrink-0">
                          {userBookmarkCount}개
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 2. Admin Special Dashboard Toggle & Platform Overview */}
        {isAdmin && (
          <div className="mt-5 pt-5 border-t border-slate-100 dark:border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <button
                  id="admin-my-bookmarks-tab"
                  onClick={() => setAdminMode('my')}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    adminMode === 'my'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
                  }`}
                >
                  <Bookmark className="h-3.5 w-3.5" />
                  <span>내 북마크 ({mySavedPosts.length})</span>
                </button>

                <button
                  id="admin-all-members-bookmarks-tab"
                  onClick={() => setAdminMode('all_members')}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    adminMode === 'all_members'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
                  }`}
                >
                  <Users className="h-3.5 w-3.5" />
                  <span>전체 회원 북마크 현황</span>
                </button>
              </div>

              {adminMode === 'all_members' && (
                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 shrink-0">
                    회원별 보기:
                  </span>
                  <select
                    id="admin-member-bookmark-filter"
                    value={selectedMemberId}
                    onChange={(e) => setSelectedMemberId(e.target.value)}
                    className="text-xs font-semibold rounded-xl border border-slate-200 bg-white px-3 py-1.5 dark:border-slate-700 dark:bg-slate-800 text-slate-800 dark:text-slate-200 outline-hidden"
                  >
                    <option value="all">전체 회원의 인기 저장글 ({adminStats.savedPostsCount}개)</option>
                    {users.map((u) => {
                      const count = posts.filter((p) => p.bookmarks?.includes(u.id)).length;
                      return (
                        <option key={u.id} value={u.id}>
                          {u.name} (@{u.handle}) - {count}개 저장
                        </option>
                      );
                    })}
                  </select>
                </div>
              )}
            </div>

            {/* Admin Stats Insight Cards when in all_members mode */}
            {adminMode === 'all_members' && (
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="rounded-2xl bg-indigo-50/60 border border-indigo-100 p-3.5 dark:bg-indigo-950/30 dark:border-indigo-900/50">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">
                      플랫폼 총 북마크 누적
                    </span>
                    <FolderHeart className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <div className="mt-1 text-xl font-black text-indigo-900 dark:text-indigo-100">
                    {adminStats.totalBookmarkSaves}회
                  </div>
                  <p className="text-[11px] text-indigo-600/80 dark:text-indigo-400/80 mt-0.5">
                    회원들이 스크랩한 총 횟수
                  </p>
                </div>

                <div className="rounded-2xl bg-purple-50/60 border border-purple-100 p-3.5 dark:bg-purple-950/30 dark:border-purple-900/50">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-purple-700 dark:text-purple-300">
                      저장된 고유 게시물
                    </span>
                    <TrendingUp className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div className="mt-1 text-xl font-black text-purple-900 dark:text-purple-100">
                    {adminStats.savedPostsCount}개
                  </div>
                  <p className="text-[11px] text-purple-600/80 dark:text-purple-400/80 mt-0.5">
                    1회 이상 북마크된 인기 글
                  </p>
                </div>

                <div className="rounded-2xl bg-emerald-50/60 border border-emerald-100 p-3.5 dark:bg-emerald-950/30 dark:border-emerald-900/50">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                      북마크 활성 회원
                    </span>
                    <Users className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div className="mt-1 text-xl font-black text-emerald-900 dark:text-emerald-100">
                    {adminStats.activeBookmarkersCount}명
                  </div>
                  <p className="text-[11px] text-emerald-600/80 dark:text-emerald-400/80 mt-0.5">
                    자신만의 보관함을 가진 회원 수
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* 3. Search Bar & Controls */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900 transition-colors flex flex-col gap-3">
        {/* Search Input and Sort Selector */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              id="bookmark-search-input"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="북마크한 글 내용, 작성자, 태그, 위치 검색..."
              className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 py-2 text-xs md:text-sm text-slate-800 placeholder-slate-400 outline-hidden focus:border-indigo-500 focus:bg-white dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:focus:border-indigo-400 transition-all"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 hover:text-slate-600"
              >
                지우기
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 justify-between sm:justify-end">
            {/* Sort Selector */}
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
              <ArrowUpDown className="h-3.5 w-3.5 shrink-0" />
              <select
                id="bookmark-sort-select"
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-bold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 outline-hidden cursor-pointer"
              >
                <option value="recent">최신 저장순</option>
                <option value="newest_post">작성일 최신순</option>
                <option value="likes">좋아요 많은순</option>
                <option value="comments">댓글 많은순</option>
              </select>
            </div>

            {/* Clear All Bookmarks (Only for own bookmarks) */}
            {adminMode === 'my' && mySavedPosts.length > 0 && (
              <button
                id="clear-all-bookmarks-btn"
                onClick={() => setShowClearConfirm(true)}
                className="flex items-center gap-1 rounded-xl border border-rose-200 bg-rose-50 px-2.5 py-1.5 text-xs font-bold text-rose-600 hover:bg-rose-100 dark:border-rose-900/60 dark:bg-rose-950/40 dark:text-rose-400 transition-colors shrink-0"
                title="모든 북마크 비우기"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">비우기</span>
              </button>
            )}
          </div>
        </div>

        {/* Content Type Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pt-1 no-scrollbar">
          <button
            onClick={() => setContentType('all')}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold whitespace-nowrap transition-all ${
              contentType === 'all'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
            }`}
          >
            <span>전체</span>
            <span className="text-[11px] opacity-80">({typeCounts.all})</span>
          </button>

          <button
            onClick={() => setContentType('media')}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold whitespace-nowrap transition-all ${
              contentType === 'media'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
            }`}
          >
            <ImageIcon className="h-3 w-3" />
            <span>사진/영상</span>
            <span className="text-[11px] opacity-80">({typeCounts.media})</span>
          </button>

          <button
            onClick={() => setContentType('text')}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold whitespace-nowrap transition-all ${
              contentType === 'text'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
            }`}
          >
            <FileText className="h-3 w-3" />
            <span>글/일상</span>
            <span className="text-[11px] opacity-80">({typeCounts.text})</span>
          </button>

          <button
            onClick={() => setContentType('poll')}
            className={`flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold whitespace-nowrap transition-all ${
              contentType === 'poll'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
            }`}
          >
            <BarChart2 className="h-3 w-3" />
            <span>투표</span>
            <span className="text-[11px] opacity-80">({typeCounts.poll})</span>
          </button>
        </div>
      </div>

      {/* Confirmation Modal for Clearing All Bookmarks */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-sm rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-slate-800 dark:bg-slate-900 animate-in zoom-in-95 duration-150">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-50 text-rose-600 dark:bg-rose-950 dark:text-rose-400 mb-4">
              <AlertCircle className="h-6 w-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              모든 북마크를 비우시겠습니까?
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">
              현재 저장된 {mySavedPosts.length}개의 북마크가 보관함에서 모두 제거됩니다. 게시물 자체는 삭제되지 않습니다.
            </p>
            <div className="mt-5 flex items-center justify-end gap-2.5">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
              >
                취소
              </button>
              <button
                onClick={handleClearAll}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 text-white hover:bg-rose-700 transition-colors shadow-xs"
              >
                모두 비우기
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. Posts Feed List */}
      <div className="flex flex-col gap-4">
        {/* Current Filter Info Bar */}
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-bold text-slate-600 dark:text-slate-400">
            {isAdmin && adminMode === 'all_members' ? (
              <span>
                {selectedMemberName}의 저장된 게시물{' '}
                <strong className="text-indigo-600 dark:text-indigo-400">
                  {filteredPosts.length}개
                </strong>
              </span>
            ) : (
              <span>
                {currentUser.name}님이 저장한 게시물{' '}
                <strong className="text-indigo-600 dark:text-indigo-400">
                  {filteredPosts.length}개
                </strong>
              </span>
            )}
          </span>

          {searchTerm && (
            <span className="text-[11px] text-slate-400">
              "{searchTerm}" 검색 결과
            </span>
          )}
        </div>

        {filteredPosts.length === 0 ? (
          /* Empty State */
          <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-slate-300 bg-white p-12 text-center dark:border-slate-800 dark:bg-slate-900 transition-colors shadow-xs">
            <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-indigo-50 text-indigo-500 dark:bg-indigo-950/60 dark:text-indigo-400 mb-4">
              <Bookmark className="h-8 w-8 stroke-[1.8px]" />
            </div>

            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {searchTerm ? '검색된 북마크가 없습니다' : '저장된 북마크가 없습니다'}
            </h3>

            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 max-w-sm leading-relaxed">
              {searchTerm
                ? '다른 키워드로 검색하거나 필터를 초기화해 보세요.'
                : '피드나 탐색을 둘러보다가 관심 있는 게시물 하단의 🔖 북마크 아이콘을 누르면 이곳에 영구 저장됩니다.'}
            </p>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              {searchTerm ? (
                <button
                  onClick={() => setSearchTerm('')}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200 transition-colors"
                >
                  검색 초기화
                </button>
              ) : (
                <>
                  <button
                    onClick={() => setActiveTab('feed')}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 transition-all shadow-md shadow-indigo-600/20"
                  >
                    <Compass className="h-4 w-4" />
                    <span>홈 피드 둘러보기</span>
                  </button>

                  {/* 1-Click Quick Bookmark Helper to test right away */}
                  {posts.length > 0 && !posts[0].bookmarks?.includes(currentUser.id) && (
                    <button
                      onClick={() => {
                        toggleBookmark(posts[0].id);
                        showToast('추천 게시물을 북마크에 추가했습니다!', 'success');
                      }}
                      className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold border border-indigo-200 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 dark:border-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300 transition-colors"
                    >
                      <Sparkles className="h-4 w-4" />
                      <span>추천 게시물 바로 북마크해보기</span>
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        ) : (
          filteredPosts.map((post) => (
            <div key={post.id} className="relative group">
              {/* Optional bookmark banner badge for admin overview */}
              {isAdmin && adminMode === 'all_members' && post.bookmarks && post.bookmarks.length > 0 && (
                <div className="mb-1.5 flex items-center justify-between px-3 py-1 rounded-xl bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 text-[11px] font-bold border border-purple-200/50 dark:border-purple-800/50">
                  <span className="flex items-center gap-1.5">
                    <BookmarkCheck className="h-3.5 w-3.5" />
                    총 {post.bookmarks.length}명의 회원이 저장함
                  </span>
                  <span className="text-[10px] text-purple-600/70 dark:text-purple-400/70">
                    저장한 회원 ID: {post.bookmarks.join(', ')}
                  </span>
                </div>
              )}
              <PostCard post={post} />
            </div>
          ))
        )}
      </div>
    </div>
  );
};
