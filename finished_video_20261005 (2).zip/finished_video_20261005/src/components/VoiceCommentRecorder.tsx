import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  Square,
  Trash2,
  Send,
  RotateCcw,
  Sparkles,
  AlertCircle,
  Volume2
} from 'lucide-react';
import { formatAudioDuration, generateSyntheticAudioBlob } from '../utils/audioUtils';
import { VoiceCommentPlayer } from './VoiceCommentPlayer';

interface VoiceCommentRecorderProps {
  onSendVoice: (audioUrl: string, duration: number, text?: string) => void;
  onCancel: () => void;
  initialText?: string;
}

export const VoiceCommentRecorder: React.FC<VoiceCommentRecorderProps> = ({
  onSendVoice,
  onCancel,
  initialText = ''
}) => {
  const [recordingStatus, setRecordingStatus] = useState<'idle' | 'recording' | 'preview'>('idle');
  const [recordSeconds, setRecordSeconds] = useState<number>(0);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);
  const [recordedDuration, setRecordedDuration] = useState<number>(0);
  const [micError, setMicError] = useState<string | null>(null);
  const [additionalText, setAdditionalText] = useState<string>(initialText);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const MAX_RECORD_SECONDS = 30;

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopTimer();
      stopStream();
      if (recordedAudioUrl && recordedAudioUrl.startsWith('blob:')) {
        URL.revokeObjectURL(recordedAudioUrl);
      }
    };
  }, []);

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const stopStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
  };

  // Start real recording
  const startRecording = async () => {
    setMicError(null);
    audioChunksRef.current = [];
    setRecordSeconds(0);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('이 브라우저에서는 음성 녹음 API가 지원되지 않습니다.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // Select supported MIME type
      let mimeType = 'audio/webm';
      if (typeof MediaRecorder.isTypeSupported === 'function') {
        if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
          mimeType = 'audio/webm;codecs=opus';
        } else if (MediaRecorder.isTypeSupported('audio/mp4')) {
          mimeType = 'audio/mp4';
        } else if (MediaRecorder.isTypeSupported('audio/ogg')) {
          mimeType = 'audio/ogg';
        }
      }

      const recorder = new MediaRecorder(stream, { mimeType });
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
        const audioUrl = URL.createObjectURL(audioBlob);
        setRecordedAudioUrl(audioUrl);
        setRecordedDuration(recordSeconds || 1);
        setRecordingStatus('preview');
        stopStream();
      };

      recorder.start(100);
      setRecordingStatus('recording');

      // Start elapsed timer
      let elapsed = 0;
      timerRef.current = setInterval(() => {
        elapsed += 1;
        setRecordSeconds(elapsed);
        if (elapsed >= MAX_RECORD_SECONDS) {
          stopRecording();
        }
      }, 1000);
    } catch (err: unknown) {
      console.warn('Microphone access failed:', err);
      const message =
        err instanceof Error ? err.message : '마이크 권한을 허용할 수 없습니다.';
      setMicError(message);
      setRecordingStatus('idle');
      stopStream();
    }
  };

  const stopRecording = () => {
    stopTimer();
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  // Fallback demo recording (using Web Audio API synthesized voice note)
  const handleSyntheticVoiceDemo = async () => {
    setMicError(null);
    setRecordingStatus('recording');
    setRecordSeconds(0);

    let sec = 0;
    timerRef.current = setInterval(() => {
      sec += 1;
      setRecordSeconds(sec);
    }, 1000);

    // Simulate 3 seconds recording
    setTimeout(async () => {
      stopTimer();
      const synthetic = await generateSyntheticAudioBlob(4);
      setRecordedAudioUrl(synthetic.url);
      setRecordedDuration(4);
      setRecordingStatus('preview');
    }, 3000);
  };

  const handleReset = () => {
    stopTimer();
    stopStream();
    if (recordedAudioUrl && recordedAudioUrl.startsWith('blob:')) {
      URL.revokeObjectURL(recordedAudioUrl);
    }
    setRecordedAudioUrl(null);
    setRecordedDuration(0);
    setRecordSeconds(0);
    setRecordingStatus('idle');
  };

  const handleSend = () => {
    if (!recordedAudioUrl) return;
    onSendVoice(recordedAudioUrl, recordedDuration, additionalText.trim() || undefined);
  };

  // Auto-start on mount
  useEffect(() => {
    startRecording();
  }, []);

  return (
    <div
      id="voice-comment-recorder-panel"
      className="w-full rounded-2xl border border-indigo-200 bg-gradient-to-br from-indigo-50/90 via-white to-blue-50/80 p-3.5 shadow-sm dark:border-indigo-900/60 dark:from-slate-900 dark:via-indigo-950/30 dark:to-slate-900 animate-in fade-in slide-in-from-top-1 duration-150"
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-indigo-100 dark:border-indigo-900/50 mb-2.5">
        <div className="flex items-center gap-1.5">
          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-indigo-600 text-white">
            <Mic className="h-3.5 w-3.5" />
          </div>
          <span className="text-xs font-bold text-slate-800 dark:text-slate-100">
            음성 댓글 녹음
          </span>
          <span className="rounded-full bg-indigo-100 px-1.5 py-0.2 text-[10px] font-semibold text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300">
            최대 {MAX_RECORD_SECONDS}초
          </span>
        </div>

        <button
          type="button"
          onClick={() => {
            handleReset();
            onCancel();
          }}
          className="rounded-full p-1 text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
          title="녹음 취소"
        >
          <Trash2 className="h-4 w-4 text-rose-500" />
        </button>
      </div>

      {/* Recording State */}
      {recordingStatus === 'recording' && (
        <div className="flex flex-col items-center justify-center py-3">
          <div className="flex items-center gap-2 mb-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
            </span>
            <span className="font-mono text-base font-bold text-rose-600 dark:text-rose-400">
              {formatAudioDuration(recordSeconds)} / {formatAudioDuration(MAX_RECORD_SECONDS)}
            </span>
          </div>

          {/* Sound Wave Animation */}
          <div className="flex items-center justify-center gap-1 h-8 my-2">
            {[40, 75, 100, 60, 90, 50, 85, 95, 70, 45, 80, 60].map((h, i) => (
              <span
                key={i}
                className="w-1 rounded-full bg-indigo-600 dark:bg-indigo-400 animate-pulse"
                style={{
                  height: `${h}%`,
                  animationDelay: `${i * 80}ms`,
                  animationDuration: '600ms'
                }}
              />
            ))}
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
            마이크에 대고 말씀해주세요...
          </p>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={stopRecording}
              className="flex items-center gap-1.5 rounded-full bg-rose-600 px-4 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-rose-700 active:scale-95 transition-all cursor-pointer"
            >
              <Square className="h-3.5 w-3.5 fill-white" />
              <span>녹음 완료</span>
            </button>

            <button
              type="button"
              onClick={() => {
                handleReset();
                onCancel();
              }}
              className="rounded-full bg-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-300 dark:bg-slate-800 dark:text-slate-300 transition-colors cursor-pointer"
            >
              취소
            </button>
          </div>
        </div>
      )}

      {/* Preview State */}
      {recordingStatus === 'preview' && recordedAudioUrl && (
        <div className="space-y-3">
          <div className="rounded-xl bg-white/70 p-2.5 dark:bg-slate-800/60 border border-indigo-100 dark:border-indigo-900/40">
            <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1">
              🎧 녹음된 음성 미리듣기:
            </span>
            <VoiceCommentPlayer
              audioUrl={recordedAudioUrl}
              duration={recordedDuration}
            />
          </div>

          {/* Optional Text message along with voice */}
          <div>
            <input
              type="text"
              value={additionalText}
              onChange={(e) => setAdditionalText(e.target.value)}
              placeholder="음성과 함께 남길 텍스트 (선택사항)"
              className="w-full rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:border-indigo-500 focus:bg-white focus:text-slate-900 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder-slate-400 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-indigo-400"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center justify-between pt-1">
            <button
              type="button"
              onClick={handleReset}
              className="flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>다시 녹음</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  handleReset();
                  onCancel();
                }}
                className="rounded-lg px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                id="submit-voice-comment-btn"
                onClick={handleSend}
                className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-1.5 text-xs font-bold text-white shadow-xs hover:bg-indigo-700 active:scale-95 transition-all cursor-pointer"
              >
                <Send className="h-3.5 w-3.5" />
                <span>음성 댓글 게시</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Error / Fallback State */}
      {recordingStatus === 'idle' && micError && (
        <div className="py-2 space-y-2.5">
          <div className="flex items-start gap-2 rounded-xl bg-amber-50 p-2.5 text-xs text-amber-800 dark:bg-amber-950/50 dark:text-amber-300 border border-amber-200 dark:border-amber-900">
            <AlertCircle className="h-4 w-4 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">마이크 권한 안내</p>
              <p className="text-[11px] mt-0.5 opacity-90">
                마이크 권한이 차단되었거나 iframe 환경입니다. 마이크 권한을 허용하거나 아래 가상 음성 생성을 통해 즉시 기능을 체험할 수 있습니다.
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={startRecording}
              className="flex items-center gap-1 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            >
              <Mic className="h-3.5 w-3.5" />
              <span>마이크 재시도</span>
            </button>

            <button
              type="button"
              onClick={handleSyntheticVoiceDemo}
              className="flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-indigo-700 shadow-xs"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>가상 음성 메모로 생성하기</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
