import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { Post } from '../types';
import {
  Share2,
  Copy,
  Check,
  Smartphone,
  Send,
  MessageCircle,
  X,
  Globe,
  Mail,
  Code,
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface ShareModalProps {
  post: Post;
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ post, isOpen, onClose }) => {
  const { users, currentUser, sendMessage, showToast, isAuthenticated, openAuthModal } = useSocial();
  const [copied, setCopied] = useState(false);
  const [selectedRecipientId, setSelectedRecipientId] = useState<string | null>(null);
  const [dmMessage, setDmMessage] = useState('');
  const [isSendingDm, setIsSendingDm] = useState(false);
  const [showEmbed, setShowEmbed] = useState(false);
  const [copiedEmbed, setCopiedEmbed] = useState(false);

  if (!isOpen) return null;

  // Generate shareable URL
  const postUrl = `${window.location.origin}${window.location.pathname}?post=${post.id}`;
  const shareTitle = `${post.authorName}님의 게시물 - 마음`;
  const shareSnippet = post.content.length > 100 ? `${post.content.slice(0, 100)}...` : post.content;
  const shareText = `[마음] ${post.authorName}님: "${shareSnippet}"`;

  // Native Web Share API Check
  const hasNativeShare = typeof navigator !== 'undefined' && !!navigator.share;

  const handleNativeShare = async () => {
    if (!hasNativeShare) {
      handleCopyLink();
      return;
    }

    try {
      await navigator.share({
        title: shareTitle,
        text: shareText,
        url: postUrl
      });
      showToast('게시물이 성공적으로 공유되었습니다.', 'success');
      onClose();
    } catch (err: any) {
      // User cancellation (AbortError) should not show error
      if (err?.name !== 'AbortError') {
        console.error('Web Share error:', err);
        handleCopyLink();
      }
    }
  };

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(postUrl);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = postUrl;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      showToast('게시물 링크가 클립보드에 복사되었습니다!', 'success');
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      console.error('Failed to copy link:', err);
      showToast('링크 복사에 실패했습니다.', 'error');
    }
  };

  const handleCopyEmbed = async () => {
    const embedCode = `<iframe src="${postUrl}" width="100%" height="450" frameborder="0"></iframe>`;
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(embedCode);
      }
      setCopiedEmbed(true);
      showToast('임베드 코드가 복사되었습니다!', 'success');
      setTimeout(() => setCopiedEmbed(false), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSendDirectMessage = (recipientId: string) => {
    if (!isAuthenticated) {
      openAuthModal('login');
      return;
    }
    setIsSendingDm(true);
    const messageContent = dmMessage.trim()
      ? `${dmMessage.trim()}\n\n🔗 ${postUrl}\n"${shareSnippet}"`
      : `[공유된 게시물] ${post.authorName}님의 글:\n"${shareSnippet}"\n\n🔗 ${postUrl}`;

    sendMessage(recipientId, messageContent);
    setIsSendingDm(false);
    setSelectedRecipientId(null);
    setDmMessage('');
    showToast('메시지로 게시물을 전송했습니다!', 'success');
    onClose();
  };

  // External Social Links
  const shareToTwitter = () => {
    const tweetUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(
      shareText
    )}&url=${encodeURIComponent(postUrl)}`;
    window.open(tweetUrl, '_blank', 'width=600,height=400');
  };

  const shareToFacebook = () => {
    const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(postUrl)}`;
    window.open(fbUrl, '_blank', 'width=600,height=450');
  };

  const shareToEmail = () => {
    const mailto = `mailto:?subject=${encodeURIComponent(
      shareTitle
    )}&body=${encodeURIComponent(`${shareText}\n\n게시물 보기: ${postUrl}`)}`;
    window.location.href = mailto;
  };

  // Friends to send DM to (excluding self)
  const availableUsers = users.filter((u) => u.id !== currentUser.id);

  return (
    <div
      id="post-share-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="post-share-modal-content"
        className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-800 dark:bg-slate-900 animate-in zoom-in-95 duration-150 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <Share2 className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                게시물 공유하기
              </h3>
              <p className="text-[11px] text-slate-400">
                {post.authorName}님의 게시물을 친구들과 공유하세요
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Post Preview Snippet */}
        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800/80 flex items-start gap-3">
          <img
            src={post.authorAvatar}
            alt={post.authorName}
            className="w-8 h-8 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700"
            referrerPolicy="no-referrer"
          />
          <div className="min-w-0 flex-1">
            <div className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">
              {post.authorName} <span className="text-slate-400 font-normal text-[11px]">@{post.authorHandle}</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mt-0.5 leading-relaxed">
              {post.content}
            </p>
          </div>
        </div>

        {/* Direct Link Copy Bar */}
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
            게시물 링크
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={postUrl}
              className="flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 select-all focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
            <button
              id={`copy-post-link-btn-${post.id}`}
              onClick={handleCopyLink}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                copied
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm shadow-indigo-600/20'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>복사됨!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>복사</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Native Web Share Button (if supported) */}
        {hasNativeShare && (
          <button
            id={`native-share-btn-${post.id}`}
            onClick={handleNativeShare}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white text-xs font-bold shadow-md shadow-indigo-600/20 active:scale-[0.99] transition-all"
          >
            <Smartphone className="w-4 h-4" />
            <span>기기 기본 공유 (Web Share)</span>
          </button>
        )}

        {/* Quick Social Share Buttons */}
        <div>
          <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            외부 소셜 미디어 공유
          </label>
          <div className="grid grid-cols-3 gap-2">
            {/* X / Twitter */}
            <button
              onClick={shareToTwitter}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors"
            >
              <span className="font-black text-slate-900 dark:text-white">𝕏</span>
              <span>트위터</span>
            </button>

            {/* Facebook */}
            <button
              onClick={shareToFacebook}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-blue-600 dark:text-blue-400 transition-colors"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>페이스북</span>
            </button>

            {/* Email */}
            <button
              onClick={shareToEmail}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 transition-colors"
            >
              <Mail className="w-3.5 h-3.5 text-amber-500" />
              <span>이메일</span>
            </button>
          </div>
        </div>

        {/* Send via Direct Message (Pulse In-App DM) */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <MessageCircle className="w-3.5 h-3.5 text-indigo-500" />
              Pulse 친구에게 메시지로 공유
            </label>
            <span className="text-[10px] text-slate-400">클릭 시 즉시 전송</span>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
            {availableUsers.map((u) => (
              <button
                key={u.id}
                onClick={() => handleSendDirectMessage(u.id)}
                disabled={isSendingDm}
                className="flex flex-col items-center p-2 rounded-xl hover:bg-indigo-50/70 dark:hover:bg-indigo-950/40 border border-transparent hover:border-indigo-200 dark:hover:border-indigo-800 transition-all shrink-0 min-w-16 group"
              >
                <div className="relative">
                  <img
                    src={u.avatar}
                    alt={u.name}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 group-hover:scale-105 transition-transform"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                    <Send className="w-2.5 h-2.5" />
                  </div>
                </div>
                <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200 mt-1 truncate max-w-14 text-center">
                  {u.name}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Embed Code Toggle */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={() => setShowEmbed((prev) => !prev)}
            className="flex items-center justify-between w-full text-[11px] font-semibold text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors"
          >
            <span className="flex items-center gap-1.5">
              <Code className="w-3.5 h-3.5" />
              웹사이트 임베드(Embed) 코드
            </span>
            <span>{showEmbed ? '접기' : '펼치기'}</span>
          </button>

          {showEmbed && (
            <div className="mt-2 space-y-1.5 animate-in fade-in duration-150">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={`<iframe src="${postUrl}" width="100%" height="450" frameborder="0"></iframe>`}
                  className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-[11px] font-mono text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 select-all"
                />
                <button
                  onClick={handleCopyEmbed}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-xs font-semibold text-slate-700 dark:text-slate-200 shrink-0"
                >
                  {copiedEmbed ? '복사됨' : '복사'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
