import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';

export const ScrollToTopButton: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
      setIsScrolled(currentScrollY > 80);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const scrollToTop = () => {
    try {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
      document.documentElement.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
      document.body.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    } catch {
      window.scrollTo(0, 0);
    }
  };

  return (
    <button
      id="global-scroll-to-top-btn"
      onClick={scrollToTop}
      title="페이지 맨 위로 바로가기"
      aria-label="페이지 맨 위로 바로가기"
      className={`group fixed bottom-[150px] md:bottom-8 right-5 md:right-8 z-40 flex h-11 w-11 md:h-12 md:w-12 items-center justify-center rounded-full shadow-lg transition-all duration-300 active:scale-90 cursor-pointer select-none border ${
        isScrolled
          ? 'bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-indigo-600/40 hover:shadow-indigo-600/60 hover:from-indigo-700 hover:to-purple-700 border-white/20 scale-100 opacity-100'
          : 'bg-white/95 text-slate-700 shadow-slate-900/10 hover:bg-white hover:text-indigo-600 dark:bg-slate-900/95 dark:text-slate-200 dark:hover:text-indigo-400 dark:shadow-black/30 border-slate-200 dark:border-slate-800 opacity-90 hover:opacity-100'
      }`}
    >
      <ArrowUp className="w-5 h-5 md:w-6 md:h-6 transition-transform duration-200 group-hover:-translate-y-1 stroke-[2.5px]" />
    </button>
  );
};
