import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  Bell,
  Heart,
  MessageCircle,
  UserPlus,
  Repeat2,
  AtSign,
  CheckCheck,
  Sparkles,
  Trash2
} from 'lucide-react';
import { formatRelativeTime } from '../utils/formatters';

export const NotificationsView: React.FC = () => {
  const {
    currentUser,
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    deleteNotification,
    deleteAllNotifications,
    setViewingUserId,
    setActiveTab
  } = useSocial();

  const [filterType, setFilterType] = useState<string>('all');
  const [showDeleteAllConfirm, setShowDeleteAllConfirm] = useState(false);

  const userNotifications = React.useMemo(() => {
    const raw = notifications.filter((n) => n.recipientId === currentUser.id);
    const seenIds = new Set<string>();
    const seenSemanticKeys = new Set<string>();
    const deduped: typeof raw = [];

    for (const n of raw) {
      if (!n || !n.id) continue;
      if (seenIds.has(n.id)) continue;

      let key = '';
      if (n.type === 'like') {
        key = `${n.recipientId}_${n.actorId}_like_${n.postId || ''}`;
      } else if (n.type === 'follow') {
        key = `${n.recipientId}_${n.actorId}_follow`;
      } else if (n.type === 'comment') {
        key = `${n.recipientId}_${n.actorId}_comment_${n.id || ''}_${n.content || ''}`;
      } else {
        const timeBucket = Math.floor(new Date(n.createdAt || Date.now()).getTime() / 30000);
        key = `${n.recipientId}_${n.actorId}_${n.type}_${n.content || ''}_${timeBucket}`;
      }

      if (seenSemanticKeys.has(key)) continue;

      seenIds.add(n.id);
      seenSemanticKeys.add(key);
      deduped.push(n);
    }
    return deduped;
  }, [notifications, currentUser.id]);

  const filtered = userNotifications.filter((n) => {
    if (filterType === 'all') return true;
    return n.type === filterType;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case 'like':
        return <Heart className="h-4 w-4 fill-rose-500 text-rose-500" />;
      case 'comment':
        return <MessageCircle className="h-4 w-4 text-indigo-500 fill-indigo-100 dark:fill-indigo-950" />;
      case 'follow':
        return <UserPlus className="h-4 w-4 text-emerald-500" />;
      case 'repost':
        return <Repeat2 className="h-4 w-4 text-amber-500" />;
      case 'mention':
        return <AtSign className="h-4 w-4 text-purple-500" />;
      case 'story_reaction':
        return <Sparkles className="h-4 w-4 text-amber-500 fill-amber-100 dark:fill-amber-950" />;
      case 'system':
      case 'welcome':
        return <Sparkles className="h-4 w-4 text-blue-500 fill-blue-100 dark:fill-blue-950" />;
      default:
        return <Bell className="h-4 w-4 text-neutral-400" />;
    }
  };

  const handleNotificationClick = (notifId: string, actorId: string) => {
    markNotificationAsRead(notifId);
    setViewingUserId(actorId);
    setActiveTab('profile');
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50 flex flex-col gap-5">
      {/* Header & Mark all as read / Delete all */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>알림</span>
            {userNotifications.filter((n) => !n.isRead).length > 0 && (
              <span className="rounded-full bg-rose-500 px-2 py-0.5 text-xs font-bold text-white">
                {userNotifications.filter((n) => !n.isRead).length}개 새 알림
              </span>
            )}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            좋아요, 댓글, 팔로우 소식을 확인하세요
          </p>
        </div>

        <div className="flex flex-col items-end gap-1.5">
          <button
            onClick={markAllNotificationsAsRead}
            disabled={userNotifications.length === 0 || userNotifications.every((n) => n.isRead)}
            className="flex items-center gap-1 text-xs font-bold text-blue-600 hover:text-blue-700 dark:text-blue-400 disabled:opacity-40 disabled:pointer-events-none cursor-pointer transition-colors"
          >
            <CheckCheck className="h-4 w-4" />
            <span>모두 읽음 표시</span>
          </button>
          <button
            onClick={() => setShowDeleteAllConfirm(true)}
            disabled={userNotifications.length === 0}
            className="flex items-center gap-1 text-xs font-bold text-rose-500 hover:text-rose-600 dark:text-rose-400 disabled:opacity-40 disabled:pointer-events-none cursor-pointer transition-colors"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>모두 삭제하기</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'all', label: '전체' },
          { id: 'like', label: '좋아요' },
          { id: 'comment', label: '댓글' },
          { id: 'follow', label: '팔로우' },
          { id: 'mention', label: '멘션' }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterType(tab.id)}
            className={`rounded-lg px-3.5 py-1.5 text-xs font-bold transition-all cursor-pointer ${
              filterType === tab.id
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      <div className="flex flex-col gap-2">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-10 text-center text-slate-400">
            <Bell className="h-10 w-10 text-slate-300 dark:text-slate-700 mb-2" />
            <p className="text-sm font-semibold">새로운 알림이 없습니다</p>
            <p className="text-xs text-slate-400 mt-1 max-w-xs">
              이웃들이 내 게시물에 남긴 좋아요, 댓글, 팔로우 소식이 여기에 실시간으로 표시됩니다.
            </p>
          </div>
        ) : (
          filtered.map((notif) => (
            <div
              key={notif.id}
              onClick={() => handleNotificationClick(notif.id, notif.actorId)}
              className={`group flex items-start gap-3 p-3.5 rounded-xl cursor-pointer transition-colors relative ${
                notif.isRead
                  ? 'bg-transparent hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  : 'bg-blue-50/50 hover:bg-blue-50 dark:bg-blue-950/30 dark:hover:bg-blue-950/50 border border-blue-100/50 dark:border-blue-900/50'
              }`}
            >
              {/* Actor avatar with type badge */}
              <div className="relative flex-shrink-0">
                <img
                  src={notif.actorAvatar}
                  alt={notif.actorName}
                  className="h-10 w-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-white dark:bg-slate-900 shadow-xs ring-1 ring-slate-200 dark:ring-slate-700">
                  {getIcon(notif.type)}
                </div>
              </div>

              {/* Notification Content */}
              <div className="flex-1 min-w-0 pr-6">
                <p className="text-xs md:text-sm text-slate-800 dark:text-slate-200">
                  <span className="font-bold text-slate-900 dark:text-white">
                    {notif.actorName}
                  </span>
                  {notif.type === 'system' || notif.type === 'welcome'
                    ? `: ${notif.content}`
                    : `님이 ${notif.content.replace(new RegExp(`^${notif.actorName || ''}님이\\s*`), '')}`}
                </p>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  {formatRelativeTime(notif.createdAt)}
                </span>
              </div>

              {/* Action indicators: Unread dot & Delete button */}
              <div className="flex items-center gap-1.5 flex-shrink-0 mt-1">
                {!notif.isRead && (
                  <span className="h-2 w-2 rounded-full bg-blue-600 flex-shrink-0" />
                )}
                <button
                  type="button"
                  title="알림 삭제"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteNotification(notif.id);
                  }}
                  className="opacity-0 group-hover:opacity-100 p-1 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-all cursor-pointer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Delete All Notifications Confirmation Modal */}
      {showDeleteAllConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4 animate-in fade-in duration-150"
          onClick={() => setShowDeleteAllConfirm(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col gap-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400">
                <Trash2 className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">모든 알림 삭제</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">수신된 모든 알림({userNotifications.length}개)을 삭제하시겠습니까?</p>
              </div>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl">
              삭제된 알림은 다시 복구할 수 없습니다. 계속하시겠습니까?
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteAllConfirm(false)}
                className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteAllNotifications();
                  setShowDeleteAllConfirm(false);
                }}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-700 shadow-sm transition-colors cursor-pointer"
              >
                모두 삭제
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
