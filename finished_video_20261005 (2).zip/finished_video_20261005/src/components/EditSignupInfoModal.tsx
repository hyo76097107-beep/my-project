import React, { useState, useEffect, useRef } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  X,
  ShieldCheck,
  User,
  AtSign,
  Mail,
  Lock,
  Eye,
  EyeOff,
  MapPin,
  Navigation,
  Loader2,
  Check,
  AlertCircle,
  Sparkles,
  Camera,
  Upload,
  Tag,
  Briefcase,
  FileText,
  RotateCw,
  KeyRound,
  Phone,
  MessageSquare
} from 'lucide-react';
import { getAutoLocation } from '../utils/geolocation';
import { formatPhoneNumber, isValidKoreanPhoneNumber } from '../utils/smsVerification';

const DEFAULT_PERSON_AVATAR =
  'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"%3E%3Crect width="128" height="128" rx="64" fill="%23E2E8F0"/%3E%3Cpath d="M64 26a24 24 0 1 0 0 48 24 24 0 0 0 0-48zm0 58c-26.7 0-49 14.3-53 36 3.6 5 8 9.4 13 13 11 7 24.8 11 40 11s29-4 40-11c5-3.6 9.4-8 13-13-4-21.7-26.3-36-53-36z" fill="%2394A3B8"/%3E%3C/svg%3E';

const POPULAR_INTERESTS_LIST = [
  '인공지능',
  '모바일',
  '가전',
  '프로그래밍',
  '과학 이슈',
  '영화',
  '드라마',
  '방송',
  '음악/K-POP',
  '웹툰/만화',
  '책/독서',
  '요리/맛집',
  '반려동물',
  '여행/캠핑',
  '인테리어/반셀프',
  '반려식물',
  '트렌드 패션',
  '화장품',
  '스킨케어',
  '쇼핑 할인 혜택',
  '주식',
  '부동산',
  '가상화폐',
  '금융/저축',
  '창업/부업',
  '축구',
  '야구',
  '골프',
  '헬스/피트니스',
  '등산',
  '러닝/마라톤',
  '격투',
  '미술',
  '사진',
  '악기',
  '공예',
  '공연/전시',
  '외국어',
  '직무 역량',
  '자격증',
  '취업/이직'
];

const POPULAR_ROLES_LIST = [
  '학생',
  '직장인/회사원',
  '전문직',
  '공무원',
  '자영업/사업',
  '프리랜서',
  '전업주부',
  '무직/기타'
];

export const EditSignupInfoModal: React.FC = () => {
  const {
    currentUser,
    users,
    isEditSignupInfoModalOpen,
    closeEditSignupInfoModal,
    updateSignupInfo
  } = useSocial();

  // Form states
  const [name, setName] = useState('');
  const [handle, setHandle] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [newPasswordConfirm, setNewPasswordConfirm] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [location, setLocation] = useState('');
  const [locationSource, setLocationSource] = useState<'gps' | 'preset' | 'manual' | 'profile' | null>(null);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [role, setRole] = useState('');
  const [bio, setBio] = useState('');
  const [avatar, setAvatar] = useState('');
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [interests, setInterests] = useState<string[]>([]);
  const [customInterest, setCustomInterest] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync state whenever modal opens or currentUser changes
  useEffect(() => {
    if (isEditSignupInfoModalOpen && currentUser) {
      setName(currentUser.name || '');
      setHandle(currentUser.handle || '');
      setEmail(currentUser.email || '');
      setPhoneNumber(currentUser.phoneNumber || '');
      setIsChangingPassword(false);
      setNewPassword('');
      setNewPasswordConfirm('');
      setShowPassword(false);
      setLocation(currentUser.location || '');
      setLocationSource(null);
      setRole(currentUser.role || '');
      setBio(currentUser.bio || '');
      setAvatar(currentUser.avatar || '');
      setCustomAvatarUrl('');
      setInterests(currentUser.interests ? [...currentUser.interests] : []);
      setCustomInterest('');
      setError(null);
      setIsSubmitting(false);
    }
  }, [isEditSignupInfoModalOpen, currentUser]);

  if (!isEditSignupInfoModalOpen) return null;

  // Real-time duplicate check against other users
  const isHandleDuplicate =
    handle.trim() &&
    users.some(
      (u) =>
        u.id !== currentUser.id &&
        u.handle.toLowerCase() === handle.trim().replace(/^@/, '').toLowerCase()
    );

  const isEmailDuplicate =
    email.trim() &&
    users.some(
      (u) =>
        u.id !== currentUser.id &&
        u.email &&
        u.email.toLowerCase() === email.trim().toLowerCase()
    );

  const isPhoneDuplicate =
    phoneNumber.trim() &&
    users.some((u) => {
      if (u.id === currentUser.id) return false;
      const uDigits = (u.phoneNumber || '').replace(/\D/g, '');
      const curDigits = phoneNumber.replace(/\D/g, '');
      return uDigits && curDigits && uDigits === curDigits;
    });

  // Auto-detect GPS location
  const handleDetectLocation = async () => {
    setIsDetectingLocation(true);
    setError(null);
    try {
      const detected = await getAutoLocation();
      if (detected && detected.address) {
        setLocation(detected.address);
        setLocationSource(detected.source);
      } else {
        setLocation('서울 강남구');
        setLocationSource('preset');
      }
    } catch {
      setError('위치를 자동으로 감지하지 못했습니다. 아래 추천 지역이나 직접 입력을 이용해주세요.');
      if (!location) {
        setLocation('서울 강남구');
        setLocationSource('preset');
      }
    } finally {
      setIsDetectingLocation(false);
    }
  };

  // Avatar file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 3 * 1024 * 1024) {
      setError('사진 파일 크기는 3MB 이하로 업로드해주세요.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setAvatar(reader.result);
        setCustomAvatarUrl('');
      }
    };
    reader.readAsDataURL(file);
  };

  // Interests handling
  const handleAddInterest = (tag: string) => {
    const trimmed = tag.trim().replace(/^#/, '');
    if (!trimmed) return;
    if (interests.includes(trimmed)) return;
    if (interests.length >= 12) {
      setError('관심사는 최대 12개까지 등록할 수 있습니다.');
      return;
    }
    setInterests([...interests, trimmed]);
    setCustomInterest('');
    setError(null);
  };

  const handleRemoveInterest = (tagToRemove: string) => {
    setInterests(interests.filter((t) => t !== tagToRemove));
  };

  // Submit handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanName = name.trim();
    const cleanHandle = handle.trim().replace(/^@/, '');
    const cleanEmail = email.trim().toLowerCase();
    const cleanLocation = location.trim();

    if (!cleanName) {
      setError('이름을 입력해주세요.');
      return;
    }

    if (!cleanHandle) {
      setError('아이디를 입력해주세요.');
      return;
    }

    if (!/^[a-zA-Z0-9_.]+$/.test(cleanHandle)) {
      setError('아이디는 영문, 숫자, 밑줄(_), 마침표(.)만 사용 가능합니다.');
      return;
    }

    if (isHandleDuplicate) {
      setError('이미 다른 회원이 사용 중인 아이디입니다. 다른 아이디를 선택해주세요.');
      return;
    }

    if (!cleanEmail || !cleanEmail.includes('@')) {
      setError('올바른 이메일 주소를 입력해주세요.');
      return;
    }

    if (isEmailDuplicate) {
      setError('이미 다른 회원이 등록한 이메일 주소입니다.');
      return;
    }

    if (isPhoneDuplicate) {
      setError('이미 다른 회원이 등록한 휴대폰 번호입니다.');
      return;
    }

    if (phoneNumber.trim() && !isValidKoreanPhoneNumber(phoneNumber)) {
      setError('유효한 휴대폰 번호 형식(010-XXXX-XXXX)을 입력해주세요.');
      return;
    }

    if (isChangingPassword) {
      if (!newPassword || newPassword.length < 4) {
        setError('새 비밀번호는 최소 4자 이상 입력해주세요.');
        return;
      }
      if (newPassword !== newPasswordConfirm) {
        setError('새 비밀번호와 비밀번호 확인이 일치하지 않습니다.');
        return;
      }
    }

    if (!cleanLocation) {
      setError('활동 및 거주 지역을 입력해주세요.');
      return;
    }

    setIsSubmitting(true);

    const result = updateSignupInfo({
      name: cleanName,
      handle: cleanHandle,
      email: cleanEmail,
      phoneNumber: phoneNumber.trim() || undefined,
      password: isChangingPassword && newPassword ? newPassword : currentUser.password,
      location: cleanLocation,
      role: role.trim() || undefined,
      bio: bio.trim() || undefined,
      avatar: avatar || currentUser.avatar,
      interests
    });

    setIsSubmitting(false);

    if (result.success) {
      closeEditSignupInfoModal();
    } else {
      setError(result.error || '회원가입 정보 수정 중 오류가 발생했습니다.');
    }
  };

  return (
    <div
      id="edit-signup-info-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm animate-in fade-in duration-200 overflow-y-auto"
      onClick={closeEditSignupInfoModal}
    >
      <div
        id="edit-signup-info-modal-content"
        className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50 my-8 max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-600/20 shrink-0">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-slate-900 dark:text-white">
                  회원가입 정보 수정
                </h3>
                <span className="rounded-full bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 px-2 py-0.5 text-[10px] font-bold text-indigo-700 dark:text-indigo-300">
                  계정 기본 설정
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                가입 시 입력했던 이름, 아이디, 이메일, 비밀번호, 지역 등의 필수 정보를 수정합니다.
              </p>
            </div>
          </div>
          <button
            type="button"
            id="close-edit-signup-info-modal-btn"
            onClick={closeEditSignupInfoModal}
            className="rounded-full p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto pr-1 py-4 space-y-6">
          {/* Account Status Info Banner */}
          <div className="rounded-xl border border-indigo-100 dark:border-indigo-900/60 bg-gradient-to-r from-indigo-50/60 to-purple-50/40 dark:from-indigo-950/40 dark:to-purple-950/20 p-3.5 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              <img
                src={avatar || currentUser.avatar}
                alt={currentUser.name}
                className="h-9 w-9 rounded-full object-cover border border-indigo-200 dark:border-indigo-800 shrink-0"
                referrerPolicy="no-referrer"
              />
              <div className="min-w-0">
                <p className="font-bold text-slate-900 dark:text-white truncate">
                  {currentUser.name} <span className="font-normal text-slate-500">(@{currentUser.handle})</span>
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  가입일: {currentUser.joinedDate} · 계정 식별자: {currentUser.id}
                </p>
              </div>
            </div>
            <span className="inline-flex items-center gap-1 rounded-md bg-emerald-50 px-2 py-1 text-[11px] font-bold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 shrink-0 border border-emerald-200/60 dark:border-emerald-800/60">
              <Check className="h-3 w-3" /> 인증된 계정
            </span>
          </div>

          {/* Error Message Display */}
          {error && (
            <div className="flex items-center gap-2 rounded-xl bg-rose-50 border border-rose-200 p-3 text-xs text-rose-700 dark:bg-rose-950/50 dark:border-rose-900/60 dark:text-rose-300">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* SECTION 1: 기본 계정 정보 (이름, 아이디, 이메일) */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 uppercase tracking-wider">
              <User className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
              <span>1. 기본 인적사항 및 로그인 계정</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {/* Name Field */}
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                  <span>이름</span>
                  <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    id="signup-edit-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    placeholder="이름 입력"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-9 pr-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-indigo-500 transition-colors"
                  />
                </div>
              </div>

              {/* Handle Field */}
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <span>아이디 / 핸들</span>
                    <span className="text-rose-500">*</span>
                  </span>
                  {isHandleDuplicate && (
                    <span className="text-[11px] text-rose-500 font-medium">이미 사용 중인 아이디</span>
                  )}
                </label>
                <div className="relative">
                  <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    id="signup-edit-handle"
                    value={handle}
                    onChange={(e) => setHandle(e.target.value)}
                    required
                    placeholder="아이디 입력 (영문, 숫자)"
                    className={`w-full rounded-xl border pl-9 pr-3.5 py-2.5 text-sm transition-colors focus:bg-white focus:outline-none ${
                      isHandleDuplicate
                        ? 'border-rose-400 bg-rose-50 text-rose-900 dark:bg-rose-950/30 dark:border-rose-700 dark:text-white'
                        : 'border-slate-200 bg-slate-50 text-slate-900 focus:border-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-white'
                    }`}
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  영문 소문자, 숫자, 밑줄(_), 마침표(.) 사용 가능
                </p>
              </div>
            </div>

            {/* Email Field */}
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <span>가입 이메일 주소</span>
                  <span className="text-rose-500">*</span>
                </span>
                {isEmailDuplicate && (
                  <span className="text-[11px] text-rose-500 font-medium">이미 등록된 이메일</span>
                )}
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="email"
                  id="signup-edit-email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="name@example.com"
                  className={`w-full rounded-xl border pl-9 pr-3.5 py-2.5 text-sm transition-colors focus:bg-white focus:outline-none ${
                    isEmailDuplicate
                      ? 'border-rose-400 bg-rose-50 text-rose-900 dark:bg-rose-950/30 dark:border-rose-700 dark:text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-900 focus:border-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-white'
                  }`}
                />
              </div>
            </div>

            {/* Phone Number Field */}
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <Phone className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400" />
                  <span>휴대폰 번호 (인증 번호)</span>
                </span>
                {isPhoneDuplicate ? (
                  <span className="text-[11px] text-rose-500 font-medium">이미 등록된 휴대폰 번호</span>
                ) : currentUser.phoneVerified ? (
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-0.5">
                    <Check className="w-3 h-3" /> 본인 인증 완료
                  </span>
                ) : null}
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="tel"
                  id="signup-edit-phone"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(formatPhoneNumber(e.target.value))}
                  placeholder="010-1234-5678"
                  className={`w-full rounded-xl border pl-9 pr-3.5 py-2.5 text-sm transition-colors focus:bg-white focus:outline-none ${
                    isPhoneDuplicate
                      ? 'border-rose-400 bg-rose-50 text-rose-900 dark:bg-rose-950/30 dark:border-rose-700 dark:text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-900 focus:border-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-white'
                  }`}
                />
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                계정 보안 및 본인 확인용 연락처입니다.
              </p>
            </div>
          </div>

          {/* SECTION 2: 비밀번호 관리 */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/30 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-indigo-100 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-300">
                  <KeyRound className="h-4 w-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                    2. 비밀번호 보안 관리
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    가입 시 설정한 비밀번호를 안전하게 변경할 수 있습니다.
                  </p>
                </div>
              </div>
              <button
                type="button"
                id="toggle-change-password-btn"
                onClick={() => {
                  setIsChangingPassword(!isChangingPassword);
                  setNewPassword('');
                  setNewPasswordConfirm('');
                }}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                  isChangingPassword
                    ? 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-xs'
                }`}
              >
                {isChangingPassword ? '변경 취소' : '비밀번호 변경하기'}
              </button>
            </div>

            {!isChangingPassword ? (
              <div className="flex items-center justify-between text-xs px-3 py-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Lock className="h-3.5 w-3.5 text-emerald-500" />
                  현재 비밀번호가 안전하게 설정되어 있습니다 (••••••••)
                </span>
                <span className="text-[11px] text-slate-400">변경 필요 시 우측 버튼 클릭</span>
              </div>
            ) : (
              <div className="space-y-3 pt-2 animate-in fade-in duration-150">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                      새 비밀번호 (최소 4자)
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="새 비밀번호 입력"
                        className="w-full rounded-xl border border-slate-200 bg-white pl-9 pr-10 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                      새 비밀번호 확인
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={newPasswordConfirm}
                        onChange={(e) => setNewPasswordConfirm(e.target.value)}
                        placeholder="비밀번호 다시 입력"
                        className="w-full rounded-xl border border-slate-200 bg-white pl-9 pr-3.5 py-2 text-sm text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                      />
                    </div>
                  </div>
                </div>
                {newPassword && newPasswordConfirm && newPassword !== newPasswordConfirm && (
                  <p className="text-[11px] text-rose-500 font-medium">비밀번호 확인이 일치하지 않습니다.</p>
                )}
                {newPassword && newPasswordConfirm && newPassword === newPasswordConfirm && (
                  <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
                    <Check className="h-3 w-3" /> 비밀번호가 일치합니다.
                  </p>
                )}
              </div>
            )}
          </div>

          {/* SECTION 3: 주거지 (위치) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 uppercase tracking-wider">
                <MapPin className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <span>3. 주거지</span>
                <span className="text-rose-500">*</span>
              </h4>

              {/* GPS Auto-detect Button */}
              <button
                type="button"
                id="edit-signup-gps-btn"
                onClick={handleDetectLocation}
                disabled={isDetectingLocation}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 text-xs font-bold hover:bg-blue-100 dark:hover:bg-blue-900/60 transition-colors border border-blue-200/60 dark:border-blue-800/60 cursor-pointer disabled:opacity-50"
              >
                {isDetectingLocation ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin text-blue-600" />
                    <span>GPS 감지 중...</span>
                  </>
                ) : (
                  <>
                    <Navigation className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                    <span>GPS 위치 자동 감지</span>
                  </>
                )}
              </button>
            </div>

            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                id="signup-edit-location"
                value={location}
                onChange={(e) => {
                  setLocation(e.target.value);
                  setLocationSource('manual');
                }}
                required
                placeholder="예: 서울 강남구 역삼동, 경기 성남시 분당구"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 pl-9 pr-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-indigo-500"
              />
            </div>
          </div>

          {/* SECTION 4: 직업 / 역할 & 자기소개 */}
          <div className="space-y-3.5">
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 uppercase tracking-wider">
              <Briefcase className="h-4 w-4 text-purple-600 dark:text-purple-400" />
              <span>4. 직업 / 역할 및 자기소개</span>
            </h4>

            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                활동 역할 / 직업
              </label>
              <input
                type="text"
                value={role}
                onChange={(e) => setRole(e.target.value)}
                placeholder="예: 학생, 직장인/회사원, 전문직, 자영업 등"
                className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-indigo-500"
              />
              <div className="flex flex-wrap gap-1.5 mt-2">
                {POPULAR_ROLES_LIST.map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRole(r)}
                    className="text-[11px] px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 transition-colors"
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  한 줄 자기소개
                </label>
                <span className="text-[11px] text-slate-400">{bio.length}/150자</span>
              </div>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                maxLength={150}
                rows={2}
                placeholder="회원가입 시 등록했던 나만의 한 줄 소개를 수정해보세요."
                className="w-full rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-indigo-500 resize-none"
              />
            </div>
          </div>

          {/* SECTION 5: 프로필 사진 (아바타) */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 uppercase tracking-wider">
              <Camera className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              <span>5. 프로필 사진 (아바타)</span>
            </h4>

            <div className="flex items-center gap-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="relative cursor-pointer group shrink-0"
                title="클릭하여 내 사진 업로드"
              >
                <img
                  src={avatar || currentUser.avatar || DEFAULT_PERSON_AVATAR}
                  alt="Avatar preview"
                  className="h-16 w-16 rounded-full object-cover border-2 border-indigo-500 shadow-md bg-white dark:bg-slate-800"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                  <Camera className="w-5 h-5" />
                </div>
                <span className="absolute bottom-0 right-0 h-4 w-4 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
              </div>

              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-300 bg-white text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition-colors shadow-xs shrink-0 cursor-pointer"
                  >
                    <Upload className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400" />
                    <span>내 사진 업로드</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAvatar(DEFAULT_PERSON_AVATAR);
                      setCustomAvatarUrl('');
                      if (fileInputRef.current) fileInputRef.current.value = '';
                    }}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 transition-colors shrink-0 cursor-pointer"
                    title="기본 사람 실루엣으로 변경"
                  >
                    <span>기본 실루엣</span>
                  </button>

                  <input
                    type="text"
                    value={customAvatarUrl}
                    onChange={(e) => {
                      setCustomAvatarUrl(e.target.value);
                      if (e.target.value.trim().startsWith('http')) {
                        setAvatar(e.target.value.trim());
                      }
                    }}
                    placeholder="이미지 URL 직접 입력"
                    className="flex-1 min-w-[140px] rounded-xl border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-indigo-500"
                  />

                  {(avatar !== currentUser.avatar || customAvatarUrl) && (
                    <button
                      type="button"
                      onClick={() => {
                        setAvatar(currentUser.avatar);
                        setCustomAvatarUrl('');
                        if (fileInputRef.current) fileInputRef.current.value = '';
                      }}
                      className="px-2.5 py-1.5 text-xs text-slate-500 hover:text-rose-600 dark:hover:text-rose-400 font-medium shrink-0 cursor-pointer"
                      title="원래 프로필 사진으로 복원"
                    >
                      원래대로
                    </button>
                  )}
                </div>

                <p className="text-[11px] text-slate-400 dark:text-slate-500">
                  원하는 사진 파일을 직접 업로드하거나 웹 이미지 주소를 입력하여 프로필 사진으로 지정할 수 있습니다.
                </p>
              </div>
            </div>
          </div>

          {/* SECTION 6: 관심사 태그 (Interests) */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 uppercase tracking-wider">
              <Tag className="h-4 w-4 text-amber-500" />
              <span>6. 관심사 태그 ({interests.length}/12)</span>
            </h4>

            {/* Current Tags */}
            <div className="flex flex-wrap gap-1.5 min-h-[32px] p-2.5 rounded-xl border border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-800/40">
              {interests.length === 0 ? (
                <span className="text-xs text-slate-400">선택된 관심사가 없습니다. 아래 추천 태그를 눌러 추가해보세요.</span>
              ) : (
                interests.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200/80 dark:border-indigo-800/80 text-xs font-bold shadow-xs"
                  >
                    <span>#{tag}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveInterest(tag)}
                      className="hover:text-rose-600 p-0.5 rounded-full"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                ))
              )}
            </div>

            {/* Add Custom Tag */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={customInterest}
                onChange={(e) => setCustomInterest(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddInterest(customInterest);
                  }
                }}
                placeholder="직접 새 관심사 입력 (예: 캠핑, 재테크)"
                className="flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-indigo-600 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-indigo-500"
              />
              <button
                type="button"
                onClick={() => handleAddInterest(customInterest)}
                className="px-3.5 py-2 rounded-xl bg-slate-800 text-white dark:bg-slate-700 text-xs font-bold hover:bg-slate-900 transition-colors"
              >
                태그 추가
              </button>
            </div>

            {/* Popular Interests quick suggestions */}
            <div className="flex flex-wrap gap-1.5 pt-1 max-h-36 overflow-y-auto p-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
              {POPULAR_INTERESTS_LIST.map((item) => {
                const isSelected = interests.includes(item);
                return (
                  <button
                    key={item}
                    type="button"
                    onClick={() => {
                      if (isSelected) {
                        handleRemoveInterest(item);
                      } else {
                        handleAddInterest(item);
                      }
                    }}
                    className={`text-[11px] px-2.5 py-1 rounded-full transition-colors font-medium border ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
                    }`}
                  >
                    {isSelected ? '✓ ' : '+ '}
                    {item}
                  </button>
                );
              })}
            </div>
          </div>
        </form>

        {/* Modal Footer Controls */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800 shrink-0">
          <button
            type="button"
            onClick={closeEditSignupInfoModal}
            className="px-4 py-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
          >
            취소
          </button>

          <button
            type="button"
            id="save-signup-info-submit-btn"
            onClick={handleSubmit}
            disabled={isSubmitting || !!isHandleDuplicate || !!isEmailDuplicate}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white text-xs md:text-sm font-bold shadow-md shadow-indigo-600/25 transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>저장 중...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="h-4 w-4" />
                <span>회원가입 정보 저장</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
