import React, { useState, useMemo, useRef } from 'react';
import { useSocial } from '../context/SocialContext';
import { DatabaseTableKey, User, Post, Comment, UserStory, Message, FullDatabaseBackup, ApiKeyRecord } from '../types';
import {
  Database,
  Lock,
  Unlock,
  KeyRound,
  Key,
  Shield,
  ShieldCheck,
  ShieldAlert,
  Save,
  Download,
  Upload,
  Plus,
  Trash2,
  Edit3,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
  FileJson,
  Search,
  Filter,
  Eye,
  EyeOff,
  Copy,
  Check,
  X,
  Code,
  Users,
  FileText,
  MessageSquare,
  Sparkles,
  Smartphone,
  MapPin,
  CheckCheck,
  Radio,
  SlidersHorizontal
} from 'lucide-react';

export const DatabaseManagementView: React.FC = () => {
  const {
    currentUser,
    users,
    posts,
    comments,
    stories,
    messages,
    apiKeysRecords,
    smsApiConfig,
    updateSmsApiConfig,
    fetchSmsApiConfig,
    testSmsApiConnection,
    isSuperAdminDbUnlocked,
    unlockSuperAdminDatabase,
    lockSuperAdminDatabase,
    updateDatabaseRecord,
    insertDatabaseRecord,
    deleteDatabaseRecord,
    replaceDatabaseTable,
    importFullDatabase,
    resetFullDatabaseToInitial,
    getFullDatabaseBackup,
    showToast,
    setActiveTab
  } = useSocial();

  // Authentication State for Super Admin DB Gate
  const [loginId, setLoginId] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isAuthorizing, setIsAuthorizing] = useState(false);

  // Active View Tab inside Database Console
  const [activeTable, setActiveTable] = useState<DatabaseTableKey | 'json_editor'>('users');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals & Editor States
  const [editingRecord, setEditingRecord] = useState<{ table: DatabaseTableKey; record: any } | null>(null);
  const [isCreatingNewRecord, setIsCreatingNewRecord] = useState<DatabaseTableKey | null>(null);
  const [newRecordData, setNewRecordData] = useState<any>({});
  const [jsonViewerRecord, setJsonViewerRecord] = useState<any | null>(null);
  const [copiedRecordId, setCopiedRecordId] = useState<string | null>(null);
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState<{ table: DatabaseTableKey; id: string; name: string } | null>(null);
  const [showResetDbConfirm, setShowResetDbConfirm] = useState(false);

  // Raw JSON Editor States
  const [jsonEditorTable, setJsonEditorTable] = useState<DatabaseTableKey | 'all'>('users');
  const [rawJsonText, setRawJsonText] = useState('');
  const [jsonParseError, setJsonParseError] = useState<string | null>(null);
  const [copiedFullJson, setCopiedFullJson] = useState(false);

  // Backup File Input Ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Check if current user is an authorized admin account
  const isSuperAdminAccount = currentUser?.isAdmin || currentUser?.handle === 'admin';
  const isAccessAuthorized = isSuperAdminAccount && isSuperAdminDbUnlocked;

  // Handle Master Authorization Submit
  const handleAuthorize = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setAuthError(null);
    setIsAuthorizing(true);

    setTimeout(() => {
      setIsAuthorizing(false);
      const cleanId = loginId.trim().toLowerCase().replace(/^@/, '');
      if (cleanId !== 'admin') {
        setAuthError('최고관리자 아이디가 일치하지 않습니다.');
        return;
      }

      const res = unlockSuperAdminDatabase(loginPassword);
      if (!res.success) {
        setAuthError(res.error || '인증에 실패했습니다. 비밀번호를 확인해주세요.');
      } else {
        setAuthError(null);
      }
    }, 400);
  };

  // Switch to Raw JSON tab & initialize text
  const openRawJsonEditor = (tableKey: DatabaseTableKey | 'all') => {
    setJsonEditorTable(tableKey);
    setJsonParseError(null);
    if (tableKey === 'users') {
      setRawJsonText(JSON.stringify(users, null, 2));
    } else if (tableKey === 'posts') {
      setRawJsonText(JSON.stringify(posts, null, 2));
    } else if (tableKey === 'comments') {
      setRawJsonText(JSON.stringify(comments, null, 2));
    } else if (tableKey === 'stories') {
      setRawJsonText(JSON.stringify(stories, null, 2));
    } else if (tableKey === 'messages') {
      setRawJsonText(JSON.stringify(messages, null, 2));
    } else if (tableKey === 'api_keys') {
      setRawJsonText(JSON.stringify(apiKeysRecords, null, 2));
    } else {
      setRawJsonText(JSON.stringify(getFullDatabaseBackup(), null, 2));
    }
    setActiveTable('json_editor');
  };

  // Apply Raw JSON
  const handleApplyRawJson = () => {
    setJsonParseError(null);
    try {
      const parsed = JSON.parse(rawJsonText);
      if (jsonEditorTable === 'all') {
        if (!parsed.tables) {
          throw new Error('전체 백업 JSON 포맷에는 "tables" 필드가 포함되어야 합니다.');
        }
        importFullDatabase(parsed.tables);
      } else {
        if (!Array.isArray(parsed)) {
          throw new Error(`[${jsonEditorTable}] 테이블 데이터는 배열(Array) 형식이어야 합니다.`);
        }
        replaceDatabaseTable(jsonEditorTable, parsed);
      }
      showToast('JSON 데이터가 데이터베이스에 성공적으로 반영되었습니다!', 'success');
    } catch (err: any) {
      setJsonParseError(err.message || '유효하지 않은 JSON 형식입니다.');
    }
  };

  // Format / Prettify Raw JSON
  const handlePrettifyRawJson = () => {
    try {
      const parsed = JSON.parse(rawJsonText);
      setRawJsonText(JSON.stringify(parsed, null, 2));
      setJsonParseError(null);
      showToast('JSON 서식이 깔끔하게 정렬되었습니다.', 'info');
    } catch (err: any) {
      setJsonParseError(err.message || 'JSON 형식이 올바르지 않아 정렬할 수 없습니다.');
    }
  };

  // Copy Raw JSON to Clipboard
  const handleCopyRawJson = () => {
    navigator.clipboard.writeText(rawJsonText);
    setCopiedFullJson(true);
    setTimeout(() => setCopiedFullJson(false), 2000);
    showToast('JSON 코드가 클립보드에 복사되었습니다.', 'info');
  };

  // Export Entire Database as JSON file
  const handleExportDatabaseFile = () => {
    const backup = getFullDatabaseBackup();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backup, null, 2));
    const downloadAnchor = document.createElement('a');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `maeum_db_backup_${timestamp}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('데이터베이스 전체 백업 파일(.json)이 다운로드되었습니다.', 'success');
  };

  // Import Database File
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);

        if (parsed.tables && typeof parsed.tables === 'object') {
          importFullDatabase(parsed.tables);
        } else if (Array.isArray(parsed)) {
          // If array of users or posts
          if (parsed.length > 0 && parsed[0].handle) {
            replaceDatabaseTable('users', parsed);
          } else if (parsed.length > 0 && parsed[0].content && parsed[0].authorId) {
            replaceDatabaseTable('posts', parsed);
          } else {
            throw new Error('알 수 없는 데이터 배열 형식입니다.');
          }
        } else {
          throw new Error('유효한 마음(Maeum) 데이터베이스 백업 JSON 파일이 아닙니다.');
        }
      } catch (err: any) {
        showToast(`파일 가져오기 실패: ${err.message}`, 'error');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Filtered Records based on Search
  const filteredUsers = useMemo(() => {
    if (!searchQuery.trim()) return users;
    const q = searchQuery.toLowerCase();
    return users.filter(
      (u) =>
        u.id.toLowerCase().includes(q) ||
        u.name.toLowerCase().includes(q) ||
        u.handle.toLowerCase().includes(q) ||
        (u.email && u.email.toLowerCase().includes(q)) ||
        (u.phoneNumber && u.phoneNumber.includes(q)) ||
        (u.role && u.role.toLowerCase().includes(q))
    );
  }, [users, searchQuery]);

  const filteredPosts = useMemo(() => {
    if (!searchQuery.trim()) return posts;
    const q = searchQuery.toLowerCase();
    return posts.filter(
      (p) =>
        p.id.toLowerCase().includes(q) ||
        p.content.toLowerCase().includes(q) ||
        p.authorName.toLowerCase().includes(q) ||
        p.authorHandle.toLowerCase().includes(q) ||
        (p.tags && p.tags.some((t) => t.toLowerCase().includes(q)))
    );
  }, [posts, searchQuery]);

  const filteredComments = useMemo(() => {
    if (!searchQuery.trim()) return comments;
    const q = searchQuery.toLowerCase();
    return comments.filter(
      (c) =>
        c.id.toLowerCase().includes(q) ||
        c.postId.toLowerCase().includes(q) ||
        c.content.toLowerCase().includes(q) ||
        c.authorName.toLowerCase().includes(q)
    );
  }, [comments, searchQuery]);

  const filteredStories = useMemo(() => {
    if (!searchQuery.trim()) return stories;
    const q = searchQuery.toLowerCase();
    return stories.filter(
      (s) =>
        s.userId.toLowerCase().includes(q) ||
        s.userName.toLowerCase().includes(q) ||
        s.items.some((it) => it.caption?.toLowerCase().includes(q))
    );
  }, [stories, searchQuery]);

  const filteredMessages = useMemo(() => {
    if (!searchQuery.trim()) return messages;
    const q = searchQuery.toLowerCase();
    return messages.filter(
      (m) =>
        m.id.toLowerCase().includes(q) ||
        m.senderId.toLowerCase().includes(q) ||
        m.receiverId.toLowerCase().includes(q) ||
        m.content.toLowerCase().includes(q)
    );
  }, [messages, searchQuery]);

  // Toggle secret visibility for API keys table
  const [showSecretMap, setShowSecretMap] = useState<Record<string, boolean>>({});
  const toggleShowSecret = (id: string) => {
    setShowSecretMap((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Toggle secret visibility inside Edit Record Modal
  const [isEditSecretVisible, setIsEditSecretVisible] = useState(false);
  const toggleEditSecretVisible = () => setIsEditSecretVisible((prev) => !prev);

  // Filtered API Keys & Secrets
  const filteredApiKeys = useMemo(() => {
    if (!apiKeysRecords) return [];
    if (!searchQuery.trim()) return apiKeysRecords;
    const q = searchQuery.toLowerCase();
    return apiKeysRecords.filter(
      (k) =>
        k.id.toLowerCase().includes(q) ||
        k.serviceName.toLowerCase().includes(q) ||
        k.keyName.toLowerCase().includes(q) ||
        k.apiKey.toLowerCase().includes(q) ||
        k.secretName.toLowerCase().includes(q) ||
        (k.senderNumber && k.senderNumber.includes(q)) ||
        (k.description && k.description.toLowerCase().includes(q))
    );
  }, [apiKeysRecords, searchQuery]);

  // Handle Save Edited Record
  const handleSaveEditedRecord = () => {
    if (!editingRecord) return;
    const { table, record } = editingRecord;
    const res = updateDatabaseRecord(table, record.id, record);
    if (res.success) {
      setEditingRecord(null);
    } else {
      showToast(res.error || '수정 실패', 'error');
    }
  };

  // Handle Create New Record
  const handleSaveNewRecord = () => {
    if (!isCreatingNewRecord) return;
    const table = isCreatingNewRecord;
    const res = insertDatabaseRecord(table, newRecordData);
    if (res.success) {
      setIsCreatingNewRecord(null);
      setNewRecordData({});
    } else {
      showToast(res.error || '생성 실패', 'error');
    }
  };

  // Open Create Record Modal with initial template
  const openCreateRecordModal = (table: DatabaseTableKey) => {
    setIsCreatingNewRecord(table);
    if (table === 'users') {
      setNewRecordData({
        name: '신규 사용자',
        handle: `user_${Date.now().toString().slice(-4)}`,
        email: `new_user_${Date.now().toString().slice(-4)}@maeum.io`,
        password: 'password123',
        phoneNumber: '01012345678',
        phoneVerified: true,
        role: '일반 회원',
        location: '서울',
        bio: '안녕하세요! 새로 가입했습니다.',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
        joinedDate: '오늘',
        followersCount: 0,
        followingCount: 0,
        isAdmin: false,
        isBanned: false
      });
    } else if (table === 'posts') {
      setNewRecordData({
        content: '관리자가 데이터베이스에서 직접 생성한 테스트 게시물입니다.',
        authorId: currentUser.id,
        authorName: currentUser.name,
        authorHandle: currentUser.handle,
        authorAvatar: currentUser.avatar,
        visibility: 'public',
        regionalScope: 'national',
        tags: ['공지', '시스템DB'],
        likes: [],
        bookmarks: [],
        reposts: [],
        commentsCount: 0,
        createdAt: new Date().toISOString()
      });
    } else if (table === 'comments') {
      setNewRecordData({
        postId: posts[0]?.id || 'post_1',
        authorId: currentUser.id,
        authorName: currentUser.name,
        authorHandle: currentUser.handle,
        authorAvatar: currentUser.avatar,
        content: '데이터베이스에서 직접 작성된 댓글입니다.',
        likes: [],
        createdAt: new Date().toISOString()
      });
    } else if (table === 'messages') {
      setNewRecordData({
        senderId: currentUser.id,
        receiverId: users.find((u) => u.id !== currentUser.id)?.id || 'user_1',
        content: '데이터베이스 직접 생성 메시지입니다.',
        createdAt: new Date().toISOString(),
        isRead: false
      });
    } else if (table === 'api_keys') {
      setNewRecordData({
        id: `api_custom_${Date.now()}`,
        serviceName: '새 외부 연동 API',
        provider: 'Custom',
        keyName: 'API_KEY',
        apiKey: '',
        secretName: 'API_SECRET',
        apiSecret: '',
        senderNumber: '010-1234-5678',
        status: 'active',
        description: '관리자가 데이터베이스에 직접 추가한 API 키 & SECRET 연동',
        updatedAt: new Date().toISOString(),
        updatedBy: currentUser?.name || '최고 관리자'
      });
    }
  };

  // =========================================================================
  // VIEW 1: GATE VIEW (최고관리자 데이터베이스 로그인 & 인증 화면)
  // =========================================================================
  if (!isAccessAuthorized) {
    return (
      <div className="max-w-2xl mx-auto py-8 px-4 animate-in fade-in duration-300">
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden">
          {/* Top Banner */}
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-8 text-white relative">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-400/30 mb-3">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>최고 관리자 전용 보안 영역</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
              <Database className="w-8 h-8 text-indigo-400" />
              데이타베이스 마스터 콘솔 로그인
            </h1>
            <p className="text-slate-300 text-xs md:text-sm mt-2 leading-relaxed">
              마음(Maeum) 소셜 네트워크의 <strong>회원, 게시물, 댓글, 스토리, 메시지, API 키 & API SECRET</strong> 전체 데이터베이스를
              직접 조회, 수정, 추가, 삭제할 수 있는 마스터 권한 인증 페이지입니다.
            </p>
          </div>

          {/* Form Area */}
          <div className="p-6 md:p-8 space-y-6">
            {authError && (
              <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-sm flex items-start gap-3 animate-in shake">
                <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-rose-600" />
                <div>
                  <div className="font-bold">인증 실패</div>
                  <div className="text-xs mt-0.5">{authError}</div>
                </div>
              </div>
            )}

            <form onSubmit={handleAuthorize} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  최고 관리자 아이디 (ID / Handle)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value)}
                    placeholder="최고 관리자 아이디를 입력하세요"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-medium"
                    required
                  />
                  <Shield className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  마스터 보안 비밀번호 (Password)
                </label>
                <div className="relative">
                  <input
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="마스터 보안 비밀번호를 입력하세요"
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-mono"
                    required
                  />
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                </div>
              </div>

              <div className="pt-2 flex flex-col gap-3">
                <button
                  type="submit"
                  disabled={isAuthorizing}
                  className="w-full py-3.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  {isAuthorizing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>보안 인증 확인 중...</span>
                    </>
                  ) : (
                    <>
                      <Unlock className="w-4 h-4" />
                      <span>최고관리자 데이터베이스 마스터 로그인</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Security Notice Box */}
            <div className="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/40 text-amber-900 dark:text-amber-300 text-xs leading-relaxed space-y-1.5">
              <div className="font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-600" />
                <span>데이터 무결성 및 보안 안내</span>
              </div>
              <p>
                본 페이지에서 데이터를 직접 수정하거나 삭제하면 <code>localStorage</code>와 소셜 네트워크 전역 상태에
                즉시 동기화됩니다. 수정 전 상단의 <strong>[DB 백업 다운로드]</strong> 기능을 활용하시기 바랍니다.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // =========================================================================
  // VIEW 2: AUTHENTICATED DATABASE CONSOLE (최고관리자 DB 마스터 관리 화면)
  // =========================================================================
  return (
    <div className="space-y-6 pb-16 animate-in fade-in duration-200">
      {/* Hidden File Input for JSON Backup Import */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept=".json,application/json"
        className="hidden"
      />

      {/* Super Admin DB Master Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 md:p-8 text-white shadow-xl border border-indigo-900/40">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-400/30">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>최고관리자 마스터 세션 인증됨</span>
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[11px] font-mono border border-indigo-400/30">
                @{currentUser.handle} ({currentUser.name})
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
              <Database className="w-7 h-7 text-indigo-400" />
              데이터베이스(DB) 직접 수정 및 관리 콘솔
            </h1>
            <p className="text-slate-300 text-xs md:text-sm max-w-2xl leading-relaxed">
              최고관리자 권한으로 시스템 내 모든 테이블(Users, Posts, Comments, Stories, Messages)의 레코드를 실시간으로 직접
              <strong> 추가 · 수정 · 삭제</strong>하거나 <strong>원시 JSON</strong>으로 일괄 갱신할 수 있습니다.
            </p>
          </div>

          {/* Quick Action Tools: Backup, Restore, Lock */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleExportDatabaseFile}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all border border-white/10 cursor-pointer shadow-xs"
              title="전체 DB를 JSON 파일로 다운로드합니다"
            >
              <Download className="w-4 h-4 text-emerald-300" />
              <span>DB 백업 다운로드</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all border border-white/10 cursor-pointer shadow-xs"
              title="백업 JSON 파일을 업로드하여 복원합니다"
            >
              <Upload className="w-4 h-4 text-sky-300" />
              <span>DB 복원 (파일 업로드)</span>
            </button>

            <button
              onClick={() => setShowResetDbConfirm(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-xs font-bold transition-all border border-rose-400/30 cursor-pointer"
              title="데이터베이스를 초기 원본 상태로 리셋합니다"
            >
              <RotateCcw className="w-4 h-4" />
              <span>DB 초기화</span>
            </button>

            <button
              onClick={() => lockSuperAdminDatabase()}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all border border-slate-700 cursor-pointer"
              title="마스터 세션을 잠금 처리합니다"
            >
              <Lock className="w-4 h-4" />
              <span>세션 잠금</span>
            </button>
          </div>
        </div>

        {/* Database Metric Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6 pt-5 border-t border-indigo-900/50">
          <div
            onClick={() => setActiveTable('users')}
            className={`p-3 rounded-2xl border transition-all cursor-pointer ${
              activeTable === 'users'
                ? 'bg-indigo-600/30 border-indigo-400 shadow-md'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="text-[11px] text-slate-300 font-medium flex items-center justify-between">
              <span>회원 (Users)</span>
              <Users className="w-3.5 h-3.5 text-indigo-400" />
            </div>
            <div className="text-xl font-black text-white mt-1">{users.length}명</div>
          </div>

          <div
            onClick={() => setActiveTable('posts')}
            className={`p-3 rounded-2xl border transition-all cursor-pointer ${
              activeTable === 'posts'
                ? 'bg-indigo-600/30 border-indigo-400 shadow-md'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="text-[11px] text-slate-300 font-medium flex items-center justify-between">
              <span>게시물 (Posts)</span>
              <FileText className="w-3.5 h-3.5 text-indigo-400" />
            </div>
            <div className="text-xl font-black text-white mt-1">{posts.length}개</div>
          </div>

          <div
            onClick={() => setActiveTable('comments')}
            className={`p-3 rounded-2xl border transition-all cursor-pointer ${
              activeTable === 'comments'
                ? 'bg-indigo-600/30 border-indigo-400 shadow-md'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="text-[11px] text-slate-300 font-medium flex items-center justify-between">
              <span>댓글 (Comments)</span>
              <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
            </div>
            <div className="text-xl font-black text-white mt-1">{comments.length}개</div>
          </div>

          <div
            onClick={() => setActiveTable('stories')}
            className={`p-3 rounded-2xl border transition-all cursor-pointer ${
              activeTable === 'stories'
                ? 'bg-indigo-600/30 border-indigo-400 shadow-md'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="text-[11px] text-slate-300 font-medium flex items-center justify-between">
              <span>스토리 (Stories)</span>
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            </div>
            <div className="text-xl font-black text-white mt-1">{stories.length}명 / {stories.reduce((acc, s) => acc + s.items.length, 0)}개</div>
          </div>

          <div
            onClick={() => setActiveTable('messages')}
            className={`p-3 rounded-2xl border transition-all cursor-pointer ${
              activeTable === 'messages'
                ? 'bg-indigo-600/30 border-indigo-400 shadow-md'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="text-[11px] text-slate-300 font-medium flex items-center justify-between">
              <span>메시지 (Messages)</span>
              <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
            </div>
            <div className="text-xl font-black text-white mt-1">{messages.length}건</div>
          </div>

          <div
            onClick={() => setActiveTable('api_keys')}
            className={`p-3 rounded-2xl border transition-all cursor-pointer ${
              activeTable === 'api_keys'
                ? 'bg-emerald-600/30 border-emerald-400 shadow-md ring-2 ring-emerald-500/20'
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            }`}
          >
            <div className="text-[11px] text-slate-300 font-medium flex items-center justify-between">
              <span>API 키 & SECRET</span>
              <Key className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-xl font-black text-white mt-1">{apiKeysRecords?.length || 6}개 연동</div>
          </div>
        </div>
      </div>

      {/* Table Navigation Tabs & Search Toolbar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Table Selector Tabs */}
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setActiveTable('users')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTable === 'users'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>회원 테이블 ({users.length})</span>
          </button>

          <button
            onClick={() => setActiveTable('posts')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTable === 'posts'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>게시물 테이블 ({posts.length})</span>
          </button>

          <button
            onClick={() => setActiveTable('comments')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTable === 'comments'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>댓글 테이블 ({comments.length})</span>
          </button>

          <button
            onClick={() => setActiveTable('stories')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTable === 'stories'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>스토리 ({stories.length})</span>
          </button>

          <button
            onClick={() => setActiveTable('messages')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTable === 'messages'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>메시지 ({messages.length})</span>
          </button>

          <button
            onClick={() => setActiveTable('api_keys')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTable === 'api_keys'
                ? 'bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-500/30'
                : 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 border border-emerald-200 dark:border-emerald-800/60'
            }`}
          >
            <Key className="w-3.5 h-3.5 text-emerald-500" />
            <span>🔑 API 키 & API SECRET ({apiKeysRecords?.length || 6})</span>
          </button>

          <button
            onClick={() => openRawJsonEditor(activeTable === 'json_editor' ? 'users' : activeTable)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTable === 'json_editor'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 hover:bg-amber-200 dark:hover:bg-amber-900/40'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>⚡ 원시 JSON 직접 편집기</span>
          </button>
        </div>

        {/* Search & Actions */}
        {activeTable !== 'json_editor' && (
          <div className="flex items-center gap-2">
            <div className="relative flex-1 md:w-56">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ID, 작성자, 내용 검색..."
                className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <button
              onClick={() => openCreateRecordModal(activeTable)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all cursor-pointer shadow-xs shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>새 레코드 추가</span>
            </button>
          </div>
        )}
      </div>

      {/* ===================================================================== */}
      {/* SECTION 1: USERS TABLE VIEW                                           */}
      {/* ===================================================================== */}
      {activeTable === 'users' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
          <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-indigo-500" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                회원 데이터베이스 테이블 (총 {filteredUsers.length}개)
              </h2>
            </div>
            <span className="text-xs text-slate-500">
              클릭하여 프로필, 권한, 휴대폰 번호, 비밀번호, 차단 여부를 직접 수정하세요.
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-bold">
                  <th className="py-3 px-4">사용자</th>
                  <th className="py-3 px-3">아이디 / ID</th>
                  <th className="py-3 px-3">연락처 / 이메일</th>
                  <th className="py-3 px-3">역할 / 권한</th>
                  <th className="py-3 px-3">가입일 / 상태</th>
                  <th className="py-3 px-4 text-right">DB 직접 작업</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={user.avatar}
                          alt={user.name}
                          className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                            <span className="truncate">{user.name}</span>
                            {user.isVerified && <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500 shrink-0" />}
                            {user.isAdmin && (
                              <span className="px-1.5 py-0.2 rounded bg-indigo-100 text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300 text-[10px] font-extrabold">
                                관리자
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400 truncate">{user.bio || '자기소개 없음'}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-mono text-indigo-600 dark:text-indigo-400 font-semibold">@{user.handle}</div>
                      <div className="text-[10px] text-slate-400 font-mono">ID: {user.id}</div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="text-slate-800 dark:text-slate-200">{user.email || '미등록'}</div>
                      <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                        <span>{user.phoneNumber || '전화번호 미등록'}</span>
                        {user.phoneVerified && (
                          <span className="text-[9px] px-1 bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 rounded font-bold">인증됨</span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-medium text-[11px]">
                        {user.role || '일반 회원'}
                      </span>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        팔로워 {user.followersCount}명 · 팔로잉 {user.followingCount}명
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="text-slate-700 dark:text-slate-300">{user.joinedDate || '기록 없음'}</div>
                      <div className="text-[10px] text-indigo-600 dark:text-indigo-400 font-mono mt-0.5 select-all">
                        IP: {user.signupIp || '127.0.0.1'}
                      </div>
                      {user.isBanned ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-600 dark:text-rose-400 mt-0.5">
                          <ShieldAlert className="w-3 h-3" />
                          차단됨 ({user.banReason || '정책 위반'})
                        </span>
                      ) : (
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                          정상 활동 중
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setEditingRecord({ table: 'users', record: { ...user } })}
                          className="p-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/80 dark:text-indigo-300 transition-colors cursor-pointer"
                          title="레코드 직접 수정"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setJsonViewerRecord(user)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                          title="JSON 보기"
                        >
                          <FileJson className="w-3.5 h-3.5" />
                        </button>
                        {!user.isAdmin && user.handle !== 'admin' && (
                          <button
                            onClick={() => setDeleteConfirmTarget({ table: 'users', id: user.id, name: `${user.name} (@${user.handle})` })}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 dark:text-rose-300 transition-colors cursor-pointer"
                            title="레코드 삭제"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* SECTION 2: POSTS TABLE VIEW                                           */}
      {/* ===================================================================== */}
      {activeTable === 'posts' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
          <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-indigo-500" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                게시물 데이터베이스 테이블 (총 {filteredPosts.length}개)
              </h2>
            </div>
            <span className="text-xs text-slate-500">
              본문 내용, 좋아요 목록, 차단(블라인드) 상태, 태그 등을 직접 편집하세요.
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-bold">
                  <th className="py-3 px-4">게시물 ID / 작성자</th>
                  <th className="py-3 px-3">게시물 본문 내용</th>
                  <th className="py-3 px-3">공개 / 지역 범위</th>
                  <th className="py-3 px-3">반응 통계</th>
                  <th className="py-3 px-3">차단(블라인드) 상태</th>
                  <th className="py-3 px-4 text-right">DB 직접 작업</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {filteredPosts.map((post) => (
                  <tr key={post.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-mono text-indigo-600 dark:text-indigo-400 font-semibold">{post.id}</div>
                      <div className="text-slate-800 dark:text-slate-200 font-medium mt-0.5 flex items-center gap-1.5">
                        <img
                          src={post.authorAvatar}
                          alt={post.authorName}
                          className="w-4 h-4 rounded-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <span>{post.authorName}</span>
                        <span className="text-slate-400 text-[10px]">@{post.authorHandle}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{post.createdAt ? new Date(post.createdAt).toLocaleDateString() : ''}</div>
                    </td>
                    <td className="py-3 px-3 max-w-xs">
                      <p className="line-clamp-2 text-slate-800 dark:text-slate-200 leading-relaxed font-normal">
                        {post.content}
                      </p>
                      {post.tags && post.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {post.tags.map((t) => (
                            <span key={t} className="text-[10px] text-indigo-600 dark:text-indigo-400">
                              #{t}
                            </span>
                          ))}
                        </div>
                      )}
                      {post.images && post.images.length > 0 && (
                        <span className="text-[10px] text-slate-400 block mt-0.5">📷 이미지 {post.images.length}장 포함</span>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-medium text-[10px]">
                        {post.visibility === 'public' ? '전체 공개' : '팔로워 전용'}
                      </span>
                      <div className="text-[10px] text-slate-400 mt-1">
                        범위: {post.regionalScope || 'national'}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="text-slate-700 dark:text-slate-300">
                        ❤️ 좋아요 {post.likes?.length || 0}개
                      </div>
                      <div className="text-[10px] text-slate-400">
                        💬 댓글 {post.commentsCount || 0}개 · 🔖 북마크 {post.bookmarks?.length || 0}개
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      {post.isBlocked ? (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 px-2 py-0.5 rounded-full">
                          <ShieldAlert className="w-3 h-3" />
                          차단됨 ({post.blockReason || '사유 미지정'})
                        </span>
                      ) : (
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                          정상 게시 중
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setEditingRecord({ table: 'posts', record: { ...post } })}
                          className="p-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/80 dark:text-indigo-300 transition-colors cursor-pointer"
                          title="게시물 직접 수정"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setJsonViewerRecord(post)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                          title="JSON 보기"
                        >
                          <FileJson className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmTarget({ table: 'posts', id: post.id, name: `게시물 [${post.id}]` })}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 dark:text-rose-300 transition-colors cursor-pointer"
                          title="게시물 삭제"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* SECTION 3: COMMENTS TABLE VIEW                                        */}
      {/* ===================================================================== */}
      {activeTable === 'comments' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
          <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-indigo-500" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                댓글 데이터베이스 테이블 (총 {filteredComments.length}개)
              </h2>
            </div>
            <span className="text-xs text-slate-500">
              각 게시물에 달린 댓글 내용 및 작성자 정보를 직접 편집/삭제할 수 있습니다.
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-bold">
                  <th className="py-3 px-4">댓글 ID / 대상 게시물</th>
                  <th className="py-3 px-3">작성자</th>
                  <th className="py-3 px-3">댓글 내용</th>
                  <th className="py-3 px-3">좋아요 수</th>
                  <th className="py-3 px-3">작성 일시</th>
                  <th className="py-3 px-4 text-right">DB 직접 작업</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {filteredComments.map((comment) => (
                  <tr key={comment.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-mono text-indigo-600 dark:text-indigo-400 font-semibold">{comment.id}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">Post: {comment.postId}</div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <img
                          src={comment.authorAvatar}
                          alt={comment.authorName}
                          className="w-5 h-5 rounded-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="font-bold text-slate-900 dark:text-white">{comment.authorName}</div>
                          <div className="text-[10px] text-slate-400 font-mono">@{comment.authorHandle}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 max-w-sm">
                      <p className="text-slate-800 dark:text-slate-200 line-clamp-2">{comment.content}</p>
                    </td>
                    <td className="py-3 px-3 text-slate-700 dark:text-slate-300 font-medium">
                      ❤️ {comment.likes?.length || 0}
                    </td>
                    <td className="py-3 px-3 text-slate-500 text-[11px]">
                      {comment.createdAt ? new Date(comment.createdAt).toLocaleString() : ''}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setEditingRecord({ table: 'comments', record: { ...comment } })}
                          className="p-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/80 dark:text-indigo-300 transition-colors cursor-pointer"
                          title="댓글 직접 수정"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setJsonViewerRecord(comment)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                          title="JSON 보기"
                        >
                          <FileJson className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmTarget({ table: 'comments', id: comment.id, name: `댓글 [${comment.id}]` })}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 dark:text-rose-300 transition-colors cursor-pointer"
                          title="댓글 삭제"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* SECTION 4: STORIES TABLE VIEW                                         */}
      {/* ===================================================================== */}
      {activeTable === 'stories' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
          <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-500" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                스토리 데이터베이스 테이블 (총 {filteredStories.length}명)
              </h2>
            </div>
            <span className="text-xs text-slate-500">
              회원별 24시간 스토리 아이템 및 시청자 통계를 직접 조회/관리합니다.
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-bold">
                  <th className="py-3 px-4">사용자 ID / 이름</th>
                  <th className="py-3 px-3">스토리 아이템 개수</th>
                  <th className="py-3 px-3">아이템 요약</th>
                  <th className="py-3 px-4 text-right">DB 직접 작업</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {filteredStories.map((story) => (
                  <tr key={story.userId} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <img
                          src={story.userAvatar}
                          alt={story.userName}
                          className="w-6 h-6 rounded-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="font-bold text-slate-900 dark:text-white">{story.userName}</div>
                          <div className="text-[10px] text-slate-400 font-mono">User ID: {story.userId}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-semibold text-indigo-600 dark:text-indigo-400">
                      총 {story.items.length}개 스토리 등록됨
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        {story.items.map((item, idx) => (
                          <div key={`${item.id || 'story-item'}_${idx}`} className="relative group">
                            <img
                              src={item.mediaUrl}
                              alt="story thumb"
                              className="w-8 h-12 object-cover rounded-md border border-slate-200 dark:border-slate-700"
                              referrerPolicy="no-referrer"
                            />
                            <div className="text-[9px] text-slate-400 text-center mt-0.5">#{idx + 1}</div>
                          </div>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setEditingRecord({ table: 'stories', record: { ...story } })}
                          className="p-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/80 dark:text-indigo-300 transition-colors cursor-pointer"
                          title="스토리 레코드 수정"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setJsonViewerRecord(story)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                          title="JSON 보기"
                        >
                          <FileJson className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmTarget({ table: 'stories', id: story.userId, name: `${story.userName}님의 스토리` })}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 dark:text-rose-300 transition-colors cursor-pointer"
                          title="스토리 삭제"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* SECTION 5: MESSAGES TABLE VIEW                                        */}
      {/* ===================================================================== */}
      {activeTable === 'messages' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
          <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-indigo-500" />
              <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                다이렉트 메시지(DM) 데이터베이스 테이블 (총 {filteredMessages.length}건)
              </h2>
            </div>
            <span className="text-xs text-slate-500">
              발신자/수신자 ID, 메시지 텍스트, 읽음 상태를 직접 편집/삭제할 수 있습니다.
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-bold">
                  <th className="py-3 px-4">메시지 ID</th>
                  <th className="py-3 px-3">발신자 (Sender)</th>
                  <th className="py-3 px-3">수신자 (Receiver)</th>
                  <th className="py-3 px-3">메시지 내용</th>
                  <th className="py-3 px-3">전송 일시 / 상태</th>
                  <th className="py-3 px-4 text-right">DB 직접 작업</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {filteredMessages.map((msg) => (
                  <tr key={msg.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono text-indigo-600 dark:text-indigo-400 font-semibold">
                      {msg.id}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-800 dark:text-slate-200">
                      {msg.senderId}
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-800 dark:text-slate-200">
                      {msg.receiverId}
                    </td>
                    <td className="py-3 px-3 max-w-sm">
                      <p className="text-slate-800 dark:text-slate-200 line-clamp-2">{msg.content}</p>
                    </td>
                    <td className="py-3 px-3">
                      <div className="text-[11px] text-slate-500">{msg.createdAt ? new Date(msg.createdAt).toLocaleString() : ''}</div>
                      <span className={`text-[10px] font-bold ${msg.isRead ? 'text-indigo-600 dark:text-indigo-400' : 'text-amber-600'}`}>
                        {msg.isRead ? '✓ 읽음' : '● 안 읽음'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setEditingRecord({ table: 'messages', record: { ...msg } })}
                          className="p-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/80 dark:text-indigo-300 transition-colors cursor-pointer"
                          title="메시지 수정"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setJsonViewerRecord(msg)}
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                          title="JSON 보기"
                        >
                          <FileJson className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirmTarget({ table: 'messages', id: msg.id, name: `메시지 [${msg.id}]` })}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 dark:text-rose-300 transition-colors cursor-pointer"
                          title="메시지 삭제"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* SECTION: API KEYS & SECRETS TABLE VIEW                                */}
      {/* ===================================================================== */}
      {activeTable === 'api_keys' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs space-y-0">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-emerald-50/60 via-white to-white dark:from-emerald-950/20 dark:via-slate-900 dark:to-slate-900">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300 flex items-center justify-center shrink-0 shadow-xs">
                <Key className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                    API 키 & API SECRET 데이터베이스 테이블 (총 {filteredApiKeys.length}개)
                  </h2>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                    직접 수정 지원
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  CoolSMS, 알리고, Twilio, 네이버 SENS, Gemini AI의 <strong>API Key</strong>와 <strong>API SECRET</strong>을 데이터베이스에서 직접 수정할 수 있습니다.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  fetchSmsApiConfig();
                  showToast('API 키 데이터베이스를 새로고침했습니다.', 'info');
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>새로고침</span>
              </button>
              <button
                type="button"
                onClick={() => openCreateRecordModal('api_keys')}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>새 API Key 등록</span>
              </button>
            </div>
          </div>

          {/* Quick Notice Banner */}
          <div className="p-3 bg-emerald-50/70 dark:bg-emerald-950/20 border-b border-emerald-100 dark:border-emerald-900/40 text-xs flex items-center justify-between text-emerald-900 dark:text-emerald-200">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="text-[11px] leading-relaxed">
                각 행의 <strong>[수정]</strong> 버튼을 누르면 API Key와 API SECRET을 팝업창에서 직접 수정할 수 있으며, 수정 즉시 시스템 영구 설정(<code>sms_api_config.json</code>)에 동기화됩니다.
              </span>
            </div>
            <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 bg-white dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-emerald-200 dark:border-emerald-800 shrink-0">
              마스터 보안 적용
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-bold text-[11px]">
                  <th className="py-3 px-4">서비스 ID / 명칭</th>
                  <th className="py-3 px-4">API KEY (인증 키)</th>
                  <th className="py-3 px-4">API SECRET (비밀 키)</th>
                  <th className="py-3 px-4">발신번호 / 엔드포인트</th>
                  <th className="py-3 px-4 text-center">연동 상태</th>
                  <th className="py-3 px-4">최종 수정일시</th>
                  <th className="py-3 px-4 text-center">DB 작업</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredApiKeys.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      검색 조건에 맞는 API Key 레코드가 없습니다.
                    </td>
                  </tr>
                ) : (
                  filteredApiKeys.map((apiRec) => {
                    const isSecretVisible = !!showSecretMap[apiRec.id];

                    return (
                      <tr
                        key={apiRec.id}
                        className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                      >
                        {/* Service ID / Name */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 flex items-center justify-center shrink-0 font-bold">
                              <Key className="w-3.5 h-3.5" />
                            </div>
                            <div>
                              <span className="font-black text-slate-900 dark:text-white block">
                                {apiRec.serviceName}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                {apiRec.id} ({apiRec.provider})
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* API KEY */}
                        <td className="py-3.5 px-4">
                          <div className="space-y-1">
                            <span className="text-[10px] font-bold text-slate-400 block">
                              {apiRec.keyName}
                            </span>
                            <div className="flex items-center gap-1.5">
                              <code className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded-md font-mono text-[11px] text-slate-900 dark:text-slate-100 max-w-xs truncate border border-slate-200 dark:border-slate-700">
                                {apiRec.apiKey ? apiRec.apiKey : '(미설정)'}
                              </code>
                              <button
                                type="button"
                                onClick={() => {
                                  if (apiRec.apiKey) {
                                    navigator.clipboard.writeText(apiRec.apiKey);
                                    showToast(`${apiRec.keyName}가 클립보드에 복사되었습니다.`, 'info');
                                  }
                                }}
                                className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                                title="API Key 복사"
                              >
                                <Copy className="w-3 h-3" />
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setIsEditSecretVisible(false);
                                  setEditingRecord({ table: 'api_keys', record: { ...apiRec } });
                                }}
                                className="p-1 hover:bg-emerald-100 dark:hover:bg-emerald-950/80 rounded text-slate-400 hover:text-emerald-600 transition-colors cursor-pointer"
                                title="이 API Key 수정하기"
                              >
                                <Edit3 className="w-3 h-3 text-emerald-600" />
                              </button>
                            </div>
                          </div>
                        </td>

                        {/* API SECRET */}
                        <td className="py-3.5 px-4">
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="text-[10px] font-bold text-slate-400">
                                {apiRec.secretName}
                              </span>
                              <button
                                type="button"
                                onClick={() => toggleShowSecret(apiRec.id)}
                                className="text-[10px] text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 font-bold flex items-center gap-0.5 cursor-pointer"
                              >
                                {isSecretVisible ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                                <span>{isSecretVisible ? '숨기기' : '보기'}</span>
                              </button>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <code className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded-md font-mono text-[11px] text-rose-600 dark:text-rose-400 max-w-xs truncate border border-slate-200 dark:border-slate-700">
                                {isSecretVisible
                                  ? apiRec.apiSecret || '(미설정)'
                                  : apiRec.apiSecret
                                  ? '••••••••••••••••'
                                  : '(미설정)'}
                              </code>
                              <button
                                type="button"
                                onClick={() => {
                                  if (apiRec.apiSecret) {
                                    navigator.clipboard.writeText(apiRec.apiSecret);
                                    showToast(`${apiRec.secretName}가 클립보드에 복사되었습니다.`, 'info');
                                  }
                                }}
                                className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                                title="API Secret 복사"
                              >
                                <Copy className="w-3 h-3" />
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setIsEditSecretVisible(true);
                                  setEditingRecord({ table: 'api_keys', record: { ...apiRec } });
                                }}
                                className="p-1 hover:bg-rose-100 dark:hover:bg-rose-950/80 rounded text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                                title="이 API Secret 수정하기"
                              >
                                <Edit3 className="w-3 h-3 text-rose-600" />
                              </button>
                            </div>
                          </div>
                        </td>

                        {/* Sender Number / Endpoint */}
                        <td className="py-3.5 px-4 font-mono text-[11px] text-slate-600 dark:text-slate-300">
                          {apiRec.senderNumber ? (
                            <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                              {apiRec.senderNumber}
                            </span>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                          {apiRec.extraParam && (
                            <div className="text-[10px] text-slate-400 mt-0.5">ID: {apiRec.extraParam}</div>
                          )}
                        </td>

                        {/* Status */}
                        <td className="py-3.5 px-4 text-center">
                          <span
                            className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold ${
                              apiRec.status === 'active'
                                ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                                : apiRec.status === 'sandbox'
                                ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                                : 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
                            }`}
                          >
                            {apiRec.status === 'active' ? '● 라이브 활성' : apiRec.status === 'sandbox' ? '● 샌드박스' : '○ 미사용'}
                          </span>
                        </td>

                        {/* Updated At */}
                        <td className="py-3.5 px-4 text-[11px] text-slate-500 dark:text-slate-400">
                          <div>{new Date(apiRec.updatedAt).toLocaleDateString('ko-KR')}</div>
                          <div className="text-[10px] text-slate-400">
                            {apiRec.updatedBy || '시스템'}
                          </div>
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setIsEditSecretVisible(false);
                                setEditingRecord({ table: 'api_keys', record: { ...apiRec } });
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1 text-[11px]"
                              title="API 키 & SECRET 수정"
                            >
                              <Key className="w-3.5 h-3.5" />
                              <span>수정</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => setJsonViewerRecord(apiRec)}
                              className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 transition-colors cursor-pointer"
                              title="JSON 보기"
                            >
                              <FileJson className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() =>
                                setDeleteConfirmTarget({
                                  table: 'api_keys',
                                  id: apiRec.id,
                                  name: `${apiRec.serviceName} (${apiRec.id})`
                                })
                              }
                              className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:hover:bg-rose-900/80 dark:text-rose-300 transition-colors cursor-pointer"
                              title="레코드 삭제"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {/* ===================================================================== */}
      {activeTable === 'json_editor' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <Code className="w-5 h-5 text-indigo-500" />
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  원시 JSON 실시간 직접 편집기 (Live JSON Editor)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  데이터베이스 테이블의 원시 JSON을 직접 수정하고 즉시 검증 및 반영할 수 있습니다.
                </p>
              </div>
            </div>

            {/* Target Slice Selector */}
            <div className="flex items-center gap-1.5 flex-wrap">
              {(['users', 'posts', 'comments', 'stories', 'messages', 'api_keys', 'all'] as const).map((tbl) => (
                <button
                  key={tbl}
                  onClick={() => openRawJsonEditor(tbl)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    jsonEditorTable === tbl
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {tbl.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* JSON Error Display */}
          {jsonParseError && (
            <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs font-mono flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">JSON 문법 오류:</span> {jsonParseError}
              </div>
            </div>
          )}

          {/* JSON Textarea with Code Styling */}
          <div className="relative">
            <textarea
              value={rawJsonText}
              onChange={(e) => {
                setRawJsonText(e.target.value);
                setJsonParseError(null);
              }}
              rows={20}
              className="w-full p-4 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-950 text-emerald-400 font-mono text-xs leading-relaxed focus:outline-hidden focus:ring-2 focus:ring-indigo-500 select-text resize-y"
              spellCheck={false}
            />
          </div>

          {/* Editor Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrettifyRawJson}
                className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition-all cursor-pointer"
              >
                서식 자동 정렬 (Beautify)
              </button>
              <button
                onClick={handleCopyRawJson}
                className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
              >
                {copiedFullJson ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedFullJson ? '복사 완료!' : 'JSON 복사'}</span>
              </button>
            </div>

            <button
              onClick={handleApplyRawJson}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-2 shadow-md shadow-indigo-600/20"
            >
              <Save className="w-4 h-4" />
              <span>수정된 JSON을 데이터베이스에 즉시 적용</span>
            </button>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL 1: EDIT RECORD MODAL (레코드 직접 수정)                         */}
      {/* ===================================================================== */}
      {editingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
              <div className="flex items-center gap-2">
                {editingRecord.table === 'api_keys' ? (
                  <Key className="w-5 h-5 text-emerald-500" />
                ) : (
                  <Edit3 className="w-5 h-5 text-indigo-500" />
                )}
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {editingRecord.table === 'api_keys'
                    ? `🔑 [API KEY & SECRET] ${editingRecord.record.serviceName || 'API'} 설정 직접 수정`
                    : `[${editingRecord.table.toUpperCase()}] 레코드 직접 수정 (ID: ${editingRecord.record.id})`}
                </h3>
              </div>
              <button
                onClick={() => setEditingRecord(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Form */}
            <div className="p-6 overflow-y-auto space-y-4 flex-1">
              {/* Form fields dynamically tailored to record type */}
              {editingRecord.table === 'users' && (
                <div className="space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">이름</label>
                      <input
                        type="text"
                        value={editingRecord.record.name || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, name: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-medium"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">아이디(핸들)</label>
                      <input
                        type="text"
                        value={editingRecord.record.handle || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, handle: e.target.value.replace(/^@/, '') }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">이메일</label>
                      <input
                        type="email"
                        value={editingRecord.record.email || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, email: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">비밀번호</label>
                      <input
                        type="text"
                        value={editingRecord.record.password || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, password: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">휴대폰 번호</label>
                      <input
                        type="text"
                        value={editingRecord.record.phoneNumber || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, phoneNumber: e.target.value }
                          })
                        }
                        placeholder="01012345678"
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">직함/역할</label>
                      <input
                        type="text"
                        value={editingRecord.record.role || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, role: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">지역 / 주소</label>
                    <input
                      type="text"
                      value={editingRecord.record.location || ''}
                      onChange={(e) =>
                        setEditingRecord({
                          ...editingRecord,
                          record: { ...editingRecord.record, location: e.target.value }
                        })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">자기소개 (Bio)</label>
                    <textarea
                      value={editingRecord.record.bio || ''}
                      onChange={(e) =>
                        setEditingRecord({
                          ...editingRecord,
                          record: { ...editingRecord.record, bio: e.target.value }
                        })
                      }
                      rows={2}
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">프로필 아바타 이미지 URL</label>
                    <input
                      type="text"
                      value={editingRecord.record.avatar || ''}
                      onChange={(e) =>
                        setEditingRecord({
                          ...editingRecord,
                          record: { ...editingRecord.record, avatar: e.target.value }
                        })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-[11px]"
                    />
                  </div>

                  {/* Boolean Switches */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!editingRecord.record.phoneVerified}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, phoneVerified: e.target.checked }
                          })
                        }
                        className="rounded text-indigo-600"
                      />
                      <span className="font-bold">휴대폰 인증됨</span>
                    </label>

                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!editingRecord.record.isVerified}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, isVerified: e.target.checked }
                          })
                        }
                        className="rounded text-indigo-600"
                      />
                      <span className="font-bold">공식 인증 뱃지</span>
                    </label>

                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!editingRecord.record.isAdmin}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, isAdmin: e.target.checked }
                          })
                        }
                        className="rounded text-indigo-600"
                      />
                      <span className="font-bold">관리자 권한</span>
                    </label>

                    <label className="flex items-center gap-2 p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!editingRecord.record.isBanned}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: {
                              ...editingRecord.record,
                              isBanned: e.target.checked,
                              banReason: e.target.checked ? (editingRecord.record.banReason || '운영 정책 위반') : undefined
                            }
                          })
                        }
                        className="rounded text-rose-600"
                      />
                      <span className="font-bold text-rose-700 dark:text-rose-300">이용 정지(차단)</span>
                    </label>
                  </div>

                  {editingRecord.record.isBanned && (
                    <div>
                      <label className="block font-bold text-rose-700 dark:text-rose-300 mb-1">차단 사유</label>
                      <input
                        type="text"
                        value={editingRecord.record.banReason || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, banReason: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50/50 dark:bg-rose-950/20 text-rose-900 dark:text-rose-200"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Editing Posts */}
              {editingRecord.table === 'posts' && (
                <div className="space-y-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">게시물 본문 내용</label>
                    <textarea
                      value={editingRecord.record.content || ''}
                      onChange={(e) =>
                        setEditingRecord({
                          ...editingRecord,
                          record: { ...editingRecord.record, content: e.target.value }
                        })
                      }
                      rows={5}
                      className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white leading-relaxed"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">공개 범위</label>
                      <select
                        value={editingRecord.record.visibility || 'public'}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, visibility: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      >
                        <option value="public">전체 공개 (public)</option>
                        <option value="followers">팔로워 전용 (followers)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">지역 범위 (Regional Scope)</label>
                      <select
                        value={editingRecord.record.regionalScope || 'national'}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, regionalScope: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      >
                        <option value="neighborhood">내 동네 (동)</option>
                        <option value="city">내 지역 (구/시)</option>
                        <option value="national">전국 피드 (기본)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">태그 (쉼표로 구분)</label>
                    <input
                      type="text"
                      value={(editingRecord.record.tags || []).join(', ')}
                      onChange={(e) =>
                        setEditingRecord({
                          ...editingRecord,
                          record: {
                            ...editingRecord.record,
                            tags: e.target.value.split(',').map((t) => t.trim().replace(/^#/, '')).filter(Boolean)
                          }
                        })
                      }
                      placeholder="일상, 맛집, 여행"
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>

                  {/* Block Switch */}
                  <div className="pt-2">
                    <label className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!!editingRecord.record.isBlocked}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: {
                              ...editingRecord.record,
                              isBlocked: e.target.checked,
                              blockReason: e.target.checked ? (editingRecord.record.blockReason || '운영 정책 위반') : undefined
                            }
                          })
                        }
                        className="rounded text-rose-600"
                      />
                      <span className="font-bold text-rose-700 dark:text-rose-300">게시물 차단(블라인드) 설정</span>
                    </label>
                  </div>

                  {editingRecord.record.isBlocked && (
                    <div>
                      <label className="block font-bold text-rose-700 dark:text-rose-300 mb-1">차단 사유</label>
                      <input
                        type="text"
                        value={editingRecord.record.blockReason || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, blockReason: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50/50 dark:bg-rose-950/20 text-rose-900 dark:text-rose-200"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Editing Comments */}
              {editingRecord.table === 'comments' && (
                <div className="space-y-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">댓글 내용</label>
                    <textarea
                      value={editingRecord.record.content || ''}
                      onChange={(e) =>
                        setEditingRecord({
                          ...editingRecord,
                          record: { ...editingRecord.record, content: e.target.value }
                        })
                      }
                      rows={4}
                      className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">대상 게시물 ID (Post ID)</label>
                    <input
                      type="text"
                      value={editingRecord.record.postId || ''}
                      onChange={(e) =>
                        setEditingRecord({
                          ...editingRecord,
                          record: { ...editingRecord.record, postId: e.target.value }
                        })
                      }
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                    />
                  </div>
                </div>
              )}

              {/* Editing Messages */}
              {editingRecord.table === 'messages' && (
                <div className="space-y-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">메시지 내용</label>
                    <textarea
                      value={editingRecord.record.content || ''}
                      onChange={(e) =>
                        setEditingRecord({
                          ...editingRecord,
                          record: { ...editingRecord.record, content: e.target.value }
                        })
                      }
                      rows={3}
                      className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">발신자 ID (Sender)</label>
                      <input
                        type="text"
                        value={editingRecord.record.senderId || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, senderId: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">수신자 ID (Receiver)</label>
                      <input
                        type="text"
                        value={editingRecord.record.receiverId || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, receiverId: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                      />
                    </div>
                  </div>
                  <label className="flex items-center gap-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={!!editingRecord.record.isRead}
                      onChange={(e) =>
                        setEditingRecord({
                          ...editingRecord,
                          record: { ...editingRecord.record, isRead: e.target.checked }
                        })
                      }
                      className="rounded text-indigo-600"
                    />
                    <span className="font-bold">읽음 상태 처리</span>
                  </label>
                </div>
              )}

              {/* Editing Stories */}
              {editingRecord.table === 'stories' && (
                <div className="space-y-3 text-xs">
                  <p className="text-slate-500">
                    스토리 복합 객체는 전체 구조 유지를 위해 아래 <strong>원시 JSON</strong>으로 직접 수정할 수 있습니다:
                  </p>
                  <textarea
                    value={JSON.stringify(editingRecord.record, null, 2)}
                    onChange={(e) => {
                      try {
                        const parsed = JSON.parse(e.target.value);
                        setEditingRecord({ ...editingRecord, record: parsed });
                      } catch (err) {
                        // ignore intermediate invalid json typing
                      }
                    }}
                    rows={12}
                    className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-950 text-emerald-400 font-mono text-xs leading-relaxed"
                  />
                </div>
              )}

              {/* Editing API Keys & API Secret */}
              {editingRecord.table === 'api_keys' && (
                <div className="space-y-4 text-xs">
                  {/* Service Info Banner */}
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/20 border border-emerald-200 dark:border-emerald-800/60 flex items-start gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                      <Key className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-black text-slate-900 dark:text-white text-sm">
                          {editingRecord.record.serviceName || 'API 서비스'}
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300">
                          {editingRecord.record.provider}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          ID: {editingRecord.record.id}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                        여기서 <strong>API KEY</strong>와 <strong>API SECRET</strong>을 수정하고 하단의 저장 버튼을 누르면, 데이터베이스 레코드뿐만 아니라 서버의 영구 설정 파일(<code>data/sms_api_config.json</code>)에 즉시 저장 및 실시간 동기화됩니다.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                        서비스 명칭
                      </label>
                      <input
                        type="text"
                        value={editingRecord.record.serviceName || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, serviceName: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                        placeholder="예: CoolSMS 문자 연동"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                        제공사 (Provider)
                      </label>
                      <select
                        value={editingRecord.record.provider || 'CoolSMS'}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, provider: e.target.value }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                      >
                        <option value="CoolSMS">CoolSMS (Solapi v4)</option>
                        <option value="Aligo">알리고 (Aligo SMS)</option>
                        <option value="Twilio">Twilio SMS</option>
                        <option value="NaverSENS">네이버 클라우드 SENS</option>
                        <option value="Custom">사용자 지정 REST API (Custom)</option>
                        <option value="GeminiAI">Google Gemini AI</option>
                      </select>
                    </div>
                  </div>

                  {/* API KEY Input Field */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="block font-black text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                        <Key className="w-4 h-4 text-emerald-600" />
                        <span>API 키 (API KEY / Account SID / Access Key)</span>
                      </label>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {editingRecord.record.keyName || 'API_KEY'}
                      </span>
                    </div>
                    <div className="relative">
                      <input
                        type="text"
                        value={editingRecord.record.apiKey || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, apiKey: e.target.value.trim() }
                          })
                        }
                        placeholder="API Key 값을 입력하세요 (예: NCSIXXXXXXXXX, ACxxxxxxxx...)"
                        className="w-full p-2.5 pr-16 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                      />
                      <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                        {editingRecord.record.apiKey && (
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(editingRecord.record.apiKey);
                              showToast('API 키가 클립보드에 복사되었습니다.', 'info');
                            }}
                            className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                            title="복사"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      인증 서버 통신 시 사용되는 고유 발급 API 키 식별자입니다.
                    </p>
                  </div>

                  {/* API SECRET Input Field */}
                  <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="block font-black text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                        <Lock className="w-4 h-4 text-rose-500" />
                        <span>API 비밀키 (API SECRET / Auth Token / Secret Key)</span>
                      </label>
                      <button
                        type="button"
                        onClick={toggleEditSecretVisible}
                        className="text-[11px] text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 font-bold flex items-center gap-1 cursor-pointer"
                      >
                        {isEditSecretVisible ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        <span>{isEditSecretVisible ? '비밀키 가리기' : '비밀키 보기'}</span>
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type={isEditSecretVisible ? 'text' : 'password'}
                        value={editingRecord.record.apiSecret || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, apiSecret: e.target.value.trim() }
                          })
                        }
                        placeholder="API SECRET 비밀키 값을 입력하세요"
                        className="w-full p-2.5 pr-16 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 font-mono text-xs focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                      />
                      <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                        {editingRecord.record.apiSecret && (
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(editingRecord.record.apiSecret);
                              showToast('API SECRET이 클립보드에 복사되었습니다.', 'info');
                            }}
                            className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                            title="복사"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      외부 발송 게이트웨이 인증을 위한 비밀 서명 또는 인증 토큰입니다. 외부에 노출되지 않도록 주의하세요.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                        발신번호 (Sender Number)
                      </label>
                      <input
                        type="text"
                        value={editingRecord.record.senderNumber || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, senderNumber: e.target.value.trim() }
                          })
                        }
                        placeholder="예: 02-1588-9999, 01012345678"
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-xs text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                        추가 식별 파라미터 (User ID / Service ID)
                      </label>
                      <input
                        type="text"
                        value={editingRecord.record.extraParam || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, extraParam: e.target.value.trim() }
                          })
                        }
                        placeholder="예: aligo_id 또는 sens service id"
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono text-xs text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                        연동 활성 상태
                      </label>
                      <select
                        value={editingRecord.record.status || 'active'}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, status: e.target.value as any }
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold text-xs"
                      >
                        <option value="active">라이브 활성 (Active)</option>
                        <option value="sandbox">테스트 모드 / 샌드박스 (Sandbox)</option>
                        <option value="inactive">비활성 (Inactive)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                        설명 / 관리 메모
                      </label>
                      <input
                        type="text"
                        value={editingRecord.record.description || ''}
                        onChange={(e) =>
                          setEditingRecord({
                            ...editingRecord,
                            record: { ...editingRecord.record, description: e.target.value }
                          })
                        }
                        placeholder="연동 목적 및 키 관련 메모"
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setEditingRecord(null)}
                className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleSaveEditedRecord}
                className={`px-5 py-2.5 rounded-xl text-white text-xs font-bold shadow-md flex items-center gap-1.5 cursor-pointer ${
                  editingRecord.table === 'api_keys'
                    ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-600/20'
                    : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-600/20'
                }`}
              >
                <Save className="w-4 h-4" />
                <span>
                  {editingRecord.table === 'api_keys'
                    ? 'API 키·SECRET 저장 및 서버 동기화'
                    : '수정 내용 DB 저장'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL 2: CREATE RECORD MODAL (새 레코드 직접 추가)                   */}
      {/* ===================================================================== */}
      {isCreatingNewRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-indigo-500" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  [{isCreatingNewRecord.toUpperCase()}] 새 레코드 직접 추가
                </h3>
              </div>
              <button
                onClick={() => setIsCreatingNewRecord(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
              {isCreatingNewRecord === 'users' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold mb-1">이름</label>
                      <input
                        type="text"
                        value={newRecordData.name || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, name: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-bold mb-1">아이디(핸들)</label>
                      <input
                        type="text"
                        value={newRecordData.handle || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, handle: e.target.value.replace(/^@/, '') })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold mb-1">이메일</label>
                      <input
                        type="email"
                        value={newRecordData.email || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, email: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block font-bold mb-1">비밀번호</label>
                      <input
                        type="text"
                        value={newRecordData.password || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, password: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-bold mb-1">휴대폰 번호</label>
                    <input
                      type="text"
                      value={newRecordData.phoneNumber || ''}
                      onChange={(e) => setNewRecordData({ ...newRecordData, phoneNumber: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                    />
                  </div>
                </div>
              )}

              {isCreatingNewRecord === 'posts' && (
                <div className="space-y-3">
                  <div>
                    <label className="block font-bold mb-1">게시물 본문 내용</label>
                    <textarea
                      value={newRecordData.content || ''}
                      onChange={(e) => setNewRecordData({ ...newRecordData, content: e.target.value })}
                      rows={5}
                      className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                </div>
              )}

              {isCreatingNewRecord === 'comments' && (
                <div className="space-y-3">
                  <div>
                    <label className="block font-bold mb-1">대상 게시물 ID</label>
                    <input
                      type="text"
                      value={newRecordData.postId || ''}
                      onChange={(e) => setNewRecordData({ ...newRecordData, postId: e.target.value })}
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-bold mb-1">댓글 내용</label>
                    <textarea
                      value={newRecordData.content || ''}
                      onChange={(e) => setNewRecordData({ ...newRecordData, content: e.target.value })}
                      rows={4}
                      className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              )}

              {isCreatingNewRecord === 'messages' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold mb-1">발신자 ID</label>
                      <input
                        type="text"
                        value={newRecordData.senderId || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, senderId: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block font-bold mb-1">수신자 ID</label>
                      <input
                        type="text"
                        value={newRecordData.receiverId || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, receiverId: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-bold mb-1">메시지 본문</label>
                    <textarea
                      value={newRecordData.content || ''}
                      onChange={(e) => setNewRecordData({ ...newRecordData, content: e.target.value })}
                      rows={3}
                      className="w-full p-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                    />
                  </div>
                </div>
              )}

              {isCreatingNewRecord === 'api_keys' && (
                <div className="space-y-4">
                  <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-center gap-2.5">
                    <Key className="w-5 h-5 text-emerald-600 shrink-0" />
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">
                        신규 API Key & SECRET 연동 등록
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        CoolSMS, 알리고, Twilio, 네이버 SENS 등 새 API 자격증명을 데이터베이스에 등록합니다.
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold mb-1">서비스 명칭</label>
                      <input
                        type="text"
                        value={newRecordData.serviceName || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, serviceName: e.target.value })}
                        placeholder="예: CoolSMS v4 실서버 연동"
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block font-bold mb-1">제공사 (Provider)</label>
                      <select
                        value={newRecordData.provider || 'CoolSMS'}
                        onChange={(e) => setNewRecordData({ ...newRecordData, provider: e.target.value })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      >
                        <option value="CoolSMS">CoolSMS (Solapi v4)</option>
                        <option value="Aligo">알리고 (Aligo)</option>
                        <option value="Twilio">Twilio</option>
                        <option value="NaverSENS">네이버 클라우드 SENS</option>
                        <option value="Custom">Custom REST API</option>
                        <option value="GeminiAI">Google Gemini AI</option>
                      </select>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
                    <label className="block font-black text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Key className="w-4 h-4 text-emerald-600" />
                      <span>API 키 (API KEY)</span>
                    </label>
                    <input
                      type="text"
                      value={newRecordData.apiKey || ''}
                      onChange={(e) => setNewRecordData({ ...newRecordData, apiKey: e.target.value.trim() })}
                      placeholder="API KEY 값을 입력하세요"
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 font-mono text-xs text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-2">
                    <label className="block font-black text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Lock className="w-4 h-4 text-rose-500" />
                      <span>API SECRET (비밀 키)</span>
                    </label>
                    <input
                      type="text"
                      value={newRecordData.apiSecret || ''}
                      onChange={(e) => setNewRecordData({ ...newRecordData, apiSecret: e.target.value.trim() })}
                      placeholder="API SECRET 비밀 키 값을 입력하세요"
                      className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 font-mono text-xs text-rose-600 dark:text-rose-400"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold mb-1">발신번호</label>
                      <input
                        type="text"
                        value={newRecordData.senderNumber || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, senderNumber: e.target.value.trim() })}
                        placeholder="예: 02-1588-9999"
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-slate-900 dark:text-white"
                      />
                    </div>
                    <div>
                      <label className="block font-bold mb-1">추가 파라미터 (User ID 등)</label>
                      <input
                        type="text"
                        value={newRecordData.extraParam || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, extraParam: e.target.value.trim() })}
                        placeholder="예: aligo_id 또는 service_id"
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold mb-1">연동 상태</label>
                      <select
                        value={newRecordData.status || 'active'}
                        onChange={(e) => setNewRecordData({ ...newRecordData, status: e.target.value as any })}
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      >
                        <option value="active">라이브 활성 (Active)</option>
                        <option value="sandbox">테스트 모드 / 샌드박스 (Sandbox)</option>
                        <option value="inactive">비활성 (Inactive)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold mb-1">설명 / 관리 메모</label>
                      <input
                        type="text"
                        value={newRecordData.description || ''}
                        onChange={(e) => setNewRecordData({ ...newRecordData, description: e.target.value })}
                        placeholder="연동 목적 및 키 관련 메모"
                        className="w-full p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsCreatingNewRecord(null)}
                className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleSaveNewRecord}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>데이터베이스에 삽입</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL 3: JSON INSPECTOR MODAL                                         */}
      {/* ===================================================================== */}
      {jsonViewerRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-850">
              <div className="flex items-center gap-2">
                <FileJson className="w-5 h-5 text-indigo-500" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  레코드 원시 JSON 뷰어 (ID: {jsonViewerRecord.id || jsonViewerRecord.userId})
                </h3>
              </div>
              <button
                onClick={() => setJsonViewerRecord(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1 bg-slate-950">
              <pre className="text-emerald-400 font-mono text-xs leading-relaxed select-text">
                {JSON.stringify(jsonViewerRecord, null, 2)}
              </pre>
            </div>

            <div className="px-5 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-between">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(JSON.stringify(jsonViewerRecord, null, 2));
                  setCopiedRecordId(jsonViewerRecord.id || 'record');
                  setTimeout(() => setCopiedRecordId(null), 1800);
                  showToast('레코드 JSON이 복사되었습니다.', 'info');
                }}
                className="px-3.5 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                {copiedRecordId ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedRecordId ? '복사됨!' : '클립보드 복사'}</span>
              </button>
              <button
                onClick={() => setJsonViewerRecord(null)}
                className="px-4 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 cursor-pointer"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL 4: DELETE CONFIRMATION MODAL                                    */}
      {/* ===================================================================== */}
      {deleteConfirmTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">데이터베이스 레코드 삭제</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                정말로 <strong>{deleteConfirmTarget.name}</strong> 레코드를 데이터베이스에서 완전히 삭제하시겠습니까? 이 작업은 즉시 반영됩니다.
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmTarget(null)}
                className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex-1"
              >
                취소
              </button>
              <button
                onClick={() => {
                  deleteDatabaseRecord(deleteConfirmTarget.table, deleteConfirmTarget.id);
                  setDeleteConfirmTarget(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer flex-1 shadow-md shadow-rose-600/20"
              >
                영구 삭제
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODAL 5: FULL DATABASE RESET CONFIRMATION                             */}
      {/* ===================================================================== */}
      {showResetDbConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-600 flex items-center justify-center mx-auto">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">데이터베이스 초기화 (Reset)</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                모든 회원, 게시물, 댓글, 스토리, 메시지를 최초 원본 데모 데이터 상태로 되돌립니다. 계속하시겠습니까?
              </p>
            </div>
            <div className="flex items-center justify-center gap-2 pt-2">
              <button
                onClick={() => setShowResetDbConfirm(false)}
                className="px-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer flex-1"
              >
                취소
              </button>
              <button
                onClick={() => {
                  resetFullDatabaseToInitial();
                  setShowResetDbConfirm(false);
                }}
                className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer flex-1 shadow-md shadow-amber-600/20"
              >
                초기화 실행
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
