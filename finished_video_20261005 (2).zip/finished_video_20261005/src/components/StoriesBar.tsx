import React from 'react';
import { useSocial } from '../context/SocialContext';
import { Plus, Bookmark } from 'lucide-react';
import { UserStory } from '../types';

interface StoriesBarProps {
  onOpenCreateStory: () => void;
}

export const StoriesBar: React.FC<StoriesBarProps> = ({ onOpenCreateStory }) => {
  const { currentUser, stories, openStoryViewer, storyDrafts } = useSocial();

  const myStory = stories.find((s) => s.userId === currentUser.id);
  const otherStories = stories.filter((s) => s.userId !== currentUser.id);

  return (
    <div className="flex items-center gap-4 overflow-x-auto pb-2 pt-1 scrollbar-none select-none">
      {/* Current User Story Item / Add Story */}
      <div className="flex flex-col items-center gap-1.5 flex-shrink-0 cursor-pointer group">
        <div className="relative">
          {myStory && myStory.items.length > 0 ? (
            <div
              onClick={() => openStoryViewer(myStory)}
              className="p-0.5 rounded-full border-2 border-blue-500 hover:scale-105 transition-transform"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="h-14 w-14 rounded-full object-cover border-2 border-white dark:border-slate-900"
                referrerPolicy="no-referrer"
              />
            </div>
          ) : (
            <div
              onClick={onOpenCreateStory}
              className="h-15 w-15 rounded-full border-2 border-dashed border-slate-300 dark:border-slate-700 flex items-center justify-center p-0.5 group-hover:border-blue-500 transition-colors"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="h-13 w-13 rounded-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          )}

          {/* Draft count badge on top left */}
          {storyDrafts.length > 0 && (
            <button
              type="button"
              id="stories-bar-drafts-badge"
              onClick={(e) => {
                e.stopPropagation();
                onOpenCreateStory();
              }}
              title={`저장된 초안 ${storyDrafts.length}개 보러가기`}
              className="absolute -top-1 -left-1 flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-amber-500 text-white text-[9px] font-bold ring-2 ring-white dark:ring-slate-900 shadow-xs hover:scale-110 transition-transform"
            >
              <Bookmark className="w-2.5 h-2.5 fill-current" />
              <span>{storyDrafts.length}</span>
            </button>
          )}

          {/* Plus icon to add story */}
          <button
            id="add-story-btn"
            onClick={(e) => {
              e.stopPropagation();
              onOpenCreateStory();
            }}
            title="새 스토리 추가"
            className="absolute bottom-0 right-0 flex h-5 w-5 items-center justify-center rounded-full bg-blue-600 text-white ring-2 ring-white dark:ring-slate-900 group-hover:scale-110 transition-transform"
          >
            <Plus className="h-3.5 w-3.5 stroke-[3]" />
          </button>
        </div>
        <span className="text-[11px] font-medium text-slate-600 dark:text-slate-300 max-w-[64px] truncate text-center">
          내 스토리
        </span>
      </div>

      {/* Friends Stories */}
      {otherStories.map((userStory) => {
        return (
          <div
            key={userStory.userId}
            id={`story-item-${userStory.userId}`}
            onClick={() => openStoryViewer(userStory)}
            className="flex flex-col items-center gap-1.5 flex-shrink-0 cursor-pointer group"
          >
            <div
              className={`p-0.5 rounded-full transition-transform group-hover:scale-105 ${
                userStory.hasUnseen
                  ? 'border-2 border-blue-500 shadow-sm'
                  : 'border-2 border-slate-300 dark:border-slate-700'
              }`}
            >
              <img
                src={userStory.userAvatar}
                alt={userStory.userName}
                className="h-14 w-14 rounded-full object-cover border-2 border-white dark:border-slate-900"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="text-[11px] font-medium text-slate-700 dark:text-slate-300 max-w-[64px] truncate text-center">
              {userStory.userName}
            </span>
          </div>
        );
      })}
    </div>
  );
};
