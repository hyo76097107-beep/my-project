import React, { useState, useRef } from 'react';
import {
  X,
  Printer,
  FileText,
  CheckCircle,
  Heart,
  MessageCircle,
  Repeat2,
  Bookmark,
  MapPin,
  BarChart2,
  Download,
  Check,
  Sparkles,
  Settings2,
  Eye,
  Calendar,
  Layers
} from 'lucide-react';
import { Post, Comment } from '../types';
import { useSocial } from '../context/SocialContext';
import { formatRelativeTime } from '../utils/formatters';

interface PrintPostModalProps {
  post: Post;
  isOpen: boolean;
  onClose: () => void;
}

export const PrintPostModal: React.FC<PrintPostModalProps> = ({
  post,
  isOpen,
  onClose
}) => {
  const { comments, showToast } = useSocial();
  const printPreviewRef = useRef<HTMLDivElement | null>(null);

  // Print customization options
  const [includeComments, setIncludeComments] = useState<boolean>(true);
  const [includeStats, setIncludeStats] = useState<boolean>(true);
  const [includeMedia, setIncludeMedia] = useState<boolean>(true);
  const [includeHeaderFooter, setIncludeHeaderFooter] = useState<boolean>(true);
  const [isPrinting, setIsPrinting] = useState<boolean>(false);
  const [copiedSummary, setCopiedSummary] = useState<boolean>(false);

  if (!isOpen) return null;

  const postComments = comments.filter((c) => c.postId === post.id);

  // Format exact date for printable document
  const postDate = new Date(post.createdAt);
  const formattedExactDate = postDate.toLocaleString('ko-KR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });

  const printTimeStr = new Date().toLocaleString('ko-KR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  // Handle direct clean printing via isolated iframe
  const handlePrint = () => {
    setIsPrinting(true);

    try {
      // Create a hidden iframe specifically for printing to avoid printing outer UI/sidebars
      const existingIframe = document.getElementById('post-print-iframe');
      if (existingIframe) {
        existingIframe.remove();
      }

      const iframe = document.createElement('iframe');
      iframe.id = 'post-print-iframe';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      document.body.appendChild(iframe);

      const iframeDoc = iframe.contentWindow?.document || iframe.contentDocument;
      if (!iframeDoc) {
        window.print();
        setIsPrinting(false);
        return;
      }

      // Generate clean standalone print HTML
      const printHtml = `
        <!DOCTYPE html>
        <html lang="ko">
        <head>
          <meta charset="utf-8">
          <title>${post.authorName}님의 게시물 - PDF 인쇄</title>
          <style>
            @page {
              size: A4 portrait;
              margin: 18mm 15mm 18mm 15mm;
            }
            * {
              box-sizing: border-box;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Apple SD Gothic Neo", "Malgun Gothic", "Pretendard", "Segoe UI", Roboto, sans-serif;
              color: #1e293b;
              background: #ffffff;
              line-height: 1.6;
              margin: 0;
              padding: 0;
              font-size: 14px;
            }
            .document-container {
              max-width: 100%;
              margin: 0 auto;
            }
            .print-header {
              display: flex;
              justify-content: space-between;
              align-items: center;
              padding-bottom: 12px;
              margin-bottom: 16px;
              border-bottom: 2px solid #e2e8f0;
            }
            .app-brand {
              font-size: 16px;
              font-weight: 800;
              color: #2563eb;
              letter-spacing: -0.5px;
            }
            .app-sub {
              font-size: 11px;
              color: #64748b;
            }
            .print-meta-right {
              text-align: right;
              font-size: 11px;
              color: #64748b;
            }
            .post-card {
              border: 1px solid #cbd5e1;
              border-radius: 12px;
              padding: 20px;
              margin-bottom: 20px;
              background-color: #ffffff;
            }
            .author-section {
              display: flex;
              align-items: center;
              gap: 12px;
              margin-bottom: 16px;
            }
            .avatar {
              width: 46px;
              height: 46px;
              border-radius: 50%;
              object-fit: cover;
              border: 1px solid #e2e8f0;
            }
            .author-name {
              font-size: 15px;
              font-weight: 700;
              color: #0f172a;
            }
            .author-handle {
              font-size: 12px;
              color: #64748b;
              margin-left: 4px;
            }
            .post-time {
              font-size: 12px;
              color: #64748b;
              margin-top: 2px;
            }
            .post-badge {
              display: inline-block;
              font-size: 11px;
              font-weight: 600;
              background: #f1f5f9;
              color: #475569;
              padding: 2px 8px;
              border-radius: 6px;
              margin-left: 6px;
            }
            .post-body {
              font-size: 15px;
              color: #1e293b;
              white-space: pre-wrap;
              line-height: 1.7;
              margin-bottom: 16px;
              word-break: break-word;
            }
            .hashtag {
              color: #2563eb;
              font-weight: 600;
            }
            .media-grid {
              display: grid;
              grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
              gap: 10px;
              margin-bottom: 16px;
            }
            .media-img {
              width: 100%;
              max-height: 320px;
              object-fit: cover;
              border-radius: 8px;
              border: 1px solid #e2e8f0;
            }
            .poll-box {
              background-color: #f8fafc;
              border: 1px solid #e2e8f0;
              border-radius: 8px;
              padding: 12px 16px;
              margin-bottom: 16px;
            }
            .poll-question {
              font-weight: 700;
              font-size: 13px;
              color: #0f172a;
              margin-bottom: 8px;
            }
            .poll-option {
              display: flex;
              justify-content: space-between;
              padding: 6px 0;
              font-size: 12px;
              border-bottom: 1px dashed #e2e8f0;
            }
            .stats-bar {
              display: flex;
              gap: 20px;
              padding-top: 14px;
              border-top: 1px solid #e2e8f0;
              font-size: 12px;
              font-weight: 600;
              color: #475569;
            }
            .stats-item {
              display: flex;
              align-items: center;
              gap: 4px;
            }
            .comments-section {
              margin-top: 24px;
              page-break-inside: avoid;
            }
            .comments-title {
              font-size: 14px;
              font-weight: 700;
              color: #0f172a;
              margin-bottom: 12px;
              padding-bottom: 6px;
              border-bottom: 1px solid #e2e8f0;
            }
            .comment-item {
              padding: 10px 0;
              border-bottom: 1px solid #f1f5f9;
              font-size: 12.5px;
            }
            .comment-author {
              font-weight: 700;
              color: #0f172a;
            }
            .comment-handle {
              color: #64748b;
              font-size: 11.5px;
              margin-left: 4px;
            }
            .comment-time {
              color: #94a3b8;
              font-size: 11px;
              float: right;
            }
            .comment-text {
              margin-top: 4px;
              color: #334155;
            }
            .print-footer {
              margin-top: 30px;
              padding-top: 12px;
              border-top: 1px solid #e2e8f0;
              display: flex;
              justify-content: space-between;
              font-size: 10.5px;
              color: #94a3b8;
            }
          </style>
        </head>
        <body>
          <div class="document-container">
            ${
              includeHeaderFooter
                ? `
              <div class="print-header">
                <div>
                  <div class="app-brand">소셜 네트워크 (Social Feed Archive)</div>
                  <div class="app-sub">게시물 원본 아카이브 문서</div>
                </div>
                <div class="print-meta-right">
                  <div>인쇄 일시: ${printTimeStr}</div>
                  <div>문서 ID: POST-${post.id.toUpperCase()}</div>
                </div>
              </div>
            `
                : ''
            }

            <div class="post-card">
              <div class="author-section">
                <img class="avatar" src="${post.authorAvatar}" alt="${post.authorName}" />
                <div>
                  <div>
                    <span class="author-name">${post.authorName}</span>
                    <span class="author-handle">@${post.authorHandle}</span>
                    ${post.authorVerified ? '<span class="post-badge">✓ 인증됨</span>' : ''}
                    ${post.feeling ? `<span class="post-badge">${post.feeling}</span>` : ''}
                    ${post.location ? `<span class="post-badge">📍 ${post.location}</span>` : ''}
                  </div>
                  <div class="post-time">작성 일시: ${formattedExactDate}</div>
                </div>
              </div>

              <div class="post-body">${post.content || ''}</div>

              ${
                includeMedia && post.images && post.images.length > 0
                  ? `
                <div class="media-grid">
                  ${post.images
                    .map(
                      (img) => `<img class="media-img" src="${img}" alt="첨부 이미지" />`
                    )
                    .join('')}
                </div>
              `
                  : ''
              }

              ${
                post.poll
                  ? `
                <div class="poll-box">
                  <div class="poll-question">📊 투표: ${post.poll.question} (총 ${post.poll.totalVotes}표)</div>
                  ${post.poll.options
                    .map(
                      (opt) => `
                    <div class="poll-option">
                      <span>• ${opt.text}</span>
                      <span><strong>${Array.isArray(opt.votes) ? opt.votes.length : (Number(opt.votes) || 0)}표</strong> (${
                        post.poll && post.poll.totalVotes > 0
                          ? Math.round(((Array.isArray(opt.votes) ? opt.votes.length : (Number(opt.votes) || 0)) / post.poll.totalVotes) * 100)
                          : 0
                      }%)</span>
                    </div>
                  `
                    )
                    .join('')}
                </div>
              `
                  : ''
              }

              ${
                includeStats
                  ? `
                <div class="stats-bar">
                  <div class="stats-item">❤️ 좋아요 ${post.likes.length}개</div>
                  <div class="stats-item">💬 댓글 ${postComments.length}개</div>
                  <div class="stats-item">🔁 리포스트 ${post.reposts.length}회</div>
                  <div class="stats-item">📌 저장 ${post.bookmarks.length}회</div>
                </div>
              `
                  : ''
              }
            </div>

            ${
              includeComments && postComments.length > 0
                ? `
              <div class="comments-section">
                <div class="comments-title">💬 등록된 댓글 (${postComments.length}개)</div>
                ${postComments
                  .map(
                    (c) => `
                  <div class="comment-item">
                    <div>
                      <span class="comment-author">${c.authorName}</span>
                      <span class="comment-handle">@${c.authorHandle}</span>
                      <span class="comment-time">${new Date(c.createdAt).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <div class="comment-text">${c.content}</div>
                  </div>
                `
                  )
                  .join('')}
              </div>
            `
                : ''
            }

            ${
              includeHeaderFooter
                ? `
              <div class="print-footer">
                <div>본 문서는 소셜 네트워크 앱에서 생성된 PDF 인쇄물입니다.</div>
                <div>원본 링크: ${window.location.origin}/#post-${post.id}</div>
              </div>
            `
                : ''
            }
          </div>
        </body>
        </html>
      `;

      iframeDoc.open();
      iframeDoc.write(printHtml);
      iframeDoc.close();

      setTimeout(() => {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        setIsPrinting(false);
        showToast('인쇄 대화상자가 열렸습니다. 대상에서 "PDF로 저장"을 선택할 수 있습니다.', 'info');
      }, 500);
    } catch (err) {
      console.warn('Iframe print error, falling back to window.print()', err);
      window.print();
      setIsPrinting(false);
    }
  };

  // Copy post summary as plain text
  const handleCopySummaryText = () => {
    const text = `[소셜 게시물 아카이브]\n작성자: ${post.authorName} (@${post.authorHandle})\n작성일시: ${formattedExactDate}\n\n내용:\n${post.content}\n\n좋아요: ${post.likes.length}개 | 댓글: ${postComments.length}개 | 리포스트: ${post.reposts.length}회`;
    navigator.clipboard.writeText(text);
    setCopiedSummary(true);
    showToast('게시물 내용이 텍스트로 복사되었습니다!', 'success');
    setTimeout(() => setCopiedSummary(false), 2000);
  };

  return (
    <div
      id="print-post-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="print-post-modal-dialog"
        className="w-full max-w-2xl rounded-2xl bg-white shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-150"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600 text-white shadow-xs">
              <Printer className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>게시물 인쇄 및 PDF 저장</span>
                <span className="rounded-full bg-blue-100 px-2 py-0.5 text-[11px] font-semibold text-blue-700 dark:bg-blue-900/60 dark:text-blue-300">
                  A4 최적화
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                게시물 내용을 깔끔한 PDF 및 인쇄 양식으로 출력합니다
              </p>
            </div>
          </div>

          <button
            type="button"
            id="close-print-modal-btn"
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body: Settings & Live Preview */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Print Options Bar */}
          <div className="rounded-xl border border-slate-200 bg-slate-50/80 p-3.5 dark:border-slate-800 dark:bg-slate-850">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-200 mb-2.5">
              <Settings2 className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <span>인쇄 및 PDF 출력 옵션</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <label className="flex items-center gap-2 rounded-lg bg-white p-2 border border-slate-200 dark:bg-slate-800 dark:border-slate-700 cursor-pointer hover:border-blue-300 transition-colors">
                <input
                  type="checkbox"
                  checked={includeComments}
                  onChange={(e) => setIncludeComments(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="font-medium text-slate-800 dark:text-slate-200">
                  댓글 포함 ({postComments.length})
                </span>
              </label>

              <label className="flex items-center gap-2 rounded-lg bg-white p-2 border border-slate-200 dark:bg-slate-800 dark:border-slate-700 cursor-pointer hover:border-blue-300 transition-colors">
                <input
                  type="checkbox"
                  checked={includeStats}
                  onChange={(e) => setIncludeStats(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="font-medium text-slate-800 dark:text-slate-200">
                  반응 통계 포함
                </span>
              </label>

              <label className="flex items-center gap-2 rounded-lg bg-white p-2 border border-slate-200 dark:bg-slate-800 dark:border-slate-700 cursor-pointer hover:border-blue-300 transition-colors">
                <input
                  type="checkbox"
                  checked={includeMedia}
                  onChange={(e) => setIncludeMedia(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="font-medium text-slate-800 dark:text-slate-200">
                  이미지 미디어
                </span>
              </label>

              <label className="flex items-center gap-2 rounded-lg bg-white p-2 border border-slate-200 dark:bg-slate-800 dark:border-slate-700 cursor-pointer hover:border-blue-300 transition-colors">
                <input
                  type="checkbox"
                  checked={includeHeaderFooter}
                  onChange={(e) => setIncludeHeaderFooter(e.target.checked)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="font-medium text-slate-800 dark:text-slate-200">
                  문서 머리글/바닥글
                </span>
              </label>
            </div>
          </div>

          {/* Live Print Preview Sheet */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                <Eye className="h-3.5 w-3.5 text-blue-500" />
                <span>인쇄 미리보기 (PDF 레이아웃)</span>
              </span>
              <span className="text-[11px] text-slate-400">A4 세로 비율</span>
            </div>

            <div
              ref={printPreviewRef}
              id="printable-post-content"
              className="rounded-xl border border-slate-300 bg-white p-6 shadow-md text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              {/* Document Header */}
              {includeHeaderFooter && (
                <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                  <div>
                    <span className="font-bold text-blue-600">소셜 네트워크</span>
                    <span className="mx-1">•</span>
                    <span>게시물 아카이브</span>
                  </div>
                  <div className="font-mono text-[11px]">
                    POST-{post.id.toUpperCase()}
                  </div>
                </div>
              )}

              {/* Author Info */}
              <div className="flex items-start gap-3 mb-4">
                <img
                  src={post.authorAvatar}
                  alt={post.authorName}
                  className="h-10 w-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-bold text-slate-900 dark:text-white text-sm">
                      {post.authorName}
                    </span>
                    {post.authorVerified && (
                      <CheckCircle className="h-3.5 w-3.5 fill-blue-600 text-white" />
                    )}
                    <span className="text-xs text-slate-500">@{post.authorHandle}</span>
                    {post.feeling && (
                      <span className="rounded bg-slate-100 px-1.5 py-0.2 text-[10px] text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                        {post.feeling}
                      </span>
                    )}
                    {post.location && (
                      <span className="text-[11px] text-slate-400 flex items-center gap-0.5">
                        <MapPin className="h-3 w-3" />
                        {post.location}
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    <span>작성일시: {formattedExactDate}</span>
                  </div>
                </div>
              </div>

              {/* Text Body */}
              <div className="text-sm leading-relaxed whitespace-pre-wrap text-slate-800 dark:text-slate-200 mb-4 font-sans">
                {post.content}
              </div>

              {/* Attached Images */}
              {includeMedia && post.images && post.images.length > 0 && (
                <div
                  className={`grid gap-2 mb-4 ${
                    post.images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
                  }`}
                >
                  {post.images.map((img, idx) => (
                    <img
                      key={idx}
                      src={img}
                      alt={`미디어 ${idx + 1}`}
                      className="w-full max-h-56 object-cover rounded-lg border border-slate-200 dark:border-slate-800"
                      referrerPolicy="no-referrer"
                    />
                  ))}
                </div>
              )}

              {/* Poll Summary */}
              {post.poll && (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 mb-4 dark:border-slate-800 dark:bg-slate-900">
                  <p className="text-xs font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-1.5">
                    <BarChart2 className="h-3.5 w-3.5 text-blue-600" />
                    <span>📊 투표: {post.poll.question}</span>
                  </p>
                  <div className="space-y-1.5">
                    {post.poll.options.map((opt) => (
                      <div
                        key={opt.id}
                        className="flex items-center justify-between text-xs py-1 border-b border-slate-200/50 dark:border-slate-800/50 last:border-0"
                      >
                        <span className="text-slate-700 dark:text-slate-300">• {opt.text}</span>
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {Array.isArray(opt.votes) ? opt.votes.length : (Number(opt.votes) || 0)}표 (
                          {post.poll && post.poll.totalVotes > 0
                            ? Math.round(((Array.isArray(opt.votes) ? opt.votes.length : (Number(opt.votes) || 0)) / post.poll.totalVotes) * 100)
                            : 0}
                          %)
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Engagement Stats */}
              {includeStats && (
                <div className="flex items-center gap-4 pt-3 border-t border-slate-200 text-xs text-slate-600 dark:border-slate-800 dark:text-slate-400">
                  <span className="flex items-center gap-1">
                    <Heart className="h-3.5 w-3.5 text-rose-500" />
                    <span>좋아요 {post.likes.length}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageCircle className="h-3.5 w-3.5 text-blue-500" />
                    <span>댓글 {postComments.length}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Repeat2 className="h-3.5 w-3.5 text-emerald-500" />
                    <span>리포스트 {post.reposts.length}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Bookmark className="h-3.5 w-3.5 text-indigo-500" />
                    <span>저장 {post.bookmarks.length}</span>
                  </span>
                </div>
              )}

              {/* Comments Section */}
              {includeComments && postComments.length > 0 && (
                <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-2">
                    💬 댓글 목록 ({postComments.length}개)
                  </span>
                  <div className="space-y-2">
                    {postComments.map((comm) => (
                      <div
                        key={comm.id}
                        className="rounded-lg bg-slate-50 p-2.5 text-xs dark:bg-slate-900 border border-slate-100 dark:border-slate-800"
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-slate-900 dark:text-white">
                            {comm.authorName}{' '}
                            <span className="font-normal text-slate-500">
                              @{comm.authorHandle}
                            </span>
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {formatRelativeTime(comm.createdAt)}
                          </span>
                        </div>
                        <p className="text-slate-700 dark:text-slate-300">{comm.content}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Footer */}
              {includeHeaderFooter && (
                <div className="mt-5 pt-3 border-t border-slate-200 text-[10px] text-slate-400 flex items-center justify-between dark:border-slate-800">
                  <span>출처: 소셜 네트워크 웹 앱</span>
                  <span>인쇄 생성 일시: {printTimeStr}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer: Action Buttons */}
        <div className="flex items-center justify-between px-5 py-3.5 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-850">
          <button
            type="button"
            onClick={handleCopySummaryText}
            className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
          >
            {copiedSummary ? (
              <Check className="h-4 w-4 text-emerald-500" />
            ) : (
              <FileText className="h-4 w-4 text-slate-500" />
            )}
            <span>{copiedSummary ? '복사됨!' : '텍스트 복사'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200/70 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              닫기
            </button>

            <button
              type="button"
              id="confirm-print-post-btn"
              onClick={handlePrint}
              disabled={isPrinting}
              className="flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-xs font-bold text-white shadow-md shadow-blue-600/25 hover:bg-blue-700 active:scale-95 transition-all cursor-pointer"
            >
              <Printer className="h-4 w-4" />
              <span>{isPrinting ? '인쇄 준비 중...' : '인쇄하기 / PDF 저장'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
