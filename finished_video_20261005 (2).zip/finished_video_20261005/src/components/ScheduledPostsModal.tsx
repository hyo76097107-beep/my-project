import React from 'react';
import { useSocial } from '../context/SocialContext';
import {
  X,
  Clock,
  Trash2,
  Send,
  Calendar,
  Image as ImageIcon,
  Video,
  BarChart2,
  MapPin,
  Smile,
  AlertCircle
} from 'lucide-react';
import { formatScheduledDateTime, formatScheduledCountdown } from '../utils/formatters';
import { getRegionalScopeConfig } from '../data/regionalScope';

interface ScheduledPostsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenCreatePost?: (mode?: 'photo' | 'video' | 'schedule' | 'location') => void;
}

export const ScheduledPostsModal: React.FC<ScheduledPostsModalProps> = ({
  isOpen,
  onClose,
  onOpenCreatePost
}) => {
  const { scheduledPosts, cancelScheduledPost, publishScheduledPostNow, currentUser } = useSocial();

  if (!isOpen) return null;

  const myScheduledPosts = scheduledPosts.filter((p) => p.authorId === currentUser.id);

  return (
    <div
      id="scheduled-posts-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50 max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400">
              <Clock className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>예약된 게시물</span>
                <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-semibold text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300">
                  {myScheduledPosts.length}개
                </span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                지정된 시간에 맞춰 자동으로 피드에 게시됩니다
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-full p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto py-4 space-y-3.5 pr-1">
          {myScheduledPosts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 mb-3">
                <Calendar className="h-7 w-7" />
              </div>
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                예약 대기 중인 게시물이 없습니다
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                게시물 작성 시 '예약 전송' 옵션을 켜고 원하는 날짜와 시간을 설정해보세요.
              </p>
              {onOpenCreatePost && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenCreatePost('schedule');
                  }}
                  className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-700 transition-colors cursor-pointer"
                >
                  <Clock className="h-3.5 w-3.5" />
                  새 예약 게시물 작성하기
                </button>
              )}
            </div>
          ) : (
            myScheduledPosts.map((post) => (
              <div
                key={post.id}
                id={`scheduled-post-card-${post.id}`}
                className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-800/50 transition-all hover:border-indigo-300 dark:hover:border-indigo-700"
              >
                {/* Schedule timing header badge */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-100/70 dark:bg-indigo-950/70 px-2.5 py-1 rounded-lg">
                    <Clock className="h-3.5 w-3.5" />
                    <span>{formatScheduledDateTime(post.scheduledAt)}</span>
                  </div>
                  <span className="text-[11px] font-medium text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-full border border-amber-200/50 dark:border-amber-800/40">
                    ⏳ {formatScheduledCountdown(post.scheduledAt)}
                  </span>
                </div>

                {/* Post Content preview */}
                {post.content && (
                  <p className="text-sm text-slate-800 dark:text-slate-100 whitespace-pre-wrap line-clamp-3 mb-2">
                    {post.content}
                  </p>
                )}

                {/* Media indicators */}
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-3">
                  {post.images && post.images.length > 0 && (
                    <span className="flex items-center gap-1 bg-white dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700">
                      <ImageIcon className="h-3.5 w-3.5 text-emerald-500" />
                      사진 {post.images.length}장
                    </span>
                  )}
                  {post.video && (
                    <span className="flex items-center gap-1 bg-white dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700">
                      <Video className="h-3.5 w-3.5 text-rose-500" />
                      동영상 첨부됨
                    </span>
                  )}
                  {post.poll && (
                    <span className="flex items-center gap-1 bg-white dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700">
                      <BarChart2 className="h-3.5 w-3.5 text-purple-500" />
                      투표: {post.poll.question}
                    </span>
                  )}
                  {post.feeling && (
                    <span className="flex items-center gap-1 bg-white dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700">
                      <Smile className="h-3.5 w-3.5 text-amber-500" />
                      {post.feeling}
                    </span>
                  )}
                  {post.location && (
                    <span className="flex items-center gap-1 bg-white dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700">
                      <MapPin className="h-3.5 w-3.5 text-red-500" />
                      {post.location}
                    </span>
                  )}
                  {post.regionalScope && (() => {
                    const scope = getRegionalScopeConfig(post.regionalScope);
                    return (
                      <span className={`flex items-center gap-1 px-2 py-0.5 rounded-md border text-[11px] font-semibold ${scope.badgeClass}`}>
                        <span>{scope.emoji}</span>
                        <span>{scope.label}</span>
                      </span>
                    );
                  })()}
                </div>

                {/* Actions */}
                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200/70 dark:border-slate-700/60">
                  <button
                    type="button"
                    onClick={() => cancelScheduledPost(post.id)}
                    className="flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>예약 취소</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => publishScheduledPostNow(post.id)}
                    className="flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-indigo-700 active:scale-95 transition-all cursor-pointer shadow-xs"
                  >
                    <Send className="h-3.5 w-3.5" />
                    <span>지금 바로 게시</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg bg-slate-100 px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
};
