import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Volume2,
  VolumeX,
  Play,
  Heart,
  AlertTriangle,
  Film,
  Image as ImageIcon,
  Cpu,
  CheckCircle2,
  XCircle,
  RotateCw,
  ShieldCheck,
  Activity,
  X
} from 'lucide-react';
import { PostMediaItem } from '../types';
import { checkDeviceCodecCapabilities, DeviceCodecDiagnosticReport } from '../utils/codecChecker';

interface InstagramMediaCarouselProps {
  mediaItems: PostMediaItem[];
  postId: string;
  isPostInView?: boolean;
  onDoubleTapLike?: () => void;
  showHeartAnimation?: boolean;
  compact?: boolean;
}

// Helper to extract YouTube embed URL if applicable
function getYouTubeEmbedUrl(url: string): string | null {
  if (!url || typeof url !== 'string') return null;
  const trimmed = url.trim();
  const regExp = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?|shorts)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/i;
  const match = trimmed.match(regExp);
  if (match && match[1]) {
    return `https://www.youtube.com/embed/${match[1]}?enablejsapi=1&rel=0&playsinline=1`;
  }
  return null;
}

export const InstagramMediaCarousel: React.FC<InstagramMediaCarouselProps> = ({
  mediaItems,
  postId,
  isPostInView = true,
  onDoubleTapLike,
  showHeartAnimation = false,
  compact = false
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [videoFitMode, setVideoFitMode] = useState<'cover' | 'contain'>('cover');
  const [isVideoMuted, setIsVideoMuted] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isAutoPlaying, setIsAutoPlaying] = useState(false);
  const [videoDuration, setVideoDuration] = useState(0);
  const [videoCurrentTime, setVideoCurrentTime] = useState(0);
  const [hasVideoError, setHasVideoError] = useState(false);
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [showNativeControls, setShowNativeControls] = useState(false);

  // H.264 & ExoPlayer Hardware Acceleration Diagnostic States
  const [showCodecModal, setShowCodecModal] = useState(false);
  const [codecReport, setCodecReport] = useState<DeviceCodecDiagnosticReport | null>(null);
  const [isDiagnosing, setIsDiagnosing] = useState(false);

  const runCodecDiagnostic = useCallback(async () => {
    setIsDiagnosing(true);
    try {
      const report = await checkDeviceCodecCapabilities();
      setCodecReport(report);
    } catch (e) {
      console.error('Failed to run codec diagnostic:', e);
    } finally {
      setIsDiagnosing(false);
    }
  }, []);

  const openCodecModal = () => {
    setShowCodecModal(true);
    if (!codecReport) {
      runCodecDiagnostic();
    }
  };

  // References
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRefs = useRef<{ [index: number]: HTMLVideoElement | null }>({});
  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);
  const lastTapTimeRef = useRef<number>(0);
  const userManuallyStartedRef = useRef(false);
  const userManuallyPausedRef = useRef(false);

  const totalItems = mediaItems.length;
  const currentItem = mediaItems[currentIndex] || mediaItems[0];
  const isCurrentVideo = currentItem?.type === 'video';

  // Sanitize and resolve URLs safely across browsers and server storage
  const getResolvedSrc = useCallback((item: PostMediaItem): string => {
    if (!item?.url) return '';
    let raw = typeof item.url === 'string' ? item.url.trim() : '';
    if (!raw) return '';

    if (raw.startsWith('blob:') || raw.startsWith('data:')) {
      return raw;
    }

    if (raw.startsWith('content://') || raw.startsWith('file://')) {
      return '/videos/sample_nature.mp4';
    }

    if (raw.includes('uploads/')) {
      const idx = raw.indexOf('uploads/');
      return `/${raw.substring(idx)}`;
    }

    if (raw.includes('videos/')) {
      const idx = raw.indexOf('videos/');
      return `/${raw.substring(idx)}`;
    }

    if (raw.includes(':3000')) {
      const path = raw.substring(raw.indexOf(':3000') + 5);
      return path.startsWith('/') ? path : `/${path}`;
    }

    if (raw.includes('commondatastorage.googleapis.com')) {
      if (raw.includes('Escapes') || raw.includes('Bullrun') || raw.includes('sample_tokyo')) {
        return '/videos/sample_tokyo.mp4';
      }
      return '/videos/sample_fitness.mp4';
    }

    return raw;
  }, []);

  // Format video time (mm:ss)
  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Video playback management when slide changes or scroll enters/exits view
  useEffect(() => {
    // Pause all non-active videos safely
    mediaItems.forEach((_, idx) => {
      if (idx !== currentIndex && videoRefs.current[idx]) {
        try {
          videoRefs.current[idx]?.pause();
        } catch {}
      }
    });

    const activeVideo = videoRefs.current[currentIndex];
    if (activeVideo) {
      if (activeVideo.duration && isFinite(activeVideo.duration) && activeVideo.duration > 0) {
        setVideoDuration(activeVideo.duration);
      }
      setVideoCurrentTime(activeVideo.currentTime || 0);
    }

    if (isCurrentVideo && activeVideo) {
      // If user has explicitly paused, keep paused
      if (userManuallyPausedRef.current) {
        setIsPlaying(false);
        return;
      }

      // If user has manually started playback, keep playing regardless of background updates
      if (userManuallyStartedRef.current) {
        if (activeVideo.paused) {
          activeVideo.play().then(() => setIsPlaying(true)).catch(() => {});
        }
        return;
      }

      // In-view autoplay: always muted to conform with browser autoplay policy
      if (isPostInView) {
        activeVideo.muted = true;
        setIsVideoMuted(true);
        const playPromise = activeVideo.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => {
              setIsPlaying(true);
              setIsAutoPlaying(true);
            })
            .catch(() => {
              setIsPlaying(false);
            });
        }
      } else {
        if (!userManuallyStartedRef.current) {
          try {
            activeVideo.pause();
          } catch {}
          setIsPlaying(false);
        }
      }
    } else {
      setIsPlaying(false);
    }
  }, [currentIndex, isCurrentVideo, isPostInView, mediaItems.length]);

  // Navigate to slide
  const goToSlide = (index: number) => {
    if (index >= 0 && index < totalItems) {
      setCurrentIndex(index);
      userManuallyStartedRef.current = false;
      userManuallyPausedRef.current = false;
      setHasVideoError(false);
    }
  };

  const handlePrev = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (currentIndex > 0) {
      goToSlide(currentIndex - 1);
    }
  };

  const handleNext = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (currentIndex < totalItems - 1) {
      goToSlide(currentIndex + 1);
    }
  };

  // Touch Swipe handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
    setDragOffset(0);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null || touchStartYRef.current === null) return;
    const diffX = e.touches[0].clientX - touchStartXRef.current;
    const diffY = e.touches[0].clientY - touchStartYRef.current;

    // If predominantly horizontal, prevent scroll & track drag
    if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 8) {
      if (!isDragging) setIsDragging(true);
      // Elastic resistance at boundaries
      if ((currentIndex === 0 && diffX > 0) || (currentIndex === totalItems - 1 && diffX < 0)) {
        setDragOffset(diffX * 0.3);
      } else {
        setDragOffset(diffX);
      }
    }
  };

  const handleTouchEnd = () => {
    if (Math.abs(dragOffset) > 40) {
      if (dragOffset < 0 && currentIndex < totalItems - 1) {
        handleNext();
      } else if (dragOffset > 0 && currentIndex > 0) {
        handlePrev();
      }
    }
    setIsDragging(false);
    setDragOffset(0);
    touchStartXRef.current = null;
    touchStartYRef.current = null;
  };

  // Mouse Drag handlers (Desktop swipe)
  const isMouseDownRef = useRef(false);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    if ((e.target as HTMLElement).closest('button, input, [role="button"], .pointer-events-auto')) return;
    touchStartXRef.current = e.clientX;
    isMouseDownRef.current = true;
    setDragOffset(0);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDownRef.current || touchStartXRef.current === null) return;
    const diffX = e.clientX - touchStartXRef.current;
    if (Math.abs(diffX) > 8) {
      if (!isDragging) setIsDragging(true);
      if ((currentIndex === 0 && diffX > 0) || (currentIndex === totalItems - 1 && diffX < 0)) {
        setDragOffset(diffX * 0.3);
      } else {
        setDragOffset(diffX);
      }
    }
  };

  const handleMouseUp = () => {
    isMouseDownRef.current = false;
    if (isDragging) {
      if (Math.abs(dragOffset) > 45) {
        if (dragOffset < 0 && currentIndex < totalItems - 1) {
          handleNext();
        } else if (dragOffset > 0 && currentIndex > 0) {
          handlePrev();
        }
      }
      setIsDragging(false);
      setDragOffset(0);
      touchStartXRef.current = null;
    }
  };

  // Double tap for Instagram heart animation or single click to toggle play/pause
  const handleContainerClick = (e: React.MouseEvent) => {
    if (isDragging || Math.abs(dragOffset) > 8) return;
    if ((e.target as HTMLElement).closest('button, input, [role="button"], .pointer-events-auto')) return;

    const now = Date.now();
    if (now - lastTapTimeRef.current < 280) {
      if (onDoubleTapLike) {
        onDoubleTapLike();
      }
      lastTapTimeRef.current = 0;
    } else {
      lastTapTimeRef.current = now;
      if (isCurrentVideo) {
        togglePlayPause(e);
      }
    }
  };

  const togglePlayPause = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    const activeVideo = videoRefs.current[currentIndex];
    if (!activeVideo) return;

    if (activeVideo.paused) {
      userManuallyStartedRef.current = true;
      userManuallyPausedRef.current = false;
      setHasVideoError(false);

      const playPromise = activeVideo.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsPlaying(true);
            setHasVideoError(false);
          })
          .catch((err) => {
            console.warn('[VideoPlay] Play with audio failed, retrying muted for browser policy:', err);
            activeVideo.muted = true;
            setIsVideoMuted(true);
            activeVideo.play()
              .then(() => {
                setIsPlaying(true);
                setHasVideoError(false);
              })
              .catch((err2) => {
                console.warn('[VideoPlay] Play muted failed:', err2);
                setIsPlaying(false);
              });
          });
      }
    } else {
      userManuallyStartedRef.current = false;
      userManuallyPausedRef.current = true;
      activeVideo.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    const newMuted = !isVideoMuted;
    setIsVideoMuted(newMuted);
    const activeVideo = videoRefs.current[currentIndex];
    if (activeVideo) {
      activeVideo.muted = newMuted;
    }
  };

  const toggleFitMode = (e: React.MouseEvent) => {
    e.stopPropagation();
    setVideoFitMode((prev) => (prev === 'cover' ? 'contain' : 'cover'));
  };

  const handleVideoTimeUpdate = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    const v = e.currentTarget;
    setVideoCurrentTime(v.currentTime);
    if (v.duration && isFinite(v.duration) && v.duration > 0) {
      setVideoDuration(v.duration);
    }
  };

  const handleProgressBarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const activeVideo = videoRefs.current[currentIndex];
    if (!activeVideo) return;
    const dur = activeVideo.duration && isFinite(activeVideo.duration) && activeVideo.duration > 0
      ? activeVideo.duration
      : videoDuration;
    if (!dur || !isFinite(dur) || dur <= 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    activeVideo.currentTime = ratio * dur;
    setVideoCurrentTime(activeVideo.currentTime);
  };

  if (!mediaItems || mediaItems.length === 0) return null;

  return (
    <div className="mt-4 w-full select-none">
      {/* Instagram 2/3 Phone Screen Height Media Frame */}
      <div
        ref={containerRef}
        onClick={handleContainerClick}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className={`relative w-full ${
          compact
            ? 'h-[360px] sm:h-[420px]'
            : 'h-[66vh] min-h-[440px] max-h-[720px] md:h-[580px]'
        } bg-neutral-950 overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md group cursor-pointer touch-pan-y`}
      >
        {/* Slides Track (Smooth Transform Slide & Real-time Drag Follow) */}
        <div
          className={`flex h-full w-full ${isDragging ? '' : 'transition-transform duration-300 ease-out'}`}
          style={{
            transform: `translateX(calc(-${currentIndex * 100}% + ${dragOffset}px))`
          }}
        >
          {mediaItems.filter(Boolean).map((item, idx) => {
            const resolvedSrc = getResolvedSrc(item);
            const isVideo = item.type === 'video';
            const youTubeEmbedUrl = isVideo ? getYouTubeEmbedUrl(resolvedSrc) : null;
            const backdropUrl = item.thumbnail || (!isVideo ? resolvedSrc : '');

            return (
              <div
                key={item.id || `media_${idx}`}
                className="relative h-full w-full flex-shrink-0 flex items-center justify-center overflow-hidden bg-black"
              >
                {/* Ambient Blurred Backdrop for rich visual presentation */}
                {backdropUrl ? (
                  <div
                    className="absolute inset-0 bg-cover bg-center opacity-25 blur-2xl scale-125 pointer-events-none"
                    style={{
                      backgroundImage: `url(${backdropUrl})`
                    }}
                  />
                ) : null}

                {isVideo ? (
                  youTubeEmbedUrl ? (
                    <div className="w-full h-full relative z-10 flex items-center justify-center bg-black">
                      <iframe
                        src={youTubeEmbedUrl}
                        title={`YouTube Video ${idx + 1}`}
                        className="w-full h-full border-0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                      />
                    </div>
                  ) : Math.abs(currentIndex - idx) <= 1 ? (
                    <video
                      key={`video_${idx}_${resolvedSrc}`}
                      ref={(el) => {
                        videoRefs.current[idx] = el;
                        if (el) {
                          el.defaultMuted = isVideoMuted;
                        }
                      }}
                      src={resolvedSrc}
                      playsInline
                      webkit-playsinline="true"
                      loop
                      muted={isVideoMuted}
                      controls={showNativeControls}
                      preload={idx === currentIndex ? 'auto' : 'metadata'}
                      poster={item.thumbnail}
                      className={`w-full h-full relative z-10 transition-all duration-300 ${
                        videoFitMode === 'cover' ? 'object-cover' : 'object-contain'
                      }`}
                      onPlay={() => {
                        if (idx === currentIndex) setIsPlaying(true);
                        setHasVideoError(false);
                      }}
                      onPause={() => {
                        if (idx === currentIndex) setIsPlaying(false);
                      }}
                      onPlaying={() => {
                        if (idx === currentIndex) {
                          setIsPlaying(true);
                          setHasVideoError(false);
                        }
                      }}
                      onTimeUpdate={idx === currentIndex ? handleVideoTimeUpdate : undefined}
                      onDurationChange={(e) => {
                        if (idx === currentIndex && isFinite(e.currentTarget.duration) && e.currentTarget.duration > 0) {
                          setVideoDuration(e.currentTarget.duration);
                        }
                      }}
                      onLoadedMetadata={(e) => {
                        if (idx === currentIndex && isFinite(e.currentTarget.duration) && e.currentTarget.duration > 0) {
                          setVideoDuration(e.currentTarget.duration);
                          setHasVideoError(false);
                        }
                      }}
                      onLoadedData={() => {
                        if (idx === currentIndex) {
                          const v = videoRefs.current[idx];
                          if (v && isFinite(v.duration) && v.duration > 0) {
                            setVideoDuration(v.duration);
                          }
                          setHasVideoError(false);
                        }
                      }}
                      onCanPlay={() => {
                        if (idx === currentIndex) {
                          setHasVideoError(false);
                        }
                      }}
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (!target || !target.error) return;
                        // Code 1: MEDIA_ERR_ABORTED - normal during seek or slide switch
                        if (target.error.code === 1) return;
                        // Code 2: MEDIA_ERR_NETWORK - transient network glitch, retry once
                        if (target.error.code === 2) {
                          console.warn('[VideoNetworkWarn] Transient network issue, reloading stream:', resolvedSrc);
                          try {
                            target.load();
                          } catch {}
                          return;
                        }
                        console.warn('[VideoError] Video playback error for:', resolvedSrc, target.error);
                        if (idx === currentIndex) {
                          setHasVideoError(true);
                        }
                      }}
                    />
                  ) : (
                    // Lightweight poster preview for distant slides to avoid hardware decoder exhaustion
                    <div className="w-full h-full relative z-10 flex items-center justify-center bg-black">
                      {item.thumbnail ? (
                        <img
                          src={item.thumbnail}
                          alt={`Video preview ${idx + 1}`}
                          className="w-full h-full object-cover opacity-80"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center text-slate-500">
                          <Film className="h-10 w-10 text-slate-600 mb-2" />
                          <span className="text-xs">동영상 {idx + 1}</span>
                        </div>
                      )}
                    </div>
                  )
                ) : (
                  <img
                    src={resolvedSrc}
                    alt={`Attachment ${idx + 1}`}
                    className={`w-full h-full relative z-10 transition-all duration-300 pointer-events-none ${
                      videoFitMode === 'cover' ? 'object-cover' : 'object-contain'
                    }`}
                    loading={Math.abs(currentIndex - idx) <= 1 ? 'eager' : 'lazy'}
                    referrerPolicy="no-referrer"
                  />
                )}

                {/* Video Play Button Overlay when paused */}
                {isVideo && !youTubeEmbedUrl && idx === currentIndex && !isPlaying && !hasVideoError && (
                  <button
                    type="button"
                    onClick={togglePlayPause}
                    aria-label="동영상 재생"
                    className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-black/60 hover:bg-black/80 text-white flex items-center justify-center backdrop-blur-md transition-all hover:scale-110 active:scale-95 shadow-2xl border border-white/20 z-20 cursor-pointer"
                  >
                    <Play className="h-7 w-7 text-white fill-white ml-0.5" />
                  </button>
                )}

                {/* Playback Error & Codec Recovery Overlay */}
                {isVideo && idx === currentIndex && hasVideoError && (
                  <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md z-30 flex flex-col items-center justify-center p-6 text-center text-white animate-in fade-in duration-200">
                    <div className="w-12 h-12 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center mb-3 text-rose-400">
                      <AlertTriangle className="h-6 w-6" />
                    </div>
                    <h4 className="text-sm font-bold text-white mb-1">동영상을 재생할 수 없습니다</h4>
                    <p className="text-xs text-slate-300 max-w-xs mb-4 leading-relaxed">
                      네트워크 연결 지연 또는 지원되지 않는 비디오 코덱(H.265 등)일 수 있습니다. 다시 시도하거나 코덱 상태를 확인하세요.
                    </p>
                    <div className="flex flex-wrap items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          const v = videoRefs.current[currentIndex];
                          if (v) {
                            v.load();
                            v.play().catch(() => {});
                          }
                          setHasVideoError(false);
                        }}
                        className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-1.5"
                      >
                        <RotateCw className="h-3.5 w-3.5" />
                        <span>다시 시도 (재생 복구)</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Double-tap Instagram Like Heart Pop Animation */}
        {showHeartAnimation && (
          <div className="absolute inset-0 m-auto flex items-center justify-center z-30 pointer-events-none">
            <Heart className="w-24 h-24 text-rose-500 fill-rose-500 drop-shadow-2xl animate-ping" />
          </div>
        )}

        {/* Top-left Indicator: Auto-play Pulse (only when playing video) */}
        {isCurrentVideo && isPlaying && (
          <div className="absolute top-3 left-3 pointer-events-none flex items-center gap-1.5 z-20">
            <div className="flex items-center gap-1.5 rounded-full bg-emerald-950/80 backdrop-blur-md px-2.5 py-1 text-[10px] font-bold text-emerald-300 border border-emerald-500/40 shadow-lg">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
              <span>{isAutoPlaying ? '화면 감지 자동재생' : '재생 중'}</span>
            </div>
          </div>
        )}

        {/* Top-right Overlays: Counter Badge + Controls */}
        <div className="absolute top-3 right-3 flex items-center gap-1.5 z-20">
          {/* Instagram-style 1/10 Counter Badge */}
          {totalItems > 1 && (
            <div className="rounded-full bg-black/70 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur-md shadow-lg border border-white/15">
              {currentIndex + 1}/{totalItems}
            </div>
          )}

          {/* Fit Mode Toggle Button */}
          <button
            type="button"
            onClick={toggleFitMode}
            title={videoFitMode === 'cover' ? '원본 비율로 보기' : '화면 꽉 채우기'}
            className="flex items-center justify-center w-8 h-8 rounded-full bg-black/70 hover:bg-black/90 text-white backdrop-blur-md shadow-lg transition-all active:scale-95 border border-white/15 cursor-pointer"
          >
            {videoFitMode === 'cover' ? (
              <Minimize2 className="h-3.5 w-3.5 text-white" />
            ) : (
              <Maximize2 className="h-3.5 w-3.5 text-white" />
            )}
          </button>

          {/* Fullscreen Button */}
          {isCurrentVideo && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                const v = videoRefs.current[currentIndex];
                if (v) {
                  if (v.requestFullscreen) {
                    v.requestFullscreen().catch(() => {});
                  } else if ((v as any).webkitRequestFullscreen) {
                    (v as any).webkitRequestFullscreen();
                  }
                }
              }}
              title="전체화면"
              className="flex items-center justify-center w-8 h-8 rounded-full bg-black/70 hover:bg-black/90 text-white backdrop-blur-md shadow-lg transition-all active:scale-95 border border-white/15 cursor-pointer"
            >
              <Maximize2 className="h-3.5 w-3.5 text-emerald-400" />
            </button>
          )}

          {/* Native Controls Toggle Button */}
          {isCurrentVideo && !getYouTubeEmbedUrl(getResolvedSrc(currentItem)) && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setShowNativeControls((prev) => !prev);
              }}
              title={showNativeControls ? '인스타그램 커스텀 UI' : '브라우저 기본 재생 바 보기'}
              className="px-2 py-1 rounded-full bg-black/70 hover:bg-black/90 text-white backdrop-blur-md shadow-lg transition-all active:scale-95 border border-white/15 cursor-pointer text-[10px] font-bold"
            >
              {showNativeControls ? '커스텀 UI' : '재생 바'}
            </button>
          )}

          {/* Sound Toggle Button (when video is active) */}
          {isCurrentVideo && (
            <button
              type="button"
              onClick={toggleMute}
              aria-label={isVideoMuted ? '소리 켜기' : '소리 끄기'}
              className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold backdrop-blur-md shadow-lg transition-all active:scale-95 border cursor-pointer ${
                isVideoMuted
                  ? 'bg-black/70 hover:bg-black/90 text-white border-white/15'
                  : 'bg-emerald-600/90 hover:bg-emerald-600 text-white border-emerald-400/30'
              }`}
            >
              {isVideoMuted ? (
                <>
                  <VolumeX className="h-3.5 w-3.5 text-slate-300" />
                  <span className="text-[11px]">소리 켜기</span>
                </>
              ) : (
                <>
                  <Volume2 className="h-3.5 w-3.5 text-white animate-pulse" />
                  <span className="text-[11px]">소리 켬</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* Left Arrow Navigation Button */}
        {currentIndex > 0 && (
          <button
            type="button"
            onClick={handlePrev}
            aria-label="이전 미디어"
            className="absolute left-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 hover:bg-black/85 text-white flex items-center justify-center backdrop-blur-md shadow-xl border border-white/20 transition-all opacity-80 hover:opacity-100 hover:scale-105 active:scale-95 z-20 cursor-pointer"
          >
            <ChevronLeft className="h-5 w-5 text-white" />
          </button>
        )}

        {/* Right Arrow Navigation Button */}
        {currentIndex < totalItems - 1 && (
          <button
            type="button"
            onClick={handleNext}
            aria-label="다음 미디어"
            className="absolute right-2.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/60 hover:bg-black/85 text-white flex items-center justify-center backdrop-blur-md shadow-xl border border-white/20 transition-all opacity-80 hover:opacity-100 hover:scale-105 active:scale-95 z-20 cursor-pointer"
          >
            <ChevronRight className="h-5 w-5 text-white" />
          </button>
        )}

        {/* Bottom Progress Bar for Video */}
        {isCurrentVideo && (
          <div className="absolute bottom-0 left-0 right-0 z-20 pointer-events-auto">
            <div className="flex items-center justify-between px-3 pb-1 text-[10px] font-semibold text-white/90 drop-shadow-md">
              <span className="bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded-md">
                {formatTime(videoCurrentTime)} / {formatTime(videoDuration)}
              </span>
              <span className="bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded-md text-slate-200">
                {videoFitMode === 'cover' ? '화면 꽉 찬 모드' : '원본 비율'}
              </span>
            </div>

            <div
              className="h-1.5 hover:h-2.5 bg-white/20 transition-all cursor-pointer relative group/bar"
              onClick={handleProgressBarClick}
            >
              <div
                className="h-full bg-gradient-to-r from-rose-500 to-indigo-500 transition-all duration-100 relative"
                style={{
                  width: `${videoDuration ? Math.min(100, Math.max(0, (videoCurrentTime / videoDuration) * 100)) : 0}%`
                }}
              >
                <span className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-md opacity-0 group-hover/bar:opacity-100 transition-opacity" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Instagram-style Pagination Dots Indicator Directly Below Video/Photo */}
      {totalItems > 1 && (
        <div
          className="flex items-center justify-center gap-1.5 py-2.5"
          role="tablist"
          aria-label="미디어 슬라이드 탐색 점"
        >
          {mediaItems.filter(Boolean).map((item, dotIdx) => {
            const isActive = dotIdx === currentIndex;
            return (
              <button
                key={dotIdx}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-label={`${dotIdx + 1}번째 미디어 (${item.type === 'video' ? '동영상' : '사진'}) 보기`}
                onClick={() => goToSlide(dotIdx)}
                className={`transition-all duration-200 rounded-full cursor-pointer focus:outline-none ${
                  isActive
                    ? 'w-5 h-1.5 bg-blue-600 dark:bg-blue-400'
                    : 'w-1.5 h-1.5 bg-slate-300 hover:bg-slate-400 dark:bg-slate-700 dark:hover:bg-slate-500'
                }`}
              />
            );
          })}
        </div>
      )}

      {/* Codec Support & ExoPlayer Hardware Acceleration Diagnostic Modal */}
      {showCodecModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
          onClick={() => setShowCodecModal(false)}
        >
          <div
            className="w-full max-w-lg rounded-2xl bg-white p-5 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-900 dark:text-white max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <Cpu className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold">ExoPlayer 코덱 & HW 가속 진단</h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    안드로이드 ExoPlayer 미디어 재생 및 H.264 호환성 검사
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCodecModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Diagnostic Summary Cards */}
            <div className="mt-4 space-y-3">
              {/* HW Acceleration Status */}
              <div
                className={`p-3.5 rounded-xl border flex items-center gap-3 ${
                  codecReport?.hasHardwareAcceleration
                    ? 'bg-emerald-50/70 border-emerald-200 dark:bg-emerald-950/30 dark:border-emerald-800/50'
                    : 'bg-amber-50/70 border-amber-200 dark:bg-amber-950/30 dark:border-amber-800/50'
                }`}
              >
                {codecReport?.hasHardwareAcceleration ? (
                  <CheckCircle2 className="h-6 w-6 text-emerald-600 dark:text-emerald-400 shrink-0" />
                ) : (
                  <Activity className="h-6 w-6 text-amber-600 dark:text-amber-400 shrink-0" />
                )}
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white">
                    {codecReport?.hasHardwareAcceleration
                      ? 'GPU 하드웨어 가속 디코딩 활성화됨'
                      : '소프트웨어 디코딩 동작 중'}
                  </div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
                    H.264/AVC 프로파일을 GPU에서 저지연·저전력으로 직접 디코딩합니다.
                  </div>
                </div>
              </div>

              {/* ExoPlayer Configuration Card */}
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
                <div className="text-xs font-bold mb-2 flex items-center gap-1.5 text-blue-600 dark:text-blue-400">
                  <ShieldCheck className="h-4 w-4" />
                  <span>ExoPlayer & 시스템 권장 규격</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 block text-[10px]">권장 코덱/프로파일</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      H.264 Baseline/Main (yuv420p)
                    </span>
                  </div>
                  <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 block text-[10px]">ExoPlayer 디코더 폴백</span>
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                      활성화 (자동 복구 ON)
                    </span>
                  </div>
                  <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 block text-[10px]">최대 호환 해상도</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      1080p (FHD) ~ 4K UHD
                    </span>
                  </div>
                  <div className="bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 block text-[10px]">스트리밍 버퍼 제어</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">
                      1.5s ~ 6.0s 적응형 버퍼
                    </span>
                  </div>
                </div>
              </div>

              {/* Profile Capability Table */}
              <div>
                <div className="text-xs font-bold mb-1.5 flex items-center justify-between">
                  <span>H.264 및 주요 코덱 프로파일 지원 현황</span>
                  <button
                    type="button"
                    onClick={runCodecDiagnostic}
                    disabled={isDiagnosing}
                    className="text-[10px] text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCw className={`h-2.5 w-2.5 ${isDiagnosing ? 'animate-spin' : ''}`} />
                    <span>진단 다시 실행</span>
                  </button>
                </div>
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {codecReport?.profiles.map((p, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/40"
                    >
                      <div>
                        <div className="font-medium text-[11px] text-slate-800 dark:text-slate-200">
                          {p.name}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {p.codecString}
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {p.isSupported ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                            <CheckCircle2 className="h-3 w-3" />
                            <span>지원됨</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                            <XCircle className="h-3 w-3" />
                            <span>미지원</span>
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Current Video File Info */}
              {currentItem && (
                <div className="p-3 rounded-xl bg-slate-100/70 dark:bg-slate-800/40 text-[11px] text-slate-600 dark:text-slate-400 space-y-1">
                  <div>
                    <strong className="text-slate-700 dark:text-slate-300">현재 미디어 경로:</strong>{' '}
                    {getResolvedSrc(currentItem)}
                  </div>
                  <div>
                    <strong className="text-slate-700 dark:text-slate-300">재생 상태:</strong>{' '}
                    {hasVideoError
                      ? '재생 오류 감지됨 (코덱 확인 필요)'
                      : isPlaying
                      ? '정상 재생 중'
                      : '일시정지 중'}
                  </div>
                </div>
              )}
            </div>

            {/* Footer Action Buttons */}
            <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => {
                  const v = videoRefs.current[currentIndex];
                  if (v) {
                    v.load();
                    v.play().catch(() => {});
                  }
                  setHasVideoError(false);
                  setShowCodecModal(false);
                }}
                className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                <RotateCw className="h-3.5 w-3.5" />
                <span>동영상 다시 불러오기</span>
              </button>

              <button
                type="button"
                onClick={() => setShowCodecModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors cursor-pointer"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
