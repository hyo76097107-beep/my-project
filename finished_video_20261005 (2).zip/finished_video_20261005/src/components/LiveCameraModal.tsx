import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Camera,
  X,
  RotateCcw,
  FlipHorizontal,
  Check,
  Zap,
  ZapOff,
  Grid,
  Clock,
  AlertCircle,
  Smartphone
} from 'lucide-react';

interface LiveCameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (file: File) => void;
  onFallbackNativeCamera?: () => void;
}

export const LiveCameraModal: React.FC<LiveCameraModalProps> = ({
  isOpen,
  onClose,
  onCapture,
  onFallbackNativeCamera
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [capturedDataUrl, setCapturedDataUrl] = useState<string | null>(null);
  const [isTorchOn, setIsTorchOn] = useState(false);
  const [isTorchSupported, setIsTorchSupported] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [isFlashing, setIsFlashing] = useState(false);

  // Stop current active tracks
  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      streamRef.current = null;
    }
  }, []);

  // Initialize camera stream
  const startCamera = useCallback(async () => {
    stopStream();
    setErrorMessage(null);
    setCapturedDataUrl(null);
    setIsTorchOn(false);

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setHasCameraPermission(false);
      setErrorMessage('이 기기 또는 브라우저는 웹 실시간 카메라 API를 직접 지원하지 않습니다. 아래 기본 카메라 앱으로 촬영해주세요.');
      return;
    }

    try {
      const constraints: MediaStreamConstraints = {
        audio: false,
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }

      setHasCameraPermission(true);

      // Check if torch/flashlight is supported
      const track = stream.getVideoTracks()[0];
      if (track) {
        const capabilities = (track.getCapabilities?.() || {}) as any;
        setIsTorchSupported(!!capabilities.torch);
      }
    } catch (err: any) {
      console.warn('[LiveCamera] getUserMedia failed:', err);
      setHasCameraPermission(false);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setErrorMessage('카메라 접근 권한이 허용되지 않았습니다. 브라우저 설정에서 카메라 권한을 허용하시거나 기본 카메라 앱으로 촬영해주세요.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setErrorMessage('사용 가능한 카메라 장치를 찾을 수 없습니다.');
      } else {
        setErrorMessage('카메라를 시작하는 중 문제가 발생했습니다. 기본 카메라 촬영을 이용해보세요.');
      }
    }
  }, [facingMode, stopStream]);

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopStream();
      setCapturedDataUrl(null);
      setCountdown(null);
    }
    return () => {
      stopStream();
    };
  }, [isOpen, startCamera, stopStream]);

  // Toggle flash torch
  const toggleTorch = async () => {
    if (!streamRef.current) return;
    const track = streamRef.current.getVideoTracks()[0];
    if (!track) return;

    try {
      const nextTorch = !isTorchOn;
      await (track as any).applyConstraints({
        advanced: [{ torch: nextTorch }]
      });
      setIsTorchOn(nextTorch);
    } catch (err) {
      console.warn('Torch constraint failed:', err);
    }
  };

  // Flip front/rear camera
  const handleToggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Execute snapshot capture
  const takeSnapshot = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;

    // Trigger flash animation
    setIsFlashing(true);
    setTimeout(() => setIsFlashing(false), 180);

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1080;
    canvas.height = video.videoHeight || 1920;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Flip horizontally if front selfie camera
    if (facingMode === 'user') {
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
    }

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    setCapturedDataUrl(dataUrl);
    stopStream();
  };

  // Shutter click with optional countdown timer
  const handleShutterClick = () => {
    if (timerSeconds > 0) {
      let current = timerSeconds;
      setCountdown(current);
      const interval = setInterval(() => {
        current -= 1;
        if (current <= 0) {
          clearInterval(interval);
          setCountdown(null);
          takeSnapshot();
        } else {
          setCountdown(current);
        }
      }, 1000);
    } else {
      takeSnapshot();
    }
  };

  // Retake photo
  const handleRetake = () => {
    setCapturedDataUrl(null);
    startCamera();
  };

  // Confirm photo usage
  const handleConfirmPhoto = () => {
    if (!capturedDataUrl) return;

    // Convert dataUrl to File
    const arr = capturedDataUrl.split(',');
    const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/jpeg';
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    const filename = `story_camera_${Date.now()}.jpg`;
    const file = new File([u8arr], filename, { type: mime });

    onCapture(file);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      id="live-camera-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-2 sm:p-4 select-none"
    >
      <div className="relative w-full max-w-md h-[90vh] max-h-[780px] bg-black rounded-3xl overflow-hidden shadow-2xl flex flex-col border border-white/10">
        {/* Flash Animation overlay */}
        {isFlashing && (
          <div className="absolute inset-0 z-40 bg-white transition-opacity duration-150 animate-out fade-out" />
        )}

        {/* Top Controls Bar */}
        <div className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between p-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
          <div className="flex items-center gap-2">
            {/* Timer Toggle */}
            <button
              type="button"
              onClick={() =>
                setTimerSeconds((prev) => (prev === 0 ? 3 : prev === 3 ? 5 : 0))
              }
              className={`p-2 rounded-full backdrop-blur-md transition-colors ${
                timerSeconds > 0
                  ? 'bg-amber-500 text-white'
                  : 'bg-black/40 text-white/80 hover:bg-black/60'
              }`}
              title="타이머 설정"
            >
              <div className="flex items-center gap-1 text-xs font-bold">
                <Clock className="w-4 h-4" />
                {timerSeconds > 0 && <span>{timerSeconds}s</span>}
              </div>
            </button>

            {/* Grid Toggle */}
            <button
              type="button"
              onClick={() => setShowGrid((prev) => !prev)}
              className={`p-2 rounded-full backdrop-blur-md transition-colors ${
                showGrid
                  ? 'bg-blue-600 text-white'
                  : 'bg-black/40 text-white/80 hover:bg-black/60'
              }`}
              title="격자 안내선 토글"
            >
              <Grid className="w-4 h-4" />
            </button>

            {/* Torch Toggle if supported */}
            {isTorchSupported && (
              <button
                type="button"
                onClick={toggleTorch}
                className={`p-2 rounded-full backdrop-blur-md transition-colors ${
                  isTorchOn
                    ? 'bg-amber-400 text-black'
                    : 'bg-black/40 text-white/80 hover:bg-black/60'
                }`}
                title="손전등 플래시"
              >
                {isTorchOn ? <Zap className="w-4 h-4" /> : <ZapOff className="w-4 h-4" />}
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-md transition-colors cursor-pointer"
            title="닫기"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder Area */}
        <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
          {capturedDataUrl ? (
            /* Review captured photo */
            <img
              src={capturedDataUrl}
              alt="Captured"
              className="w-full h-full object-cover"
            />
          ) : errorMessage ? (
            /* Error state / Permission prompt */
            <div className="flex flex-col items-center justify-center p-6 text-center text-white gap-3 max-w-xs">
              <div className="p-3 rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/40">
                <AlertCircle className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold">카메라를 시작할 수 없습니다</h3>
              <p className="text-xs text-white/70 leading-relaxed">{errorMessage}</p>

              {onFallbackNativeCamera && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onFallbackNativeCamera();
                  }}
                  className="mt-2 w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>휴대폰 기본 카메라로 촬영하기</span>
                </button>
              )}
            </div>
          ) : (
            /* Live Video Stream */
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${
                  facingMode === 'user' ? 'scale-x-[-1]' : ''
                }`}
              />

              {/* Composition Grid (Rule of Thirds) */}
              {showGrid && (
                <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3 opacity-30">
                  <div className="border-r border-b border-white" />
                  <div className="border-r border-b border-white" />
                  <div className="border-b border-white" />
                  <div className="border-r border-b border-white" />
                  <div className="border-r border-b border-white" />
                  <div className="border-b border-white" />
                  <div className="border-r border-white" />
                  <div className="border-r border-white" />
                  <div />
                </div>
              )}

              {/* Countdown overlay */}
              {countdown !== null && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/40 z-30 pointer-events-none">
                  <span className="text-8xl font-black text-white animate-ping">
                    {countdown}
                  </span>
                </div>
              )}
            </>
          )}
        </div>

        {/* Bottom Shutter / Review Controls */}
        <div className="relative p-6 bg-gradient-to-t from-black via-black/90 to-transparent flex items-center justify-around z-30 shrink-0">
          {capturedDataUrl ? (
            /* Review state buttons */
            <div className="flex items-center justify-between w-full px-4 gap-4">
              <button
                type="button"
                onClick={handleRetake}
                className="flex-1 py-3 px-4 rounded-2xl bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-all active:scale-95 border border-white/15 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>다시 촬영</span>
              </button>

              <button
                type="button"
                onClick={handleConfirmPhoto}
                className="flex-1 py-3 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/40 transition-all active:scale-95 cursor-pointer"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>스토리에 사용하기</span>
              </button>
            </div>
          ) : (
            /* Live camera shutter controls */
            <>
              {/* Native Camera App trigger */}
              {onFallbackNativeCamera ? (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onFallbackNativeCamera();
                  }}
                  className="p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
                  title="기본 카메라 앱으로 전환"
                >
                  <Smartphone className="w-5 h-5" />
                </button>
              ) : (
                <div className="w-11" />
              )}

              {/* Large Shutter Button */}
              <button
                type="button"
                onClick={handleShutterClick}
                disabled={!hasCameraPermission || !!errorMessage}
                className="relative flex items-center justify-center w-18 h-18 rounded-full border-4 border-white bg-transparent hover:scale-105 active:scale-90 transition-all disabled:opacity-40 cursor-pointer shadow-lg"
                title="사진 촬영"
              >
                <div className="w-14 h-14 rounded-full bg-white active:bg-slate-200 transition-colors" />
              </button>

              {/* Flip Camera front / rear */}
              <button
                type="button"
                onClick={handleToggleFacingMode}
                className="p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all active:rotate-180 duration-300 cursor-pointer"
                title="전면 / 후면 카메라 전환"
              >
                <FlipHorizontal className="w-5 h-5" />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
