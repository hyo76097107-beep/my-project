import React, { useState, useRef } from 'react';
import { Languages, Sparkles, Copy, Check, ChevronDown, RefreshCw, Volume2, Globe2, X, AlertCircle } from 'lucide-react';
import { TargetLanguageOption, PostTranslationState } from '../types';
import { useSocial } from '../context/SocialContext';

export const SUPPORTED_LANGUAGES: TargetLanguageOption[] = [
  { code: 'ko', name: '한국어 (Korean)', nativeName: '한국어', flag: '🇰🇷' },
  { code: 'en', name: '영어 (English)', nativeName: 'English', flag: '🇺🇸' },
  { code: 'ja', name: '일본어 (Japanese)', nativeName: '日本語', flag: '🇯🇵' },
  { code: 'zh', name: '중국어 (Chinese)', nativeName: '中文', flag: '🇨🇳' },
  { code: 'es', name: '스페인어 (Spanish)', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'fr', name: '프랑스어 (French)', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'de', name: '독일어 (German)', nativeName: 'Deutsch', flag: '🇩🇪' },
  { code: 'vi', name: '베트남어 (Vietnamese)', nativeName: 'Tiếng Việt', flag: '🇻🇳' },
];

interface PostTranslatorProps {
  postId: string;
  content: string;
}

export const PostTranslator: React.FC<PostTranslatorProps> = ({ postId, content }) => {
  const { showToast } = useSocial();

  // Determine initial smart target language: if post has Korean, default target to English; otherwise default to Korean
  const hasKorean = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/.test(content);
  const defaultTargetLang = hasKorean ? SUPPORTED_LANGUAGES[1] : SUPPORTED_LANGUAGES[0];

  const [isOpen, setIsOpen] = useState(false);
  const [selectedLang, setSelectedLang] = useState<TargetLanguageOption>(defaultTargetLang);
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [cache, setCache] = useState<Record<string, { text: string; detected?: string }>>({});

  const [translationState, setTranslationState] = useState<PostTranslationState>({
    translatedText: '',
    targetLanguage: defaultTargetLang.name,
    targetLanguageCode: defaultTargetLang.code,
    isLoading: false,
    error: null,
  });

  const menuRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  React.useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsLangMenuOpen(false);
      }
    };
    if (isLangMenuOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [isLangMenuOpen]);

  const handleTranslate = async (targetLang: TargetLanguageOption = selectedLang) => {
    if (!content.trim()) return;

    setIsOpen(true);
    setSelectedLang(targetLang);

    // Check cache first
    if (cache[targetLang.code]) {
      setTranslationState({
        translatedText: cache[targetLang.code].text,
        detectedLanguage: cache[targetLang.code].detected,
        targetLanguage: targetLang.name,
        targetLanguageCode: targetLang.code,
        isLoading: false,
        error: null,
      });
      return;
    }

    setTranslationState((prev) => ({
      ...prev,
      targetLanguage: targetLang.name,
      targetLanguageCode: targetLang.code,
      isLoading: true,
      error: null,
    }));

    try {
      const response = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: content,
          targetLanguage: targetLang.name,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || '번역을 가져오는 중 오류가 발생했습니다.');
      }

      const translated = data.translatedText;
      const detected = data.detectedLanguage;

      setCache((prev) => ({
        ...prev,
        [targetLang.code]: { text: translated, detected },
      }));

      setTranslationState({
        translatedText: translated,
        detectedLanguage: detected,
        targetLanguage: targetLang.name,
        targetLanguageCode: targetLang.code,
        isLoading: false,
        error: null,
      });
    } catch (err: any) {
      console.error('Translation error:', err);
      setTranslationState((prev) => ({
        ...prev,
        isLoading: false,
        error: err.message || '번역에 실패했습니다. 다시 시도해주세요.',
      }));
    }
  };

  const handleCopyTranslated = async () => {
    if (!translationState.translatedText) return;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(translationState.translatedText);
      }
      setCopied(true);
      showToast('번역된 내용이 클립보드에 복사되었습니다.', 'success');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast('복사에 실패했습니다.', 'error');
    }
  };

  const handleSpeak = () => {
    if (!translationState.translatedText || typeof window === 'undefined') return;

    if (!('speechSynthesis' in window)) {
      showToast('현재 브라우저에서 음성 재생을 지원하지 않습니다.', 'error');
      return;
    }

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(translationState.translatedText);
    utterance.lang = selectedLang.code;
    utterance.rate = 0.95;

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="mt-2.5">
      {/* 1. View Translation Trigger Button (When collapsed) */}
      {!isOpen ? (
        <div className="flex items-center gap-2">
          <button
            type="button"
            id={`post-translate-btn-${postId}`}
            onClick={() => handleTranslate(selectedLang)}
            className="group inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-semibold text-blue-600 dark:text-blue-400 bg-blue-50/60 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/60 transition-all active:scale-95 cursor-pointer border border-blue-200/50 dark:border-blue-800/50"
            title="Gemini AI로 이 게시물을 실시간 번역하여 봅니다"
          >
            <Languages className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 group-hover:rotate-12 transition-transform" />
            <span>번역 보기</span>
            <span className="inline-flex items-center gap-0.5 text-[10px] text-blue-500/80 dark:text-blue-300/80 font-normal">
              ({selectedLang.flag} {selectedLang.nativeName})
            </span>
            <Sparkles className="w-3 h-3 text-amber-500 animate-pulse" />
          </button>
        </div>
      ) : (
        /* 2. Expanded Translation Card */
        <div
          id={`post-translation-container-${postId}`}
          className="rounded-xl border border-blue-100 bg-gradient-to-br from-blue-50/70 via-indigo-50/30 to-slate-50 p-3.5 dark:border-blue-900/50 dark:from-blue-950/30 dark:via-indigo-950/20 dark:to-slate-900/60 shadow-xs animate-in fade-in-50 duration-200"
        >
          {/* Header bar: Info & Language Selector & Actions */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-blue-100/80 dark:border-blue-900/40 pb-2.5">
            <div className="flex items-center gap-2 flex-wrap">
              {/* AI Badge */}
              <div className="inline-flex items-center gap-1 rounded-md bg-blue-600 px-2 py-0.5 text-[10px] font-bold text-white shadow-2xs">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>Gemini 번역</span>
              </div>

              {/* Language Selector Dropdown */}
              <div ref={menuRef} className="relative inline-block">
                <button
                  type="button"
                  id={`post-lang-select-btn-${postId}`}
                  onClick={() => setIsLangMenuOpen((prev) => !prev)}
                  className="flex items-center gap-1.5 rounded-lg border border-slate-200/90 bg-white px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 transition-colors cursor-pointer"
                >
                  <Globe2 className="w-3 h-3 text-indigo-500" />
                  <span>
                    {translationState.detectedLanguage ? `${translationState.detectedLanguage} ➔ ` : ''}
                    {selectedLang.flag} {selectedLang.nativeName}
                  </span>
                  <ChevronDown className={`w-3 h-3 text-slate-400 transition-transform ${isLangMenuOpen ? 'rotate-180' : ''}`} />
                </button>

                {/* Dropdown Menu */}
                {isLangMenuOpen && (
                  <div
                    id={`post-lang-dropdown-${postId}`}
                    className="absolute left-0 top-full mt-1.5 w-48 rounded-xl border border-slate-200 bg-white p-1 shadow-xl dark:border-slate-700 dark:bg-slate-800 z-30 animate-in fade-in-0 zoom-in-95 duration-100"
                  >
                    <div className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-700/60 mb-1">
                      번역할 목표 언어 선택
                    </div>
                    <div className="max-h-48 overflow-y-auto space-y-0.5">
                      {SUPPORTED_LANGUAGES.map((lang) => (
                        <button
                          key={lang.code}
                          type="button"
                          onClick={() => {
                            setIsLangMenuOpen(false);
                            handleTranslate(lang);
                          }}
                          className={`flex w-full items-center justify-between rounded-lg px-2.5 py-1.5 text-xs text-left transition-colors ${
                            selectedLang.code === lang.code
                              ? 'bg-blue-50 font-bold text-blue-600 dark:bg-blue-950/60 dark:text-blue-400'
                              : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-700/60'
                          }`}
                        >
                          <span className="flex items-center gap-2">
                            <span>{lang.flag}</span>
                            <span>{lang.name}</span>
                          </span>
                          {selectedLang.code === lang.code && (
                            <Check className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right side utility actions */}
            <div className="flex items-center gap-1">
              {/* Refresh / Retranslate */}
              <button
                type="button"
                onClick={() => handleTranslate(selectedLang)}
                disabled={translationState.isLoading}
                title="다시 번역하기"
                className="p-1 rounded-lg text-slate-400 hover:bg-slate-200/60 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${translationState.isLoading ? 'animate-spin text-blue-500' : ''}`} />
              </button>

              {/* TTS Listen */}
              {translationState.translatedText && !translationState.isLoading && (
                <button
                  type="button"
                  onClick={handleSpeak}
                  title={isPlayingAudio ? '음성 재생 중지' : '발음 듣기 (음성 재생)'}
                  className={`p-1 rounded-lg transition-colors ${
                    isPlayingAudio
                      ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/60 dark:text-blue-300 animate-pulse'
                      : 'text-slate-400 hover:bg-slate-200/60 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
              )}

              {/* Copy Button */}
              {translationState.translatedText && !translationState.isLoading && (
                <button
                  type="button"
                  onClick={handleCopyTranslated}
                  title="번역 내용 복사"
                  className="p-1 rounded-lg text-slate-400 hover:bg-slate-200/60 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"
                >
                  {copied ? (
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              )}

              {/* Close / View Original Button */}
              <button
                type="button"
                id={`post-close-translate-btn-${postId}`}
                onClick={() => setIsOpen(false)}
                title="원문 보기 (번역 닫기)"
                className="flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-semibold text-slate-600 hover:bg-slate-200/70 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white transition-colors cursor-pointer"
              >
                <span>원문 보기</span>
                <X className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Translation Body Content */}
          <div className="mt-2.5">
            {translationState.isLoading ? (
              <div className="py-2.5 space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-blue-600 dark:text-blue-400">
                  <div className="h-3 w-3 rounded-full border-2 border-blue-600 border-t-transparent animate-spin" />
                  <span>Gemini 3.7 Flash로 실시간 번역 중...</span>
                </div>
                <div className="h-3.5 bg-blue-200/50 dark:bg-blue-900/40 rounded-md animate-pulse w-4/5" />
                <div className="h-3.5 bg-blue-200/40 dark:bg-blue-900/30 rounded-md animate-pulse w-3/5" />
              </div>
            ) : translationState.error ? (
              <div className="flex items-start gap-2 rounded-lg bg-rose-50 p-2.5 text-xs text-rose-700 dark:bg-rose-950/40 dark:text-rose-300">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
                <div className="flex-1">
                  <p className="font-semibold">{translationState.error}</p>
                  <button
                    type="button"
                    onClick={() => handleTranslate(selectedLang)}
                    className="mt-1.5 inline-flex items-center gap-1 font-bold underline hover:text-rose-900 dark:hover:text-rose-100"
                  >
                    <RefreshCw className="w-3 h-3" /> 다시 시도
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-slate-900 dark:text-slate-100 text-sm md:text-base leading-relaxed whitespace-pre-wrap selection:bg-blue-100 dark:selection:bg-blue-900">
                {translationState.translatedText}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
