import React, { useState, useRef, useEffect } from 'react';
import { useSocial } from '../context/SocialContext';
import { StoryDraft, StoryBgm } from '../types';
import { formatRelativeTime } from '../utils/formatters';
import { StoryCanvasView } from './StoryCanvasView';
import { getStoryFilterName } from '../data/storyFiltersData';
import {
  FolderOpen,
  Trash2,
  Sparkles,
  Edit3,
  Play,
  Pause,
  Music,
  Search,
  Plus,
  Clock,
  VolumeX,
  ArrowRight,
  AlertTriangle,
  Layers,
  Wand2,
  Type,
  Smile,
  Film
} from 'lucide-react';

interface StoryDraftsListProps {
  onSelectDraft: (draft: StoryDraft) => void;
  onQuickPublishDraft: (draft: StoryDraft) => void;
  onNewStory: () => void;
}

export const StoryDraftsList: React.FC<StoryDraftsListProps> = ({
  onSelectDraft,
  onQuickPublishDraft,
  onNewStory
}) => {
  const { storyDrafts, deleteStoryDraft, clearAllStoryDrafts } = useSocial();
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest'>('newest');
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [previewingBgmId, setPreviewingBgmId] = useState<string | null>(null);

  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  // Stop audio on unmount
  useEffect(() => {
    return () => {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
        previewAudioRef.current = null;
      }
    };
  }, []);

  const handleTogglePreviewBgm = (bgm?: StoryBgm, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!bgm) return;

    if (previewingBgmId === bgm.id) {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
      }
      setPreviewingBgmId(null);
    } else {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
      }
      const audio = new Audio(bgm.audioUrl);
      audio.volume = 0.6;
      audio.play().catch(() => {});
      audio.onended = () => {
        setPreviewingBgmId(null);
      };
      previewAudioRef.current = audio;
      setPreviewingBgmId(bgm.id);
    }
  };

  const filteredDrafts = storyDrafts
    .filter((draft) => {
      const q = searchQuery.toLowerCase().trim();
      if (!q) return true;
      const matchCaption = draft.caption?.toLowerCase().includes(q);
      const matchBgm = draft.bgm?.title.toLowerCase().includes(q) || draft.bgm?.artist.toLowerCase().includes(q);
      return matchCaption || matchBgm;
    })
    .sort((a, b) => {
      const timeA = new Date(a.savedAt).getTime();
      const timeB = new Date(b.savedAt).getTime();
      return sortBy === 'newest' ? timeB - timeA : timeA - timeB;
    });

  const handleClearAll = () => {
    clearAllStoryDrafts();
    setShowClearConfirm(false);
  };

  return (
    <div id="story-drafts-container" className="flex flex-col h-full overflow-hidden">
      {/* Search and Sort Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pb-3 border-b border-slate-100 dark:border-slate-800 shrink-0">
        {/* Search input */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="초안 문구 또는 배경음악 검색..."
            className="w-full pl-9 pr-3 py-1.5 text-xs sm:text-sm rounded-lg border border-slate-200 bg-slate-50 text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:bg-white focus:text-slate-900 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500 transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              ✕
            </button>
          )}
        </div>

        {/* Filter controls */}
        <div className="flex items-center justify-between sm:justify-end gap-2 shrink-0">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'newest' | 'oldest')}
            className="text-xs rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 focus:outline-none"
          >
            <option value="newest">최신 저장순</option>
            <option value="oldest">오래된 순</option>
          </select>

          {storyDrafts.length > 0 && (
            <button
              type="button"
              onClick={() => setShowClearConfirm((prev) => !prev)}
              className="text-xs text-rose-500 hover:text-rose-600 dark:text-rose-400 font-medium px-2 py-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">전체 비우기</span>
            </button>
          )}
        </div>
      </div>

      {/* Clear Confirmation Prompt */}
      {showClearConfirm && (
        <div className="my-2 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 flex items-center justify-between gap-3 animate-in fade-in duration-150">
          <div className="flex items-center gap-2 text-xs text-rose-800 dark:text-rose-200 font-medium">
            <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
            <span>저장된 모든 스토리 초안({storyDrafts.length}개)을 삭제하시겠습니까?</span>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setShowClearConfirm(false)}
              className="px-2.5 py-1 text-xs rounded-md bg-white text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 font-medium hover:bg-slate-50"
            >
              취소
            </button>
            <button
              type="button"
              onClick={handleClearAll}
              className="px-2.5 py-1 text-xs rounded-md bg-rose-600 text-white font-semibold hover:bg-rose-700 shadow-xs"
            >
              모두 삭제
            </button>
          </div>
        </div>
      )}

      {/* Drafts List Grid / Empty State */}
      <div className="flex-1 overflow-y-auto pr-1 py-3 space-y-3">
        {filteredDrafts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 px-4 text-center">
            <div className="h-14 w-14 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-center justify-center text-amber-500 mb-3 shadow-xs">
              <FolderOpen className="w-7 h-7" />
            </div>
            <h4 className="text-sm sm:text-base font-bold text-slate-800 dark:text-white">
              {searchQuery ? '검색된 스토리 초안이 없습니다' : '저장된 스토리 초안이 없습니다'}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs leading-relaxed">
              {searchQuery
                ? '다른 검색어로 다시 시도해보세요.'
                : '스토리 에디터에서 사진, BGM, 문구를 작성한 후 [초안 저장] 버튼을 누르면 언제든 다시 불러올 수 있습니다.'}
            </p>
            <button
              type="button"
              onClick={onNewStory}
              className="mt-4 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold shadow-md shadow-blue-600/20 flex items-center gap-1.5 active:scale-95 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>새 스토리 작성하기</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredDrafts.map((draft) => {
              const isBgmPlaying = previewingBgmId === draft.bgm?.id;

              return (
                <div
                  key={draft.id}
                  id={`draft-card-${draft.id}`}
                  className="group relative flex flex-col rounded-xl border border-slate-200/90 bg-white p-3 shadow-xs hover:border-blue-400 hover:shadow-md transition-all dark:border-slate-800 dark:bg-slate-850 dark:hover:border-blue-500/70"
                >
                  {/* Top Header: Timestamp & Delete Button */}
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100 dark:border-slate-800/80">
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{formatRelativeTime(draft.savedAt)} 저장됨</span>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteStoryDraft(draft.id);
                      }}
                      title="초안 삭제"
                      className="text-slate-400 hover:text-rose-500 dark:hover:text-rose-400 p-1 rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Visual Preview Box */}
                  <div
                    onClick={() => onSelectDraft(draft)}
                    className="relative h-44 w-full rounded-lg overflow-hidden bg-slate-950 flex items-center justify-center cursor-pointer group-hover:ring-2 group-hover:ring-blue-500/50 transition-all shadow-inner"
                  >
                    <StoryCanvasView
                      mediaUrl={draft.mediaUrl}
                      mediaType={draft.mediaType}
                      filterId={draft.filterId}
                      textOverlays={draft.textOverlays}
                      stickerOverlays={draft.stickerOverlays}
                      interactive={false}
                      className="h-full w-full"
                    />

                    {/* Gradient Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40 pointer-events-none" />

                    {/* Top Right Badges: Media Type & Filter & Overlays info */}
                    <div className="absolute top-2 right-2 z-10 flex items-center gap-1 pointer-events-none">
                      {(draft.mediaType === 'video' || /\.(mp4|mov|webm|mkv|3gp|avi|m4v)(\?.*)?$/i.test(draft.mediaUrl) || draft.mediaUrl.startsWith('data:video/')) && (
                        <span className="px-1.5 py-0.5 rounded-md bg-emerald-900/80 backdrop-blur-md border border-emerald-400/40 text-emerald-200 text-[9px] font-bold flex items-center gap-0.5">
                          <Film className="w-2.5 h-2.5 text-emerald-300" />
                          <span>동영상</span>
                        </span>
                      )}
                      {draft.filterId && draft.filterId !== 'normal' && (
                        <span className="px-1.5 py-0.5 rounded-md bg-purple-900/80 backdrop-blur-md border border-purple-400/40 text-purple-200 text-[9px] font-bold">
                          {getStoryFilterName(draft.filterId)}
                        </span>
                      )}
                      {(draft.textOverlays?.length || 0) > 0 && (
                        <span className="px-1.5 py-0.5 rounded-md bg-blue-900/80 backdrop-blur-md border border-blue-400/40 text-blue-200 text-[9px] font-bold flex items-center gap-0.5">
                          <Type className="w-2.5 h-2.5" />
                          <span>{draft.textOverlays?.length}</span>
                        </span>
                      )}
                      {(draft.stickerOverlays?.length || 0) > 0 && (
                        <span className="px-1.5 py-0.5 rounded-md bg-pink-900/80 backdrop-blur-md border border-pink-400/40 text-pink-200 text-[9px] font-bold flex items-center gap-0.5">
                          <Smile className="w-2.5 h-2.5" />
                          <span>{draft.stickerOverlays?.length}</span>
                        </span>
                      )}
                    </div>

                    {/* BGM Badge on preview with quick preview audio trigger */}
                    {draft.bgm ? (
                      <div
                        onClick={(e) => handleTogglePreviewBgm(draft.bgm, e)}
                        className="absolute top-2 left-2 z-10 flex items-center justify-between px-2.5 py-1 rounded-full bg-black/60 hover:bg-black/80 backdrop-blur-md border border-white/20 text-white text-[11px] shadow-sm transition-all max-w-[65%]"
                        title={isBgmPlaying ? '음악 멈춤' : '음악 미리듣기'}
                      >
                        <div className="flex items-center gap-1.5 min-w-0 truncate">
                          <Music className={`w-3 h-3 text-amber-300 shrink-0 ${isBgmPlaying ? 'animate-spin' : ''}`} />
                          <span className="font-semibold text-amber-100 truncate">{draft.bgm.title}</span>
                          <span className="text-[10px] text-white/70 truncate hidden sm:inline">• {draft.bgm.artist}</span>
                        </div>

                        <div className="h-4 w-4 rounded-full bg-white/20 flex items-center justify-center shrink-0 ml-1">
                          {isBgmPlaying ? (
                            <Pause className="w-2 h-2 fill-current text-amber-300" />
                          ) : (
                            <Play className="w-2 h-2 fill-current ml-0.5 text-white" />
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10 text-white/70 text-[10px]">
                        <VolumeX className="w-2.5 h-2.5" />
                        <span>BGM 없음</span>
                      </div>
                    )}

                    {/* Caption Preview Text overlay */}
                    {draft.caption && (
                      <div className="absolute bottom-2 left-2 right-2 rounded-lg bg-black/60 p-1.5 text-center text-xs font-medium text-white backdrop-blur-sm border border-white/10 shadow-xs line-clamp-1">
                        {draft.caption}
                      </div>
                    )}

                    {/* Hover Load Overlay Banner */}
                    <div className="absolute inset-0 bg-blue-600/30 opacity-0 group-hover:opacity-100 backdrop-blur-[1px] flex items-center justify-center text-white font-bold text-xs transition-opacity pointer-events-none">
                      <div className="px-3 py-1.5 rounded-full bg-black/70 backdrop-blur-md border border-white/30 flex items-center gap-1 shadow-lg">
                        <Edit3 className="w-3.5 h-3.5 text-blue-300" />
                        <span>에디터로 불러오기</span>
                      </div>
                    </div>
                  </div>

                  {/* Caption Summary Text */}
                  <div className="mt-2.5 flex-1 min-h-[36px]">
                    <p className="text-xs text-slate-700 dark:text-slate-300 font-medium line-clamp-2">
                      {draft.caption ? (
                        draft.caption
                      ) : (
                        <span className="italic text-slate-400 dark:text-slate-500">문구 없이 사진만 저장됨</span>
                      )}
                    </p>
                  </div>

                  {/* Card Bottom Actions */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => onSelectDraft(draft)}
                      className="flex-1 py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <Edit3 className="w-3 h-3 text-blue-500" />
                      <span>불러와서 편집</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onQuickPublishDraft(draft)}
                      className="py-1.5 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-center gap-1 shadow-xs shadow-blue-600/20 active:scale-95 transition-all"
                      title="이 초안을 지금 바로 24시간 스토리로 공유합니다"
                    >
                      <Sparkles className="w-3 h-3 text-amber-300" />
                      <span>바로 공유</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Bottom Summary Bar */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 shrink-0">
        <div className="flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-blue-500" />
          <span>총 <strong>{storyDrafts.length}</strong>개의 초안 보관 중</span>
        </div>
        <button
          type="button"
          onClick={onNewStory}
          className="text-blue-600 dark:text-blue-400 hover:underline font-semibold flex items-center gap-1"
        >
          <span>새 스토리 직접 작성하기</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
