import React, { useState, useRef, useEffect } from 'react';
import { useSocial } from '../context/SocialContext';
import { Sun, Moon, Laptop, Check, ChevronDown, Sparkles } from 'lucide-react';
import { ThemeMode } from '../types';

interface ThemeSwitchMenuProps {
  idPrefix?: string;
  variant?: 'header' | 'sidebar' | 'mobile' | 'segmented';
  className?: string;
}

export const ThemeSwitchMenu: React.FC<ThemeSwitchMenuProps> = ({
  idPrefix = 'theme',
  variant = 'header',
  className = ''
}) => {
  const {
    themeMode,
    isDarkMode,
    systemPrefersDark,
    setThemeMode,
    toggleDarkMode,
    triggerSystemThemeNotice
  } = useSocial();

  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleSelectMode = (mode: ThemeMode) => {
    setThemeMode(mode);
    setIsOpen(false);
  };

  const getThemeTitle = () => {
    if (themeMode === 'system') {
      return `시스템 자동 감지 중 (${isDarkMode ? '밤/다크' : '낮/라이트'} 모드 작동)`;
    }
    return themeMode === 'dark' ? '다크 모드 (밤 모드)' : '라이트 모드 (낮 모드)';
  };

  // 1. Segmented Control variant (useful for settings / full controls)
  if (variant === 'segmented') {
    return (
      <div
        id={`${idPrefix}-segmented-group`}
        className={`inline-flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 ${className}`}
      >
        <button
          type="button"
          id={`${idPrefix}-opt-system`}
          onClick={() => handleSelectMode('system')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            themeMode === 'system'
              ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
          title="OS 시스템 테마 설정에 따라 낮/밤 모드를 자동 전환합니다"
        >
          <Laptop className="w-3.5 h-3.5" />
          <span>자동 ({systemPrefersDark ? '밤' : '낮'})</span>
        </button>

        <button
          type="button"
          id={`${idPrefix}-opt-light`}
          onClick={() => handleSelectMode('light')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            themeMode === 'light'
              ? 'bg-white dark:bg-slate-700 text-amber-500 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
          title="항상 밝은 라이트(낮) 모드를 유지합니다"
        >
          <Sun className="w-3.5 h-3.5" />
          <span>낮 모드</span>
        </button>

        <button
          type="button"
          id={`${idPrefix}-opt-dark`}
          onClick={() => handleSelectMode('dark')}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
            themeMode === 'dark'
              ? 'bg-white dark:bg-slate-700 text-indigo-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
          title="항상 어두운 다크(밤) 모드를 유지합니다"
        >
          <Moon className="w-3.5 h-3.5" />
          <span>밤 모드</span>
        </button>
      </div>
    );
  }

  // 2. Default dropdown button with popover options
  return (
    <div ref={menuRef} className={`relative inline-block text-left ${className}`}>
      <div className="flex items-center">
        {/* Main Cycle Toggle Button */}
        <button
          id={`${idPrefix}-toggle-btn`}
          type="button"
          onClick={toggleDarkMode}
          onContextMenu={(e) => {
            e.preventDefault();
            setIsOpen((prev) => !prev);
          }}
          title={`${getThemeTitle()} • 클릭: 모드 전환 (자동 ➔ 낮 ➔ 밤) • 우클릭/더보기: 상세 선택`}
          aria-label={getThemeTitle()}
          className={`relative flex items-center justify-center transition-all active:scale-95 ${
            variant === 'sidebar'
              ? 'h-9 w-9 rounded-xl border border-slate-200 bg-white text-slate-700 shadow-xs hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
              : variant === 'mobile'
              ? 'h-8 w-8 rounded-lg border border-neutral-200 bg-white text-neutral-700 shadow-xs hover:bg-neutral-100 dark:border-neutral-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-neutral-800'
              : 'p-2 rounded-xl text-slate-600 hover:bg-slate-100 hover:text-indigo-600 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors'
          }`}
        >
          {themeMode === 'system' ? (
            <div className="relative flex items-center justify-center">
              <Laptop className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
              <span
                className="absolute -top-1 -right-1 flex h-2 w-2"
                title="시스템 자동 감지 중"
              >
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-600"></span>
              </span>
            </div>
          ) : isDarkMode ? (
            <Moon className="h-4 w-4 text-amber-400 dark:text-amber-300 animate-in spin-in-180 duration-300" />
          ) : (
            <Sun className="h-4 w-4 text-amber-500 animate-in spin-in-180 duration-300" />
          )}
        </button>

        {/* Small Dropdown Arrow Button */}
        <button
          id={`${idPrefix}-menu-trigger`}
          type="button"
          onClick={() => setIsOpen((prev) => !prev)}
          title="테마 선택 메뉴 열기 (시스템 자동/낮/밤)"
          aria-label="테마 선택 메뉴 열기"
          aria-expanded={isOpen}
          className={`-ml-1 flex items-center justify-center rounded-r-lg p-1 text-slate-400 hover:text-slate-700 dark:text-slate-500 dark:hover:text-slate-200 transition-colors ${
            isOpen ? 'text-indigo-600 dark:text-indigo-400' : ''
          }`}
        >
          <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {/* Popover Menu */}
      {isOpen && (
        <div
          id={`${idPrefix}-dropdown-menu`}
          className="absolute right-0 top-full mt-2 w-64 origin-top-right rounded-2xl border border-slate-200 bg-white/95 p-1.5 shadow-xl backdrop-blur-md ring-1 ring-black/5 dark:border-slate-800 dark:bg-slate-900/95 dark:ring-white/10 z-50 animate-in fade-in-0 zoom-in-95 duration-150"
        >
          <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800/80 mb-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                테마 모드 설정
              </span>
              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-indigo-500" />
                자동 전환
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              사용자의 시스템 설정에 맞춰 자동으로 낮/밤을 변경합니다.
            </p>
          </div>

          <div className="space-y-0.5">
            {/* 1. System Mode */}
            <button
              type="button"
              id={`${idPrefix}-select-system`}
              onClick={() => handleSelectMode('system')}
              className={`flex w-full items-center justify-between gap-2.5 rounded-xl px-3 py-2 text-left text-xs font-medium transition-colors ${
                themeMode === 'system'
                  ? 'bg-indigo-50 text-indigo-600 font-bold dark:bg-indigo-950/50 dark:text-indigo-400'
                  : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-100/70 text-indigo-600 dark:bg-indigo-900/40 dark:text-indigo-400">
                  <Laptop className="h-4 w-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span>시스템 자동 감지</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-indigo-100 text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300 font-semibold">
                      추천
                    </span>
                  </div>
                  <p className="text-[10px] font-normal text-slate-400 dark:text-slate-500">
                    현재 OS: {systemPrefersDark ? '밤(다크) 모드' : '낮(라이트) 모드'} 감지됨
                  </p>
                </div>
              </div>
              {themeMode === 'system' && (
                <Check className="h-4 w-4 text-indigo-600 dark:text-indigo-400 flex-shrink-0" />
              )}
            </button>

            {/* 2. Light (Day) Mode */}
            <button
              type="button"
              id={`${idPrefix}-select-light`}
              onClick={() => handleSelectMode('light')}
              className={`flex w-full items-center justify-between gap-2.5 rounded-xl px-3 py-2 text-left text-xs font-medium transition-colors ${
                themeMode === 'light'
                  ? 'bg-amber-50 text-amber-600 font-bold dark:bg-amber-950/40 dark:text-amber-400'
                  : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-100/70 text-amber-600 dark:bg-amber-900/40 dark:text-amber-400">
                  <Sun className="h-4 w-4" />
                </div>
                <div>
                  <span>라이트 모드 (낮)</span>
                  <p className="text-[10px] font-normal text-slate-400 dark:text-slate-500">
                    밝은 흰색 배경 유지
                  </p>
                </div>
              </div>
              {themeMode === 'light' && (
                <Check className="h-4 w-4 text-amber-600 dark:text-amber-400 flex-shrink-0" />
              )}
            </button>

            {/* 3. Dark (Night) Mode */}
            <button
              type="button"
              id={`${idPrefix}-select-dark`}
              onClick={() => handleSelectMode('dark')}
              className={`flex w-full items-center justify-between gap-2.5 rounded-xl px-3 py-2 text-left text-xs font-medium transition-colors ${
                themeMode === 'dark'
                  ? 'bg-indigo-50 text-indigo-600 font-bold dark:bg-indigo-950/50 dark:text-indigo-400'
                  : 'text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/80'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-100/70 text-indigo-600 dark:bg-indigo-900/40 dark:text-indigo-400">
                  <Moon className="h-4 w-4" />
                </div>
                <div>
                  <span>다크 모드 (밤)</span>
                  <p className="text-[10px] font-normal text-slate-400 dark:text-slate-500">
                    눈이 편안한 어두운 배경 유지
                  </p>
                </div>
              </div>
              {themeMode === 'dark' && (
                <Check className="h-4 w-4 text-indigo-600 dark:text-indigo-400 flex-shrink-0" />
              )}
            </button>
          </div>

          {/* Test Simulation Quick Trigger */}
          <div className="mt-1.5 pt-1.5 border-t border-slate-100 dark:border-slate-800/80 px-2 py-1 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span>시스템 전환 알림 테스트:</span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                id={`${idPrefix}-test-sim-light`}
                onClick={() => {
                  triggerSystemThemeNotice('light');
                  setIsOpen(false);
                }}
                className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-amber-600 font-semibold transition-colors cursor-pointer"
                title="시스템 낮 모드 전환 알림 테스트"
              >
                ☀️ 낮
              </button>
              <button
                type="button"
                id={`${idPrefix}-test-sim-dark`}
                onClick={() => {
                  triggerSystemThemeNotice('dark');
                  setIsOpen(false);
                }}
                className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-indigo-500 font-semibold transition-colors cursor-pointer"
                title="시스템 밤 모드 전환 알림 테스트"
              >
                🌙 밤
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
