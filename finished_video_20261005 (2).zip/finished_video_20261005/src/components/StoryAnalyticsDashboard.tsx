import React, { useState, useMemo } from 'react';
import {
  Eye,
  Heart,
  Clock,
  TrendingUp,
  Users,
  Smartphone,
  Monitor,
  Tablet,
  Sparkles,
  BarChart3,
  PieChart as PieIcon,
  X,
  MessageCircle,
  CheckCircle2,
  Timer,
  Smile,
  Flame,
  ThumbsUp,
  Percent,
  Award,
  Filter,
  ArrowRight
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { StoryViewer, StoryReaction } from '../types';
import { formatRelativeTime } from '../utils/formatters';

interface StoryAnalyticsDashboardProps {
  viewers: StoryViewer[];
  reactions?: StoryReaction[];
  totalStoryDurationSeconds?: number;
  onSimulateView?: () => void;
  onSimulateReaction?: (emoji?: string) => void;
  onSendDm?: (viewer: StoryViewer) => void;
  onClose?: () => void;
}

interface EmotionMeta {
  label: string;
  name: string;
  color: string;
  bgColor: string;
  textColor: string;
  isPositive: boolean;
}

// Preset emotion styling & metadata dictionary
const EMOTION_CONFIG: Record<string, EmotionMeta> = {
  '❤️': {
    label: '하트',
    name: '하트 (사랑)',
    color: '#f43f5e', // rose-500
    bgColor: 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800/40',
    textColor: 'text-rose-600 dark:text-rose-400',
    isPositive: true
  },
  '👍': {
    label: '좋아요',
    name: '좋아요 (추천)',
    color: '#3b82f6', // blue-500
    bgColor: 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800/40',
    textColor: 'text-blue-600 dark:text-blue-400',
    isPositive: true
  },
  '😂': {
    label: '웃음',
    name: '웃음 (재미)',
    color: '#f59e0b', // amber-500
    bgColor: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800/40',
    textColor: 'text-amber-600 dark:text-amber-400',
    isPositive: true
  },
  '🔥': {
    label: '불꽃',
    name: '불꽃 (열광)',
    color: '#ef4444', // red-500
    bgColor: 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800/40',
    textColor: 'text-red-600 dark:text-red-400',
    isPositive: true
  },
  '😍': {
    label: '반함',
    name: '반함 (설렘)',
    color: '#ec4899', // pink-500
    bgColor: 'bg-pink-50 dark:bg-pink-950/40 border-pink-200 dark:border-pink-800/40',
    textColor: 'text-pink-600 dark:text-pink-400',
    isPositive: true
  },
  '👏': {
    label: '박수',
    name: '박수 (응원)',
    color: '#8b5cf6', // violet-500
    bgColor: 'bg-violet-50 dark:bg-violet-950/40 border-violet-200 dark:border-violet-800/40',
    textColor: 'text-violet-600 dark:text-violet-400',
    isPositive: true
  },
  '😮': {
    label: '놀람',
    name: '놀람 (감탄)',
    color: '#06b6d4', // cyan-500
    bgColor: 'bg-cyan-50 dark:bg-cyan-950/40 border-cyan-200 dark:border-cyan-800/40',
    textColor: 'text-cyan-600 dark:text-cyan-400',
    isPositive: true
  },
  '🎉': {
    label: '축하',
    name: '축하 (환호)',
    color: '#10b981', // emerald-500
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/40',
    textColor: 'text-emerald-600 dark:text-emerald-400',
    isPositive: true
  },
  '💯': {
    label: '최고',
    name: '최고 (완벽)',
    color: '#6366f1', // indigo-500
    bgColor: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800/40',
    textColor: 'text-indigo-600 dark:text-indigo-400',
    isPositive: true
  },
  '🙌': {
    label: '만세',
    name: '만세 (열광)',
    color: '#14b8a6', // teal-500
    bgColor: 'bg-teal-50 dark:bg-teal-950/40 border-teal-200 dark:border-teal-800/40',
    textColor: 'text-teal-600 dark:text-teal-400',
    isPositive: true
  }
};

const getEmotionMeta = (emoji: string): EmotionMeta => {
  return (
    EMOTION_CONFIG[emoji] || {
      label: '공감',
      name: `${emoji} 공감`,
      color: '#64748b',
      bgColor: 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700',
      textColor: 'text-slate-600 dark:text-slate-300',
      isPositive: true
    }
  );
};

export const StoryAnalyticsDashboard: React.FC<StoryAnalyticsDashboardProps> = ({
  viewers,
  reactions = [],
  totalStoryDurationSeconds = 5,
  onSimulateView,
  onSimulateReaction,
  onSendDm,
  onClose
}) => {
  // Default to 'reactions' tab to directly spotlight the requested Emotion Reaction Analysis chart
  const [activeTab, setActiveTab] = useState<'reactions' | 'viewers' | 'retention'>('reactions');
  const [chartViewMode, setChartViewMode] = useState<'bar' | 'donut' | 'both'>('both');
  const [selectedEmojiFilter, setSelectedEmojiFilter] = useState<string | null>(null);
  const [filterQuery, setFilterQuery] = useState('');

  // 1. Gather all reactions: direct reactions + any reactionEmoji recorded on viewers
  const consolidatedReactions = useMemo(() => {
    const list: StoryReaction[] = [...reactions];
    viewers.forEach((v) => {
      if (v.reactionEmoji && !list.some((r) => r.userId === v.userId && r.emoji === v.reactionEmoji)) {
        list.push({
          id: `react_v_${v.userId}_${Date.now()}`,
          userId: v.userId,
          userName: v.userName,
          userAvatar: v.userAvatar,
          emoji: v.reactionEmoji,
          createdAt: v.viewedAt
        });
      }
    });
    return list;
  }, [reactions, viewers]);

  const totalViews = viewers.length;
  const totalReactions = consolidatedReactions.length;

  // 2. Aggregate Emotion Breakdown for Visualization
  const { emotionChartData, topReaction, secondReaction, positiveRate, engagementRate } = useMemo(() => {
    const map: Record<
      string,
      {
        emoji: string;
        count: number;
        users: Array<{ id: string; name: string; avatar: string; time: string }>;
      }
    > = {};

    consolidatedReactions.forEach((r) => {
      if (!map[r.emoji]) {
        map[r.emoji] = {
          emoji: r.emoji,
          count: 0,
          users: []
        };
      }
      map[r.emoji].count += 1;
      map[r.emoji].users.push({
        id: r.userId,
        name: r.userName,
        avatar: r.userAvatar,
        time: r.createdAt
      });
    });

    // Sort descending by count: highest reaction first
    const sorted = Object.values(map).sort((a, b) => b.count - a.count);

    const totalCount = consolidatedReactions.length;

    const chartData = sorted.map((item) => {
      const meta = getEmotionMeta(item.emoji);
      const percentage = totalCount > 0 ? Math.round((item.count / totalCount) * 100) : 0;
      return {
        emoji: item.emoji,
        label: meta.label,
        displayName: `${item.emoji} ${meta.label}`,
        fullName: meta.name,
        count: item.count,
        percentage,
        color: meta.color,
        users: item.users
      };
    });

    // KPI Highlights
    const top = chartData[0] || null;
    const second = chartData[1] || null;

    const positiveReactionsCount = consolidatedReactions.filter(
      (r) => getEmotionMeta(r.emoji).isPositive
    ).length;

    const positiveScore =
      totalCount > 0 ? Math.round((positiveReactionsCount / totalCount) * 100) : 100;

    const engagement =
      totalViews > 0 ? Math.round((totalCount / totalViews) * 100) : 0;

    return {
      emotionChartData: chartData,
      topReaction: top,
      secondReaction: second,
      positiveRate: positiveScore,
      engagementRate: engagement
    };
  }, [consolidatedReactions, totalViews]);

  // 3. Watch Duration and Retention calculations
  const calculatedDurations = viewers.map((v) => {
    if (v.watchDurationSeconds !== undefined) return v.watchDurationSeconds;
    const seed = (v.userId.charCodeAt(v.userId.length - 1) || 3) % 4;
    return Math.min(totalStoryDurationSeconds, 3.2 + seed * 0.5);
  });

  const avgDuration =
    totalViews > 0
      ? (calculatedDurations.reduce((a, b) => a + b, 0) / totalViews).toFixed(1)
      : '0.0';

  const avgCompletionRate =
    totalViews > 0
      ? Math.min(
          100,
          Math.round((parseFloat(avgDuration) / totalStoryDurationSeconds) * 100)
        )
      : 0;

  const retentionBuckets = [
    { label: '0 ~ 25% (이탈)', count: 0, color: 'bg-rose-500' },
    { label: '25 ~ 50%', count: 0, color: 'bg-amber-500' },
    { label: '50 ~ 75%', count: 0, color: 'bg-blue-500' },
    { label: '75 ~ 100% (완료)', count: 0, color: 'bg-emerald-500' }
  ];

  viewers.forEach((v) => {
    const dur = v.watchDurationSeconds ?? 4.5;
    const rate = (dur / totalStoryDurationSeconds) * 100;
    if (rate <= 25) retentionBuckets[0].count++;
    else if (rate <= 50) retentionBuckets[1].count++;
    else if (rate <= 75) retentionBuckets[2].count++;
    else retentionBuckets[3].count++;
  });

  const deviceCounts = {
    mobile: 0,
    desktop: 0,
    tablet: 0
  };
  viewers.forEach((v) => {
    const dev = v.deviceType || 'mobile';
    deviceCounts[dev] = (deviceCounts[dev] || 0) + 1;
  });

  // Filtered reactions list according to selected emoji filter
  const displayedReactions = useMemo(() => {
    if (!selectedEmojiFilter) return consolidatedReactions;
    return consolidatedReactions.filter((r) => r.emoji === selectedEmojiFilter);
  }, [consolidatedReactions, selectedEmojiFilter]);

  // Filtered viewers list
  const filteredViewers = viewers.filter(
    (v) =>
      v.userName.toLowerCase().includes(filterQuery.toLowerCase()) ||
      (v.userHandle && v.userHandle.toLowerCase().includes(filterQuery.toLowerCase()))
  );

  return (
    <div
      id="story-analytics-dashboard-panel"
      className="flex flex-col h-full max-h-[85vh] bg-white/98 dark:bg-slate-900/98 text-slate-900 dark:text-white rounded-t-2xl shadow-2xl backdrop-blur-2xl border-t border-slate-200 dark:border-slate-800 transition-colors"
      onClick={(e) => e.stopPropagation()}
    >
      {/* 1. Header Bar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100 dark:border-slate-800 shrink-0">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-tr from-rose-500 via-amber-500 to-blue-600 text-white shadow-sm">
            <Smile className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              스토리 감정 반응 & 통계 대시보드
              <span className="px-1.5 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-300 text-[10px] font-semibold border border-rose-200/70 dark:border-rose-800/40">
                실시간 분석
              </span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              사용자들이 남긴 좋아요, 하트, 웃음 등의 반응 비율과 감정 순위를 시각화합니다.
            </p>
          </div>
        </div>

        {onClose && (
          <button
            type="button"
            id="story-analytics-close-btn"
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-700 dark:hover:text-white transition-colors cursor-pointer"
            title="대시보드 닫기"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* 2. Top Metric KPI Cards */}
      <div className="p-3 sm:p-4 grid grid-cols-3 gap-2 sm:gap-3 bg-slate-50/60 dark:bg-slate-950/40 border-b border-slate-100 dark:border-slate-800/80 shrink-0">
        {/* Metric 1: Total Reactions & Top Reaction */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/60 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-[11px] font-medium">총 감정 반응</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500/30" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1">
            <span className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {totalReactions}
            </span>
            <span className="text-[10px] font-medium text-slate-500">개</span>
          </div>
          <div className="mt-1 text-[10px] text-rose-600 dark:text-rose-400 font-medium truncate flex items-center gap-1">
            {topReaction ? (
              <>
                <Award className="w-2.5 h-2.5 shrink-0 text-amber-500" />
                <span className="truncate">
                  1위 {topReaction.displayName} ({topReaction.count}개)
                </span>
              </>
            ) : (
              <span>반응 대기 중</span>
            )}
          </div>
        </div>

        {/* Metric 2: Total Views */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/60 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-[11px] font-medium">총 조회수</span>
            <Eye className="w-3.5 h-3.5 text-blue-500" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1">
            <span className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {totalViews}
            </span>
            <span className="text-[10px] font-medium text-slate-500">명</span>
          </div>
          <div className="mt-1 text-[10px] text-blue-600 dark:text-blue-400 font-medium flex items-center gap-0.5">
            <TrendingUp className="w-2.5 h-2.5" />
            <span>반응률 {engagementRate}%</span>
          </div>
        </div>

        {/* Metric 3: Positive Sentiment Index */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/60 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
            <span className="text-[11px] font-medium">긍정 호감도</span>
            <Smile className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="mt-1.5 flex items-baseline gap-1">
            <span className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              {positiveRate}%
            </span>
          </div>
          <div className="mt-1 text-[10px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-0.5">
            <CheckCircle2 className="w-2.5 h-2.5" />
            <span>친밀도 높음</span>
          </div>
        </div>
      </div>

      {/* 3. Realtime Reaction Simulation Bar */}
      <div className="px-4 py-2 bg-gradient-to-r from-rose-50/80 via-amber-50/60 to-blue-50/80 dark:from-rose-950/20 dark:via-amber-950/20 dark:to-blue-950/20 border-b border-slate-200/60 dark:border-slate-800/60 flex flex-wrap items-center justify-between gap-2 text-xs shrink-0">
        <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 font-medium text-[11px]">
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>빠른 반응 추가 테스트:</span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          {onSimulateReaction && (
            <div className="flex items-center gap-1">
              {[
                { emoji: '❤️', label: '하트' },
                { emoji: '👍', label: '좋아요' },
                { emoji: '😂', label: '웃음' },
                { emoji: '🔥', label: '불꽃' },
                { emoji: '😍', label: '반함' },
                { emoji: '👏', label: '박수' }
              ].map(({ emoji, label }) => (
                <button
                  key={emoji}
                  type="button"
                  id={`simulate-reaction-btn-${label}`}
                  onClick={() => onSimulateReaction(emoji)}
                  className="px-2 py-1 rounded-lg bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs transition-all cursor-pointer border border-slate-200 dark:border-white/10 shadow-xs hover:scale-110 active:scale-95 flex items-center gap-1 font-medium"
                  title={`친구 ${label}(${emoji}) 반응 추가`}
                >
                  <span>{emoji}</span>
                  <span className="hidden sm:inline text-[10px] text-slate-600 dark:text-slate-300">
                    +{label}
                  </span>
                </button>
              ))}
            </div>
          )}
          {onSimulateView && (
            <button
              type="button"
              id="analytics-simulate-view-btn"
              onClick={onSimulateView}
              className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white font-semibold text-[11px] transition-all cursor-pointer border border-slate-200 dark:border-white/10 shadow-xs active:scale-95"
            >
              + 조회 시뮬레이션
            </button>
          )}
        </div>
      </div>

      {/* 4. Tab Navigation */}
      <div className="flex items-center px-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
        <button
          type="button"
          id="tab-btn-emotion-analysis"
          onClick={() => setActiveTab('reactions')}
          className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
            activeTab === 'reactions'
              ? 'border-rose-500 text-rose-600 dark:border-rose-400 dark:text-rose-400'
              : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" />
          <span>감정 반응 분석</span>
          <span className="px-1.5 py-0.2 rounded-full bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 text-[10px]">
            {totalReactions}
          </span>
        </button>

        <button
          type="button"
          id="tab-btn-viewers-list"
          onClick={() => setActiveTab('viewers')}
          className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
            activeTab === 'viewers'
              ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
              : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>조회자 목록</span>
          <span className="px-1.5 py-0.2 rounded-full bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-300 text-[10px]">
            {viewers.length}
          </span>
        </button>

        <button
          type="button"
          id="tab-btn-retention-analytics"
          onClick={() => setActiveTab('retention')}
          className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold border-b-2 transition-colors cursor-pointer ${
            activeTab === 'retention'
              ? 'border-indigo-600 text-indigo-600 dark:border-indigo-400 dark:text-indigo-400'
              : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
          }`}
        >
          <Timer className="w-3.5 h-3.5" />
          <span>시청 유지율</span>
        </button>
      </div>

      {/* 5. Scrollable Tab Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
        {/* ================================================================= */}
        {/* TAB: 감정 반응 분석 (Emotion Reaction Analysis Visual Charts) */}
        {/* ================================================================= */}
        {activeTab === 'reactions' && (
          <div className="space-y-4">
            {totalReactions === 0 ? (
              <div className="py-10 text-center text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center gap-2.5 bg-slate-50/50 dark:bg-slate-800/30 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 p-6">
                <div className="h-12 w-12 rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-500 flex items-center justify-center">
                  <Heart className="w-6 h-6 stroke-[1.5]" />
                </div>
                <h4 className="font-bold text-sm text-slate-700 dark:text-slate-200">
                  아직 도착한 감정 반응이 없습니다
                </h4>
                <p className="text-xs text-slate-400 dark:text-slate-400 max-w-xs leading-relaxed">
                  상단의 <span className="font-semibold text-rose-500">[+하트]</span>,{' '}
                  <span className="font-semibold text-blue-500">[+좋아요]</span>,{' '}
                  <span className="font-semibold text-amber-500">[+웃음]</span> 버튼을 눌러
                  실시간 감정 반응 분석 차트를 시각화해보세요!
                </p>
              </div>
            ) : (
              <>
                {/* Visual Chart Header & Mode Toggle Controls */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 p-3 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-700/50">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <BarChart3 className="w-3.5 h-3.5 text-rose-500" />
                      <span>사용자들이 가장 많이 남긴 반응 시각화</span>
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      총 {totalReactions}건의 감정 반응을 빈도 순서로 집계했습니다.
                    </p>
                  </div>

                  {/* Chart View Toggle: Bar / Donut / Both */}
                  <div className="flex items-center bg-white dark:bg-slate-800 p-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-[11px]">
                    <button
                      type="button"
                      onClick={() => setChartViewMode('bar')}
                      className={`px-2.5 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                        chartViewMode === 'bar'
                          ? 'bg-rose-500 text-white shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                      }`}
                    >
                      막대 차트
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartViewMode('donut')}
                      className={`px-2.5 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                        chartViewMode === 'donut'
                          ? 'bg-rose-500 text-white shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                      }`}
                    >
                      도넛 차트
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartViewMode('both')}
                      className={`px-2.5 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                        chartViewMode === 'both'
                          ? 'bg-rose-500 text-white shadow-xs'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                      }`}
                    >
                      모두 보기
                    </button>
                  </div>
                </div>

                {/* Top Highlights Summary Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {/* 1st Top Reaction */}
                  <div className="p-2.5 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200/80 dark:border-rose-800/40">
                    <div className="flex items-center justify-between text-rose-600 dark:text-rose-400 text-[11px] font-bold">
                      <span className="flex items-center gap-1">
                        <Award className="w-3 h-3 text-amber-500" />
                        1위 최다 반응
                      </span>
                      <span className="text-xs">{topReaction?.percentage}%</span>
                    </div>
                    <div className="mt-1 flex items-center gap-1.5">
                      <span className="text-xl">{topReaction?.emoji}</span>
                      <div>
                        <p className="text-xs font-extrabold text-slate-900 dark:text-white leading-tight">
                          {topReaction?.label}
                        </p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">
                          {topReaction?.count}건 참여
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* 2nd Reaction */}
                  <div className="p-2.5 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-800/40">
                    <div className="flex items-center justify-between text-blue-600 dark:text-blue-400 text-[11px] font-bold">
                      <span>2위 반응</span>
                      <span className="text-xs">{secondReaction ? `${secondReaction.percentage}%` : '-'}</span>
                    </div>
                    <div className="mt-1 flex items-center gap-1.5">
                      <span className="text-xl">{secondReaction?.emoji || '💬'}</span>
                      <div>
                        <p className="text-xs font-extrabold text-slate-900 dark:text-white leading-tight">
                          {secondReaction?.label || '단일 반응'}
                        </p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400">
                          {secondReaction ? `${secondReaction.count}건 참여` : '없음'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Positive Rate */}
                  <div className="p-2.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-800/40">
                    <div className="flex items-center justify-between text-amber-700 dark:text-amber-400 text-[11px] font-bold">
                      <span>긍정 감정 지수</span>
                      <Smile className="w-3 h-3" />
                    </div>
                    <div className="mt-1">
                      <p className="text-base font-extrabold text-slate-900 dark:text-white leading-tight">
                        {positiveRate}%
                      </p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        호감 & 공감 반응 비율
                      </p>
                    </div>
                  </div>

                  {/* Reaction Diversity */}
                  <div className="p-2.5 rounded-xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200/80 dark:border-purple-800/40">
                    <div className="flex items-center justify-between text-purple-700 dark:text-purple-400 text-[11px] font-bold">
                      <span>감정 다양성</span>
                      <Sparkles className="w-3 h-3" />
                    </div>
                    <div className="mt-1">
                      <p className="text-base font-extrabold text-slate-900 dark:text-white leading-tight">
                        {emotionChartData.length}가지
                      </p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        서로 다른 반응 유형
                      </p>
                    </div>
                  </div>
                </div>

                {/* Main Charts Area: Recharts BarChart & Donut Chart */}
                <div
                  className={`grid gap-3 ${
                    chartViewMode === 'both' ? 'grid-cols-1 lg:grid-cols-12' : 'grid-cols-1'
                  }`}
                >
                  {/* Chart 1: Horizontal Bar Chart (Frequency Ranking) */}
                  {(chartViewMode === 'bar' || chartViewMode === 'both') && (
                    <div
                      className={`p-3.5 rounded-2xl bg-white dark:bg-slate-800/70 border border-slate-200/80 dark:border-slate-700/60 shadow-xs flex flex-col ${
                        chartViewMode === 'both' ? 'lg:col-span-7' : 'w-full'
                      }`}
                    >
                      <div className="flex items-center justify-between pb-2 mb-1 border-b border-slate-100 dark:border-slate-700/50">
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                          <BarChart3 className="w-3.5 h-3.5 text-blue-500" />
                          감정 반응 순위 막대 차트
                        </span>
                        <span className="text-[10px] text-slate-400">
                          높은 순서대로 정렬됨
                        </span>
                      </div>

                      <div className="w-full h-56 mt-2">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            layout="vertical"
                            data={emotionChartData}
                            margin={{ top: 5, right: 30, left: 15, bottom: 5 }}
                          >
                            <XAxis
                              type="number"
                              allowDecimals={false}
                              tickLine={false}
                              axisLine={false}
                              tick={{ fill: '#94a3b8', fontSize: 11 }}
                            />
                            <YAxis
                              type="category"
                              dataKey="displayName"
                              tickLine={false}
                              axisLine={false}
                              tick={{ fill: '#334155', fontSize: 12, fontWeight: 600 }}
                              width={75}
                            />
                            <Tooltip
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  const d = payload[0].payload;
                                  return (
                                    <div className="p-2.5 rounded-xl bg-slate-900/95 text-white border border-white/15 shadow-xl text-xs backdrop-blur-md">
                                      <div className="flex items-center gap-1.5 font-bold">
                                        <span className="text-base">{d.emoji}</span>
                                        <span>{d.fullName}</span>
                                      </div>
                                      <div className="mt-1 flex items-center justify-between gap-4 text-slate-300 text-[11px]">
                                        <span>반응 수:</span>
                                        <strong className="text-white font-bold">{d.count}건</strong>
                                      </div>
                                      <div className="flex items-center justify-between gap-4 text-slate-300 text-[11px]">
                                        <span>전체 점유율:</span>
                                        <strong className="text-rose-400 font-bold">{d.percentage}%</strong>
                                      </div>
                                      {d.users && d.users.length > 0 && (
                                        <div className="mt-1.5 pt-1.5 border-t border-white/10 text-[10px] text-slate-400">
                                          <span>남긴 친구: </span>
                                          <span className="text-slate-200">
                                            {d.users.map((u: any) => u.name).slice(0, 3).join(', ')}
                                            {d.users.length > 3 ? ` 외 ${d.users.length - 3}명` : ''}
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <Bar dataKey="count" radius={[0, 6, 6, 0]}>
                              {emotionChartData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}

                  {/* Chart 2: Donut Chart (Proportion & Share) */}
                  {(chartViewMode === 'donut' || chartViewMode === 'both') && (
                    <div
                      className={`p-3.5 rounded-2xl bg-white dark:bg-slate-800/70 border border-slate-200/80 dark:border-slate-700/60 shadow-xs flex flex-col ${
                        chartViewMode === 'both' ? 'lg:col-span-5' : 'w-full'
                      }`}
                    >
                      <div className="flex items-center justify-between pb-2 mb-1 border-b border-slate-100 dark:border-slate-700/50">
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                          <PieIcon className="w-3.5 h-3.5 text-amber-500" />
                          감정 반응 점유율 (도넛)
                        </span>
                        <span className="text-[10px] text-slate-400">
                          비율 분석
                        </span>
                      </div>

                      <div className="w-full h-56 relative flex items-center justify-center">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Tooltip
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  const d = payload[0].payload;
                                  return (
                                    <div className="p-2 rounded-xl bg-slate-900/95 text-white border border-white/15 shadow-xl text-xs backdrop-blur-md">
                                      <div className="flex items-center gap-1 font-bold">
                                        <span>{d.emoji}</span>
                                        <span>{d.label}</span>
                                      </div>
                                      <div className="mt-0.5 text-slate-300 text-[11px]">
                                        {d.count}건 ({d.percentage}%)
                                      </div>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <Pie
                              data={emotionChartData}
                              dataKey="count"
                              nameKey="displayName"
                              cx="50%"
                              cy="50%"
                              innerRadius={52}
                              outerRadius={78}
                              paddingAngle={3}
                            >
                              {emotionChartData.map((entry, index) => (
                                <Cell key={`donut-${index}`} fill={entry.color} />
                              ))}
                            </Pie>
                          </PieChart>
                        </ResponsiveContainer>

                        {/* Center Donut Label */}
                        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                          <span className="text-2xl animate-pulse">{topReaction?.emoji || '❤️'}</span>
                          <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 mt-0.5">
                            최다 {topReaction?.label}
                          </span>
                          <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                            {topReaction?.percentage}%
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Interactive Emotion Filter Chips */}
                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <Filter className="w-3.5 h-3.5 text-slate-400" />
                      <span>반응별 참여 친구 필터링</span>
                    </h5>
                    {selectedEmojiFilter && (
                      <button
                        type="button"
                        onClick={() => setSelectedEmojiFilter(null)}
                        className="text-[11px] font-semibold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
                      >
                        필터 초기화 (전체 보기)
                      </button>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => setSelectedEmojiFilter(null)}
                      className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                        selectedEmojiFilter === null
                          ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-transparent shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      <span>전체 반응</span>
                      <span className="text-[10px] opacity-75">({totalReactions})</span>
                    </button>

                    {emotionChartData.map((d) => {
                      const isSelected = selectedEmojiFilter === d.emoji;
                      return (
                        <button
                          key={d.emoji}
                          type="button"
                          onClick={() => setSelectedEmojiFilter(isSelected ? null : d.emoji)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                            isSelected
                              ? 'ring-2 ring-offset-1 ring-slate-900 dark:ring-white border-transparent text-white'
                              : 'hover:scale-105'
                          }`}
                          style={{
                            backgroundColor: isSelected ? d.color : undefined,
                            borderColor: !isSelected ? `${d.color}40` : undefined
                          }}
                        >
                          <span className="text-sm">{d.emoji}</span>
                          <span className={isSelected ? 'text-white' : 'text-slate-800 dark:text-slate-200'}>
                            {d.label}
                          </span>
                          <span
                            className={`text-[10px] px-1.5 py-0.2 rounded-full font-extrabold ${
                              isSelected
                                ? 'bg-white/25 text-white'
                                : 'bg-slate-200/80 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
                            }`}
                          >
                            {d.count}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Reaction Activity Feed / Participants for selected emoji */}
                <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      {selectedEmojiFilter ? (
                        <span className="flex items-center gap-1.5">
                          <span>{selectedEmojiFilter}</span>
                          <span>{getEmotionMeta(selectedEmojiFilter).label} 반응을 남긴 친구들</span>
                          <span className="text-slate-400 font-normal">
                            ({displayedReactions.length}명)
                          </span>
                        </span>
                      ) : (
                        <span>최근 반응 기록 ({displayedReactions.length}명)</span>
                      )}
                    </h5>
                  </div>

                  <div className="space-y-2 max-h-52 overflow-y-auto pr-1 scrollbar-thin">
                    {displayedReactions.map((reaction) => {
                      const meta = getEmotionMeta(reaction.emoji);
                      return (
                        <div
                          key={reaction.id}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100/80 dark:bg-slate-800/40 dark:hover:bg-slate-800 border border-slate-200/60 dark:border-slate-700/40 transition-colors"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="relative shrink-0">
                              <img
                                src={reaction.userAvatar}
                                alt={reaction.userName}
                                className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200 dark:ring-slate-700"
                                referrerPolicy="no-referrer"
                              />
                              <span className="absolute -bottom-1 -right-1 text-xs bg-white dark:bg-slate-900 rounded-full shadow-xs px-0.5">
                                {reaction.emoji}
                              </span>
                            </div>
                            <div className="truncate">
                              <div className="flex items-center gap-1.5">
                                <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                                  {reaction.userName}
                                </p>
                                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-medium ${meta.bgColor} ${meta.textColor}`}>
                                  {reaction.emoji} {meta.label}
                                </span>
                              </div>
                              <p className="text-[10px] text-slate-400 mt-0.5">
                                {formatRelativeTime(reaction.createdAt)}
                              </p>
                            </div>
                          </div>

                          {onSendDm && (
                            <button
                              type="button"
                              onClick={() =>
                                onSendDm({
                                  userId: reaction.userId,
                                  userName: reaction.userName,
                                  userAvatar: reaction.userAvatar,
                                  viewedAt: reaction.createdAt,
                                  reactionEmoji: reaction.emoji
                                })
                              }
                              className="px-2.5 py-1 rounded-lg bg-slate-200/80 hover:bg-blue-600 text-slate-700 hover:text-white dark:bg-slate-700 dark:hover:bg-blue-600 dark:text-slate-200 dark:hover:text-white text-xs font-semibold transition-all flex items-center gap-1 cursor-pointer shrink-0 ml-2"
                            >
                              <MessageCircle className="w-3 h-3" />
                              <span>DM</span>
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* ================================================================= */}
        {/* TAB: 조회자 목록 (Viewers List with Watch Duration & Reaction) */}
        {/* ================================================================= */}
        {activeTab === 'viewers' && (
          <div className="space-y-3">
            {viewers.length > 3 && (
              <input
                type="text"
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="조회자 이름 또는 아이디 검색..."
                className="w-full px-3 py-1.5 text-xs rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
              />
            )}

            {filteredViewers.length === 0 ? (
              <div className="py-8 text-center text-slate-400 dark:text-slate-500 text-xs flex flex-col items-center gap-2">
                <Users className="w-8 h-8 text-slate-300 dark:text-slate-600 stroke-[1.5]" />
                <p className="font-medium text-slate-600 dark:text-slate-300">
                  {viewers.length === 0
                    ? '아직 스토리를 확인한 친구가 없습니다.'
                    : '검색 결과가 없습니다.'}
                </p>
                <p className="text-[11px] text-slate-400 dark:text-slate-500">
                  상단의 [+ 조회 시뮬레이션] 버튼을 눌러 실시간 유입을 확인해보세요.
                </p>
              </div>
            ) : (
              filteredViewers.map((viewer) => {
                const duration = viewer.watchDurationSeconds ?? 4.8;
                const completion =
                  viewer.completionRate ??
                  Math.min(100, Math.round((duration / totalStoryDurationSeconds) * 100));

                return (
                  <div
                    key={viewer.userId}
                    className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100/90 dark:bg-slate-800/50 dark:hover:bg-slate-800 border border-slate-200/70 dark:border-slate-700/40 transition-all"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="relative shrink-0">
                        <img
                          src={viewer.userAvatar}
                          alt={viewer.userName}
                          className="h-10 w-10 rounded-full object-cover ring-2 ring-blue-500/20"
                          referrerPolicy="no-referrer"
                        />
                        {viewer.reactionEmoji && (
                          <span
                            className="absolute -bottom-1 -right-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-white dark:bg-slate-900 ring-1 ring-slate-200 dark:ring-white/30 text-[11px] shadow-sm animate-bounce"
                            title={`남긴 반응: ${viewer.reactionEmoji}`}
                          >
                            {viewer.reactionEmoji}
                          </span>
                        )}
                      </div>

                      <div className="truncate">
                        <div className="flex items-center gap-1.5 truncate">
                          <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {viewer.userName}
                          </p>
                          {viewer.userHandle && (
                            <span className="text-[10px] text-slate-400 truncate">
                              @{viewer.userHandle}
                            </span>
                          )}
                          {viewer.reactionEmoji && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-50 dark:bg-rose-500/20 text-rose-600 dark:text-rose-300 ring-1 ring-rose-300 dark:ring-rose-400/30 font-medium">
                              {viewer.reactionEmoji} 반응
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2.5 text-[10px] text-slate-500 dark:text-slate-400 mt-1">
                          <span className="flex items-center gap-1">
                            <Clock className="w-2.5 h-2.5 text-blue-500" />
                            {formatRelativeTime(viewer.viewedAt)}
                          </span>

                          <span className="flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-1.5 py-0.2 rounded">
                            <Timer className="w-2.5 h-2.5" />
                            {duration.toFixed(1)}초 시청 ({completion}%)
                          </span>

                          {viewer.deviceType && (
                            <span className="hidden sm:inline-flex items-center gap-0.5 text-slate-400">
                              {viewer.deviceType === 'desktop' ? (
                                <Monitor className="w-2.5 h-2.5" />
                              ) : (
                                <Smartphone className="w-2.5 h-2.5" />
                              )}
                              {viewer.deviceType}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {onSendDm && (
                      <button
                        type="button"
                        onClick={() => onSendDm(viewer)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-200/80 hover:bg-blue-600 text-slate-700 hover:text-white dark:bg-slate-700 dark:hover:bg-blue-600 dark:text-slate-200 dark:hover:text-white text-xs font-semibold transition-all flex items-center gap-1 cursor-pointer shrink-0 ml-2"
                      >
                        <MessageCircle className="w-3 h-3" />
                        <span className="hidden sm:inline">메시지</span>
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* ================================================================= */}
        {/* TAB: 시청 유지율 및 기기 분석 (Retention & Devices) */}
        {/* ================================================================= */}
        {activeTab === 'retention' && (
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-700/40">
              <h5 className="text-xs font-bold text-slate-900 dark:text-white flex items-center justify-between">
                <span>시청 구간별 유지율 분포</span>
                <span className="text-[11px] font-normal text-slate-500">
                  총 {totalViews}명 기준
                </span>
              </h5>

              <div className="mt-3 space-y-2">
                {retentionBuckets.map((bucket) => {
                  const percent = totalViews > 0 ? Math.round((bucket.count / totalViews) * 100) : 0;
                  return (
                    <div key={bucket.label} className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-600 dark:text-slate-300">
                        <span>{bucket.label}</span>
                        <span className="font-bold">
                          {bucket.count}명 ({percent}%)
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${bucket.color} transition-all duration-500`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-700/40 flex flex-col items-center text-center">
                <Smartphone className="w-4 h-4 text-blue-500" />
                <span className="text-[10px] text-slate-500 mt-1">모바일</span>
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {deviceCounts.mobile}명
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-700/40 flex flex-col items-center text-center">
                <Monitor className="w-4 h-4 text-indigo-500" />
                <span className="text-[10px] text-slate-500 mt-1">데스크톱</span>
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {deviceCounts.desktop}명
                </span>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-700/40 flex flex-col items-center text-center">
                <Tablet className="w-4 h-4 text-purple-500" />
                <span className="text-[10px] text-slate-500 mt-1">태블릿</span>
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  {deviceCounts.tablet}명
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2 p-2.5 rounded-xl bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200/60 dark:border-blue-800/40 text-xs text-blue-800 dark:text-blue-300">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-blue-600 dark:text-blue-400 mt-0.5" />
              <p className="leading-relaxed text-[11px]">
                시청자의 <strong>{avgCompletionRate}%</strong>가 스토리를 끝까지 시청했습니다.
                {avgCompletionRate >= 80
                  ? ' 높은 몰입도와 시청 유지율을 기록하고 있습니다! 🎉'
                  : ' BGM이나 매력적인 스티커/텍스트를 추가하면 유지율을 더 높일 수 있습니다.'}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
