import React, { useState, useRef, useEffect } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  X,
  Sparkles,
  Check,
  Music,
  Play,
  Pause,
  VolumeX,
  Bookmark,
  FolderOpen,
  Edit3,
  RotateCcw,
  Wand2,
  Type,
  Smile,
  Trash2,
  Camera,
  Image as ImageIcon,
  Upload,
  Smartphone
} from 'lucide-react';
import { PRESET_POST_PHOTOS } from '../data/mockData';
import { PRESET_STORY_BGMS, resolveBgmAudioUrl } from '../data/storyBgmData';
import {
  StoryBgm,
  StoryDraft,
  StoryTextOverlay,
  StoryStickerOverlay
} from '../types';
import { StoryDraftsList } from './StoryDraftsList';
import { StoryCanvasView } from './StoryCanvasView';
import { StoryEditorToolbox, StoryEditorSubTab } from './StoryEditorToolbox';
import { LiveCameraModal } from './LiveCameraModal';
import { formatRelativeTime } from '../utils/formatters';
import { getStoryFilterName } from '../data/storyFiltersData';
import { compressImageFile } from '../utils/imageCompressor';
import { uploadMediaFile } from '../services/mediaUpload';

interface CreateStoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateStoryModal: React.FC<CreateStoryModalProps> = ({ isOpen, onClose }) => {
  const {
    createStory,
    storyDrafts,
    saveStoryDraft,
    deleteStoryDraft,
    selectedDraftForEdit,
    setSelectedDraftForEdit,
    showToast
  } = useSocial();

  const [activeTab, setActiveTab] = useState<'editor' | 'drafts'>('editor');
  const [editorSubTab, setEditorSubTab] = useState<StoryEditorSubTab>('media');
  
  // Media & Basics
  const [selectedPhoto, setSelectedPhoto] = useState<string>('');
  const [customUrl, setCustomUrl] = useState('');
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [caption, setCaption] = useState('');
  const [selectedBgm, setSelectedBgm] = useState<StoryBgm | null>(PRESET_STORY_BGMS[0]);
  const [customBgms, setCustomBgms] = useState<StoryBgm[]>([]);
  
  // Media Upload & Camera State
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [uploadStatusText, setUploadStatusText] = useState('');
  const [isLiveCameraOpen, setIsLiveCameraOpen] = useState(false);

  // Hidden File Inputs for Camera, Gallery, Video, and Audio
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);
  const audioInputRef = useRef<HTMLInputElement | null>(null);
  
  // Editor Customizations: Filter, Text Overlays, Stickers
  const [filterId, setFilterId] = useState<string>('normal');
  const [textOverlays, setTextOverlays] = useState<StoryTextOverlay[]>([]);
  const [stickerOverlays, setStickerOverlays] = useState<StoryStickerOverlay[]>([]);
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [selectedItemType, setSelectedItemType] = useState<'text' | 'sticker' | null>(null);

  // Draft Management
  const [previewingBgmId, setPreviewingBgmId] = useState<string | null>(null);
  const [editingDraftId, setEditingDraftId] = useState<string | null>(null);
  const [lastSavedTimestamp, setLastSavedTimestamp] = useState<string | null>(null);

  const previewAudioRef = useRef<HTMLAudioElement | null>(null);

  // Sync state when selectedDraftForEdit is passed from context
  useEffect(() => {
    if (selectedDraftForEdit && isOpen) {
      if (PRESET_POST_PHOTOS.includes(selectedDraftForEdit.mediaUrl)) {
        setSelectedPhoto(selectedDraftForEdit.mediaUrl);
        setCustomUrl('');
      } else {
        setCustomUrl(selectedDraftForEdit.mediaUrl);
      }
      const isVid =
        selectedDraftForEdit.mediaType === 'video' ||
        /\.(mp4|mov|webm|mkv|3gp|avi|m4v)(\?.*)?$/i.test(selectedDraftForEdit.mediaUrl) ||
        selectedDraftForEdit.mediaUrl.startsWith('data:video/');
      setMediaType(isVid ? 'video' : 'image');
      setCaption(selectedDraftForEdit.caption || '');
      setSelectedBgm(selectedDraftForEdit.bgm || null);
      setFilterId(selectedDraftForEdit.filterId || 'normal');
      setTextOverlays(selectedDraftForEdit.textOverlays || []);
      setStickerOverlays(selectedDraftForEdit.stickerOverlays || []);
      setEditingDraftId(selectedDraftForEdit.id);
      setLastSavedTimestamp(selectedDraftForEdit.savedAt);
      setActiveTab('editor');
    }
  }, [selectedDraftForEdit, isOpen]);

  // Stop audio preview when modal is closed or unmounted
  useEffect(() => {
    return () => {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
        previewAudioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!isOpen && previewAudioRef.current) {
      previewAudioRef.current.pause();
      setPreviewingBgmId(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleTogglePreviewAudio = async (bgm: StoryBgm, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (previewingBgmId === bgm.id) {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
      }
      setPreviewingBgmId(null);
    } else {
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
      }
      const audioUrl = await resolveBgmAudioUrl(bgm);
      if (!audioUrl) return;
      const audio = new Audio(audioUrl);
      audio.volume = 0.6;
      audio.play().catch(() => {});
      audio.onended = () => {
        setPreviewingBgmId(null);
      };
      previewAudioRef.current = audio;
      setPreviewingBgmId(bgm.id);
    }
  };

  const handleSelectBgm = async (bgm: StoryBgm | null) => {
    if (bgm) {
      const audioUrl = await resolveBgmAudioUrl(bgm);
      const readyBgm = { ...bgm, audioUrl };
      setSelectedBgm(readyBgm);
      if (previewingBgmId !== bgm.id) {
        handleTogglePreviewAudio(readyBgm);
      }
    } else {
      setSelectedBgm(null);
      if (previewAudioRef.current) {
        previewAudioRef.current.pause();
        setPreviewingBgmId(null);
      }
    }
  };

  const handleTriggerUploadAudio = () => {
    audioInputRef.current?.click();
  };

  const handleProcessAudioFile = async (file: File) => {
    if (!file.type.startsWith('audio/') && !/\.(mp3|wav|m4a|aac|ogg|flac)$/i.test(file.name)) {
      showToast('오디오 파일(.mp3, .wav, .m4a 등)만 등록할 수 있습니다.', 'error');
      return;
    }

    if (file.size > 50 * 1024 * 1024) {
      showToast('50MB 이하의 오디오 파일만 업로드할 수 있습니다.', 'error');
      return;
    }

    const localUrl = URL.createObjectURL(file);
    const cleanTitle = file.name.replace(/\.[^/.]+$/, '');
    const customTrack: StoryBgm = {
      id: `custom_bgm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      title: cleanTitle,
      artist: '직접 등록한 음원',
      genre: '사용자 BGM',
      audioUrl: localUrl,
      coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
      duration: 30,
      license: '사용자 직접 등록 (저작권 무료)',
      isCustom: true
    };

    setCustomBgms((prev) => [customTrack, ...prev]);
    setSelectedBgm(customTrack);
    handleTogglePreviewAudio(customTrack);
    showToast(`저작권 무료 음원 "${cleanTitle}"이(가) 등록되었습니다! 🎶`, 'success');

    // Background server upload for persistence
    try {
      const uploadRes = await uploadMediaFile(file);
      if (uploadRes && uploadRes.url) {
        customTrack.audioUrl = uploadRes.url;
        setSelectedBgm((curr) => (curr?.id === customTrack.id ? { ...curr, audioUrl: uploadRes.url } : curr));
        setCustomBgms((prev) => prev.map((b) => (b.id === customTrack.id ? { ...b, audioUrl: uploadRes.url } : b)));
      }
    } catch (err) {
      console.warn('[AudioUpload] Server upload fallback to local URL:', err);
    } finally {
      if (audioInputRef.current) audioInputRef.current.value = '';
    }
  };

  const handleAudioInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessAudioFile(file);
    }
  };

  const handleAddCustomAudioUrl = (url: string, title?: string) => {
    if (!url.trim()) return;
    const cleanTitle = title?.trim() || '외부 웹 음원';
    const customTrack: StoryBgm = {
      id: `custom_url_${Date.now()}`,
      title: cleanTitle,
      artist: '외부 웹 링크',
      genre: '웹 BGM',
      audioUrl: url.trim(),
      coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop&q=80',
      duration: 30,
      license: '웹 음원 링크 (저작권 무료)',
      isCustom: true
    };
    setCustomBgms((prev) => [customTrack, ...prev]);
    setSelectedBgm(customTrack);
    handleTogglePreviewAudio(customTrack);
    showToast(`"${cleanTitle}" 음원이 적용되었습니다! 🎵`, 'success');
  };

  const handleDeleteCustomBgm = (id: string) => {
    setCustomBgms((prev) => prev.filter((b) => b.id !== id));
    if (selectedBgm?.id === id) {
      setSelectedBgm(PRESET_STORY_BGMS[0]);
    }
    showToast('등록했던 사용자 음원이 삭제되었습니다.', 'info');
  };

  const handleClose = () => {
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
      setPreviewingBgmId(null);
    }
    setSelectedDraftForEdit(null);
    onClose();
  };

  const handleTriggerCamera = () => {
    cameraInputRef.current?.click();
  };

  const handleTriggerGallery = () => {
    galleryInputRef.current?.click();
  };

  const handleTriggerVideo = () => {
    videoInputRef.current?.click();
  };

  const handleTriggerLiveCamera = () => {
    setIsLiveCameraOpen(true);
  };

  const handleProcessVideoFile = async (file: File) => {
    if (!file.type.startsWith('video/') && !/\.(mp4|mov|webm|mkv|3gp|avi|m4v)$/i.test(file.name)) {
      showToast('동영상 파일(.mp4, .mov, .webm 등)만 선택할 수 있습니다.', 'error');
      return;
    }

    if (file.size > 200 * 1024 * 1024) {
      showToast('200MB 이하의 동영상 파일만 업로드할 수 있습니다.', 'error');
      return;
    }

    setIsUploadingPhoto(true);
    setUploadStatusText('동영상 최적화 및 업로드 준비 중...');

    try {
      // 1. Instant responsive local preview with ObjectURL for instant playback
      const localPreviewUrl = URL.createObjectURL(file);
      setCustomUrl(localPreviewUrl);
      setSelectedPhoto('');
      setMediaType('video');
      showToast('동영상이 스토리에 성공적으로 등록되었습니다! 🎬', 'success');

      // 2. Upload to server storage (/api/sync/upload) for multi-device sync
      try {
        setUploadStatusText('서버로 동영상 업로드 중...');
        const uploadRes = await uploadMediaFile(file, (msg) => setUploadStatusText(msg));
        if (uploadRes && uploadRes.url) {
          setCustomUrl(uploadRes.url);
        }
      } catch (uploadErr) {
        console.warn('[StoryVideoUpload] Server upload fallback to local preview:', uploadErr);
      }
    } catch (err) {
      console.error('[StoryVideoUpload] Error processing video:', err);
      showToast('동영상을 처리하는 중 오류가 발생했습니다.', 'error');
    } finally {
      setIsUploadingPhoto(false);
      setUploadStatusText('');
      if (videoInputRef.current) videoInputRef.current.value = '';
    }
  };

  const handleProcessPhotoFile = async (file: File) => {
    if (file.type.startsWith('video/')) {
      handleProcessVideoFile(file);
      return;
    }

    if (!file.type.startsWith('image/')) {
      showToast('이미지(사진) 또는 동영상 파일만 등록할 수 있습니다.', 'error');
      return;
    }

    setIsUploadingPhoto(true);
    setUploadStatusText('사진 압축 및 최적화 중...');

    try {
      // 1. High-speed client compression for instant responsive UI
      const compressedDataUrl = await compressImageFile(file, 1920, 1920, 0.88);
      // Immediately set on canvas so user sees their photo right away with zero lag!
      setCustomUrl(compressedDataUrl);
      setSelectedPhoto('');
      setMediaType('image');
      showToast('사진이 스토리에 성공적으로 등록되었습니다! 📸', 'success');

      // 2. Upload to server storage (/api/sync/upload) for multi-device sync
      try {
        setUploadStatusText('서버로 안전하게 동기화 중...');
        const uploadRes = await uploadMediaFile(file, (msg) => setUploadStatusText(msg));
        if (uploadRes && uploadRes.url) {
          setCustomUrl(uploadRes.url);
        }
      } catch (uploadErr) {
        console.warn('[StoryPhotoUpload] Server upload fallback to compressed data URL:', uploadErr);
      }
    } catch (err) {
      console.error('[StoryPhotoUpload] Error processing image:', err);
      showToast('사진을 처리하는 중 오류가 발생했습니다.', 'error');
    } finally {
      setIsUploadingPhoto(false);
      setUploadStatusText('');
      if (cameraInputRef.current) cameraInputRef.current.value = '';
      if (galleryInputRef.current) galleryInputRef.current.value = '';
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessPhotoFile(file);
    }
  };

  const handleVideoInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessVideoFile(file);
    }
  };

  const handleDropMediaFile = (file: File) => {
    if (file.type.startsWith('video/') || /\.(mp4|mov|webm|mkv|3gp|avi|m4v)$/i.test(file.name)) {
      handleProcessVideoFile(file);
    } else {
      handleProcessPhotoFile(file);
    }
  };

  const handleResetToNew = () => {
    setSelectedPhoto('');
    setCustomUrl('');
    setMediaType('image');
    setCaption('');
    setSelectedBgm(PRESET_STORY_BGMS[0]);
    setFilterId('normal');
    setTextOverlays([]);
    setStickerOverlays([]);
    setSelectedItemId(null);
    setSelectedItemType(null);
    setEditingDraftId(null);
    setLastSavedTimestamp(null);
    setSelectedDraftForEdit(null);
    setEditorSubTab('media');
    showToast('새 스토리 작성 모드로 전환되었습니다. 사진이나 동영상을 등록해보세요!', 'info');
  };

  // Text Overlay Handlers
  const handleAddText = (
    text: string,
    color: string,
    styleType: any,
    fontSize: any
  ) => {
    const newTextItem: StoryTextOverlay = {
      id: `txt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      text,
      x: 50,
      y: 35 + textOverlays.length * 10,
      color,
      styleType,
      fontSize
    };
    setTextOverlays((prev) => [...prev, newTextItem]);
    setSelectedItemId(newTextItem.id);
    setSelectedItemType('text');
    showToast('텍스트가 캔버스에 추가되었습니다! 드래그하여 원하는 위치로 이동하세요.', 'info');
  };

  const handleUpdateText = (id: string, updates: Partial<StoryTextOverlay>) => {
    setTextOverlays((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...updates } : t))
    );
  };

  const handleUpdateTextPosition = (id: string, x: number, y: number) => {
    setTextOverlays((prev) =>
      prev.map((t) => (t.id === id ? { ...t, x, y } : t))
    );
  };

  // Sticker Overlay Handlers
  const handleAddSticker = (
    content: string,
    type: 'badge' | 'emoji' | 'sticker'
  ) => {
    const newSticker: StoryStickerOverlay = {
      id: `stk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      content,
      type,
      x: 40 + Math.random() * 20,
      y: 30 + Math.random() * 20,
      scale: 1,
      rotation: type === 'badge' ? 0 : Math.floor(Math.random() * 20) - 10
    };
    setStickerOverlays((prev) => [...prev, newSticker]);
    setSelectedItemId(newSticker.id);
    setSelectedItemType('sticker');
    showToast('스티커가 추가되었습니다! 자유롭게 위치를 드래그해보세요.', 'info');
  };

  const handleUpdateSticker = (id: string, updates: Partial<StoryStickerOverlay>) => {
    setStickerOverlays((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updates } : s))
    );
  };

  const handleUpdateStickerPosition = (id: string, x: number, y: number) => {
    setStickerOverlays((prev) =>
      prev.map((s) => (s.id === id ? { ...s, x, y } : s))
    );
  };

  const handleDeleteOverlay = (type: 'text' | 'sticker', id: string) => {
    if (type === 'text') {
      setTextOverlays((prev) => prev.filter((t) => t.id !== id));
    } else {
      setStickerOverlays((prev) => prev.filter((s) => s.id !== id));
    }
    if (selectedItemId === id) {
      setSelectedItemId(null);
      setSelectedItemType(null);
    }
  };

  const handleClearAllOverlays = () => {
    setTextOverlays([]);
    setStickerOverlays([]);
    setSelectedItemId(null);
    setSelectedItemType(null);
    showToast('모든 텍스트와 스티커가 지워졌습니다.', 'info');
  };

  const handleSaveDraft = () => {
    const finalMedia = customUrl.trim() || selectedPhoto;
    if (!finalMedia) {
      showToast('초안으로 저장할 사진 또는 동영상을 먼저 휴대폰으로 촬영하거나 선택해주세요.', 'info');
      setEditorSubTab('media');
      return;
    }
    const savedId = saveStoryDraft(
      finalMedia,
      caption.trim() || undefined,
      undefined,
      selectedBgm || undefined,
      editingDraftId || undefined,
      filterId,
      textOverlays,
      stickerOverlays,
      mediaType
    );
    setEditingDraftId(savedId);
    setLastSavedTimestamp(new Date().toISOString());
  };

  const handleLoadDraftFromList = (draft: StoryDraft) => {
    if (PRESET_POST_PHOTOS.includes(draft.mediaUrl)) {
      setSelectedPhoto(draft.mediaUrl);
      setCustomUrl('');
    } else {
      setCustomUrl(draft.mediaUrl);
    }
    const isVid =
      draft.mediaType === 'video' ||
      /\.(mp4|mov|webm|mkv|3gp|avi|m4v)(\?.*)?$/i.test(draft.mediaUrl) ||
      draft.mediaUrl.startsWith('data:video/');
    setMediaType(isVid ? 'video' : 'image');
    setCaption(draft.caption || '');
    setSelectedBgm(draft.bgm || null);
    setFilterId(draft.filterId || 'normal');
    setTextOverlays(draft.textOverlays || []);
    setStickerOverlays(draft.stickerOverlays || []);
    setSelectedItemId(null);
    setSelectedItemType(null);
    setEditingDraftId(draft.id);
    setLastSavedTimestamp(draft.savedAt);
    setActiveTab('editor');
    showToast('초안을 성공적으로 불러왔습니다! 📝', 'info');
  };

  const handleQuickPublishDraft = (draft: StoryDraft) => {
    createStory(
      draft.mediaUrl,
      draft.caption || undefined,
      draft.bgColor || undefined,
      draft.bgm || undefined,
      draft.filterId,
      draft.textOverlays,
      draft.stickerOverlays,
      draft.mediaType
    );
    deleteStoryDraft(draft.id);
    showToast('초안이 24시간 스토리에 성공적으로 게시되었습니다! ✨', 'success');
    handleClose();
  };

  const handleSubmit = async (e?: React.FormEvent | React.MouseEvent) => {
    e?.preventDefault?.();
    if (previewAudioRef.current) {
      previewAudioRef.current.pause();
    }
    const finalMedia = customUrl.trim() || selectedPhoto;
    if (!finalMedia) {
      showToast('스토리에 등록할 사진 또는 동영상을 먼저 휴대폰으로 촬영하거나 앨범에서 선택해주세요!', 'error');
      setEditorSubTab('media');
      return;
    }

    let finalBgm = selectedBgm;
    if (finalBgm && (!finalBgm.audioUrl || (!finalBgm.audioUrl.startsWith('blob:') && !finalBgm.audioUrl.startsWith('data:') && !finalBgm.audioUrl.startsWith('http')))) {
      const resolvedUrl = await resolveBgmAudioUrl(finalBgm);
      if (resolvedUrl) {
        finalBgm = { ...finalBgm, audioUrl: resolvedUrl };
      }
    }

    createStory(
      finalMedia,
      caption.trim() || undefined,
      undefined,
      finalBgm || undefined,
      filterId,
      textOverlays,
      stickerOverlays,
      mediaType
    );
    
    // If this was an existing draft, remove it from drafts after publishing
    if (editingDraftId) {
      deleteStoryDraft(editingDraftId);
    }
    
    showToast('새 스토리가 성공적으로 공유되었습니다! 🎉', 'success');
    handleClose();
  };

  const finalPhoto = customUrl.trim() || selectedPhoto;

  return (
    <div
      id="create-story-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4 backdrop-blur-sm animate-in fade-in duration-150 overflow-y-auto"
      onClick={handleClose}
    >
      <div
        className="w-full max-w-lg max-h-[94vh] flex flex-col rounded-2xl border border-slate-200 bg-white p-4 sm:p-5 shadow-2xl ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50 my-auto overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400">
              <Sparkles className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                스토리 편집기 & 초안 관리
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                사진 및 동영상 등록, 텍스트 오버레이, 스티커 배치, 필터 및 BGM 추가
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tab Navigation: Editor vs Drafts */}
        <div className="flex items-center p-1 my-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 shrink-0">
          <button
            type="button"
            id="tab-story-editor"
            onClick={() => setActiveTab('editor')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activeTab === 'editor'
                ? 'bg-white text-blue-600 shadow-xs dark:bg-slate-900 dark:text-blue-400'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>스토리 편집기</span>
            {editingDraftId && (
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" title="초안 편집 중" />
            )}
          </button>

          <button
            type="button"
            id="tab-story-drafts"
            onClick={() => setActiveTab('drafts')}
            className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              activeTab === 'drafts'
                ? 'bg-white text-blue-600 shadow-xs dark:bg-slate-900 dark:text-blue-400'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'
            }`}
          >
            <FolderOpen className="w-3.5 h-3.5" />
            <span>초안 보관함</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                storyDrafts.length > 0
                  ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/60 dark:text-blue-300'
                  : 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-400'
              }`}
            >
              {storyDrafts.length}
            </span>
          </button>
        </div>

        {/* Tab 1: Interactive Story Editor */}
        {activeTab === 'editor' ? (
          <div className="flex flex-col gap-3 overflow-y-auto pr-1">
            {/* Loaded Draft Banner Notice */}
            {editingDraftId && (
              <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-center justify-between gap-2 text-xs text-amber-900 dark:text-amber-200 animate-in fade-in shrink-0">
                <div className="flex items-center gap-1.5 min-w-0 truncate">
                  <Bookmark className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0 fill-current" />
                  <span className="font-semibold truncate">
                    임시 저장된 초안을 불러와 수정 중입니다
                  </span>
                  {lastSavedTimestamp && (
                    <span className="text-[11px] text-amber-700 dark:text-amber-400 truncate hidden sm:inline">
                      ({formatRelativeTime(lastSavedTimestamp)})
                    </span>
                  )}
                </div>
                <button
                  type="button"
                  onClick={handleResetToNew}
                  className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 border border-slate-200 dark:border-slate-700 font-medium text-[11px] flex items-center gap-1 shrink-0"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>새로 쓰기</span>
                </button>
              </div>
            )}

            {/* Interactive Story Canvas Preview Area */}
            <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-950 shadow-md">
              <StoryCanvasView
                mediaUrl={finalPhoto}
                mediaType={mediaType}
                filterId={filterId}
                textOverlays={textOverlays}
                stickerOverlays={stickerOverlays}
                interactive={true}
                selectedItemId={selectedItemId}
                selectedItemType={selectedItemType}
                onSelectItem={(item) => {
                  setSelectedItemId(item ? item.id : null);
                  setSelectedItemType(item ? item.type : null);
                  if (item?.type === 'text') setEditorSubTab('text');
                  if (item?.type === 'sticker') setEditorSubTab('stickers');
                }}
                onUpdateTextPosition={handleUpdateTextPosition}
                onUpdateStickerPosition={handleUpdateStickerPosition}
                onDeleteOverlay={handleDeleteOverlay}
                className="h-56 sm:h-64 w-full"
                onTriggerCamera={handleTriggerCamera}
                onTriggerGallery={handleTriggerGallery}
                onTriggerVideo={handleTriggerVideo}
                onTriggerLiveCamera={handleTriggerLiveCamera}
                isProcessing={isUploadingPhoto}
                onDropPhoto={handleDropMediaFile}
              />

              {/* Floating Top Left Badges: Filter & BGM */}
              <div className="absolute top-2.5 left-2.5 right-2.5 z-30 flex items-center justify-between pointer-events-none">
                <div className="flex items-center gap-1.5 pointer-events-auto">
                  {/* Filter Pill */}
                  {filterId !== 'normal' && (
                    <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-purple-900/80 backdrop-blur-md border border-purple-400/40 text-purple-200 text-[10px] font-bold shadow-sm">
                      <Wand2 className="w-3.5 h-3.5 text-purple-300" />
                      <span>{getStoryFilterName(filterId)} 필터</span>
                    </div>
                  )}

                  {/* BGM Pill */}
                  {selectedBgm ? (
                    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/20 text-white text-[11px] shadow-sm max-w-[160px] truncate">
                      <Music className={`w-3.5 h-3.5 text-amber-300 shrink-0 ${previewingBgmId === selectedBgm.id ? 'animate-spin' : ''}`} />
                      <span className="font-semibold truncate text-amber-100">{selectedBgm.title}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/40 backdrop-blur-md border border-white/10 text-white/70 text-[10px]">
                      <VolumeX className="w-2.5 h-2.5" />
                      <span>음악 없음</span>
                    </div>
                  )}
                </div>

                {/* Clear overlays button if any exist */}
                {(textOverlays.length > 0 || stickerOverlays.length > 0) && (
                  <button
                    type="button"
                    onClick={handleClearAllOverlays}
                    title="모든 스티커 & 텍스트 지우기"
                    className="pointer-events-auto px-2 py-1 rounded-md bg-black/60 hover:bg-rose-900/80 border border-white/20 text-white text-[10px] font-medium backdrop-blur-md flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-2.5 h-2.5 text-rose-400" />
                    <span>초기화</span>
                  </button>
                )}
              </div>
            </div>

            {/* Story Editor Toolbox Controls */}
            <StoryEditorToolbox
              currentSubTab={editorSubTab}
              onChangeSubTab={setEditorSubTab}
              filterId={filterId}
              onSelectFilter={(id) => {
                setFilterId(id);
                showToast(`"${getStoryFilterName(id)}" 필터가 적용되었습니다. ✨`, 'info');
              }}
              textOverlays={textOverlays}
              onAddText={handleAddText}
              onUpdateText={handleUpdateText}
              onDeleteOverlay={handleDeleteOverlay}
              selectedItemId={selectedItemId}
              selectedItemType={selectedItemType}
              onSelectItem={(item) => {
                setSelectedItemId(item ? item.id : null);
                setSelectedItemType(item ? item.type : null);
              }}
              stickerOverlays={stickerOverlays}
              onAddSticker={handleAddSticker}
              onUpdateSticker={handleUpdateSticker}
              selectedPhoto={selectedPhoto}
              customUrl={customUrl}
              onSelectPhoto={(photo) => {
                setSelectedPhoto(photo);
                setMediaType('image');
              }}
              onChangeCustomUrl={(url) => {
                setCustomUrl(url);
                const isVid = /\.(mp4|mov|webm|mkv|3gp|avi|m4v)(\?.*)?$/i.test(url) || url.startsWith('data:video/');
                setMediaType(isVid ? 'video' : 'image');
              }}
              mediaType={mediaType}
              onTriggerCamera={handleTriggerCamera}
              onTriggerGallery={handleTriggerGallery}
              onTriggerVideo={handleTriggerVideo}
              onTriggerLiveCamera={handleTriggerLiveCamera}
              isUploadingPhoto={isUploadingPhoto}
              uploadStatusText={uploadStatusText}
              selectedBgm={selectedBgm}
              onSelectBgm={handleSelectBgm}
              previewingBgmId={previewingBgmId}
              onTogglePreviewAudio={handleTogglePreviewAudio}
              customBgms={customBgms}
              onTriggerUploadAudio={handleTriggerUploadAudio}
              onAddCustomAudioUrl={handleAddCustomAudioUrl}
              onDeleteCustomBgm={handleDeleteCustomBgm}
            />

            {/* Caption Input */}
            <div className="pt-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                스토리 하단 캡션 문구 (선택)
              </label>
              <input
                type="text"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleSubmit();
                  }
                }}
                placeholder="스토리에 남길 한 마디를 적어보세요..."
                maxLength={100}
                className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:bg-white focus:text-slate-900 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Submit & Draft Buttons Bar */}
            <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 shrink-0">
              {/* Draft Save Button */}
              <button
                type="button"
                id="save-story-draft-btn"
                onClick={handleSaveDraft}
                className="px-3 py-2 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:hover:bg-amber-900/60 dark:text-amber-200 border border-amber-200 dark:border-amber-800 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                title="작성 중인 스토리를 초안으로 임시 저장합니다"
              >
                <Bookmark className="w-3.5 h-3.5 fill-current text-amber-500" />
                <span>{editingDraftId ? '초안 업데이트' : '초안 임시 저장'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleClose}
                  className="rounded-lg px-3.5 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
                >
                  취소
                </button>
                <button
                  type="button"
                  id="publish-story-btn"
                  onClick={handleSubmit}
                  className="rounded-lg bg-blue-600 px-4 sm:px-5 py-2 text-xs sm:text-sm font-semibold text-white shadow-md shadow-blue-600/20 hover:bg-blue-700 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>스토리 공유하기</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Tab 2: Drafts Storage List View */
          <div className="flex-1 overflow-hidden">
            <StoryDraftsList
              onSelectDraft={handleLoadDraftFromList}
              onQuickPublishDraft={handleQuickPublishDraft}
              onNewStory={handleResetToNew}
            />
          </div>
        )}

        {/* Hidden Camera, Gallery, and Video File Inputs */}
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={handleFileInputChange}
        />
        <input
          ref={galleryInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileInputChange}
        />
        <input
          ref={videoInputRef}
          type="file"
          accept="video/mp4,video/quicktime,video/webm,video/*"
          className="hidden"
          onChange={handleVideoInputChange}
        />
        <input
          ref={audioInputRef}
          type="file"
          accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac"
          className="hidden"
          onChange={handleAudioInputChange}
        />

        {/* Live In-App Camera Viewfinder Modal */}
        <LiveCameraModal
          isOpen={isLiveCameraOpen}
          onClose={() => setIsLiveCameraOpen(false)}
          onCapture={handleProcessPhotoFile}
          onFallbackNativeCamera={handleTriggerCamera}
        />
      </div>
    </div>
  );
};
