import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { PostCard } from './PostCard';
import { ThemeSwitchMenu } from './ThemeSwitchMenu';
import {
  MapPin,
  Link as LinkIcon,
  Calendar,
  CheckCircle,
  MessageCircle,
  Edit3,
  Bookmark,
  Heart,
  Grid,
  FileText,
  Users,
  Sparkles,
  ArrowLeft,
  Tag,
  Smile,
  Github,
  Instagram,
  Plus,
  Info,
  ExternalLink,
  X,
  Layers,
  Share2,
  ShieldCheck,
  Phone
} from 'lucide-react';
import { formatNumber } from '../utils/formatters';

interface ProfileViewProps {
  onOpenEditProfile: () => void;
}

type ProfileTab = 'posts' | 'media' | 'about' | 'liked' | 'bookmarks';

export const ProfileView: React.FC<ProfileViewProps> = ({ onOpenEditProfile }) => {
  const {
    currentUser,
    users,
    posts,
    deletedPostIds,
    toggleFollow,
    viewingUserId,
    setViewingUserId,
    setActiveTab,
    setActiveTag,
    setActiveChatUserId,
    openEditSignupInfoModal
  } = useSocial();

  const [activeProfileTab, setActiveProfileTab] = useState<ProfileTab>('posts');
  const [lightboxPhoto, setLightboxPhoto] = useState<string | null>(null);

  const profileUser = viewingUserId
    ? users.find((u) => u.id === viewingUserId) || currentUser
    : currentUser;

  const isOwnProfile = profileUser.id === currentUser.id;
  const isFollowing = currentUser.followingIds?.includes(profileUser.id) ?? false;

  // User posts (excluding deleted posts)
  const userPosts = posts.filter(
    (p) =>
      p.authorId === profileUser.id &&
      !(deletedPostIds || []).includes(p.id) &&
      !(p as any).isDeleted
  );

  // User media posts (images or mediaItems)
  const userMediaPosts = userPosts.filter(
    (p) => (p.images && p.images.length > 0) || (p.mediaItems && p.mediaItems.length > 0)
  );

  // Liked posts
  const likedPosts = posts.filter(
    (p) =>
      p.likes?.includes(profileUser.id) &&
      !(deletedPostIds || []).includes(p.id) &&
      !(p as any).isDeleted
  );

  // Bookmarked posts (only shown if own profile)
  const bookmarkedPosts = posts.filter(
    (p) =>
      p.bookmarks?.includes(currentUser.id) &&
      !(deletedPostIds || []).includes(p.id) &&
      !(p as any).isDeleted
  );

  // Total likes received across all posts by this user
  const totalLikesReceived = userPosts.reduce((acc, p) => acc + (p.likes?.length || 0), 0);

  const handleStartChat = () => {
    setActiveChatUserId(profileUser.id);
    setActiveTab('messages');
  };

  const handleTagClick = (tag: string) => {
    setActiveTag(tag);
    setActiveTab('explore');
  };

  const getDisplayedPosts = () => {
    switch (activeProfileTab) {
      case 'posts':
        return userPosts;
      case 'media':
        return userMediaPosts;
      case 'liked':
        return likedPosts;
      case 'bookmarks':
        return bookmarkedPosts;
      default:
        return userPosts;
    }
  };

  const displayedPosts = getDisplayedPosts();

  return (
    <div className="flex flex-col gap-5">
      {/* Main Profile Header Card */}
      <div className="rounded-2xl border border-slate-200 bg-white overflow-hidden shadow-sm ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
        {/* Banner Cover */}
        <div className="relative h-44 md:h-56 w-full bg-slate-200 dark:bg-slate-800 overflow-hidden group">
          <img
            src={profileUser.banner}
            alt="Profile Banner"
            className="h-full w-full object-cover group-hover:scale-102 transition-transform duration-500"
            referrerPolicy="no-referrer"
          />

          {!isOwnProfile ? (
            <button
              onClick={() => setViewingUserId(currentUser.id)}
              className="absolute top-4 left-4 flex items-center gap-1.5 rounded-full bg-slate-900/60 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur-md hover:bg-slate-900/80 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>내 프로필로 돌아가기</span>
            </button>
          ) : (
            <button
              onClick={onOpenEditProfile}
              className="absolute top-4 right-4 flex items-center gap-1.5 rounded-full bg-slate-900/60 px-3 py-1.5 text-xs font-semibold text-white backdrop-blur-md hover:bg-slate-900/80 transition-colors"
            >
              <Edit3 className="h-3.5 w-3.5" />
              <span>커버 & 프로필 수정</span>
            </button>
          )}
        </div>

        {/* Info & Avatar Area */}
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between -mt-16 md:-mt-20 mb-4 gap-4">
            <div className="relative">
              <img
                src={profileUser.avatar}
                alt={profileUser.name}
                className="h-24 w-24 md:h-28 md:w-28 rounded-full object-cover border-4 border-white shadow-lg dark:border-slate-900 bg-white dark:bg-slate-800"
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-1 right-1 h-4 w-4 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              {isOwnProfile ? (
                <>
                  <button
                    id="edit-profile-btn"
                    onClick={onOpenEditProfile}
                    className="flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-xs md:text-sm font-bold text-slate-800 shadow-xs hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors"
                  >
                    <Edit3 className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                    <span>프로필 편집</span>
                  </button>

                  <button
                    type="button"
                    id="edit-signup-info-btn"
                    onClick={openEditSignupInfoModal}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-50 to-purple-50 hover:from-indigo-100 hover:to-purple-100 text-indigo-700 border border-indigo-200/90 dark:from-indigo-950/70 dark:to-purple-950/40 dark:text-indigo-300 dark:border-indigo-800/90 px-3.5 py-2 text-xs md:text-sm font-bold shadow-xs transition-all active:scale-95 cursor-pointer"
                  >
                    <ShieldCheck className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
                    <span>회원가입 정보 수정</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={handleStartChat}
                    className="flex items-center gap-1.5 rounded-xl border border-slate-300 px-4 py-2 text-xs md:text-sm font-bold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800 transition-colors"
                  >
                    <MessageCircle className="h-4 w-4" />
                    <span>메시지 (DM)</span>
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFollow(profileUser.id, profileUser.name, profileUser.handle);
                    }}
                    className={`rounded-xl px-5 py-2 text-xs md:text-sm font-bold shadow-md transition-all cursor-pointer ${
                      isFollowing
                        ? 'border border-slate-300 bg-slate-100 text-slate-700 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-rose-950/40 dark:hover:text-rose-400'
                        : 'bg-blue-600 text-white shadow-blue-600/25 hover:bg-blue-700 active:scale-95'
                    }`}
                  >
                    {isFollowing ? '팔로잉' : '팔로우'}
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Name, Verified, Role & Handle */}
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white">
                {profileUser.name}
              </h1>
              {profileUser.isVerified && (
                <CheckCircle className="h-5 w-5 fill-blue-600 text-white" />
              )}
              {profileUser.role && (
                <span className="rounded-full bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 text-xs font-semibold px-2.5 py-0.5 border border-blue-200/60 dark:border-blue-800/60">
                  {profileUser.role}
                </span>
              )}
            </div>
            <p className="text-xs md:text-sm text-slate-400 font-medium">@{profileUser.handle}</p>
          </div>

          {/* Status Message (한 줄 상태 / 오늘의 기분) */}
          {profileUser.statusMessage && (
            <div className="mt-3 inline-flex items-center gap-2 rounded-xl bg-slate-100 dark:bg-slate-800/80 px-3 py-1.5 text-xs text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
              <Smile className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
              <span className="font-semibold">{profileUser.statusMessage}</span>
            </div>
          )}

          {/* Bio Description */}
          <p className="mt-3 text-sm text-slate-800 dark:text-slate-200 leading-relaxed max-w-2xl whitespace-pre-line">
            {profileUser.bio}
          </p>

          {/* Meta Badges (Location, Website, Github, Instagram, Join Date) */}
          <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
            {profileUser.location && (
              <span className="flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5 text-slate-400" />
                {profileUser.location}
              </span>
            )}
            {profileUser.website && (
              <a
                href={profileUser.website}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-blue-600 dark:text-blue-400 hover:underline"
              >
                <LinkIcon className="h-3.5 w-3.5" />
                {profileUser.website.replace('https://', '')}
              </a>
            )}
            {profileUser.githubUrl && (
              <a
                href={profileUser.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              >
                <Github className="h-3.5 w-3.5" />
                <span>GitHub</span>
              </a>
            )}
            {profileUser.instagramUrl && (
              <a
                href={profileUser.instagramUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-pink-600 dark:text-pink-400 hover:underline"
              >
                <Instagram className="h-3.5 w-3.5" />
                <span>Instagram</span>
              </a>
            )}
            <span className="flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5" />
              {profileUser.joinedDate} 가입
            </span>
            {profileUser.phoneVerified && (
              <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full">
                <Phone className="h-3 w-3" />
                휴대폰 인증회원
              </span>
            )}
          </div>

          {/* Interests & Hobbies Tags (관심사 & 취미) */}
          <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Tag className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                관심사 & 취미
              </span>
              {isOwnProfile && (
                <button
                  onClick={onOpenEditProfile}
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold flex items-center gap-1"
                >
                  <Plus className="h-3 w-3" />
                  <span>관심사 설정</span>
                </button>
              )}
            </div>

            {profileUser.interests && profileUser.interests.length > 0 ? (
              <div className="flex flex-wrap gap-1.5">
                {profileUser.interests.map((interest, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleTagClick(interest)}
                    className="inline-flex items-center rounded-lg bg-blue-50/80 dark:bg-blue-950/40 px-2.5 py-1 text-xs font-medium text-blue-700 dark:text-blue-300 border border-blue-200/70 dark:border-blue-800/70 hover:bg-blue-100 dark:hover:bg-blue-900/60 transition-colors"
                  >
                    #{interest}
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-between text-xs text-slate-400 py-1">
                <span>등록된 관심사가 없습니다.</span>
                {isOwnProfile && (
                  <button
                    onClick={onOpenEditProfile}
                    className="text-blue-600 dark:text-blue-400 font-bold hover:underline"
                  >
                    + 지금 관심사 추가하기
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Featured Photos Showcase Gallery (대표 사진첩) */}
          {profileUser.featuredPhotos && profileUser.featuredPhotos.length > 0 && (
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Layers className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                  대표 사진첩 ({profileUser.featuredPhotos.length})
                </span>
                {isOwnProfile && (
                  <button
                    onClick={onOpenEditProfile}
                    className="text-xs text-blue-600 dark:text-blue-400 hover:underline font-semibold"
                  >
                    편집
                  </button>
                )}
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {profileUser.featuredPhotos.map((photoUrl, idx) => (
                  <div
                    key={idx}
                    onClick={() => setLightboxPhoto(photoUrl)}
                    className="aspect-square rounded-xl overflow-hidden cursor-pointer relative group border border-slate-200 dark:border-slate-700"
                  >
                    <img
                      src={photoUrl}
                      alt={`Featured ${idx + 1}`}
                      className="h-full w-full object-cover group-hover:scale-108 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity">
                      <Sparkles className="h-4 w-4" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Stats Bar */}
          <div className="mt-6 grid grid-cols-4 divide-x divide-slate-200 rounded-xl bg-slate-50 p-4 dark:divide-slate-800 dark:bg-slate-800/50">
            <div className="text-center">
              <span className="block text-base md:text-lg font-black text-slate-900 dark:text-white">
                {userPosts.length}
              </span>
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                게시물
              </span>
            </div>
            <div className="text-center">
              <span className="block text-base md:text-lg font-black text-slate-900 dark:text-white">
                {formatNumber(profileUser.followersCount)}
              </span>
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                팔로워
              </span>
            </div>
            <div className="text-center">
              <span className="block text-base md:text-lg font-black text-slate-900 dark:text-white">
                {formatNumber(profileUser.followingCount)}
              </span>
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                팔로잉
              </span>
            </div>
            <div className="text-center">
              <span className="block text-base md:text-lg font-black text-slate-900 dark:text-white">
                {formatNumber(totalLikesReceived)}
              </span>
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                받은 좋아요
              </span>
            </div>
          </div>
        </div>

        {/* Profile Navigation Tabs */}
        <div className="flex border-t border-slate-200 dark:border-slate-800 overflow-x-auto">
          <button
            onClick={() => setActiveProfileTab('posts')}
            className={`flex flex-1 items-center justify-center gap-2 py-3.5 px-3 text-xs md:text-sm font-bold border-b-2 whitespace-nowrap transition-all ${
              activeProfileTab === 'posts'
                ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400 bg-blue-50/20 dark:bg-blue-950/20'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <FileText className="h-4 w-4" />
            <span>게시물 ({userPosts.length})</span>
          </button>

          <button
            onClick={() => setActiveProfileTab('media')}
            className={`flex flex-1 items-center justify-center gap-2 py-3.5 px-3 text-xs md:text-sm font-bold border-b-2 whitespace-nowrap transition-all ${
              activeProfileTab === 'media'
                ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400 bg-blue-50/20 dark:bg-blue-950/20'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <Grid className="h-4 w-4" />
            <span>미디어 ({userMediaPosts.length})</span>
          </button>

          <button
            onClick={() => setActiveProfileTab('about')}
            className={`flex flex-1 items-center justify-center gap-2 py-3.5 px-3 text-xs md:text-sm font-bold border-b-2 whitespace-nowrap transition-all ${
              activeProfileTab === 'about'
                ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400 bg-blue-50/20 dark:bg-blue-950/20'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <Info className="h-4 w-4" />
            <span>상세 정보 & 관심사</span>
          </button>

          <button
            onClick={() => setActiveProfileTab('liked')}
            className={`flex flex-1 items-center justify-center gap-2 py-3.5 px-3 text-xs md:text-sm font-bold border-b-2 whitespace-nowrap transition-all ${
              activeProfileTab === 'liked'
                ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400 bg-blue-50/20 dark:bg-blue-950/20'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <Heart className="h-4 w-4" />
            <span>좋아요 ({likedPosts.length})</span>
          </button>

          {isOwnProfile && (
            <button
              onClick={() => setActiveProfileTab('bookmarks')}
              className={`flex flex-1 items-center justify-center gap-2 py-3.5 px-3 text-xs md:text-sm font-bold border-b-2 whitespace-nowrap transition-all ${
                activeProfileTab === 'bookmarks'
                  ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400 bg-blue-50/20 dark:bg-blue-950/20'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              <Bookmark className="h-4 w-4" />
              <span>저장됨 ({bookmarkedPosts.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* Tab Content Stream */}
      <div className="flex flex-col gap-4">
        {/* ABOUT & INTERESTS TAB */}
        {activeProfileTab === 'about' ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50 flex flex-col gap-6">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                개인화 프로필 소개
              </h3>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-200/60 dark:border-slate-800">
                {profileUser.bio || '등록된 소개글이 없습니다.'}
              </p>
            </div>

            {/* Interests Breakdown */}
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
                <Tag className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                주요 관심사 및 취미 태그
              </h3>
              {profileUser.interests && profileUser.interests.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {profileUser.interests.map((tag, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleTagClick(tag)}
                      className="rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 px-3.5 py-1.5 text-xs font-semibold text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/80 transition-colors shadow-xs"
                    >
                      #{tag}
                    </button>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400">등록된 관심사가 없습니다.</p>
              )}
            </div>

            {/* Profile Information List */}
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
                기본 상세 정보
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                  <span className="text-xs font-medium text-slate-400 w-20">직업/역할</span>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {profileUser.role || '미설정'}
                  </span>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                  <span className="text-xs font-medium text-slate-400 w-20">거주/위치</span>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {profileUser.location || '미설정'}
                  </span>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                  <span className="text-xs font-medium text-slate-400 w-20">웹사이트</span>
                  {profileUser.website ? (
                    <a
                      href={profileUser.website}
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline truncate"
                    >
                      {profileUser.website}
                    </a>
                  ) : (
                    <span className="text-xs text-slate-400">미설정</span>
                  )}
                </div>
                <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                  <span className="text-xs font-medium text-slate-400 w-20">가입일</span>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    {profileUser.joinedDate}
                  </span>
                </div>
              </div>
            </div>

            {/* Display & Theme Preferences */}
            {isOwnProfile && (
              <div className="rounded-xl border border-slate-200 p-4 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                      화면 테마 설정 (낮/밤 모드 자동 전환)
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      OS 시스템 테마 변경 시 실시간으로 낮/밤 모드를 자동 전환합니다.
                    </p>
                  </div>
                  <ThemeSwitchMenu idPrefix="profile-theme" variant="segmented" />
                </div>
              </div>
            )}

            {isOwnProfile && (
              <div className="pt-2 flex items-center gap-2.5 flex-wrap">
                <button
                  type="button"
                  id="about-tab-edit-profile-btn"
                  onClick={onOpenEditProfile}
                  className="rounded-xl border border-slate-300 bg-white dark:border-slate-700 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-xs py-2.5 px-4 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-xs"
                >
                  프로필 및 테마/링크 수정
                </button>

                <button
                  type="button"
                  id="about-tab-edit-signup-btn"
                  onClick={openEditSignupInfoModal}
                  className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs py-2.5 px-4 shadow-sm shadow-indigo-600/20 transition-all active:scale-95 cursor-pointer"
                >
                  <ShieldCheck className="h-4 w-4" />
                  <span>회원가입 정보 수정 (이메일/비밀번호/지역/아이디)</span>
                </button>
              </div>
            )}
          </div>
        ) : displayedPosts.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-12 text-center ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
            {activeProfileTab === 'bookmarks' ? (
              <>
                <Bookmark className="h-8 w-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <p className="font-bold text-slate-700 dark:text-slate-300">
                  저장된 북마크가 없습니다
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  피드에서 게시물의 북마크 아이콘을 눌러 흥미로운 글을 저장해보세요.
                </p>
              </>
            ) : (
              <>
                <Sparkles className="h-8 w-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <p className="font-bold text-slate-700 dark:text-slate-300">
                  표시할 항목이 없습니다
                </p>
              </>
            )}
          </div>
        ) : activeProfileTab === 'media' ? (
          /* Media Photos Grid View */
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {userMediaPosts.flatMap((p) => {
              const galleryUrls: string[] = [];
              if (p.images && p.images.length > 0) {
                galleryUrls.push(...p.images);
              } else if (p.mediaItems && p.mediaItems.length > 0) {
                p.mediaItems.forEach((m) => {
                  if (m.type === 'image' && m.url) galleryUrls.push(m.url);
                  else if (m.thumbnail) galleryUrls.push(m.thumbnail);
                });
              }
              return galleryUrls.map((img, i) => (
                <div
                  key={`${p.id}-${i}`}
                  onClick={() => setLightboxPhoto(img)}
                  className="aspect-square overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-800 relative group cursor-pointer border border-slate-200/60 dark:border-slate-800"
                >
                  <img
                    src={img}
                    alt="Gallery photo"
                    className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-xs font-bold gap-3 transition-opacity">
                    <span className="flex items-center gap-1">
                      <Heart className="h-3.5 w-3.5 fill-white" />
                      {p.likes.length}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="h-3.5 w-3.5 fill-white" />
                      {p.commentsCount}
                    </span>
                  </div>
                </div>
              ));
            })}
          </div>
        ) : (
          displayedPosts.map((post) => <PostCard key={post.id} post={post} />)
        )}
      </div>

      {/* Lightbox Modal for Photo viewing */}
      {lightboxPhoto && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => setLightboxPhoto(null)}
        >
          <button
            onClick={() => setLightboxPhoto(null)}
            className="absolute top-4 right-4 z-50 rounded-full bg-white/20 p-2.5 text-white hover:bg-white/30 backdrop-blur-md transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
          <img
            src={lightboxPhoto}
            alt="Expanded view"
            className="max-h-[85vh] max-w-[90vw] rounded-xl object-contain shadow-2xl"
            onClick={(e) => e.stopPropagation()}
            referrerPolicy="no-referrer"
          />
        </div>
      )}
    </div>
  );
};
