import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { useSocial } from '../context/SocialContext';
import { StoriesBar } from './StoriesBar';
import { PostCard } from './PostCard';
import { generateMoreMockPosts } from '../data/mockData';
import { Post } from '../types';
import {
  Sparkles,
  Users,
  Flame,
  Image as ImageIcon,
  PlusCircle,
  X,
  Filter,
  Film,
  CheckCircle2,
  Loader2,
  ArrowUp,
  RefreshCw,
  Layers,
  Clock,
  CalendarClock,
  MapPin
} from 'lucide-react';
import { ScheduledPostsModal } from './ScheduledPostsModal';
import { RegionalScope, REGIONAL_SCOPES, getRegionalScopeConfig } from '../data/regionalScope';
import { isPostMatchingUserLocation, getScopeFilterExplanation } from '../data/regionalMatching';

import { CreatePostInitialMode } from './CreatePostModal';

interface FeedViewProps {
  onOpenCreatePost: (initialMode?: CreatePostInitialMode) => void;
  onOpenCreateStory: () => void;
}

type FeedFilter = 'all' | 'following' | 'trending' | 'media';

const INITIAL_BATCH_SIZE = 4;
const LOAD_MORE_BATCH_SIZE = 3;

export const FeedView: React.FC<FeedViewProps> = ({ onOpenCreatePost, onOpenCreateStory }) => {
  const { currentUser, posts, deletedPostIds, scheduledPosts, activeTag, setActiveTag } = useSocial();
  const [feedFilter, setFeedFilter] = useState<FeedFilter>('all');
  const [selectedRegionalScope, setSelectedRegionalScope] = useState<'all' | RegionalScope>('all');
  const [prioritizeFollowing, setPrioritizeFollowing] = useState<boolean>(true);
  const [showScheduledModal, setShowScheduledModal] = useState<boolean>(false);

  // Dynamic feed extension state for infinite scrolling
  const [extraPosts, setExtraPosts] = useState<Post[]>([]);
  const [dynamicPage, setDynamicPage] = useState<number>(1);
  const [visibleCount, setVisibleCount] = useState<number>(INITIAL_BATCH_SIZE);
  const [isLoadingMore, setIsLoadingMore] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [showScrollTop, setShowScrollTop] = useState<boolean>(false);
  const [autoScrollEnabled, setAutoScrollEnabled] = useState<boolean>(true);

  // Ref for intersection observer sentinel
  const sentinelRef = useRef<HTMLDivElement | null>(null);
  const isFetchingRef = useRef<boolean>(false);

  // Auto-scroll to shared post if URL has ?post=postId
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sharedPostId = params.get('post');
    if (sharedPostId) {
      setTimeout(() => {
        const el = document.getElementById(`post-card-${sharedPostId}`);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          el.classList.add('ring-2', 'ring-indigo-500', 'ring-offset-2', 'dark:ring-offset-slate-900');
          setTimeout(() => {
            el.classList.remove('ring-2', 'ring-indigo-500', 'ring-offset-2', 'dark:ring-offset-slate-900');
          }, 3000);
        }
      }, 300);
    }
  }, []);

  // Monitor scroll position for "Back to top" button
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 450) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Reset pagination when filter, activeTag, or selectedRegionalScope changes
  useEffect(() => {
    setVisibleCount(INITIAL_BATCH_SIZE);
  }, [feedFilter, activeTag, selectedRegionalScope]);

  // Merge context posts and extra dynamically generated posts (strictly excluding any deleted posts)
  const combinedPosts = useMemo(() => {
    const deletedSet = new Set(deletedPostIds || []);
    const validContextPosts = posts.filter(
      (p) => !deletedSet.has(p.id) && !(p as any).isDeleted
    );
    const existingIds = new Set(validContextPosts.map((p) => p.id));
    const uniqueExtra = extraPosts.filter(
      (p) => !existingIds.has(p.id) && !deletedSet.has(p.id) && !(p as any).isDeleted
    );
    return [...validContextPosts, ...uniqueExtra];
  }, [posts, extraPosts, deletedPostIds]);

  // User location helper
  const userLocation = currentUser.location || '서울 강남구';

  // Count posts available per regional scope for chip badges based on user's location
  const scopeCounts = useMemo(() => {
    const counts: Record<string, number> = { all: combinedPosts.length };
    for (const scopeConfig of REGIONAL_SCOPES) {
      const matchCount = combinedPosts.filter((post) =>
        isPostMatchingUserLocation(post.location, userLocation, scopeConfig.id, post.regionalScope)
      ).length;
      counts[scopeConfig.id] = matchCount;
    }
    return counts;
  }, [combinedPosts, userLocation]);

  // Filter and sort posts with following prioritization and user location matching
  const processedPosts = useMemo(() => {
    // 1. Filter posts based on active category, active hashtag, and user location
    const filtered = combinedPosts.filter((post) => {
      // Ensure deleted posts are never shown on the main page
      if ((deletedPostIds || []).includes(post.id) || (post as any).isDeleted) {
        return false;
      }

      // User location-based regional scope filter
      if (selectedRegionalScope !== 'all') {
        const matchesLocation = isPostMatchingUserLocation(
          post.location,
          userLocation,
          selectedRegionalScope,
          post.regionalScope
        );
        if (!matchesLocation) {
          return false;
        }
      }

      // Hashtag filter
      if (activeTag) {
        const matchesContent = post.content.toLowerCase().includes(activeTag.toLowerCase());
        const matchesTags = post.tags?.some((t) =>
          t.toLowerCase().includes(activeTag.toLowerCase())
        );
        if (!matchesContent && !matchesTags) return false;
      }

      if (feedFilter === 'following') {
        return (
          currentUser.followingIds?.includes(post.authorId) ||
          post.authorId === currentUser.id
        );
      }

      if (feedFilter === 'trending') {
        return (post.likes?.length || 0) >= 2 || post.commentsCount >= 2;
      }

      if (feedFilter === 'media') {
        return (post.images && post.images.length > 0) || Boolean(post.video);
      }

      return true;
    });

    // 2. Sort posts
    if (feedFilter === 'all' && prioritizeFollowing) {
      // Sort: Followed users & own posts first (newest to oldest), then others (newest to oldest)
      return [...filtered].sort((a, b) => {
        const aIsFollowed = currentUser.followingIds?.includes(a.authorId) || a.authorId === currentUser.id;
        const bIsFollowed = currentUser.followingIds?.includes(b.authorId) || b.authorId === currentUser.id;

        if (aIsFollowed && !bIsFollowed) return -1;
        if (!aIsFollowed && bIsFollowed) return 1;

        // Same group: sort by date descending
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
    }

    if (feedFilter === 'trending') {
      return [...filtered].sort((a, b) => {
        const aScore = (a.likes?.length || 0) * 2 + (a.commentsCount || 0) * 3 + (a.reposts?.length || 0) * 2;
        const bScore = (b.likes?.length || 0) * 2 + (b.commentsCount || 0) * 3 + (b.reposts?.length || 0) * 2;
        return bScore - aScore;
      });
    }

    // Default chronological sort
    return [...filtered].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [combinedPosts, selectedRegionalScope, userLocation, activeTag, feedFilter, prioritizeFollowing, currentUser]);

  // Posts currently rendered on screen
  const visiblePosts = useMemo(() => {
    return processedPosts.slice(0, visibleCount);
  }, [processedPosts, visibleCount]);

  // Check if there are more posts or if dynamic batches can be generated
  const hasMore = useMemo(() => {
    if (visibleCount < processedPosts.length) return true;
    // If we've reached the end of current pool in 'all' or 'trending' tab, allow up to page 5 dynamic fetches
    if ((feedFilter === 'all' || feedFilter === 'trending') && dynamicPage <= 4) {
      return true;
    }
    return false;
  }, [visibleCount, processedPosts.length, feedFilter, dynamicPage]);

  // Load more handler with realistic delay
  const handleLoadMore = useCallback(() => {
    if (isFetchingRef.current || !hasMore || isLoadingMore) return;

    isFetchingRef.current = true;
    setIsLoadingMore(true);

    setTimeout(() => {
      // If we still have unshown posts in the current pool
      if (visibleCount < processedPosts.length) {
        setVisibleCount((prev) => Math.min(prev + LOAD_MORE_BATCH_SIZE, processedPosts.length));
        setIsLoadingMore(false);
        isFetchingRef.current = false;
      } else if ((feedFilter === 'all' || feedFilter === 'trending') && dynamicPage <= 4) {
        // Fetch new dynamic mock batch
        const nextBatch = generateMoreMockPosts(dynamicPage);
        setExtraPosts((prev) => [...prev, ...nextBatch]);
        setDynamicPage((prev) => prev + 1);
        setVisibleCount((prev) => prev + LOAD_MORE_BATCH_SIZE);
        setIsLoadingMore(false);
        isFetchingRef.current = false;
      } else {
        setIsLoadingMore(false);
        isFetchingRef.current = false;
      }
    }, 600);
  }, [hasMore, isLoadingMore, visibleCount, processedPosts.length, feedFilter, dynamicPage]);

  // Setup IntersectionObserver for auto-loading
  useEffect(() => {
    if (!autoScrollEnabled || !hasMore) return;

    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const first = entries[0];
        if (first.isIntersecting && !isFetchingRef.current) {
          handleLoadMore();
        }
      },
      {
        root: null,
        rootMargin: '350px', // Trigger before reaching the very end for seamless scroll
        threshold: 0.1
      }
    );

    observer.observe(sentinel);

    return () => {
      observer.disconnect();
    };
  }, [handleLoadMore, autoScrollEnabled, hasMore]);

  // Manual Feed Refresh
  const handleRefreshFeed = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setVisibleCount(INITIAL_BATCH_SIZE);
      setIsRefreshing(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 500);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filterTabs: { id: FeedFilter; label: string; icon: React.ElementType; badge?: string }[] = [
    { id: 'all', label: '추천 피드', icon: Sparkles, badge: '팔로잉 우선' },
    { id: 'following', label: '팔로잉 피드', icon: Users },
    { id: 'media', label: '사진 & 동영상', icon: ImageIcon },
    { id: 'trending', label: '인기 급상승', icon: Flame }
  ];

  return (
    <div className="flex flex-col gap-5 relative">
      {/* 1. Stories Carousel Box */}
      <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
        <StoriesBar onOpenCreateStory={onOpenCreateStory} />
      </section>

      {/* 2. Quick Post Trigger Box */}
      <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
        <div
          onClick={() => onOpenCreatePost()}
          className="flex items-center gap-3 cursor-pointer"
        >
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="h-10 w-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
            referrerPolicy="no-referrer"
          />
          <div className="flex-1 rounded-full bg-slate-100 dark:bg-slate-800 px-4 py-2.5 text-xs md:text-sm text-slate-400 hover:bg-slate-200/70 dark:hover:bg-slate-700/70 transition-colors">
            {currentUser.name}님, 오늘 어떤 일이 있었나요? 텍스트, 사진, 동영상을 공유해보세요...
          </div>
          <button
            type="button"
            className="flex h-9 items-center gap-1.5 rounded-full bg-blue-600 px-4 text-xs font-bold text-white shadow-xs shadow-blue-600/20 hover:bg-blue-700 transition-colors shrink-0"
          >
            <PlusCircle className="h-4 w-4" />
            <span className="hidden sm:inline">게시물 작성</span>
          </button>
        </div>

        {/* Quick Media Action Buttons */}
        <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center flex-wrap gap-2">
            <button
              type="button"
              onClick={() => onOpenCreatePost('photo')}
              className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-emerald-400 transition-colors cursor-pointer"
            >
              <ImageIcon className="h-4 w-4 text-emerald-500" />
              <span>사진 올리기</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenCreatePost('video')}
              className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-rose-50 hover:text-rose-600 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-rose-400 transition-colors cursor-pointer"
            >
              <Film className="h-4 w-4 text-rose-500" />
              <span>동영상 공유</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenCreatePost('schedule')}
              className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-indigo-400 transition-colors cursor-pointer"
            >
              <Clock className="h-4 w-4 text-indigo-500" />
              <span>예약 전송</span>
            </button>
            <button
              type="button"
              onClick={() => onOpenCreatePost('location')}
              className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-blue-50 hover:text-blue-600 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-blue-400 transition-colors cursor-pointer"
            >
              <MapPin className="h-4 w-4 text-blue-500" />
              <span>지역별 공개</span>
            </button>
          </div>
          <div className="flex items-center gap-3">
            {scheduledPosts.filter((p) => p.authorId === currentUser.id).length > 0 && (
              <button
                type="button"
                onClick={() => setShowScheduledModal(true)}
                className="flex items-center gap-1.5 rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400 dark:hover:bg-indigo-900/60 transition-colors cursor-pointer"
              >
                <CalendarClock className="h-3.5 w-3.5" />
                <span>예약 글 {scheduledPosts.filter((p) => p.authorId === currentUser.id).length}개</span>
              </button>
            )}
            <button
              onClick={handleRefreshFeed}
              disabled={isRefreshing}
              title="피드 새로고침"
              className="flex items-center gap-1 text-[11px] font-semibold text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-blue-600' : ''}`} />
              <span className="hidden sm:inline">새로고침</span>
            </button>
          </div>
        </div>
      </section>

      {/* Active Hashtag Filter Banner */}
      {activeTag && (
        <div className="flex items-center justify-between rounded-xl bg-blue-50 px-4 py-2.5 text-xs font-semibold text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200 dark:border-blue-900">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-blue-600" />
            <span>#{activeTag} 해시태그 검색 결과</span>
          </div>
          <button
            onClick={() => setActiveTag(null)}
            className="flex items-center gap-1 hover:underline text-slate-500 dark:text-slate-400"
          >
            <span>전체보기</span>
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* 3. Feed Filter Tabs & Prioritization Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-1 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {filterTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = feedFilter === tab.id;
            return (
              <button
                key={tab.id}
                id={`feed-filter-${tab.id}`}
                onClick={() => setFeedFilter(tab.id)}
                className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs md:text-sm font-bold transition-all shrink-0 ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-xs shadow-blue-600/20'
                    : 'text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Following Priority Indicator / Status */}
        {feedFilter === 'all' && (
          <div className="flex items-center gap-1.5 self-end sm:self-auto text-[11px] text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/80 px-2.5 py-1 rounded-lg">
            <CheckCircle2 className="h-3.5 w-3.5 text-blue-600" />
            <span>팔로잉 우선 정렬 적용 중</span>
          </div>
        )}
      </div>

      {/* 3.1 Regional Scope Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1.5 px-0.5 text-xs">
        <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 shrink-0 flex items-center gap-1 mr-1">
          <MapPin className="h-3.5 w-3.5 text-blue-500" />
          지역별 피드:
        </span>
        <button
          type="button"
          id="scope-filter-all"
          onClick={() => setSelectedRegionalScope('all')}
          title="전체 지역 게시물 보기"
          className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition-all shrink-0 cursor-pointer ${
            selectedRegionalScope === 'all'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
          }`}
        >
          <span>🌐</span>
          <span>전체 피드</span>
          <span className="text-[10px] opacity-75 font-normal">
            ({scopeCounts['all'] || 0})
          </span>
        </button>
        {REGIONAL_SCOPES.map((scope) => {
          const isSelected = selectedRegionalScope === scope.id;
          const count = scopeCounts[scope.id] || 0;
          return (
            <button
              key={scope.id}
              type="button"
              id={`scope-filter-${scope.id}`}
              onClick={() => setSelectedRegionalScope(scope.id)}
              title={`${scope.label} (내 위치: ${userLocation})`}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition-all shrink-0 cursor-pointer border ${
                isSelected
                  ? `${scope.activeBtnClass} shadow-xs font-bold scale-[1.02]`
                  : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50'
              }`}
            >
              <span>{scope.emoji}</span>
              <span>{scope.label}</span>
              <span className={`text-[10px] px-1 rounded-full ${
                isSelected
                  ? 'bg-white/30 dark:bg-black/20 font-bold'
                  : 'bg-slate-100 dark:bg-slate-700/60 text-slate-500 dark:text-slate-400'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
        {selectedRegionalScope !== 'all' && (
          <button
            type="button"
            onClick={() => setSelectedRegionalScope('all')}
            className="text-[11px] font-semibold text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-200 underline ml-1 shrink-0 cursor-pointer"
          >
            전체 보기
          </button>
        )}
      </div>

      {/* Active Regional Filter Status Banner */}
      {selectedRegionalScope !== 'all' && (() => {
        const info = getScopeFilterExplanation(userLocation, selectedRegionalScope);
        const config = getRegionalScopeConfig(selectedRegionalScope);
        return (
          <div className="flex items-center justify-between gap-3 px-3.5 py-2.5 bg-blue-50/90 dark:bg-blue-950/40 border border-blue-200/90 dark:border-blue-800/80 rounded-xl text-xs shadow-xs animate-in fade-in duration-150">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-base leading-none shrink-0">{config.emoji}</span>
              <div className="truncate">
                <span className="font-bold text-blue-900 dark:text-blue-100 mr-1.5">
                  [{config.label}] {info.targetRegion}
                </span>
                <span className="text-blue-700 dark:text-blue-300">
                  해당 게시물 <strong>{processedPosts.length}개</strong> 표시 중
                </span>
                <span className="text-slate-400 dark:text-slate-500 ml-1.5 text-[11px] hidden md:inline">
                  (내 위치: {userLocation} · {info.explanation})
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setSelectedRegionalScope('all')}
              className="shrink-0 px-2.5 py-1 rounded-lg text-xs font-bold text-blue-700 hover:text-blue-900 dark:text-blue-300 dark:hover:text-blue-100 bg-blue-100/70 hover:bg-blue-200/80 dark:bg-blue-900/50 transition-colors cursor-pointer"
            >
              전체 지역으로 보기
            </button>
          </div>
        );
      })()}

      {/* 4. Posts Feed Stream */}
      <div className="flex flex-col gap-4">
        {visiblePosts.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center dark:border-slate-800 dark:bg-slate-900 ring-1 ring-slate-200/50">
            <Sparkles className="h-10 w-10 text-blue-400 mb-3" />
            <p className="font-bold text-slate-800 dark:text-slate-200">
              {selectedRegionalScope !== 'all'
                ? `${getRegionalScopeConfig(selectedRegionalScope).emoji} ${getRegionalScopeConfig(selectedRegionalScope).label} 범위에 해당하는 게시물이 없습니다`
                : '해당 피드에 표시할 게시물이 없습니다'}
            </p>
            <p className="text-xs text-slate-400 mt-1 max-w-sm">
              {selectedRegionalScope !== 'all'
                ? `현재 선택된 "${getRegionalScopeConfig(selectedRegionalScope).label}" 범위의 게시물이 없습니다. 필터를 해제하거나 이 지역 범위로 새 게시물을 작성해보세요!`
                : feedFilter === 'following'
                ? '아직 팔로우한 사용자의 새 게시물이 없습니다. 다양한 사용자들을 팔로우해보세요!'
                : '새로운 텍스트, 사진, 동영상 게시물을 직접 작성해보세요!'}
            </p>
            <div className="mt-4 flex items-center gap-2">
              {selectedRegionalScope !== 'all' && (
                <button
                  onClick={() => setSelectedRegionalScope('all')}
                  className="rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 px-4 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer transition-colors"
                >
                  전체 지역 게시물 보기
                </button>
              )}
              <button
                onClick={() => onOpenCreatePost()}
                className="rounded-xl bg-blue-600 px-5 py-2 text-xs font-bold text-white hover:bg-blue-700 shadow-xs shadow-blue-600/20 cursor-pointer transition-colors"
              >
                게시물 작성하기
              </button>
            </div>
          </div>
        ) : (
          <>
            {visiblePosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                onTagClick={(t) => setActiveTag(t)}
                onScopeClick={(scope) => setSelectedRegionalScope(scope)}
              />
            ))}

            {/* Infinite Scroll Trigger Sentinel */}
            <div
              id="feed-infinite-scroll-sentinel"
              ref={sentinelRef}
              className="h-6 w-full -mt-2 pointer-events-none"
              aria-hidden="true"
            />

            {/* Loading Indicator / Skeleton while fetching next batch */}
            {isLoadingMore && (
              <div className="flex flex-col gap-3 animate-in fade-in duration-200">
                {/* Skeleton Post Card */}
                <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs dark:border-slate-800 dark:bg-slate-900 animate-pulse">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-800" />
                    <div className="space-y-1.5 flex-1">
                      <div className="w-28 h-3.5 rounded-full bg-slate-200 dark:bg-slate-800" />
                      <div className="w-16 h-2.5 rounded-full bg-slate-200 dark:bg-slate-800" />
                    </div>
                  </div>
                  <div className="space-y-2 mb-3">
                    <div className="w-full h-3 rounded-full bg-slate-200 dark:bg-slate-800" />
                    <div className="w-4/5 h-3 rounded-full bg-slate-200 dark:bg-slate-800" />
                  </div>
                  <div className="w-full h-44 rounded-xl bg-slate-100 dark:bg-slate-800/60" />
                </div>

                {/* Status Message */}
                <div className="flex items-center justify-center gap-2 py-3 text-xs font-semibold text-slate-500 dark:text-slate-400">
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                  <span>새로운 피드 게시물을 불러오는 중...</span>
                </div>
              </div>
            )}

            {/* End of Feed Banner or Manual Load More Fallback */}
            {!isLoadingMore && (
              <div className="mt-2 text-center py-4">
                {hasMore ? (
                  <button
                    id="feed-manual-load-more-btn"
                    onClick={handleLoadMore}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors shadow-xs"
                  >
                    <Layers className="w-3.5 h-3.5 text-indigo-600" />
                    <span>게시물 더 불러오기</span>
                  </button>
                ) : (
                  <div className="flex flex-col items-center justify-center p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/60">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-100 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400 mb-2">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      모든 최신 소식을 확인했습니다 ✨
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      새로운 친구를 팔로우하거나 상단의 작성 버튼으로 일상을 공유해보세요!
                    </p>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* Scheduled Posts Modal */}
      <ScheduledPostsModal
        isOpen={showScheduledModal}
        onClose={() => setShowScheduledModal(false)}
        onOpenCreatePost={onOpenCreatePost}
      />
    </div>
  );
};


