import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { ActiveTab } from '../types';
import { ThemeSwitchMenu } from './ThemeSwitchMenu';
import {
  Home,
  Compass,
  Bell,
  MessageCircle,
  Bookmark,
  User,
  PlusCircle,
  Moon,
  Sun,
  Users,
  Check,
  LogOut,
  LogIn,
  UserPlus,
  ShieldCheck,
  ShieldAlert,
  Database
} from 'lucide-react';

interface SidebarProps {
  onOpenCreatePost: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onOpenCreatePost }) => {
  const {
    currentUser,
    posts,
    activeTab,
    setActiveTab,
    unreadNotificationsCount,
    unreadMessagesCount,
    isDarkMode,
    toggleDarkMode,
    setViewingUserId,
    isAuthenticated,
    openAuthModal,
    logout,
    openEditSignupInfoModal,
    unlockSuperAdminDatabase
  } = useSocial();

  const [showUserSwitcher, setShowUserSwitcher] = useState(false);

  const myBookmarksCount = posts.filter((p) => p.bookmarks?.includes(currentUser.id)).length;

  const navItems: { id: ActiveTab; label: string; icon: React.ElementType; badge?: number; highlight?: boolean }[] = [
    { id: 'feed', label: '홈 피드', icon: Home },
    { id: 'explore', label: '탐색 & 트렌드', icon: Compass },
    { id: 'notifications', label: '알림', icon: Bell, badge: unreadNotificationsCount },
    { id: 'messages', label: '메시지 (DM)', icon: MessageCircle, badge: unreadMessagesCount },
    { id: 'bookmarks', label: '북마크 저장됨', icon: Bookmark, badge: myBookmarksCount > 0 ? myBookmarksCount : undefined },
    { id: 'profile', label: '내 프로필', icon: User }
  ];

  const handleNavClick = (tabId: ActiveTab) => {
    if (tabId === 'profile') {
      if (!isAuthenticated) {
        openAuthModal('login');
        return;
      }
      setViewingUserId(currentUser.id);
    }
    setActiveTab(tabId);
  };

  return (
    <aside className="sticky top-0 h-screen w-64 xl:w-72 flex-col justify-between border-r border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 hidden md:flex z-30 select-none">
      {/* Top Logo & Nav */}
      <div className="flex flex-col gap-6">
        {/* Brand Header */}
        <div className="flex items-center justify-between px-1">
          <div
            id="brand-logo-btn"
            onClick={() => handleNavClick('feed')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-600/20 group-hover:scale-105 transition-transform font-bold text-lg">
              M
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
                마음
              </span>
              <p className="text-[11px] font-medium text-slate-400 -mt-1">소셜 네트워크</p>
            </div>
          </div>

          {/* Dark / Light / System Auto Mode Toggle */}
          <ThemeSwitchMenu idPrefix="sidebar-theme" variant="sidebar" />
        </div>

        {/* Nav Links */}
        <nav className="flex flex-col gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`relative flex items-center justify-between rounded-xl px-4 py-3 text-sm font-semibold transition-all ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400 font-bold shadow-xs'
                    : 'text-slate-500 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`h-5 w-5 transition-transform ${
                      isActive
                        ? 'stroke-[2.5px] text-indigo-600 dark:text-indigo-400'
                        : 'stroke-2'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge !== undefined && item.badge > 0 ? (
                  <span className="flex h-5 min-w-[20px] items-center justify-center rounded-full bg-rose-500 px-1.5 text-[11px] font-bold text-white shadow-xs animate-pulse">
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </nav>

        {/* Create Post Button */}
        <button
          id="sidebar-create-post-btn"
          onClick={() => {
            if (!isAuthenticated) {
              openAuthModal('login');
              return;
            }
            onOpenCreatePost();
          }}
          className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 py-3 px-4 text-sm font-semibold text-white shadow-md shadow-indigo-600/25 hover:from-indigo-700 hover:to-purple-700 active:scale-[0.98] transition-all"
        >
          <PlusCircle className="h-4 w-4" />
          <span>새 게시물 작성</span>
        </button>
      </div>

      {/* Bottom Auth Section */}
      <div className="relative pt-4 border-t border-slate-100 dark:border-slate-800">
        {isAuthenticated ? (
          <>
            {/* Switcher Popover */}
            {showUserSwitcher && (
              <div
                id="user-switcher-popover"
                className="absolute bottom-20 left-0 right-0 rounded-2xl border border-slate-200 bg-white p-3 shadow-xl dark:border-slate-800 dark:bg-slate-900 z-50 animate-in fade-in slide-in-from-bottom-2 duration-150 space-y-2"
              >
                <div className="flex items-center justify-between px-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                  <span className="text-xs font-bold text-slate-700 dark:text-slate-200 tracking-tight flex items-center gap-1.5">
                    <Users className="h-3.5 w-3.5 text-indigo-600" />
                    계정관리
                  </span>
                  <span className="text-[10px] bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 px-1.5 py-0.5 rounded font-medium flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    현재 로그인 계정
                  </span>
                </div>

                {/* Current Logged In Account Details (No switching to other accounts) */}
                <div className="p-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 rounded-xl">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      className="h-9 w-9 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate flex items-center gap-1">
                        {currentUser.name}
                        {currentUser.isAdmin && (
                          <span className="text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 px-1 py-0.2 rounded font-normal">
                            관리자
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">@{currentUser.handle}</div>
                    </div>
                    <Check className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                  </div>
                </div>

                {/* Account Actions in Popover */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                  <button
                    type="button"
                    id="sidebar-edit-signup-info-btn"
                    onClick={() => {
                      setShowUserSwitcher(false);
                      openEditSignupInfoModal();
                    }}
                    className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-indigo-700 bg-indigo-50 dark:bg-indigo-950/60 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 rounded-lg transition-colors font-bold border border-indigo-200/70 dark:border-indigo-800/70 cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    <span>회원가입 정보 수정</span>
                  </button>

                  {/* Super Admin Database Buttons */}
                  {(currentUser?.isAdmin || currentUser?.handle === 'admin') && (
                    <div className="space-y-1.5 pt-0.5">
                      <button
                        type="button"
                        id="sidebar-db-management-btn"
                        onClick={() => {
                          setShowUserSwitcher(false);
                          unlockSuperAdminDatabase();
                          setActiveTab('database');
                        }}
                        className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-emerald-700 bg-emerald-50 dark:bg-emerald-950/60 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 rounded-lg transition-colors font-bold border border-emerald-200/70 dark:border-emerald-800/70 cursor-pointer"
                      >
                        <Database className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                        <span>데이타베이스(DB) 콘솔</span>
                      </button>

                      <button
                        type="button"
                        id="sidebar-admin-page-btn"
                        onClick={() => {
                          setShowUserSwitcher(false);
                          setActiveTab('admin');
                        }}
                        className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-indigo-700 bg-indigo-50 dark:bg-indigo-950/60 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 rounded-lg transition-colors font-bold border border-indigo-200/70 dark:border-indigo-800/70 cursor-pointer"
                      >
                        <ShieldAlert className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                        <span>관리자페이지</span>
                      </button>
                    </div>
                  )}

                  <button
                    onClick={() => {
                      setShowUserSwitcher(false);
                      logout();
                      openAuthModal('signup');
                    }}
                    className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors font-medium cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>새 계정 회원가입</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowUserSwitcher(false);
                      logout();
                    }}
                    className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors font-medium"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    로그아웃
                  </button>
                </div>
              </div>
            )}

            {/* Current User Card Button */}
            <div className="flex items-center justify-between gap-1">
              <button
                id="current-user-profile-button"
                onClick={() => setShowUserSwitcher((prev) => !prev)}
                className="flex flex-1 items-center gap-2.5 rounded-xl p-2 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left group min-w-0"
              >
                <div className="relative shrink-0">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="h-10 w-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                    {currentUser.name}
                  </p>
                  <p className="text-xs text-slate-400 truncate">@{currentUser.handle}</p>
                </div>
              </button>

              <button
                id="sidebar-logout-quick-btn"
                onClick={logout}
                title="로그아웃"
                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors shrink-0"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </>
        ) : (
          /* Logged Out / Guest State */
          <div className="space-y-2">
            <div className="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 rounded-xl">
              <p className="text-xs font-bold text-indigo-900 dark:text-indigo-200">
                로그인이 필요합니다
              </p>
              <p className="text-[11px] text-indigo-700/80 dark:text-indigo-300/80 mt-0.5">
                게시물 작성, 좋아요, 댓글, DM 소통을 위해 로그인하세요.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                id="sidebar-login-btn"
                onClick={() => openAuthModal('login')}
                className="flex-1 py-2 px-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-sm flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
              >
                <LogIn className="w-3.5 h-3.5 shrink-0" />
                <span>로그인</span>
              </button>

              <button
                id="sidebar-signup-btn"
                onClick={() => openAuthModal('signup')}
                className="flex-1 py-2 px-2.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
              >
                <UserPlus className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <span>회원가입</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};

