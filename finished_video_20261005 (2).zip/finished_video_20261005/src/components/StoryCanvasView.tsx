import React, { useRef, useState, useEffect } from 'react';
import { StoryTextOverlay, StoryStickerOverlay } from '../types';
import { getStoryFilterCss } from '../data/storyFiltersData';
import { PRESET_TEXT_STYLES } from '../data/storyStickersData';
import {
  Trash2,
  Move,
  Type,
  Sparkles,
  Camera,
  Image as ImageIcon,
  Upload,
  RefreshCw,
  Smartphone,
  Film,
  Play,
  Volume2,
  VolumeX
} from 'lucide-react';

interface StoryCanvasViewProps {
  mediaUrl: string;
  mediaType?: 'image' | 'video';
  filterId?: string;
  textOverlays?: StoryTextOverlay[];
  stickerOverlays?: StoryStickerOverlay[];
  caption?: string;
  interactive?: boolean;
  isPaused?: boolean;
  selectedItemId?: string | null;
  selectedItemType?: 'text' | 'sticker' | null;
  onSelectItem?: (item: { type: 'text' | 'sticker'; id: string } | null) => void;
  onUpdateTextPosition?: (id: string, x: number, y: number) => void;
  onUpdateStickerPosition?: (id: string, x: number, y: number) => void;
  onDeleteOverlay?: (type: 'text' | 'sticker', id: string) => void;
  className?: string;
  imageClassName?: string;
  // Camera & Photo & Video Selection Handlers
  onTriggerCamera?: () => void;
  onTriggerGallery?: () => void;
  onTriggerVideo?: () => void;
  onTriggerLiveCamera?: () => void;
  isProcessing?: boolean;
  onDropPhoto?: (file: File) => void;
  onDurationLoaded?: (duration: number) => void;
  onVideoEnded?: () => void;
  onVideoTimeUpdate?: (currentTime: number, duration: number) => void;
}

export const StoryCanvasView: React.FC<StoryCanvasViewProps> = ({
  mediaUrl,
  mediaType,
  filterId = 'normal',
  textOverlays = [],
  stickerOverlays = [],
  caption,
  interactive = false,
  isPaused = false,
  selectedItemId = null,
  selectedItemType = null,
  onSelectItem,
  onUpdateTextPosition,
  onUpdateStickerPosition,
  onDeleteOverlay,
  className = '',
  imageClassName = 'object-cover',
  onTriggerCamera,
  onTriggerGallery,
  onTriggerVideo,
  onTriggerLiveCamera,
  isProcessing = false,
  onDropPhoto,
  onDurationLoaded,
  onVideoEnded,
  onVideoTimeUpdate
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [isVideoMuted, setIsVideoMuted] = useState(true);
  const [draggingItem, setDraggingItem] = useState<{
    type: 'text' | 'sticker';
    id: string;
    startX: number;
    startY: number;
    initX: number;
    initY: number;
  } | null>(null);

  const filterCss = getStoryFilterCss(filterId);

  const isVideo =
    mediaType === 'video' ||
    /\.(mp4|mov|webm|mkv|3gp|avi|m4v)(\?.*)?$/i.test(mediaUrl) ||
    mediaUrl.startsWith('data:video/');

  // Video play/pause effect based on isPaused prop
  useEffect(() => {
    if (!videoRef.current || !isVideo) return;
    if (isPaused) {
      videoRef.current.pause();
    } else {
      videoRef.current.play().catch(() => {});
    }
  }, [isPaused, isVideo, mediaUrl]);

  // Drag-and-drop for photo/video files onto canvas
  const handleDragOver = (e: React.DragEvent) => {
    if (!interactive) return;
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    if (!interactive) return;
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/') || file.type.startsWith('video/')) {
        onDropPhoto?.(file);
      }
    }
  };

  // Dragging logic for interactive mode
  const handlePointerDown = (
    e: React.PointerEvent,
    type: 'text' | 'sticker',
    id: string,
    currentX: number,
    currentY: number
  ) => {
    if (!interactive) return;
    e.stopPropagation();
    e.preventDefault();

    onSelectItem?.({ type, id });

    setDraggingItem({
      type,
      id,
      startX: e.clientX,
      startY: e.clientY,
      initX: currentX,
      initY: currentY
    });
  };

  useEffect(() => {
    if (!draggingItem || !containerRef.current) return;

    const handlePointerMove = (e: PointerEvent) => {
      if (!containerRef.current || !draggingItem) return;
      const rect = containerRef.current.getBoundingClientRect();
      const deltaXPixels = e.clientX - draggingItem.startX;
      const deltaYPixels = e.clientY - draggingItem.startY;

      const deltaXPercent = (deltaXPixels / rect.width) * 100;
      const deltaYPercent = (deltaYPixels / rect.height) * 100;

      const newX = Math.max(5, Math.min(95, draggingItem.initX + deltaXPercent));
      const newY = Math.max(5, Math.min(95, draggingItem.initY + deltaYPercent));

      if (draggingItem.type === 'text') {
        onUpdateTextPosition?.(draggingItem.id, newX, newY);
      } else {
        onUpdateStickerPosition?.(draggingItem.id, newX, newY);
      }
    };

    const handlePointerUp = () => {
      setDraggingItem(null);
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
    };
  }, [draggingItem, onUpdateTextPosition, onUpdateStickerPosition]);

  const getTextClassByStyle = (overlay: StoryTextOverlay) => {
    const stylePreset = PRESET_TEXT_STYLES.find((s) => s.id === overlay.styleType);
    const bgClass = stylePreset ? stylePreset.bgClass : 'bg-black/60 px-3 py-1 rounded-xl shadow-md';

    let sizeClass = 'text-base';
    if (overlay.fontSize === 'sm') sizeClass = 'text-xs';
    else if (overlay.fontSize === 'base') sizeClass = 'text-sm sm:text-base';
    else if (overlay.fontSize === 'lg') sizeClass = 'text-base sm:text-lg font-bold';
    else if (overlay.fontSize === 'xl') sizeClass = 'text-lg sm:text-xl font-bold';
    else if (overlay.fontSize === '2xl') sizeClass = 'text-xl sm:text-2xl font-black';

    return `${bgClass} ${sizeClass}`;
  };

  return (
    <div
      ref={containerRef}
      id="story-canvas-container"
      onClick={() => {
        if (interactive) {
          onSelectItem?.(null);
        }
      }}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={`relative select-none overflow-hidden bg-slate-950 flex items-center justify-center ${className}`}
    >
      {/* Background Story Image, Video or Media Prompt */}
      {mediaUrl ? (
        isVideo ? (
          <video
            ref={videoRef}
            src={mediaUrl}
            autoPlay
            loop={interactive}
            muted={isVideoMuted}
            playsInline
            preload="auto"
            style={{ filter: filterCss }}
            className={`h-full w-full pointer-events-none transition-[filter] duration-200 ${imageClassName}`}
            onLoadedMetadata={(e) => {
              const dur = e.currentTarget.duration;
              if (isFinite(dur) && dur > 0) {
                onDurationLoaded?.(dur);
              }
            }}
            onDurationChange={(e) => {
              const dur = e.currentTarget.duration;
              if (isFinite(dur) && dur > 0) {
                onDurationLoaded?.(dur);
              }
            }}
            onTimeUpdate={(e) => {
              const cur = e.currentTarget.currentTime;
              const dur = e.currentTarget.duration;
              if (isFinite(dur) && dur > 0) {
                onVideoTimeUpdate?.(cur, dur);
              }
            }}
            onEnded={() => {
              onVideoEnded?.();
            }}
          />
        ) : (
          <img
            src={mediaUrl}
            alt="Story Content"
            style={{ filter: filterCss }}
            className={`h-full w-full pointer-events-none transition-[filter] duration-200 ${imageClassName}`}
            referrerPolicy="no-referrer"
          />
        )
      ) : (
        /* Empty State: Direct Smartphone Camera, Gallery & Video Prompt */
        <div className="h-full w-full flex flex-col items-center justify-center p-4 sm:p-6 text-center bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 text-slate-200 relative select-none">
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2.5 rounded-2xl bg-blue-600/20 text-blue-400 border border-blue-500/30 shadow-inner">
              <Camera className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div className="p-2.5 rounded-2xl bg-purple-600/20 text-purple-400 border border-purple-500/30 shadow-inner">
              <ImageIcon className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div className="p-2.5 rounded-2xl bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 shadow-inner">
              <Film className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
          </div>

          <h3 className="text-sm sm:text-base font-bold text-white mb-1">
            스토리에 올릴 사진이나 동영상을 선택하세요
          </h3>
          <p className="text-[11px] sm:text-xs text-slate-400 max-w-xs mb-3.5 leading-relaxed">
            휴대폰 카메라로 바로 촬영하거나, 저장된 사진 및 동영상을 자유롭게 올릴 수 있습니다.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 w-full max-w-md z-30">
            {onTriggerCamera && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onTriggerCamera();
                }}
                className="py-2.5 px-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/30 transition-all cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>카메라 촬영</span>
              </button>
            )}

            {onTriggerGallery && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onTriggerGallery();
                }}
                className="py-2.5 px-2 rounded-xl bg-purple-600 hover:bg-purple-700 active:scale-95 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-purple-600/30 transition-all cursor-pointer"
              >
                <ImageIcon className="w-3.5 h-3.5" />
                <span>사진 선택</span>
              </button>
            )}

            {onTriggerVideo && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onTriggerVideo();
                }}
                className="py-2.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
              >
                <Film className="w-3.5 h-3.5" />
                <span>동영상 선택</span>
              </button>
            )}
          </div>

          {onTriggerLiveCamera && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onTriggerLiveCamera();
              }}
              className="mt-2.5 text-[11px] text-slate-400 hover:text-white underline underline-offset-2 transition-colors cursor-pointer"
            >
              화면에서 실시간 뷰파인더로 촬영하기
            </button>
          )}

          <span className="text-[10px] text-slate-500 mt-2.5 hidden sm:inline">
            💡 또는 사진/동영상 파일을 이 영역에 직접 끌어다 놓으세요
          </span>
        </div>
      )}

      {/* Video Indicator and Sound Toggle Badge on top/bottom */}
      {interactive && mediaUrl && isVideo && (
        <div className="absolute top-2.5 right-2.5 z-30 flex items-center gap-1.5 pointer-events-auto">
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-900/80 backdrop-blur-md border border-emerald-400/40 text-emerald-200 text-[10px] font-bold shadow-sm">
            <Film className="w-3 h-3 text-emerald-300" />
            <span>동영상 스토리</span>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsVideoMuted((prev) => !prev);
            }}
            title={isVideoMuted ? '동영상 소리 켜기' : '동영상 음소거'}
            className="p-1.5 rounded-full bg-black/60 hover:bg-black/80 text-white backdrop-blur-md border border-white/20 text-xs transition-colors cursor-pointer"
          >
            {isVideoMuted ? <VolumeX className="w-3 h-3 text-white/70" /> : <Volume2 className="w-3 h-3 text-emerald-400" />}
          </button>
        </div>
      )}

      {/* Floating Change Media Action Pill when media is already loaded */}
      {interactive && mediaUrl && (onTriggerCamera || onTriggerGallery || onTriggerVideo) && (
        <div className="absolute bottom-2.5 left-2.5 z-30 flex items-center gap-1.5 pointer-events-auto">
          {onTriggerCamera && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onTriggerCamera();
              }}
              title="휴대폰 카메라로 다시 찍기"
              className="px-2 py-1 rounded-full bg-black/70 hover:bg-blue-600 text-white backdrop-blur-md border border-white/20 text-[10px] font-semibold flex items-center gap-1 shadow-md transition-colors cursor-pointer"
            >
              <Camera className="w-3 h-3" />
              <span>촬영</span>
            </button>
          )}
          {onTriggerGallery && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onTriggerGallery();
              }}
              title="앨범에서 다른 사진 선택"
              className="px-2 py-1 rounded-full bg-black/70 hover:bg-purple-600 text-white backdrop-blur-md border border-white/20 text-[10px] font-semibold flex items-center gap-1 shadow-md transition-colors cursor-pointer"
            >
              <ImageIcon className="w-3 h-3 text-purple-300" />
              <span>사진</span>
            </button>
          )}
          {onTriggerVideo && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onTriggerVideo();
              }}
              title="기기에 저장된 동영상 선택"
              className="px-2 py-1 rounded-full bg-black/70 hover:bg-emerald-600 text-white backdrop-blur-md border border-white/20 text-[10px] font-semibold flex items-center gap-1 shadow-md transition-colors cursor-pointer"
            >
              <Film className="w-3 h-3 text-emerald-300" />
              <span>동영상</span>
            </button>
          )}
        </div>
      )}

      {/* Loading & Processing Spinner Overlay */}
      {isProcessing && (
        <div className="absolute inset-0 z-40 bg-black/75 backdrop-blur-xs flex flex-col items-center justify-center gap-2 text-white">
          <div className="w-8 h-8 rounded-full border-3 border-blue-500 border-t-transparent animate-spin" />
          <span className="text-xs font-semibold">사진 최적화 및 등록 중...</span>
        </div>
      )}

      {/* Drag Over Visual Indicator */}
      {isDragOver && (
        <div className="absolute inset-0 z-40 bg-blue-600/40 backdrop-blur-xs border-2 border-dashed border-white flex flex-col items-center justify-center gap-1.5 text-white animate-in fade-in duration-100">
          <Upload className="w-10 h-10 animate-bounce" />
          <span className="text-sm font-bold">사진을 놓으면 즉시 스토리에 적용됩니다</span>
        </div>
      )}

      {/* Story Sticker Overlays */}
      {stickerOverlays.map((sticker) => {
        const isSelected =
          interactive && selectedItemId === sticker.id && selectedItemType === 'sticker';
        const isBadge = sticker.type === 'badge';

        return (
          <div
            key={sticker.id}
            style={{
              left: `${sticker.x}%`,
              top: `${sticker.y}%`,
              transform: `translate(-50%, -50%) scale(${sticker.scale || 1}) rotate(${
                sticker.rotation || 0
              }deg)`
            }}
            onPointerDown={(e) =>
              handlePointerDown(e, 'sticker', sticker.id, sticker.x, sticker.y)
            }
            className={`absolute z-20 cursor-move transition-transform ${
              interactive ? 'touch-none' : 'pointer-events-none'
            }`}
          >
            <div
              className={`relative flex items-center justify-center transition-all ${
                isSelected
                  ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-black/50 rounded-xl'
                  : ''
              }`}
            >
              {isBadge ? (
                <div className="px-3 py-1.5 rounded-xl shadow-lg border border-white/20 text-xs sm:text-sm whitespace-nowrap bg-black/70 backdrop-blur-md text-white font-extrabold tracking-wide">
                  {sticker.content}
                </div>
              ) : (
                <span className="text-3xl sm:text-4xl filter drop-shadow-[0_4px_6px_rgba(0,0,0,0.5)]">
                  {sticker.content}
                </span>
              )}

              {/* Interactive Handle on Selected Sticker */}
              {isSelected && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteOverlay?.('sticker', sticker.id);
                  }}
                  title="스티커 삭제"
                  className="absolute -top-3 -right-3 h-6 w-6 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-lg hover:bg-rose-700 active:scale-95 transition-all cursor-pointer z-30"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        );
      })}

      {/* Story Text Overlays */}
      {textOverlays.map((textItem) => {
        const isSelected =
          interactive && selectedItemId === textItem.id && selectedItemType === 'text';

        return (
          <div
            key={textItem.id}
            style={{
              left: `${textItem.x}%`,
              top: `${textItem.y}%`,
              transform: `translate(-50%, -50%) rotate(${textItem.rotation || 0}deg)`
            }}
            onPointerDown={(e) =>
              handlePointerDown(e, 'text', textItem.id, textItem.x, textItem.y)
            }
            className={`absolute z-20 cursor-move transition-transform max-w-[85%] text-center ${
              interactive ? 'touch-none' : 'pointer-events-none'
            }`}
          >
            <div
              className={`relative transition-all ${
                isSelected
                  ? 'ring-2 ring-blue-500 ring-offset-2 ring-offset-black/50 rounded-xl'
                  : ''
              }`}
            >
              <div
                style={{ color: textItem.color || '#ffffff' }}
                className={`${getTextClassByStyle(textItem)} break-words leading-snug`}
              >
                {textItem.text}
              </div>

              {/* Interactive Handle on Selected Text */}
              {isSelected && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteOverlay?.('text', textItem.id);
                  }}
                  title="텍스트 오버레이 삭제"
                  className="absolute -top-3 -right-3 h-6 w-6 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-lg hover:bg-rose-700 active:scale-95 transition-all cursor-pointer z-30"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        );
      })}

      {/* Bottom Caption Overlay (if provided and present) */}
      {caption && caption.trim() && (
        <div className="absolute bottom-3 left-3 right-3 z-10 rounded-xl bg-black/60 p-2.5 text-center text-xs sm:text-sm font-medium text-white backdrop-blur-md border border-white/15 shadow-md pointer-events-none">
          {caption}
        </div>
      )}

      {/* Interactive Helper Overlay hint when empty */}
      {interactive && textOverlays.length === 0 && stickerOverlays.length === 0 && (
        <div className="absolute top-2 left-2 z-10 pointer-events-none">
          <div className="px-2 py-1 rounded-md bg-black/40 backdrop-blur-xs border border-white/10 text-[10px] text-white/75 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>하단 툴바로 텍스트/스티커/필터를 추가해보세요</span>
          </div>
        </div>
      )}
    </div>
  );
};
