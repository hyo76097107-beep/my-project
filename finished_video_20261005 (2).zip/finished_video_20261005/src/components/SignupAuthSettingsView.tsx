import React, { useState, useEffect } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  Mail,
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  Send,
  Zap,
  Info,
  Layers,
  Lock,
  RefreshCw,
  ExternalLink,
  ShieldAlert,
  Server,
  Database,
  PlusCircle,
  Trash2,
  Search,
  Check,
  FileText,
  History,
  RotateCcw,
  Hash,
  Users,
  Key,
  Eye,
  EyeOff,
  Save,
  Settings,
  Radio,
  Globe,
  Copy,
  SlidersHorizontal
} from 'lucide-react';
import { isValidEmailAddress } from '../utils/emailVerification';
import { isValidKoreanPhoneNumber, formatPhoneNumber, generateVerificationCode } from '../utils/smsVerification';
import { SignupVerificationMethod, SmsVerificationStatus, SmsProviderType, SmsApiConfig } from '../types';

export const SignupAuthSettingsView: React.FC = () => {
  const {
    signupAuthConfig,
    updateSignupAuthConfig,
    emailGatewayInfo,
    refreshEmailGatewayStatus,
    smsGatewayInfo,
    refreshSmsGatewayStatus,
    smsApiConfig,
    isLoadingSmsConfig,
    fetchSmsApiConfig,
    updateSmsApiConfig,
    resetSmsApiConfig,
    testSmsApiConnection,
    sendEmailVerificationCode,
    sendSmsVerificationCode,
    currentUser,
    showToast,
    smsDbRecords,
    smsDbStats,
    isLoadingSmsDb,
    fetchSmsDbRecords,
    insertSmsDbRecord,
    verifySmsDbRecordManual,
    deleteSmsDbRecord,
    clearSmsDbRecords,
  } = useSocial();

  const currentMethod = signupAuthConfig?.verificationMethod || 'email';

  // Sub-settings local state
  const [selectedMethod, setSelectedMethod] = useState<SignupVerificationMethod>(currentMethod);
  const [codeExpiration, setCodeExpiration] = useState<number>(signupAuthConfig?.codeExpirationMinutes || 5);

  // Email test sandbox
  const [testEmail, setTestEmail] = useState(currentUser?.email || 'admin@maeum.io');
  const [isSendingTestEmail, setIsSendingTestEmail] = useState(false);
  const [testEmailResult, setTestEmailResult] = useState<{
    success: boolean;
    message: string;
    code?: string;
    isReal?: boolean;
    provider?: string;
  } | null>(null);

  // SMS test sandbox
  const [testPhone, setTestPhone] = useState(currentUser?.phoneNumber || '010-1234-5678');
  const [isSendingTestSms, setIsSendingTestSms] = useState(false);
  const [testSmsResult, setTestSmsResult] = useState<{
    success: boolean;
    message: string;
    code?: string;
    isReal?: boolean;
    provider?: string;
  } | null>(null);

  // SMS Database Direct Input ("디비에 입력하는 칸") & Management States
  const [dbPhoneInput, setDbPhoneInput] = useState('010-8888-9999');
  const [dbCodeInput, setDbCodeInput] = useState('');
  const [dbStatusInput, setDbStatusInput] = useState<SmsVerificationStatus>('pending');
  const [dbProviderInput, setDbProviderInput] = useState<SmsProviderType>('CoolSMS');
  const [dbNotesInput, setDbNotesInput] = useState('관리자 수동 직접 입력 테스트');
  const [dbExpiresMinutes, setDbExpiresMinutes] = useState(3);
  const [dbSearchTerm, setDbSearchTerm] = useState('');
  const [dbFilterStatus, setDbFilterStatus] = useState('all');
  const [isInsertingDb, setIsInsertingDb] = useState(false);

  const handleGenerateRandomCode = () => {
    setDbCodeInput(generateVerificationCode());
  };

  const handleDirectDbInsert = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanDigits = dbPhoneInput.replace(/\D/g, '');
    if (!cleanDigits || cleanDigits.length < 10) {
      showToast('유효한 휴대폰 번호를 입력해주세요.', 'error');
      return;
    }

    setIsInsertingDb(true);
    const codeToUse = dbCodeInput.trim() || generateVerificationCode();
    const res = await insertSmsDbRecord({
      phoneNumber: cleanDigits,
      code: codeToUse,
      status: dbStatusInput,
      provider: dbProviderInput,
      notes: dbNotesInput.trim() || '관리자 직접 입력',
      expiresInMinutes: dbExpiresMinutes,
    });
    setIsInsertingDb(false);

    if (res.success) {
      setDbCodeInput('');
      setDbNotesInput('관리자 수동 직접 입력 테스트');
    }
  };

  // SMS API Configuration Editing States
  const [apiProvider, setApiProvider] = useState<SmsProviderType>('CoolSMS');
  const [apiSenderNumber, setApiSenderNumber] = useState('010-1234-5678');
  const [coolsmsKey, setCoolsmsKey] = useState('');
  const [coolsmsSecret, setCoolsmsSecret] = useState('');
  const [aligoKey, setAligoKey] = useState('');
  const [aligoUserId, setAligoUserId] = useState('');
  const [twilioSid, setTwilioSid] = useState('');
  const [twilioToken, setTwilioToken] = useState('');
  const [naverAccessKey, setNaverAccessKey] = useState('');
  const [naverSecretKey, setNaverSecretKey] = useState('');
  const [naverServiceId, setNaverServiceId] = useState('');
  const [customApiUrl, setCustomApiUrl] = useState('');
  const [customAuthHeader, setCustomAuthHeader] = useState('');
  const [smsTemplate, setSmsTemplate] = useState('[마음(Maeum)] 본인확인 인증번호 [{code}]를 3분 이내에 입력해주세요. (타인 노출 금지)');
  const [apiTestMode, setApiTestMode] = useState(false);
  const [showSecret, setShowSecret] = useState(false);
  const [isSavingApi, setIsSavingApi] = useState(false);
  const [isTestingApiConnection, setIsTestingApiConnection] = useState(false);
  const [apiTestResult, setApiTestResult] = useState<{
    success: boolean;
    provider: string;
    message: string;
    error?: string;
  } | null>(null);

  // Sync state when smsApiConfig is loaded from server
  const [hasLoadedApiConfig, setHasLoadedApiConfig] = useState(false);
  useEffect(() => {
    if (smsApiConfig && !hasLoadedApiConfig) {
      setApiProvider(smsApiConfig.provider || 'CoolSMS');
      setApiSenderNumber(smsApiConfig.senderNumber || '010-1234-5678');
      setCoolsmsKey(smsApiConfig.coolsmsApiKey || '');
      setCoolsmsSecret(smsApiConfig.coolsmsApiSecret || '');
      setAligoKey(smsApiConfig.aligoApiKey || '');
      setAligoUserId(smsApiConfig.aligoUserId || '');
      setTwilioSid(smsApiConfig.twilioAccountSid || '');
      setTwilioToken(smsApiConfig.twilioAuthToken || '');
      setNaverAccessKey(smsApiConfig.naverAccessKey || '');
      setNaverSecretKey(smsApiConfig.naverSecretKey || '');
      setNaverServiceId(smsApiConfig.naverServiceId || '');
      setCustomApiUrl(smsApiConfig.customApiUrl || '');
      setCustomAuthHeader(smsApiConfig.customAuthHeader || '');
      setSmsTemplate(smsApiConfig.smsTemplate || '[마음(Maeum)] 본인확인 인증번호 [{code}]를 3분 이내에 입력해주세요. (타인 노출 금지)');
      setApiTestMode(smsApiConfig.testMode ?? false);
      setHasLoadedApiConfig(true);
    }
  }, [smsApiConfig, hasLoadedApiConfig]);

  const handleSaveSmsApiConfig = async () => {
    setIsSavingApi(true);
    try {
      const res = await updateSmsApiConfig({
        provider: apiProvider,
        senderNumber: apiSenderNumber,
        coolsmsApiKey: coolsmsKey,
        coolsmsApiSecret: coolsmsSecret,
        aligoApiKey: aligoKey,
        aligoUserId: aligoUserId,
        twilioAccountSid: twilioSid,
        twilioAuthToken: twilioToken,
        naverAccessKey,
        naverSecretKey,
        naverServiceId,
        customApiUrl,
        customAuthHeader,
        smsTemplate,
        testMode: apiTestMode,
      });
      setIsSavingApi(false);
      if (res.success) {
        showToast('SMS 문자메시지 API 설정이 성공적으로 저장되었습니다.', 'success');
      }
    } catch (e: any) {
      setIsSavingApi(false);
      showToast(e.message || '저장 중 오류 발생', 'error');
    }
  };

  const handleResetSmsApiConfig = async () => {
    if (!window.confirm('SMS API 설정을 기본값으로 초기화하시겠습니까?')) return;
    const res = await resetSmsApiConfig();
    if (res.success) {
      setHasLoadedApiConfig(false);
    }
  };

  const handleTestSmsApiConnection = async () => {
    setIsTestingApiConnection(true);
    setApiTestResult(null);
    try {
      const targetPhone = testPhone.replace(/\D/g, '') || apiSenderNumber.replace(/\D/g, '') || '01012345678';
      const res = await testSmsApiConnection(
        targetPhone,
        `[마음(Maeum)] SMS API 연동 통신 테스트 발송입니다. (${apiProvider})`
      );
      setIsTestingApiConnection(false);
      setApiTestResult({
        success: res.success,
        provider: res.provider || apiProvider,
        message: res.success
          ? `[${res.provider}] SMS API 통신 및 발송에 성공했습니다!`
          : `API 발송 테스트 실패: ${res.error || '통신사 게이트웨이 응답 에러'}`,
        error: res.error,
      });
      if (res.success) {
        showToast('SMS API 연결 테스트 성공!', 'success');
      } else {
        showToast(res.error || 'SMS API 연결 테스트 실패', 'error');
      }
    } catch (e: any) {
      setIsTestingApiConnection(false);
      setApiTestResult({
        success: false,
        provider: apiProvider,
        message: '테스트 요청 중 네트워크 오류가 발생했습니다.',
        error: e.message,
      });
    }
  };

  // Apply method change
  const handleSelectMethod = (method: SignupVerificationMethod) => {
    setSelectedMethod(method);
    updateSignupAuthConfig({
      verificationMethod: method,
      codeExpirationMinutes: codeExpiration,
      allowEmailLogin: false
    });
  };

  const handleSaveSubSettings = () => {
    updateSignupAuthConfig({
      verificationMethod: selectedMethod,
      codeExpirationMinutes: codeExpiration,
      allowEmailLogin: false
    });
    showToast('인증 정책 세부 설정이 저장되었습니다.', 'success');
  };

  // Run Test Email Send
  const handleSendTestEmail = async () => {
    if (!testEmail.trim() || !isValidEmailAddress(testEmail)) {
      showToast('유효한 테스트 이메일 주소를 입력해주세요.', 'error');
      return;
    }

    setIsSendingTestEmail(true);
    setTestEmailResult(null);

    try {
      const res = await sendEmailVerificationCode(testEmail, '관리자 인증 테스트');
      setIsSendingTestEmail(false);
      if (res.success) {
        setTestEmailResult({
          success: true,
          message: res.isRealEmailSent
            ? `실제 메일함([${testEmail}])으로 6자리 인증 메일이 발송되었습니다.`
            : `테스트 발송 완료! 수신된 6자리 인증코드: [${res.simulatedCode}]`,
          code: res.simulatedCode,
          isReal: res.isRealEmailSent,
          provider: res.provider
        });
        showToast('이메일 인증 테스트 발송에 성공했습니다.', 'success');
      } else {
        setTestEmailResult({
          success: false,
          message: res.error || '이메일 발송에 실패했습니다.'
        });
        showToast(res.error || '이메일 발송 실패', 'error');
      }
    } catch (e: any) {
      setIsSendingTestEmail(false);
      setTestEmailResult({
        success: false,
        message: '서버와의 통신 오류가 발생했습니다.'
      });
    }
  };

  // Run Test SMS Send
  const handleSendTestSms = async () => {
    const raw = testPhone.replace(/\D/g, '');
    if (!raw || raw.length < 10) {
      showToast('유효한 휴대폰 번호를 입력해주세요.', 'error');
      return;
    }

    setIsSendingTestSms(true);
    setTestSmsResult(null);

    try {
      const res = await sendSmsVerificationCode(testPhone);
      setIsSendingTestSms(false);
      if (res.success) {
        setTestSmsResult({
          success: true,
          message: res.isRealSmsSent
            ? `실제 휴대폰([${testPhone}])으로 6자리 SMS 문자가 발송되었습니다.`
            : `테스트 SMS 발송 완료! 수신된 6자리 인증코드: [${res.simulatedCode}]`,
          code: res.simulatedCode,
          isReal: res.isRealSmsSent,
          provider: res.provider
        });
        showToast('SMS 문자 인증 테스트 발송에 성공했습니다.', 'success');
      } else {
        setTestSmsResult({
          success: false,
          message: res.error || 'SMS 발송에 실패했습니다.'
        });
        showToast(res.error || 'SMS 발송 실패', 'error');
      }
    } catch (e: any) {
      setIsSendingTestSms(false);
      setTestSmsResult({
        success: false,
        message: '서버와의 통신 오류가 발생했습니다.'
      });
    }
  };

  const methodOptions: {
    id: SignupVerificationMethod;
    title: string;
    badge: string;
    badgeColor: string;
    description: string;
    bullets: string[];
    icon: any;
    recommended?: boolean;
  }[] = [
    {
      id: 'sms',
      title: '휴대폰 SMS 문자메시지 본인인증 (운영 기본값)',
      badge: '단독 적용 중 (추천)',
      badgeColor: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
      description: '회원가입 시 사용자의 대한민국 휴대폰 번호(010-XXXX-XXXX)로 6자리 SMS 문자를 전송하여 본인인증을 진행합니다. 이메일은 단순 계정 아이디로만 사용되며 별도 인증을 거치지 않습니다.',
      bullets: [
        '휴대폰 번호 기반의 강력한 실명 1인 1계정 가입 정책',
        '스팸 및 봇 계정 원천 차단 (영구 DB 기록 및 중복 가입 방지)',
        'CoolSMS, Twilio 통신사 연동 및 브라우저 실시간 샌드박스 완벽 지원',
        '인증 요청 및 완료 내역이 서버 영구 DB 파일에 실시간 감사 기록'
      ],
      icon: Smartphone,
      recommended: true
    },
    {
      id: 'none',
      title: '인증 생략 (간편 가입 모드)',
      badge: '개발 & 테스트용',
      badgeColor: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700',
      description: '별도의 6자리 문자 인증 없이 아이디와 비밀번호, 이메일만 입력하면 즉시 가입 완료됩니다.',
      bullets: [
        '개발 및 테스트 단계에서 신속한 회원 생성 용이',
        '모든 방문자가 인증 대기 없이 즉시 가입 가능한 모드'
      ],
      icon: Zap
    }
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-200 pb-12">
      {/* Top Banner */}
      <div className="rounded-3xl border border-emerald-200 bg-gradient-to-br from-emerald-50/90 via-slate-50/60 to-white p-6 dark:border-emerald-900/50 dark:bg-gradient-to-br dark:from-slate-900 dark:via-emerald-950/40 dark:to-slate-900 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-600/10 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-200 dark:border-emerald-800">
              <Smartphone className="w-3.5 h-3.5" />
              <span>휴대폰 SMS 본인인증 & DB 관리 센터</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
              휴대폰 SMS 문자메시지 본인인증 관리
            </h2>
            <p className="text-xs md:text-sm text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
              이메일 인증을 없애고 <strong>휴대폰 SMS 문자메시지 6자리 코드 본인인증</strong>을 단독 가입 인증 수단으로 적용합니다. 인증 요청 및 결과는 서버 영구 DB 파일에 실시간 안전하게 저장됩니다.
            </p>
          </div>

          {/* Active Policy Status Pill */}
          <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl border border-emerald-100 dark:border-slate-700 shadow-xs flex flex-col items-center justify-center min-w-44 text-center">
            <span className="text-[11px] font-bold text-slate-400 dark:text-slate-400">현재 활성 가입 정책</span>
            <div className="mt-1 flex items-center gap-1.5 font-black text-sm text-emerald-600 dark:text-emerald-400">
              {currentMethod === 'none' ? (
                <>
                  <Zap className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-600 dark:text-slate-300">간편 가입 (인증 생략)</span>
                </>
              ) : (
                <>
                  <Smartphone className="w-4 h-4 text-emerald-500" />
                  <span className="text-emerald-600 dark:text-emerald-400">SMS 문자 본인인증 [적용 중]</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Selection Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-500" />
            가입 인증 수단 정책 선택 (원클릭 즉시 적용)
          </h3>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            카드 클릭 시 즉시 시스템 전체에 활성화됩니다.
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {methodOptions.map((opt) => {
            const isSelected = selectedMethod === opt.id;
            const Icon = opt.icon;

            return (
              <div
                key={opt.id}
                onClick={() => handleSelectMethod(opt.id)}
                className={`relative rounded-2xl p-5 border-2 transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 shadow-lg shadow-indigo-600/10 ring-2 ring-indigo-500/20'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700 hover:shadow-xs'
                }`}
              >
                {/* Active Checkmark Pin */}
                {isSelected && (
                  <div className="absolute top-4 right-4 flex items-center gap-1 px-2.5 py-1 rounded-full bg-indigo-600 text-white text-[11px] font-black shadow-xs">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>현재 적용 중</span>
                  </div>
                )}

                <div>
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${
                        isSelected
                          ? 'bg-indigo-600 text-white shadow-indigo-600/30'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="min-w-0 pr-16">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${opt.badgeColor}`}>
                          {opt.badge}
                        </span>
                      </div>
                      <h4 className="text-sm font-extrabold text-slate-900 dark:text-white mt-1">
                        {opt.title}
                      </h4>
                    </div>
                  </div>

                  <p className="mt-3 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {opt.description}
                  </p>

                  <div className="mt-3.5 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                    {opt.bullets.map((b, i) => (
                      <div key={i} className="flex items-start gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                        <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
                        <span>{b}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-xs">
                  <span className="text-[11px] font-bold text-slate-400">
                    {isSelected ? '활성화 상태' : '클릭하여 이 방식으로 변경'}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectMethod(opt.id);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    {isSelected ? '선택됨' : '선택 적용'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sub Settings: Expiration time & Email Code Login */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-indigo-500" />
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              인증번호 유효시간 및 부가 보안 설정
            </h4>
          </div>
          <button
            type="button"
            onClick={handleSaveSubSettings}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
          >
            설정 저장
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-xs">
          {/* Code Expiration */}
          <div className="space-y-2">
            <label className="font-bold text-slate-800 dark:text-slate-200 block">
              6자리 인증코드 유효시간 (만료 타이머)
            </label>
            <p className="text-slate-500 dark:text-slate-400 text-[11px]">
              이메일 및 SMS 문자로 발송된 6자리 코드의 유효 기간입니다. 시간 만료 시 재전송을 요청해야 합니다.
            </p>
            <div className="flex items-center gap-2 pt-1">
              {[3, 5, 10, 15].map((mins) => (
                <button
                  key={mins}
                  type="button"
                  onClick={() => {
                    setCodeExpiration(mins);
                    updateSignupAuthConfig({ codeExpirationMinutes: mins });
                  }}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    codeExpiration === mins
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  {mins}분 ({mins * 60}초)
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Audit timestamp */}
        {signupAuthConfig?.updatedAt && (
          <div className="pt-2 text-[11px] text-slate-400 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span>
              마지막 변경 일시: {new Date(signupAuthConfig.updatedAt).toLocaleString('ko-KR')}
            </span>
            <span>담당자: {signupAuthConfig.updatedBy || '시스템 관리자'}</span>
          </div>
        )}
      </div>

      {/* SMS Gateway API Configuration & Modification Console */}
      <div className="rounded-2xl border border-emerald-200/90 bg-white p-5 md:p-6 dark:border-emerald-900/50 dark:bg-slate-900 shadow-xs space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shrink-0 shadow-md">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  SMS 문자메시지 API 설정 및 수정 콘솔
                </h3>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  실시간 API 연동 & 수정
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                CoolSMS(Solapi), 알리고(Aligo), Twilio, 네이버클라우드 SENS 등 통신사 SMS API 키와 발신번호를 직접 수정하고 영구 저장할 수 있습니다.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => {
                fetchSmsApiConfig();
                refreshSmsGatewayStatus();
              }}
              disabled={isLoadingSmsConfig}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              title="API 설정 새로고침"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingSmsConfig ? 'animate-spin' : ''}`} />
              <span>새로고침</span>
            </button>
            <button
              type="button"
              onClick={handleResetSmsApiConfig}
              className="px-3 py-1.5 bg-slate-100 hover:bg-rose-50 dark:bg-slate-800 dark:hover:bg-rose-950/40 text-slate-600 hover:text-rose-600 dark:text-slate-300 dark:hover:text-rose-300 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              title="설정 기본값 초기화"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>초기화</span>
            </button>
          </div>
        </div>

        {/* Current API Status Ribbon */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[11px] font-bold text-slate-400 block">선택된 SMS 발송 엔진</span>
              <span className="text-xs font-black text-slate-800 dark:text-slate-100 flex items-center gap-1.5">
                <Radio className="w-3.5 h-3.5 text-emerald-500" />
                {apiProvider}
              </span>
            </div>
            <span className="px-2 py-0.5 text-[10px] font-bold rounded-md bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
              {apiProvider === 'Sandbox' ? '가상 샌드박스' : '통신사 API'}
            </span>
          </div>

          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[11px] font-bold text-slate-400 block">등록된 발신번호</span>
              <span className="text-xs font-black text-slate-800 dark:text-slate-100 font-mono">
                {apiSenderNumber || '미설정'}
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-medium">통신사 등록 필수</span>
          </div>

          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[11px] font-bold text-slate-400 block">발송 동작 모드</span>
              <span className="text-xs font-black text-slate-800 dark:text-slate-100">
                {apiTestMode ? '테스트 샌드박스 (DB 모드)' : '실제 통신망 발송 (라이브)'}
              </span>
            </div>
            <span
              className={`px-2 py-0.5 text-[10px] font-bold rounded-md ${
                apiTestMode
                  ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                  : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
              }`}
            >
              {apiTestMode ? '샌드박스' : '실제 발송'}
            </span>
          </div>
        </div>

        {/* Provider Selection Tabs */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <SlidersHorizontal className="w-3.5 h-3.5 text-emerald-600" />
            <span>SMS API 제공사 선택</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
            {[
              { id: 'CoolSMS' as SmsProviderType, label: 'CoolSMS (Solapi)', desc: '대한민국 표준' },
              { id: 'Aligo' as SmsProviderType, label: '알리고 (Aligo)', desc: '국내 SMS' },
              { id: 'NaverSENS' as SmsProviderType, label: '네이버 SENS', desc: '네이버클라우드' },
              { id: 'Twilio' as SmsProviderType, label: 'Twilio', desc: '글로벌 해외 발송' },
              { id: 'Custom' as SmsProviderType, label: '사용자 API', desc: 'Custom HTTP' },
              { id: 'Sandbox' as SmsProviderType, label: '테스트 샌드박스', desc: 'DB 시뮬레이션' },
            ].map((p) => {
              const isSelected = apiProvider === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setApiProvider(p.id)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    isSelected
                      ? 'border-emerald-500 bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 ring-2 ring-emerald-500/20 shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="text-xs font-black truncate">{p.label}</div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{p.desc}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Provider Form Fields */}
        <div className="p-4 bg-slate-50/80 dark:bg-slate-800/50 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200/80 dark:border-slate-700/60 pb-3">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-emerald-500" />
              <span>[{apiProvider}] API 인증 정보 및 발송자 설정</span>
            </span>
            <button
              type="button"
              onClick={() => setShowSecret(!showSecret)}
              className="text-[11px] text-slate-500 hover:text-slate-700 dark:text-slate-400 flex items-center gap-1 cursor-pointer"
            >
              {showSecret ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{showSecret ? '비밀키 숨기기' : '비밀키 보기'}</span>
            </button>
          </div>

          {/* CoolSMS / Solapi Fields */}
          {apiProvider === 'CoolSMS' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  CoolSMS API Key (NCS...)
                </label>
                <input
                  type="text"
                  value={coolsmsKey}
                  onChange={(e) => setCoolsmsKey(e.target.value)}
                  placeholder="예: NCSXXXXXXXXXXXXX"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
                <p className="text-[11px] text-slate-500">솔라피/쿨에스엠에스 콘솔 발급 API Key</p>
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  CoolSMS API Secret Key
                </label>
                <input
                  type={showSecret ? 'text' : 'password'}
                  value={coolsmsSecret}
                  onChange={(e) => setCoolsmsSecret(e.target.value)}
                  placeholder="예: XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
                <p className="text-[11px] text-slate-500">암호화 전자서명(HMAC-SHA256)용 시크릿 키</p>
              </div>
            </div>
          )}

          {/* Aligo Fields */}
          {apiProvider === 'Aligo' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  알리고 API Key
                </label>
                <input
                  type="text"
                  value={aligoKey}
                  onChange={(e) => setAligoKey(e.target.value)}
                  placeholder="알리고 관리자에서 발급받은 API Key"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
                <p className="text-[11px] text-slate-500">smartsms.aligo.in &gt; API Key 관리</p>
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  알리고 사용자 계정 아이디 (user_id)
                </label>
                <input
                  type="text"
                  value={aligoUserId}
                  onChange={(e) => setAligoUserId(e.target.value)}
                  placeholder="알리고 로그인 아이디"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
                <p className="text-[11px] text-slate-500">알리고 서비스 로그인 시 사용하는 ID</p>
              </div>
            </div>
          )}

          {/* Naver Cloud SENS Fields */}
          {apiProvider === 'NaverSENS' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  SENS Service ID
                </label>
                <input
                  type="text"
                  value={naverServiceId}
                  onChange={(e) => setNaverServiceId(e.target.value)}
                  placeholder="ncp:sms:kr:..."
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  NCP Access Key
                </label>
                <input
                  type="text"
                  value={naverAccessKey}
                  onChange={(e) => setNaverAccessKey(e.target.value)}
                  placeholder="NCP IAM Access Key"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  NCP Secret Key
                </label>
                <input
                  type={showSecret ? 'text' : 'password'}
                  value={naverSecretKey}
                  onChange={(e) => setNaverSecretKey(e.target.value)}
                  placeholder="NCP IAM Secret Key"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>
            </div>
          )}

          {/* Twilio Fields */}
          {apiProvider === 'Twilio' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  Twilio Account SID
                </label>
                <input
                  type="text"
                  value={twilioSid}
                  onChange={(e) => setTwilioSid(e.target.value)}
                  placeholder="ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  Twilio Auth Token
                </label>
                <input
                  type={showSecret ? 'text' : 'password'}
                  value={twilioToken}
                  onChange={(e) => setTwilioToken(e.target.value)}
                  placeholder="Twilio Console Auth Token"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>
            </div>
          )}

          {/* Custom API Fields */}
          {apiProvider === 'Custom' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  Custom Endpoint URL (POST)
                </label>
                <input
                  type="url"
                  value={customApiUrl}
                  onChange={(e) => setCustomApiUrl(e.target.value)}
                  placeholder="https://api.yourdomain.com/sms/send"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>

              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 block">
                  Authorization Header (선택 사항)
                </label>
                <input
                  type="text"
                  value={customAuthHeader}
                  onChange={(e) => setCustomAuthHeader(e.target.value)}
                  placeholder="Bearer your-secret-token"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                />
              </div>
            </div>
          )}

          {/* Sandbox Mode Explanation */}
          {apiProvider === 'Sandbox' && (
            <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/20 rounded-xl border border-emerald-200/60 dark:border-emerald-900/40 text-xs space-y-1 text-emerald-800 dark:text-emerald-300">
              <div className="font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>시뮬레이션 샌드박스 (개발 및 테스트 모드)</span>
              </div>
              <p className="text-[11px] leading-relaxed text-emerald-700 dark:text-emerald-400">
                외부 통신사 API 계정이 없어도 가입자가 요청한 6자리 인증번호가 서버 영구 DB에 실시간 저장되며 화면에 즉시 표시되어 누구나 100% 정상적으로 본인인증을 통과할 수 있습니다.
              </p>
            </div>
          )}

          {/* Common Settings: Sender Number & Test Mode Toggle */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-2 border-t border-slate-200/60 dark:border-slate-700/40">
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300 block">
                발신번호 (Sender Phone Number)
              </label>
              <input
                type="tel"
                value={apiSenderNumber}
                onChange={(e) => setApiSenderNumber(formatPhoneNumber(e.target.value))}
                placeholder="예: 02-1234-5678, 1588-1234, 010-1234-5678"
                className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-mono focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
              />
              <p className="text-[11px] text-slate-500">
                전기통신사업법에 따라 통신사에 사전 등록된 공식 발신번호만 전송 가능합니다.
              </p>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 dark:text-slate-300 block">
                동작 모드 토글 (라이브 통신망 vs 샌드박스)
              </label>
              <div className="pt-0.5">
                <button
                  type="button"
                  onClick={() => setApiTestMode(!apiTestMode)}
                  className={`w-full flex items-center justify-between px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                    apiTestMode
                      ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200'
                      : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                  }`}
                >
                  <span className="flex items-center gap-1.5">
                    {apiTestMode ? <Sparkles className="w-3.5 h-3.5 text-amber-600" /> : <Zap className="w-3.5 h-3.5 text-emerald-600" />}
                    <span>{apiTestMode ? '테스트 샌드박스 가동 중' : '실제 통신사 발송 가동 중'}</span>
                  </span>
                  <span className="text-[10px] underline underline-offset-2">클릭하여 전환</span>
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                샌드박스 모드 켜짐 시 SMS 요금이 차감되지 않고 DB 기록 및 화면 안내로만 작동합니다.
              </p>
            </div>
          </div>

          {/* SMS Text Template Customization */}
          <div className="space-y-1.5 pt-2 border-t border-slate-200/60 dark:border-slate-700/40 text-xs">
            <div className="flex items-center justify-between">
              <label className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-indigo-500" />
                <span>SMS 문자메시지 문구 템플릿</span>
              </label>
              <button
                type="button"
                onClick={() => {
                  if (!smsTemplate.includes('{code}')) {
                    setSmsTemplate(`${smsTemplate} [{code}]`);
                  }
                }}
                className="px-2 py-0.5 text-[11px] font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:text-indigo-300 rounded-md transition-colors cursor-pointer"
              >
                + &#123;code&#125; 변수 삽입
              </button>
            </div>
            <textarea
              rows={2}
              value={smsTemplate}
              onChange={(e) => setSmsTemplate(e.target.value)}
              placeholder="[마음(Maeum)] 본인확인 인증번호 [{code}]를 3분 이내에 입력해주세요."
              className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
            />
            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>&#123;code&#125; 자리에 6자리 랜덤 인증번호가 자동으로 치환됩니다.</span>
              <span className="font-mono">{smsTemplate.length}자 ({smsTemplate.length * 2}바이트)</span>
            </div>
          </div>

          {/* Action Buttons: Save & Test Connection */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-200/60 dark:border-slate-700/40">
            <div className="text-[11px] text-slate-500">
              저장 즉시 서버 백엔드 메모리와 영구 설정 파일(<code>sms_api_config.json</code>)에 동기화됩니다.
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              <button
                type="button"
                disabled={isTestingApiConnection}
                onClick={handleTestSmsApiConnection}
                className="flex-1 sm:flex-none px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                {isTestingApiConnection ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Radio className="w-3.5 h-3.5 text-emerald-500" />
                )}
                <span>API 연결 테스트</span>
              </button>

              <button
                type="button"
                disabled={isSavingApi}
                onClick={handleSaveSmsApiConfig}
                className="flex-1 sm:flex-none px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
              >
                {isSavingApi ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Save className="w-3.5 h-3.5" />
                )}
                <span>SMS API 설정 저장</span>
              </button>
            </div>
          </div>

          {/* Test Connection Result Alert */}
          {apiTestResult && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 animate-in fade-in ${
                apiTestResult.success
                  ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60 text-emerald-900 dark:text-emerald-200'
                  : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60 text-rose-900 dark:text-rose-200'
              }`}
            >
              {apiTestResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-0.5 flex-1">
                <div className="font-bold">{apiTestResult.message}</div>
                {apiTestResult.error && (
                  <div className="text-[11px] opacity-80 font-mono mt-0.5">{apiTestResult.error}</div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Live Admin SMS Sandbox Sender Test */}
        <div className="space-y-2 pt-1 border-t border-slate-100 dark:border-slate-800">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
            휴대폰 번호로 6자리 SMS 인증문자 즉시 발송 테스트 (전송 검증)
          </label>
          <div className="flex gap-2">
            <input
              type="tel"
              value={testPhone}
              onChange={(e) => setTestPhone(formatPhoneNumber(e.target.value))}
              placeholder="010-1234-5678"
              className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
            />
            <button
              type="button"
              disabled={isSendingTestSms}
              onClick={handleSendTestSms}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shrink-0 transition-all cursor-pointer"
            >
              {isSendingTestSms ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
              <span>SMS 발송 테스트</span>
            </button>
          </div>

          {testSmsResult && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 animate-in fade-in ${
                testSmsResult.success
                  ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-200'
                  : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800/60 text-rose-800 dark:text-rose-200'
              }`}
            >
              {testSmsResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1.5 flex-1">
                <div className="font-medium">{testSmsResult.message}</div>
                {testSmsResult.code && (
                  <div className="flex items-center gap-2 pt-0.5">
                    <span className="font-mono text-sm font-black bg-white dark:bg-slate-800 px-2.5 py-1 rounded-md inline-block border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-300">
                      인증코드: {testSmsResult.code}
                    </span>
                    <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                      (서버 DB에 안전하게 저장 완료)
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* SMS Verification Database (DB) Management & Direct DB Input Section */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 shadow-xs">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  SMS 인증 데이터베이스 (DB) 관리 & 레코드 입력 칸
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  영구 DB 저장 연동
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                휴대폰 SMS 인증 요청 및 인증 성공 기록이 서버 영구 DB 파일에 실시간 저장되며, 관리자가 수동으로 DB 레코드를 직접 입력하거나 조회할 수 있습니다.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => fetchSmsDbRecords(dbSearchTerm, dbFilterStatus)}
              disabled={isLoadingSmsDb}
              className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingSmsDb ? 'animate-spin' : ''}`} />
              <span>DB 새로고침</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if (window.confirm('SMS 인증 DB 테스트 기록을 초기화하시겠습니까?')) {
                  clearSmsDbRecords();
                }
              }}
              className="px-3 py-1.5 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900/40 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>DB 초기화</span>
            </button>
          </div>
        </div>

        {/* Database Statistics Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
            <div className="text-[11px] font-medium text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <FileText className="w-3 h-3 text-slate-400" />
              <span>전체 DB 레코드</span>
            </div>
            <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              {smsDbStats?.total ?? smsDbRecords.length}
              <span className="text-xs font-normal text-slate-400 ml-1">건</span>
            </div>
          </div>

          <div className="p-3.5 bg-emerald-50/60 dark:bg-emerald-950/20 rounded-xl border border-emerald-200/70 dark:border-emerald-900/40">
            <div className="text-[11px] font-medium text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              <span>본인인증 완료</span>
            </div>
            <div className="text-xl font-bold text-emerald-700 dark:text-emerald-300 mt-1">
              {smsDbStats?.verified ?? 0}
              <span className="text-xs font-normal text-emerald-600/70 ml-1">건</span>
            </div>
          </div>

          <div className="p-3.5 bg-amber-50/60 dark:bg-amber-950/20 rounded-xl border border-amber-200/70 dark:border-amber-900/40">
            <div className="text-[11px] font-medium text-amber-700 dark:text-amber-300 flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-600" />
              <span>인증 대기 중</span>
            </div>
            <div className="text-xl font-bold text-amber-700 dark:text-amber-300 mt-1">
              {smsDbStats?.pending ?? 0}
              <span className="text-xs font-normal text-amber-600/70 ml-1">건</span>
            </div>
          </div>

          <div className="p-3.5 bg-indigo-50/60 dark:bg-indigo-950/20 rounded-xl border border-indigo-200/70 dark:border-indigo-900/40">
            <div className="text-[11px] font-medium text-indigo-700 dark:text-indigo-300 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-indigo-600" />
              <span>인증 성공률</span>
            </div>
            <div className="text-xl font-bold text-indigo-700 dark:text-indigo-300 mt-1">
              {smsDbStats?.successRate ?? 0}
              <span className="text-xs font-normal text-indigo-600/70 ml-1">%</span>
            </div>
          </div>
        </div>

        {/* [핵심] SMS 인증 DB 직접 입력 칸 (Direct DB Input Box) */}
        <div className="p-4 sm:p-5 bg-gradient-to-br from-indigo-50/70 via-slate-50/70 to-emerald-50/60 dark:from-indigo-950/30 dark:via-slate-900 dark:to-emerald-950/20 rounded-2xl border-2 border-indigo-200 dark:border-indigo-800/80 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-indigo-100 dark:border-indigo-900/50 pb-3">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-indigo-600 text-white shadow-xs">
                <PlusCircle className="w-4 h-4" />
              </span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                SMS 인증 데이터베이스(DB) 직접 입력 칸
              </h4>
            </div>
            <span className="text-[11px] font-medium text-indigo-700 dark:text-indigo-300 bg-indigo-100/70 dark:bg-indigo-950/80 px-2.5 py-0.5 rounded-full self-start sm:self-auto">
              수동 데이터 입력 및 가상 테스트 레코드 생성
            </span>
          </div>

          <form onSubmit={handleDirectDbInsert} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {/* 칸 1: 휴대폰 번호 입력 칸 */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Smartphone className="w-3.5 h-3.5 text-indigo-600" />
                  <span>휴대폰 번호 입력 칸 *</span>
                </label>
                <input
                  type="tel"
                  required
                  value={dbPhoneInput}
                  onChange={(e) => setDbPhoneInput(formatPhoneNumber(e.target.value))}
                  placeholder="010-1234-5678"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                />
              </div>

              {/* 칸 2: 6자리 인증번호 입력 칸 */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                    <Hash className="w-3.5 h-3.5 text-indigo-600" />
                    <span>인증코드 6자리 입력 칸</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleGenerateRandomCode}
                    className="text-[10px] text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 font-bold underline cursor-pointer"
                  >
                    무작위 생성
                  </button>
                </div>
                <input
                  type="text"
                  maxLength={6}
                  value={dbCodeInput}
                  onChange={(e) => setDbCodeInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="미입력 시 6자리 자동 발급"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-mono tracking-widest text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                />
              </div>

              {/* 칸 3: 인증 상태 선택 칸 */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                  <span>인증 상태 선택 칸</span>
                </label>
                <select
                  value={dbStatusInput}
                  onChange={(e) => setDbStatusInput(e.target.value as SmsVerificationStatus)}
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                >
                  <option value="pending">대기중 (pending - 인증번호 입력 대기)</option>
                  <option value="verified">즉시 인증완료 (verified - 본인확인 완료 상태)</option>
                  <option value="expired">만료됨 (expired - 3분 초과)</option>
                  <option value="failed">실패 (failed - 시도초과/불일치)</option>
                </select>
              </div>

              {/* 칸 4: 발송 게이트웨이 / 프로바이더 선택 칸 */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Server className="w-3.5 h-3.5 text-indigo-600" />
                  <span>발송 프로바이더 선택 칸</span>
                </label>
                <select
                  value={dbProviderInput}
                  onChange={(e) => setDbProviderInput(e.target.value as SmsProviderType)}
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                >
                  <option value="CoolSMS">CoolSMS (국내 통신사 게이트웨이)</option>
                  <option value="Twilio">Twilio (글로벌 SMS)</option>
                  <option value="DirectSMS">DirectSMS (통신사 직접 연동)</option>
                  <option value="Manual_Admin_Input">Manual_Admin_Input (관리자 직접 수동입력)</option>
                  <option value="Sandbox">Sandbox (가상 테스트 샌드박스)</option>
                </select>
              </div>

              {/* 칸 5: 유효시간 설정 칸 */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-indigo-600" />
                  <span>인증 유효시간 칸</span>
                </label>
                <select
                  value={dbExpiresMinutes}
                  onChange={(e) => setDbExpiresMinutes(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                >
                  <option value={3}>3분 (표준 유효시간)</option>
                  <option value={5}>5분</option>
                  <option value={10}>10분</option>
                  <option value={15}>15분</option>
                </select>
              </div>

              {/* 칸 6: 메모 및 인증 목적 입력 칸 */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-indigo-600" />
                  <span>관리자 메모 / 인증 목적 칸</span>
                </label>
                <input
                  type="text"
                  value={dbNotesInput}
                  onChange={(e) => setDbNotesInput(e.target.value)}
                  placeholder="예: 고객센터 본인확인 수동 인증 요청 건"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                />
              </div>
            </div>

            {/* DB 등록 실행 버튼 */}
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="submit"
                disabled={isInsertingDb || !dbPhoneInput.trim()}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-2 shadow-md hover:shadow-indigo-500/20 transition-all cursor-pointer"
              >
                {isInsertingDb ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <PlusCircle className="w-4 h-4" />
                )}
                <span>DB에 신규 인증 레코드 즉시 입력/저장</span>
              </button>
            </div>
          </form>
        </div>

        {/* Live SMS Verification Database Table */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <History className="w-4 h-4 text-indigo-600" />
              <span>실시간 SMS 인증 DB 레코드 목록 ({smsDbRecords.length}건)</span>
            </h4>

            {/* Search & Filter */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={dbSearchTerm}
                  onChange={(e) => {
                    setDbSearchTerm(e.target.value);
                    fetchSmsDbRecords(e.target.value, dbFilterStatus);
                  }}
                  placeholder="전화번호 또는 인증코드 검색"
                  className="pl-8 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                />
              </div>

              <select
                value={dbFilterStatus}
                onChange={(e) => {
                  setDbFilterStatus(e.target.value);
                  fetchSmsDbRecords(dbSearchTerm, e.target.value);
                }}
                className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-700 dark:text-slate-300 font-medium"
              >
                <option value="all">전체 상태</option>
                <option value="pending">대기중 (pending)</option>
                <option value="verified">인증완료 (verified)</option>
                <option value="expired">만료됨 (expired)</option>
                <option value="failed">실패 (failed)</option>
              </select>
            </div>
          </div>

          {/* Records Table */}
          <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
            <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-[11px] font-bold text-slate-700 dark:text-slate-200 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">고유 DB ID</th>
                  <th className="py-2.5 px-3">휴대폰 번호</th>
                  <th className="py-2.5 px-3">인증번호 6자리</th>
                  <th className="py-2.5 px-3">인증 상태</th>
                  <th className="py-2.5 px-3">프로바이더</th>
                  <th className="py-2.5 px-3">등록일시 / 만료</th>
                  <th className="py-2.5 px-3">연동 회원</th>
                  <th className="py-2.5 px-3 text-right">DB 관리</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
                {smsDbRecords.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-400">
                      등록된 SMS 인증 DB 레코드가 없습니다. 위 입력 칸에서 신규 레코드를 등록하거나 SMS 인증을 요청해보세요.
                    </td>
                  </tr>
                ) : (
                  smsDbRecords.map((rec) => {
                    const isExpired = rec.status === 'pending' && Date.now() > rec.expiresTimestamp;
                    const displayStatus = isExpired ? 'expired' : rec.status;

                    return (
                      <tr
                        key={rec.id}
                        className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                      >
                        <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                          {rec.id.replace('sms_rec_', '')}
                        </td>
                        <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-slate-100">
                          {rec.displayPhone}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="font-mono font-bold tracking-wider px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60 text-[11px]">
                            {rec.code}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          {displayStatus === 'verified' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300">
                              <Check className="w-3 h-3" />
                              인증완료
                            </span>
                          )}
                          {displayStatus === 'pending' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300">
                              <Clock className="w-3 h-3" />
                              대기중
                            </span>
                          )}
                          {displayStatus === 'expired' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                              만료됨
                            </span>
                          )}
                          {displayStatus === 'failed' && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 dark:bg-rose-950/70 text-rose-700 dark:text-rose-300">
                              실패
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-[11px] text-slate-500">
                          {rec.provider}
                        </td>
                        <td className="py-2.5 px-3 text-[11px] text-slate-500">
                          <div>{new Date(rec.createdTimestamp).toLocaleTimeString('ko-KR')}</div>
                          <div className="text-[10px] text-slate-400">
                            {rec.verifiedAt
                              ? `인증: ${new Date(rec.verifiedAt).toLocaleTimeString('ko-KR')}`
                              : `만료: ${new Date(rec.expiresTimestamp).toLocaleTimeString('ko-KR')}`}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-[11px]">
                          {rec.userHandle ? (
                            <span className="font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1">
                              <Users className="w-3 h-3" />
                              @{rec.userHandle}
                            </span>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {displayStatus !== 'verified' && (
                              <button
                                type="button"
                                onClick={() => verifySmsDbRecordManual(rec.id)}
                                title="DB에서 즉시 본인인증 완료 처리"
                                className="px-2 py-1 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                              >
                                즉시인증
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => deleteSmsDbRecord(rec.id)}
                              title="DB 레코드 삭제"
                              className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-400 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
