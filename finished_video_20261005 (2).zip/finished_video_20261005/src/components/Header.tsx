import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { GlobalHeaderSearch } from './GlobalHeaderSearch';
import { ThemeSwitchMenu } from './ThemeSwitchMenu';
import {
  Bell,
  Sparkles,
  PlusCircle,
  MessageCircle
} from 'lucide-react';
import { ActiveTab } from '../types';

interface HeaderProps {
  onOpenCreatePost: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenCreatePost }) => {
  const {
    activeTab,
    setActiveTab,
    unreadNotificationsCount,
    unreadMessagesCount,
    isAuthenticated,
    currentUser
  } = useSocial();

  const getTabTitle = (tab: ActiveTab) => {
    switch (tab) {
      case 'feed':
        return { title: '홈 피드', subtitle: '친구들의 새로운 소식을 확인해보세요' };
      case 'explore':
        return { title: '탐색 & 트렌드', subtitle: '관심사와 인기 해시태그를 둘러보세요' };
      case 'notifications':
        return { title: '알림', subtitle: '내 활동과 관련된 새로운 소식입니다' };
      case 'messages':
        return { title: '메시지', subtitle: '다이렉트 메시지로 실시간 소통하세요' };
      case 'bookmarks':
        return { title: '북마크', subtitle: '저장해 둔 유용한 게시물 모음입니다' };
      case 'profile':
        return { title: '내 프로필', subtitle: '프로필 정보와 게시물을 관리하세요' };
      default:
        return { title: '마음', subtitle: '' };
    }
  };

  const { title } = getTabTitle(activeTab);

  return (
    <header
      id="app-global-header"
      className="sticky top-0 z-30 mb-4 rounded-2xl border border-slate-200/80 bg-white/80 px-4 py-3 backdrop-blur-md shadow-xs dark:border-slate-800/80 dark:bg-slate-900/80 transition-colors"
    >
      <div className="flex items-center justify-between gap-2 sm:gap-3">
        {/* Left: View Title (hidden on mobile/tablet to give maximum room to search bar) */}
        <div className="hidden md:flex items-center gap-2 shrink-0">
          <h1 className="text-base font-black tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
            {title}
          </h1>
        </div>

        {/* Center: Global Search Bar */}
        <div className="flex-1 min-w-0 max-w-xl">
          <GlobalHeaderSearch />
        </div>

        {/* Right: Quick Action Controls */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Quick Notification Shortcut */}
          <button
            id="header-notifications-btn"
            onClick={() => setActiveTab('notifications')}
            title="알림"
            className="relative p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors shrink-0"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500" />
              </span>
            )}
          </button>

          {/* Quick Message Shortcut */}
          <button
            id="header-messages-btn"
            onClick={() => setActiveTab('messages')}
            title="메시지"
            className="relative p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 transition-colors shrink-0"
          >
            <MessageCircle className="w-4 h-4" />
            {unreadMessagesCount > 0 && (
              <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500" />
              </span>
            )}
          </button>

          {/* Dark / Light / System Auto Mode Toggle */}
          <ThemeSwitchMenu idPrefix="header-theme" variant="header" className="shrink-0" />

          {/* Create Post (Authenticated) */}
          {isAuthenticated && (
            <button
              id="header-create-post-quick-btn"
              onClick={onOpenCreatePost}
              title="새 게시물 작성"
              className="flex items-center gap-1 sm:gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white text-xs font-bold shadow-xs transition-all active:scale-95 shrink-0"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">작성</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
