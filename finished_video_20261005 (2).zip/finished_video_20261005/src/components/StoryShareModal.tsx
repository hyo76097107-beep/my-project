import React, { useState, useMemo } from 'react';
import { useSocial } from '../context/SocialContext';
import { UserStory, StoryItem, User } from '../types';
import {
  X,
  Search,
  Send,
  Check,
  Share2,
  Copy,
  MessageCircle,
  Sparkles,
  Users,
  CheckCheck
} from 'lucide-react';
import { formatRelativeTime } from '../utils/formatters';

interface StoryShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  storyUser: UserStory;
  storyItem: StoryItem;
}

const QUICK_MESSAGE_PRESETS = [
  '이 스토리 대박이야! 꼭 봐봐 🔥',
  '여기 너무 예쁘다 ✨',
  '오늘 같이 갈래? ☕️',
  '이거 완전 취향저격이야! 👍'
];

export const StoryShareModal: React.FC<StoryShareModalProps> = ({
  isOpen,
  onClose,
  storyUser,
  storyItem
}) => {
  const { users, currentUser, sendMessage, showToast } = useSocial();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [customMessage, setCustomMessage] = useState('');
  const [sentUserIds, setSentUserIds] = useState<string[]>([]);
  const [isCopied, setIsCopied] = useState(false);

  // Available friends (all users except current user)
  const candidateUsers = useMemo(() => {
    return users.filter((u) => u.id !== currentUser.id);
  }, [users, currentUser.id]);

  // Filtered by search keyword
  const filteredUsers = useMemo(() => {
    if (!searchQuery.trim()) return candidateUsers;
    const q = searchQuery.toLowerCase();
    return candidateUsers.filter(
      (u) =>
        u.name.toLowerCase().includes(q) ||
        u.handle.toLowerCase().includes(q) ||
        (u.bio && u.bio.toLowerCase().includes(q))
    );
  }, [candidateUsers, searchQuery]);

  if (!isOpen) return null;

  const isOwnStory = storyUser.userId === currentUser.id;

  const toggleSelectUser = (userId: string) => {
    if (sentUserIds.includes(userId)) return;
    setSelectedUserIds((prev) =>
      prev.includes(userId) ? prev.filter((id) => id !== userId) : [...prev, userId]
    );
  };

  const handleSendToUser = (targetUser: User) => {
    const headerText = isOwnStory
      ? `[스토리 공유] 내 새로운 스토리를 공유했습니다!`
      : `[스토리 공유] ${storyUser.userName}님의 스토리를 공유했습니다!`;
    
    const captionSnippet = storyItem.caption ? `\n"${storyItem.caption}"` : '';
    const extraMsg = customMessage.trim() ? `\n💬 ${customMessage.trim()}` : '';
    const fullMessage = `${headerText}${captionSnippet}${extraMsg}`;

    sendMessage(targetUser.id, fullMessage, storyItem.mediaUrl);
    setSentUserIds((prev) => [...prev, targetUser.id]);
    setSelectedUserIds((prev) => prev.filter((id) => id !== targetUser.id));
    showToast(`${targetUser.name}님에게 스토리를 전송했습니다.`, 'success');
  };

  const handleSendToAllSelected = () => {
    if (selectedUserIds.length === 0) return;

    const headerText = isOwnStory
      ? `[스토리 공유] 내 새로운 스토리를 공유했습니다!`
      : `[스토리 공유] ${storyUser.userName}님의 스토리를 공유했습니다!`;
    
    const captionSnippet = storyItem.caption ? `\n"${storyItem.caption}"` : '';
    const extraMsg = customMessage.trim() ? `\n💬 ${customMessage.trim()}` : '';
    const fullMessage = `${headerText}${captionSnippet}${extraMsg}`;

    selectedUserIds.forEach((targetId) => {
      sendMessage(targetId, fullMessage, storyItem.mediaUrl);
    });

    setSentUserIds((prev) => [...prev, ...selectedUserIds]);
    showToast(`친구 ${selectedUserIds.length}명에게 스토리를 공유했습니다!`, 'success');
    setSelectedUserIds([]);
  };

  const handleCopyStoryLink = async () => {
    const dummyUrl = `${window.location.origin}${window.location.pathname}?storyUser=${storyUser.userId}&storyId=${storyItem.id}`;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(dummyUrl);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = dummyUrl;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setIsCopied(true);
      showToast('스토리 링크가 클립보드에 복사되었습니다!', 'success');
      setTimeout(() => setIsCopied(false), 2000);
    } catch {
      showToast('링크 복사에 실패했습니다.', 'error');
    }
  };

  return (
    <div
      id="story-share-modal-backdrop"
      className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 p-3 sm:p-4 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="story-share-modal"
        className="relative flex w-full max-w-md flex-col overflow-hidden rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl text-white animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 p-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600/20 text-blue-400">
              <Share2 className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">스토리 공유하기</h3>
              <p className="text-[11px] text-slate-400">
                친구에게 다이렉트 메시지(DM)로 스토리를 바로 전달합니다.
              </p>
            </div>
          </div>
          <button
            type="button"
            id="story-share-close-btn"
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Story Preview Card */}
        <div className="p-3.5 bg-slate-950/60 border-b border-slate-800/80">
          <div className="flex items-center gap-3 rounded-xl bg-slate-800/60 p-2.5 border border-slate-700/60">
            {/* Thumbnail */}
            <div className="relative h-14 w-11 shrink-0 overflow-hidden rounded-lg bg-slate-700 ring-1 ring-white/10">
              {storyItem.mediaUrl ? (
                <img
                  src={storyItem.mediaUrl}
                  alt="Story thumbnail"
                  className="h-full w-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div
                  className={`h-full w-full bg-gradient-to-tr ${
                    storyItem.bgColor || 'from-blue-600 to-indigo-800'
                  } flex items-center justify-center text-[10px] text-white font-bold p-1 text-center`}
                >
                  Aa
                </div>
              )}
            </div>

            {/* Meta */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <img
                  src={storyUser.userAvatar}
                  alt={storyUser.userName}
                  className="h-4 w-4 rounded-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="text-xs font-semibold text-white truncate">
                  {storyUser.userName}님의 스토리
                </span>
                <span className="text-[10px] text-slate-400">
                  • {formatRelativeTime(storyItem.createdAt)}
                </span>
              </div>
              <p className="mt-1 text-xs text-slate-300 truncate">
                {storyItem.caption || '사진 스토리'}
              </p>
            </div>

            {/* Quick Copy Link Button */}
            <button
              type="button"
              id="story-share-copy-link-btn"
              onClick={handleCopyStoryLink}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-700/70 hover:bg-slate-700 text-slate-200 text-[11px] font-medium transition-colors cursor-pointer shrink-0"
              title="링크 복사"
            >
              {isCopied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-semibold">복사됨</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5 text-slate-300" />
                  <span>링크 복사</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Search Friends Input */}
        <div className="p-3 border-b border-slate-800/80">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              id="story-share-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="공유할 친구 이름 또는 아이디 검색..."
              className="w-full rounded-xl bg-slate-800/90 pl-9 pr-8 py-2 text-xs text-white placeholder-slate-400 border border-slate-700/60 focus:border-blue-500 focus:outline-none transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Message Presets & Custom Message Input */}
        <div className="px-3.5 pt-2.5 pb-1">
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1 text-[11px]">
            {QUICK_MESSAGE_PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setCustomMessage(preset)}
                className={`whitespace-nowrap px-2.5 py-1 rounded-full border transition-colors cursor-pointer shrink-0 ${
                  customMessage === preset
                    ? 'bg-blue-600/30 border-blue-500 text-blue-200'
                    : 'bg-slate-800/70 border-slate-700/60 text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {preset}
              </button>
            ))}
          </div>

          <div className="mt-1.5">
            <input
              type="text"
              id="story-share-custom-msg-input"
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              placeholder="함께 전달할 메시지 입력 (선택사항)..."
              className="w-full rounded-lg bg-slate-800/60 px-3 py-1.5 text-xs text-white placeholder-slate-400 border border-slate-700/60 focus:border-blue-500 focus:outline-none transition-colors"
            />
          </div>
        </div>

        {/* Friends Selection List */}
        <div className="flex-1 overflow-y-auto max-h-56 p-3 space-y-1.5 scrollbar-thin">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 px-1 pb-1">
            <span>친구 목록 ({filteredUsers.length})</span>
            {selectedUserIds.length > 0 && (
              <span className="text-blue-400 font-bold">{selectedUserIds.length}명 선택됨</span>
            )}
          </div>

          {filteredUsers.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              <Users className="mx-auto h-7 w-7 text-slate-600 mb-1" />
              <p>검색 결과와 일치하는 친구가 없습니다.</p>
            </div>
          ) : (
            filteredUsers.map((user) => {
              const isSent = sentUserIds.includes(user.id);
              const isSelected = selectedUserIds.includes(user.id);

              return (
                <div
                  key={user.id}
                  onClick={() => toggleSelectUser(user.id)}
                  className={`flex items-center justify-between p-2 rounded-xl transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-blue-950/40 border-blue-600/60 shadow-xs'
                      : isSent
                      ? 'bg-emerald-950/20 border-emerald-800/40 opacity-80'
                      : 'bg-slate-800/40 hover:bg-slate-800 border-slate-700/30'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="relative">
                      <img
                        src={user.avatar}
                        alt={user.name}
                        className="h-9 w-9 rounded-full object-cover ring-1 ring-white/10"
                        referrerPolicy="no-referrer"
                      />
                      {isSelected && (
                        <div className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-blue-600 text-white text-[10px]">
                          <Check className="h-2.5 w-2.5 stroke-[3]" />
                        </div>
                      )}
                    </div>
                    <div className="truncate">
                      <p className="text-xs font-bold text-white truncate flex items-center gap-1">
                        {user.name}
                        {user.isVerified && (
                          <span className="text-blue-400 text-[10px]">✓</span>
                        )}
                      </p>
                      <p className="text-[11px] text-slate-400 truncate">@{user.handle}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                    {isSent ? (
                      <span className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-900/60 text-emerald-300 text-xs font-semibold">
                        <CheckCheck className="h-3.5 w-3.5" />
                        전송됨
                      </span>
                    ) : (
                      <button
                        type="button"
                        id={`story-share-send-to-${user.id}`}
                        onClick={() => handleSendToUser(user)}
                        className="flex items-center gap-1 px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 active:scale-95 text-white text-xs font-semibold transition-all cursor-pointer shadow-xs"
                      >
                        <Send className="h-3 w-3" />
                        보내기
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer / Batch Send Action */}
        <div className="border-t border-slate-800 p-3 bg-slate-950/80 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors cursor-pointer"
          >
            닫기
          </button>

          {selectedUserIds.length > 0 && (
            <button
              type="button"
              id="story-share-batch-send-btn"
              onClick={handleSendToAllSelected}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 active:scale-95 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
            >
              <Send className="h-3.5 w-3.5" />
              <span>선택한 {selectedUserIds.length}명에게 모두 보내기</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
