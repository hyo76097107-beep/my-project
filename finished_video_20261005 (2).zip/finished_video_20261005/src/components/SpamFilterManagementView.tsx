import React, { useState, useMemo } from 'react';
import { useSocial } from '../context/SocialContext';
import { SpamFilterAction } from '../types';
import {
  GAMBLING_SPAM_KEYWORDS,
  FINANCE_SPAM_KEYWORDS,
  ADULT_SPAM_KEYWORDS,
  PROMO_SPAM_KEYWORDS,
  DEFAULT_SPAM_KEYWORDS
} from '../utils/spamFilter';
import {
  ShieldAlert,
  ShieldCheck,
  Shield,
  AlertTriangle,
  Plus,
  Trash2,
  RotateCcw,
  Search,
  CheckCircle,
  Eye,
  EyeOff,
  Sparkles,
  Sliders,
  Filter,
  Play,
  Copy,
  Info,
  Layers,
  FileText,
  MessageSquare,
  Send,
  Camera,
  Activity,
  Flame
} from 'lucide-react';

export const SpamFilterManagementView: React.FC = () => {
  const {
    spamFilterSettings,
    updateSpamFilterSettings,
    addSpamKeywords,
    removeSpamKeyword,
    resetSpamKeywordsToDefault,
    clearAllSpamKeywords,
    resetSpamStats,
    runSpamCheck,
    showToast
  } = useSocial();

  // Keyword input & search
  const [keywordInput, setKeywordInput] = useState('');
  const [keywordSearch, setKeywordSearch] = useState('');

  // Simulator state
  const [simulatorInput, setSimulatorInput] = useState(
    '안녕하세요! 오늘 밤 카지노 바카라 사이트에서 불법대출 받아서 고수익보장 혜택 누려보세요.'
  );
  const [simulationResult, setSimulationResult] = useState<{
    hasSpam: boolean;
    detectedWords: string[];
    cleanText: string;
    actionTaken: 'none' | 'block' | 'mask' | 'auto_blind';
    noticeMessage?: string;
  } | null>(null);

  // Filtered keywords list
  const filteredKeywords = useMemo(() => {
    const list = spamFilterSettings.keywords || [];
    if (!keywordSearch.trim()) return list;
    const term = keywordSearch.trim().toLowerCase();
    return list.filter((kw) => kw.toLowerCase().includes(term));
  }, [spamFilterSettings.keywords, keywordSearch]);

  // Handle Add Keywords (comma-separated or single)
  const handleAddKeywords = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!keywordInput.trim()) return;

    const rawKeywords = keywordInput
      .split(/[,;\n]+/)
      .map((k) => k.trim())
      .filter((k) => k.length > 0);

    if (rawKeywords.length === 0) return;

    const result = addSpamKeywords(rawKeywords);
    setKeywordInput('');

    if (result.addedCount > 0) {
      showToast(
        `새 스팸 키워드 ${result.addedCount}개가 성공적으로 등록되었습니다.${
          result.duplicateCount > 0 ? ` (중복 ${result.duplicateCount}개 제외)` : ''
        }`,
        'success'
      );
    } else {
      showToast('이미 등록되어 있는 스팸 키워드입니다.', 'info');
    }
  };

  // Add Preset Pack
  const handleAddPresetPack = (packName: string, keywords: string[]) => {
    const result = addSpamKeywords(keywords);
    if (result.addedCount > 0) {
      showToast(
        `[${packName}] 추천 키워드 ${result.addedCount}개가 추가 등록되었습니다.`,
        'success'
      );
    } else {
      showToast(`[${packName}] 추천 키워드가 이미 모두 등록되어 있습니다.`, 'info');
    }
  };

  // Run Simulator
  const handleRunSimulator = () => {
    if (!simulatorInput.trim()) {
      showToast('테스트할 문장을 입력해주세요.', 'info');
      return;
    }
    const result = runSpamCheck(simulatorInput.trim(), 'posts');
    setSimulationResult(result);
  };

  // Helper to highlight detected keywords in text
  const renderHighlightedText = (text: string, detectedWords: string[]) => {
    if (!detectedWords || detectedWords.length === 0) {
      return <span>{text}</span>;
    }

    const regex = new RegExp(`(${detectedWords.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})`, 'gi');
    const parts = text.split(regex);

    return (
      <span>
        {parts.map((part, index) => {
          const isMatched = detectedWords.some((w) => w.toLowerCase() === part.toLowerCase());
          if (isMatched) {
            return (
              <span
                key={index}
                className="bg-rose-500 text-white font-black px-1.5 py-0.5 rounded-md mx-0.5 inline-block animate-pulse shadow-xs"
              >
                {part}
              </span>
            );
          }
          return <span key={index}>{part}</span>;
        })}
      </span>
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* ============================================================ */}
      {/* 1. TOP HEADER & SYSTEM STATUS BANNER                         */}
      {/* ============================================================ */}
      <div className="rounded-3xl bg-linear-to-br from-indigo-900 via-slate-900 to-indigo-950 p-6 sm:p-7 text-white shadow-xl border border-indigo-800/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 h-64 w-64 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold tracking-wide uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>최고관리자 보안 센터</span>
              </span>
              {spamFilterSettings.isEnabled ? (
                <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  실시간 필터링 가동 중
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400" />
                  필터링 일시 중지됨
                </span>
              )}
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
              <span>스팸 단어(금지어) 자동 필터링 관리</span>
              <span className="text-sm font-normal text-indigo-300/80">v2.0</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              피드 게시물, 댓글, 1:1 메시지(DM), 24시간 스토리 등에 등록되는 불법 도박, 불법 금융/대출, 음란성 홍보, 상업성 스팸 키워드를 사전에 감지하여 <strong>즉시 차단</strong>하거나 <strong>자동 마스킹(***)</strong> 및 <strong>자동 블라인드</strong> 처리합니다.
            </p>
          </div>

          {/* Quick Toggle Button */}
          <div className="shrink-0 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              type="button"
              id="admin-toggle-spam-filter-btn"
              onClick={() => {
                const nextState = !spamFilterSettings.isEnabled;
                updateSpamFilterSettings({ isEnabled: nextState });
                showToast(
                  nextState
                    ? '🛡️ 스팸 단어 필터링 시스템이 활성화되었습니다.'
                    : '⚠️ 스팸 단어 필터링 시스템이 비활성화되었습니다.',
                  nextState ? 'success' : 'info'
                );
              }}
              className={`px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer ${
                spamFilterSettings.isEnabled
                  ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-900/40 ring-2 ring-rose-400/40'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-900/40 ring-2 ring-emerald-400/40'
              }`}
            >
              {spamFilterSettings.isEnabled ? (
                <>
                  <ShieldAlert className="w-4 h-4" />
                  <span>필터링 일시 중지</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>필터링 즉시 가동</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Real-time Stats Cards Grid */}
        <div className="mt-6 pt-5 border-t border-indigo-800/40 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-slate-900/60 backdrop-blur-xs p-3.5 rounded-2xl border border-indigo-800/50">
            <span className="text-[11px] text-slate-400 font-medium block">등록된 스팸 키워드</span>
            <span className="text-xl sm:text-2xl font-black text-indigo-300 mt-0.5 block">
              {(spamFilterSettings.keywords || []).length}개
            </span>
          </div>

          <div className="bg-slate-900/60 backdrop-blur-xs p-3.5 rounded-2xl border border-indigo-800/50">
            <span className="text-[11px] text-rose-300 font-medium block flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
              누적 등록 차단
            </span>
            <span className="text-xl sm:text-2xl font-black text-rose-400 mt-0.5 block">
              {spamFilterSettings.stats.totalBlockedCount}건
            </span>
          </div>

          <div className="bg-slate-900/60 backdrop-blur-xs p-3.5 rounded-2xl border border-indigo-800/50">
            <span className="text-[11px] text-amber-300 font-medium block flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              자동 마스킹(***)
            </span>
            <span className="text-xl sm:text-2xl font-black text-amber-400 mt-0.5 block">
              {spamFilterSettings.stats.totalMaskedCount}건
            </span>
          </div>

          <div className="bg-slate-900/60 backdrop-blur-xs p-3.5 rounded-2xl border border-indigo-800/50">
            <span className="text-[11px] text-cyan-300 font-medium block flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              자동 블라인드
            </span>
            <span className="text-xl sm:text-2xl font-black text-cyan-400 mt-0.5 block">
              {spamFilterSettings.stats.totalAutoBlindedCount}건
            </span>
          </div>
        </div>

        {spamFilterSettings.stats.lastDetectedKeyword && (
          <div className="mt-3 flex items-center justify-between text-[11px] text-indigo-300/80 bg-indigo-950/40 px-3 py-1.5 rounded-xl border border-indigo-800/30">
            <div className="flex items-center gap-1.5 truncate">
              <Activity className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <span>
                최근 감지된 스팸 단어: <strong className="text-rose-300">[{spamFilterSettings.stats.lastDetectedKeyword}]</strong>
              </span>
              {spamFilterSettings.stats.lastDetectedAt && (
                <span className="text-slate-400">
                  ({new Date(spamFilterSettings.stats.lastDetectedAt).toLocaleTimeString('ko-KR')})
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={resetSpamStats}
              className="text-[10px] text-slate-400 hover:text-white underline cursor-pointer ml-2 shrink-0"
            >
              통계 초기화
            </button>
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/* 2. FILTERING POLICY & TARGET SCOPE SETTINGS CARD             */}
      {/* ============================================================ */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-sm border border-slate-200 dark:border-slate-800 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-xl">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                스팸 감지 시 동작 정책 (Action Policy)
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                회원이 작성한 텍스트에 스팸 키워드가 포함되어 있을 때 실행할 조치를 선택합니다.
              </p>
            </div>
          </div>
        </div>

        {/* Action Policy Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Option 1: Block */}
          <button
            type="button"
            id="policy-block-btn"
            onClick={() => {
              updateSpamFilterSettings({ action: 'block' });
              showToast('스팸 처리 정책이 [🚫 등록 즉시 차단]으로 설정되었습니다.', 'success');
            }}
            className={`p-4 rounded-2xl border text-left transition-all cursor-pointer relative ${
              spamFilterSettings.action === 'block'
                ? 'bg-rose-50/80 dark:bg-rose-950/30 border-rose-300 dark:border-rose-800 ring-2 ring-rose-500/20'
                : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-rose-100 dark:bg-rose-900/50 text-rose-600 dark:text-rose-400">
                <ShieldAlert className="w-4 h-4" />
              </span>
              {spamFilterSettings.action === 'block' && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-600 text-white">
                  적용 중
                </span>
              )}
            </div>
            <div className="font-bold text-xs text-slate-900 dark:text-white mb-1">
              🚫 등록 즉시 차단 (권장)
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
              스팸 단어가 포함된 글, 댓글, 메시지 전송을 즉시 거부하고 회원 화면에 경고 알림창을 표시합니다.
            </p>
          </button>

          {/* Option 2: Mask */}
          <button
            type="button"
            id="policy-mask-btn"
            onClick={() => {
              updateSpamFilterSettings({ action: 'mask' });
              showToast('스팸 처리 정책이 [🎭 자동 마스킹 (***)]으로 설정되었습니다.', 'success');
            }}
            className={`p-4 rounded-2xl border text-left transition-all cursor-pointer relative ${
              spamFilterSettings.action === 'mask'
                ? 'bg-amber-50/80 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800 ring-2 ring-amber-500/20'
                : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-amber-100 dark:bg-amber-900/50 text-amber-600 dark:text-amber-400">
                <Filter className="w-4 h-4" />
              </span>
              {spamFilterSettings.action === 'mask' && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-600 text-white">
                  적용 중
                </span>
              )}
            </div>
            <div className="font-bold text-xs text-slate-900 dark:text-white mb-1">
              🎭 자동 마스킹 (*** 치환)
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
              스팸 단어 부분만 지정된 문자열(예: ***)로 자동 치환하여 게시물이나 댓글 등록을 허용합니다.
            </p>
          </button>

          {/* Option 3: Auto-Blind */}
          <button
            type="button"
            id="policy-blind-btn"
            onClick={() => {
              updateSpamFilterSettings({ action: 'auto_blind' });
              showToast('스팸 처리 정책이 [👁️ 자동 블라인드(차단)]으로 설정되었습니다.', 'success');
            }}
            className={`p-4 rounded-2xl border text-left transition-all cursor-pointer relative ${
              spamFilterSettings.action === 'auto_blind'
                ? 'bg-cyan-50/80 dark:bg-cyan-950/30 border-cyan-300 dark:border-cyan-800 ring-2 ring-cyan-500/20'
                : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="p-2 rounded-xl bg-cyan-100 dark:bg-cyan-900/50 text-cyan-600 dark:text-cyan-400">
                <EyeOff className="w-4 h-4" />
              </span>
              {spamFilterSettings.action === 'auto_blind' && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-600 text-white">
                  적용 중
                </span>
              )}
            </div>
            <div className="font-bold text-xs text-slate-900 dark:text-white mb-1">
              👁️ 자동 블라인드 (검토 대기)
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
              등록은 진행되나 즉시 블라인드 처리되어 일반 회원에게 노출되지 않으며 관리자 검토를 대기합니다.
            </p>
          </button>
        </div>

        {/* Custom Replacement Mask Input (Visible when 'mask' is active) */}
        {spamFilterSettings.action === 'mask' && (
          <div className="p-4 bg-amber-50/50 dark:bg-amber-950/20 rounded-2xl border border-amber-200 dark:border-amber-900/60 space-y-2">
            <label className="text-xs font-bold text-amber-900 dark:text-amber-200 block">
              마스킹 대체 문자열 설정
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={spamFilterSettings.replacementMask || '***'}
                onChange={(e) => updateSpamFilterSettings({ replacementMask: e.target.value })}
                placeholder="예: ***, [스팸감지], [차단됨]"
                className="w-full max-w-xs px-3 py-2 bg-white dark:bg-slate-800 border border-amber-300 dark:border-amber-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
              />
              <span className="text-[11px] text-amber-700 dark:text-amber-400">
                감지된 스팸 단어가 위 문자열로 교체됩니다.
              </span>
            </div>
          </div>
        )}

        {/* Target Scope Checkboxes */}
        <div className="pt-2">
          <label className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-2.5">
            필터링 적용 범위 선택
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-750 transition-colors">
              <input
                type="checkbox"
                checked={spamFilterSettings.targetScope.posts}
                onChange={(e) =>
                  updateSpamFilterSettings({
                    targetScope: { ...spamFilterSettings.targetScope, posts: e.target.checked }
                  })
                }
                className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
              />
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200">
                <FileText className="w-3.5 h-3.5 text-indigo-500" />
                <span>피드 게시물</span>
              </div>
            </label>

            <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-750 transition-colors">
              <input
                type="checkbox"
                checked={spamFilterSettings.targetScope.comments}
                onChange={(e) =>
                  updateSpamFilterSettings({
                    targetScope: { ...spamFilterSettings.targetScope, comments: e.target.checked }
                  })
                }
                className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
              />
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200">
                <MessageSquare className="w-3.5 h-3.5 text-indigo-500" />
                <span>댓글 및 답글</span>
              </div>
            </label>

            <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-750 transition-colors">
              <input
                type="checkbox"
                checked={spamFilterSettings.targetScope.messages}
                onChange={(e) =>
                  updateSpamFilterSettings({
                    targetScope: { ...spamFilterSettings.targetScope, messages: e.target.checked }
                  })
                }
                className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
              />
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200">
                <Send className="w-3.5 h-3.5 text-indigo-500" />
                <span>1:1 메시지 (DM)</span>
              </div>
            </label>

            <label className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-750 transition-colors">
              <input
                type="checkbox"
                checked={spamFilterSettings.targetScope.stories}
                onChange={(e) =>
                  updateSpamFilterSettings({
                    targetScope: { ...spamFilterSettings.targetScope, stories: e.target.checked }
                  })
                }
                className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
              />
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200">
                <Camera className="w-3.5 h-3.5 text-indigo-500" />
                <span>스토리 캡션</span>
              </div>
            </label>
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 3. SPAM KEYWORD DICTIONARY & PRESETS                         */}
      {/* ============================================================ */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-sm border border-slate-200 dark:border-slate-800 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>스팸 키워드 사전 관리</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
                총 {spamFilterSettings.keywords.length}개 단어
              </span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              필터링할 금지어를 직접 등록하거나 추천 스팸 단어 팩을 원클릭으로 일괄 추가할 수 있습니다.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="admin-reset-spam-keywords-btn"
              onClick={resetSpamKeywordsToDefault}
              className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>기본 단어 복원</span>
            </button>
            <button
              type="button"
              id="admin-clear-all-spam-keywords-btn"
              onClick={() => {
                if (window.confirm('모든 스팸 키워드를 삭제하시겠습니까?')) {
                  clearAllSpamKeywords();
                }
              }}
              className="px-3 py-1.5 rounded-xl border border-rose-200 dark:border-rose-900 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-600 dark:text-rose-400 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>전체 비우기</span>
            </button>
          </div>
        </div>

        {/* Recommended Preset Packs Bar */}
        <div>
          <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-2">
            💡 카테고리별 추천 스팸 팩 (클릭 시 원클릭 추가)
          </span>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => handleAddPresetPack('불법도박/카지노', GAMBLING_SPAM_KEYWORDS)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>🎲 불법도박/카지노 팩 ({GAMBLING_SPAM_KEYWORDS.length})</span>
            </button>

            <button
              type="button"
              onClick={() => handleAddPresetPack('불법대출/금융사기', FINANCE_SPAM_KEYWORDS)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>💸 불법대출/사기 팩 ({FINANCE_SPAM_KEYWORDS.length})</span>
            </button>

            <button
              type="button"
              onClick={() => handleAddPresetPack('유해/성인/조건만남', ADULT_SPAM_KEYWORDS)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>🔞 유해/성인 팩 ({ADULT_SPAM_KEYWORDS.length})</span>
            </button>

            <button
              type="button"
              onClick={() => handleAddPresetPack('상업스팸/홍보봇', PROMO_SPAM_KEYWORDS)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <span>📢 홍보/스팸봇 팩 ({PROMO_SPAM_KEYWORDS.length})</span>
            </button>

            <button
              type="button"
              onClick={() => handleAddPresetPack('전체 추천 스팸팩', DEFAULT_SPAM_KEYWORDS)}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>전체 추천 팩 일괄 적용 ({DEFAULT_SPAM_KEYWORDS.length})</span>
            </button>
          </div>
        </div>

        {/* Add New Keyword Form */}
        <form onSubmit={handleAddKeywords} className="flex flex-col sm:flex-row items-center gap-2">
          <div className="relative flex-1 w-full">
            <input
              type="text"
              id="admin-add-spam-keyword-input"
              value={keywordInput}
              onChange={(e) => setKeywordInput(e.target.value)}
              placeholder="추가할 스팸 키워드를 입력하세요 (쉼표로 구분하여 여러 개 동시 입력 가능: 카지노, 바카라, 불법대출)"
              className="w-full pl-3.5 pr-10 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
          </div>
          <button
            type="submit"
            id="admin-submit-spam-keyword-btn"
            disabled={!keywordInput.trim()}
            className="w-full sm:w-auto px-5 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition-all flex items-center justify-center gap-1.5 shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>키워드 등록</span>
          </button>
        </form>

        {/* Search & Keywords Chip List */}
        <div className="space-y-3 pt-1">
          <div className="flex items-center justify-between gap-3">
            <div className="relative flex-1 max-w-xs">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={keywordSearch}
                onChange={(e) => setKeywordSearch(e.target.value)}
                placeholder="등록된 키워드 검색..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>
            <span className="text-[11px] text-slate-400">
              {keywordSearch ? `검색 결과: ${filteredKeywords.length}개` : `총 ${spamFilterSettings.keywords.length}개`}
            </span>
          </div>

          {/* Chips Grid */}
          <div className="max-h-60 overflow-y-auto p-4 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 flex flex-wrap gap-2">
            {filteredKeywords.length === 0 ? (
              <div className="w-full py-8 text-center text-xs text-slate-400">
                {keywordSearch
                  ? `'${keywordSearch}'와 일치하는 스팸 키워드가 없습니다.`
                  : '등록된 스팸 키워드가 없습니다. 위 입력창에서 단어를 추가해보세요.'}
              </div>
            ) : (
              filteredKeywords.map((word) => (
                <span
                  key={word}
                  className="group inline-flex items-center gap-1 px-3 py-1 rounded-xl bg-white dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 border border-slate-200/80 dark:border-slate-700 shadow-2xs hover:border-rose-300 dark:hover:border-rose-700 transition-colors"
                >
                  <span className="text-rose-500 dark:text-rose-400 text-[10px]">#</span>
                  <span>{word}</span>
                  <button
                    type="button"
                    onClick={() => removeSpamKeyword(word)}
                    title={`'${word}' 삭제`}
                    className="ml-1 p-0.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-md hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </span>
              ))
            )}
          </div>
        </div>
      </div>

      {/* ============================================================ */}
      {/* 4. INTERACTIVE LIVE TEST SIMULATOR                           */}
      {/* ============================================================ */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 p-6 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <Play className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                실시간 스팸 필터링 시뮬레이터
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                샘플 문장을 입력하여 현재 설정된 정책에 따라 어떻게 감지되고 처리되는지 미리 검증해볼 수 있습니다.
              </p>
            </div>
          </div>
        </div>

        {/* Sample sentence buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
            샘플 문장:
          </span>
          <button
            type="button"
            onClick={() => {
              setSimulatorInput('오늘 밤 카지노 바카라 사이트에서 불법대출 받아서 고수익보장 누리세요!');
              setSimulationResult(null);
            }}
            className="text-[11px] px-2.5 py-1 rounded-lg bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 font-medium hover:bg-rose-100 transition-colors cursor-pointer"
          >
            🎰 도박 및 불법대출 복합 스팸
          </button>
          <button
            type="button"
            onClick={() => {
              setSimulatorInput('급전 필요하신 분 조건만남 및 주식리딩방 카톡ID추가 해주세요.');
              setSimulationResult(null);
            }}
            className="text-[11px] px-2.5 py-1 rounded-lg bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 font-medium hover:bg-amber-100 transition-colors cursor-pointer"
          >
            🔞 조건만남 및 홍보봇 스팸
          </button>
          <button
            type="button"
            onClick={() => {
              setSimulatorInput('오늘 성수동에서 친구와 맛있는 커피 마시고 전시회 다녀왔어요! 날씨도 정말 화창하네요 ✨');
              setSimulationResult(null);
            }}
            className="text-[11px] px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 font-medium hover:bg-emerald-100 transition-colors cursor-pointer"
          >
            ✅ 정상적인 일상 게시물
          </button>
        </div>

        {/* Simulator Input Area */}
        <div className="space-y-2">
          <textarea
            id="admin-simulator-textarea"
            rows={3}
            value={simulatorInput}
            onChange={(e) => {
              setSimulatorInput(e.target.value);
              setSimulationResult(null);
            }}
            placeholder="테스트할 임의의 문장을 직접 작성해보세요..."
            className="w-full p-3.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
          />

          <div className="flex items-center justify-end gap-2">
            <button
              type="button"
              id="admin-run-simulator-btn"
              onClick={handleRunSimulator}
              className="px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/25 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>실시간 필터링 테스트 실행</span>
            </button>
          </div>
        </div>

        {/* Simulation Output Panel */}
        {simulationResult && (
          <div
            className={`p-4 rounded-2xl border transition-all ${
              simulationResult.hasSpam
                ? 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-300 dark:border-rose-900'
                : 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-900'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              {simulationResult.hasSpam ? (
                <>
                  <ShieldAlert className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                  <span className="font-bold text-xs text-rose-900 dark:text-rose-200">
                    🚨 스팸 키워드 감지됨 ({simulationResult.detectedWords.length}개 키워드 적발)
                  </span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                  <span className="font-bold text-xs text-emerald-900 dark:text-emerald-200">
                    ✅ 안전한 문장 (스팸 키워드 미감지)
                  </span>
                </>
              )}
            </div>

            {simulationResult.hasSpam ? (
              <div className="space-y-3 text-xs">
                {/* Detected Keywords Tag List */}
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-slate-600 dark:text-slate-400 font-medium">
                    적발된 단어:
                  </span>
                  {simulationResult.detectedWords.map((w) => (
                    <span
                      key={w}
                      className="px-2 py-0.5 rounded-md bg-rose-600 text-white font-bold text-[11px]"
                    >
                      {w}
                    </span>
                  ))}
                </div>

                {/* Highlighted text preview */}
                <div className="p-3 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-rose-200 dark:border-rose-900/60 text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                  {renderHighlightedText(simulatorInput, simulationResult.detectedWords)}
                </div>

                {/* Action Policy Execution Preview */}
                <div className="p-3 rounded-xl bg-rose-100/70 dark:bg-rose-900/40 border border-rose-300/60 dark:border-rose-800 text-[11px] text-rose-900 dark:text-rose-200 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <span>현재 설정된 정책: </span>
                    <span className="underline uppercase tracking-wide">
                      {spamFilterSettings.action === 'block' && '🚫 [작성 차단 & 거부]'}
                      {spamFilterSettings.action === 'mask' && '🎭 [자동 마스킹]'}
                      {spamFilterSettings.action === 'auto_blind' && '👁️ [자동 블라인드 처리]'}
                    </span>
                  </div>
                  <div>
                    {spamFilterSettings.action === 'block' && (
                      <p>
                        사용자에게{' '}
                        <code className="bg-rose-200 dark:bg-rose-800 px-1 py-0.5 rounded">
                          "{simulationResult.noticeMessage}"
                        </code>{' '}
                        경고창이 즉시 발생하며, 서버 또는 DB에 등록되지 않습니다.
                      </p>
                    )}
                    {spamFilterSettings.action === 'mask' && (
                      <div>
                        <p className="mb-1">스팸 단어가 마스킹 치환되어 아래와 같이 최종 등록됩니다:</p>
                        <div className="p-2 bg-white dark:bg-slate-900 rounded-lg border border-amber-300 dark:border-amber-700 text-slate-900 dark:text-slate-100 font-mono">
                          {simulationResult.cleanText}
                        </div>
                      </div>
                    )}
                    {spamFilterSettings.action === 'auto_blind' && (
                      <p>
                        게시물은 등록되나{' '}
                        <span className="font-bold">`isBlocked: true` (차단 사유: 스팸 키워드 자동 감지)</span>
                        로 즉시 격리 처리되어 일반 피드에서 블라인드 처리됩니다.
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xs text-emerald-800 dark:text-emerald-300">
                입력하신 문장에는 등록된 스팸 단어가 포함되어 있지 않아 정상적으로 작성 및 전송됩니다.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
