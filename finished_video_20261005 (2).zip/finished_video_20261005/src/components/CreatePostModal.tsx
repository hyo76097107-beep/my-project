import React, { useState, useRef, useMemo, useEffect } from 'react';
import { useSocial } from '../context/SocialContext';
import { PostMediaItem } from '../types';
import { InstagramMediaCarousel } from './InstagramMediaCarousel';
import {
  X,
  Image as ImageIcon,
  Video,
  BarChart2,
  Smile,
  MapPin,
  Globe,
  Lock,
  Plus,
  Trash2,
  Upload,
  Play,
  CheckCircle,
  Film,
  Clock,
  Calendar,
  Sparkles,
  AlertCircle,
  CalendarClock,
  ChevronRight,
  Loader2,
  RotateCw,
  Check,
  ArrowLeft,
  ArrowRight,
  Music,
  Disc,
  ShieldCheck,
  Pause,
  Search,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { extractHashtags, formatScheduledDateTime, formatScheduledCountdown } from '../utils/formatters';
import { compressImageFile, generateVideoThumbnail } from '../utils/imageCompressor';
import { uploadMediaFile } from '../services/mediaUpload';
import { validateVideoFileForExoPlayer } from '../utils/codecChecker';
import { ScheduledPostsModal } from './ScheduledPostsModal';
import { getAutoLocation } from '../utils/geolocation';
import { MOOD_CATEGORIES, MoodCategoryId, findMoodCategoryByItem } from '../data/feelingCategories';
import { REGIONAL_SCOPES, getRegionalScopeConfig, RegionalScope } from '../data/regionalScope';
import { StoryBgm } from '../types';
import { resolveBgmAudioUrl, PRESET_STORY_BGMS, COPYRIGHT_FREE_CATEGORIES } from '../data/storyBgmData';

export type CreatePostInitialMode = 'photo' | 'video' | 'schedule' | 'location' | null;

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: CreatePostInitialMode;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({ isOpen, onClose, initialMode }) => {
  const { currentUser, createPost, scheduledPosts, showToast } = useSocial();
  const [content, setContent] = useState('');
  
  // Unified Media state (Photos & Videos, up to 10 total like Instagram)
  const [attachedMedia, setAttachedMedia] = useState<PostMediaItem[]>([]);
  const attachedMediaRef = useRef<PostMediaItem[]>(attachedMedia);
  useEffect(() => {
    attachedMediaRef.current = attachedMedia;
  }, [attachedMedia]);

  const [isProcessingMedia, setIsProcessingMedia] = useState(false);
  const [processingStatusText, setProcessingStatusText] = useState('');
  const [customPhotoUrl, setCustomPhotoUrl] = useState('');
  const [showPhotoPicker, setShowPhotoPicker] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  const [customVideoUrl, setCustomVideoUrl] = useState('');
  const [showVideoPicker, setShowVideoPicker] = useState(false);
  const videoInputRef = useRef<HTMLInputElement>(null);

  // Poll state
  const [showPollCreator, setShowPollCreator] = useState(false);
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState<string[]>(['', '']);

  // Extras & Location state
  const [feeling, setFeeling] = useState<string | undefined>(undefined);
  const [showFeelings, setShowFeelings] = useState(false);
  const [selectedMoodCategory, setSelectedMoodCategory] = useState<MoodCategoryId>('positive');
  const [location, setLocation] = useState('');
  const [showLocationInput, setShowLocationInput] = useState(false);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [isAutoLocationEnabled, setIsAutoLocationEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('auto_add_location');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });
  const [locationSource, setLocationSource] = useState<'gps' | 'profile' | 'preset' | 'manual' | null>(null);
  const [visibility, setVisibility] = useState<'public' | 'followers'>('public');
  const [regionalScope, setRegionalScope] = useState<RegionalScope>('national');
  const currentScopeConfig = getRegionalScopeConfig(regionalScope);

  // Automatically detect and attach location when modal opens
  useEffect(() => {
    if (isOpen) {
      if (isAutoLocationEnabled && !location) {
        let isCancelled = false;
        setIsDetectingLocation(true);

        getAutoLocation(currentUser.location)
          .then((result) => {
            if (!isCancelled) {
              setLocation(result.address);
              setLocationSource(result.source);
              setIsDetectingLocation(false);
            }
          })
          .catch(() => {
            if (!isCancelled) {
              setIsDetectingLocation(false);
            }
          });

        return () => {
          isCancelled = true;
        };
      }
    } else {
      setIsDetectingLocation(false);
    }
  }, [isOpen, isAutoLocationEnabled, currentUser.location]);

  // Handler to manually refresh or re-detect current location
  const handleRefreshLocation = async () => {
    setIsDetectingLocation(true);
    try {
      const result = await getAutoLocation(currentUser.location);
      setLocation(result.address);
      setLocationSource(result.source);
      showToast(`📍 위치가 자동으로 추가되었습니다: ${result.address}`, 'info');
    } catch {
      showToast('위치 정보를 가져오는 데 실패했습니다.', 'error');
    } finally {
      setIsDetectingLocation(false);
    }
  };

  const handleToggleAutoLocation = (enabled: boolean) => {
    setIsAutoLocationEnabled(enabled);
    try {
      localStorage.setItem('auto_add_location', String(enabled));
    } catch {}
    if (enabled) {
      showToast('게시물 작성 시 위치 자동 추가가 활성화되었습니다.', 'info');
      if (!location) {
        handleRefreshLocation();
      }
    } else {
      showToast('위치 자동 추가가 비활성화되었습니다.', 'info');
    }
  };

  const handleCloseModal = () => {
    setContent('');
    setAttachedMedia([]);
    setShowPhotoPicker(false);
    setShowVideoPicker(false);
    setShowPollCreator(false);
    setPollQuestion('');
    setPollOptions(['', '']);
    setFeeling(undefined);
    setLocation('');
    setLocationSource(null);
    setIsScheduled(false);
    setShowSchedulePicker(false);
    setShowLocationInput(false);
    setSelectedBgm(null);
    setShowBgmDrawer(false);
    if (postBgmAudioRef.current) {
      postBgmAudioRef.current.pause();
      setPreviewingBgmId(null);
    }
    onClose();
  };

  // Schedule state
  const [showSchedulePicker, setShowSchedulePicker] = useState(false);
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduleDate, setScheduleDate] = useState<string>(() => {
    const d = new Date(Date.now() + 60 * 60 * 1000);
    return d.toISOString().slice(0, 10);
  });
  const [scheduleTime, setScheduleTime] = useState<string>(() => {
    const d = new Date(Date.now() + 60 * 60 * 1000);
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  });
  const [showScheduledListModal, setShowScheduledListModal] = useState(false);

  // Background Music (BGM) state
  const [selectedBgm, setSelectedBgm] = useState<StoryBgm | null>(null);
  const [showBgmDrawer, setShowBgmDrawer] = useState(false);
  const [bgmSearchQuery, setBgmSearchQuery] = useState('');
  const [activeBgmCategory, setActiveBgmCategory] = useState<string>('all');
  const [previewingBgmId, setPreviewingBgmId] = useState<string | null>(null);
  const [customBgms, setCustomBgms] = useState<StoryBgm[]>([]);
  const [showCustomAudioUrlInput, setShowCustomAudioUrlInput] = useState(false);
  const [customAudioUrlInput, setCustomAudioUrlInput] = useState('');
  const [customAudioTitleInput, setCustomAudioTitleInput] = useState('');
  const postBgmAudioRef = useRef<HTMLAudioElement | null>(null);
  const audioFileInputRef = useRef<HTMLInputElement | null>(null);

  // Stop preview audio when modal closes or unmounts
  useEffect(() => {
    return () => {
      if (postBgmAudioRef.current) {
        postBgmAudioRef.current.pause();
        postBgmAudioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!isOpen && postBgmAudioRef.current) {
      postBgmAudioRef.current.pause();
      setPreviewingBgmId(null);
    }
  }, [isOpen]);

  const handleTogglePreviewAudio = async (bgm: StoryBgm, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (previewingBgmId === bgm.id) {
      postBgmAudioRef.current?.pause();
      setPreviewingBgmId(null);
      return;
    }

    if (postBgmAudioRef.current) {
      postBgmAudioRef.current.pause();
    }

    let url = bgm.audioUrl;
    if (!url || (!url.startsWith('blob:') && !url.startsWith('data:') && !url.startsWith('http'))) {
      url = await resolveBgmAudioUrl(bgm);
    }
    if (!url) return;

    const audio = new Audio(url);
    audio.volume = 0.6;
    audio.play().catch(() => {});
    audio.onended = () => setPreviewingBgmId(null);
    postBgmAudioRef.current = audio;
    setPreviewingBgmId(bgm.id);
  };

  const handleSelectBgm = async (bgm: StoryBgm | null) => {
    if (bgm) {
      let resolved = bgm;
      if (!bgm.audioUrl || (!bgm.audioUrl.startsWith('blob:') && !bgm.audioUrl.startsWith('data:') && !bgm.audioUrl.startsWith('http'))) {
        const url = await resolveBgmAudioUrl(bgm);
        resolved = { ...bgm, audioUrl: url };
      }
      setSelectedBgm(resolved);
      handleTogglePreviewAudio(resolved);
      showToast(`배경음악 "${bgm.title}"이(가) 선택되었습니다! 🎵`, 'info');
    } else {
      setSelectedBgm(null);
      if (postBgmAudioRef.current) {
        postBgmAudioRef.current.pause();
        setPreviewingBgmId(null);
      }
      showToast('배경음악이 제거되었습니다.', 'info');
    }
  };

  const handleProcessAudioFile = async (file: File) => {
    if (!file.type.startsWith('audio/') && !/\.(mp3|wav|m4a|aac|ogg|flac)$/i.test(file.name)) {
      showToast('오디오 파일(.mp3, .wav, .m4a 등)만 등록할 수 있습니다.', 'error');
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      showToast('50MB 이하의 오디오 파일만 업로드할 수 있습니다.', 'error');
      return;
    }
    const localUrl = URL.createObjectURL(file);
    const cleanTitle = file.name.replace(/\.[^/.]+$/, '');
    const customTrack: StoryBgm = {
      id: `custom_bgm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      title: cleanTitle,
      artist: currentUser.name || '직접 등록한 음원',
      genre: '사용자 BGM',
      audioUrl: localUrl,
      coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
      duration: 30,
      license: '사용자 직접 등록 (저작권 무료)',
      isCustom: true
    };
    setCustomBgms((prev) => [customTrack, ...prev]);
    setSelectedBgm(customTrack);
    handleTogglePreviewAudio(customTrack);
    showToast(`저작권 무료 음원 "${cleanTitle}"이(가) 등록 및 적용되었습니다! 🎶`, 'success');

    // Background server upload
    try {
      const uploadRes = await uploadMediaFile(file);
      if (uploadRes && uploadRes.url) {
        customTrack.audioUrl = uploadRes.url;
        setSelectedBgm((curr) => (curr?.id === customTrack.id ? { ...curr, audioUrl: uploadRes.url } : curr));
        setCustomBgms((prev) => prev.map((b) => (b.id === customTrack.id ? { ...b, audioUrl: uploadRes.url } : b)));
      }
    } catch (err) {
      console.warn('[AudioUpload] Server upload fallback to local URL:', err);
    } finally {
      if (audioFileInputRef.current) audioFileInputRef.current.value = '';
    }
  };

  const handleAddCustomAudioUrl = (url: string, title?: string) => {
    if (!url.trim()) return;
    const cleanTitle = title?.trim() || '외부 웹 음원';
    const customTrack: StoryBgm = {
      id: `custom_url_${Date.now()}`,
      title: cleanTitle,
      artist: '외부 웹 링크',
      genre: '웹 BGM',
      audioUrl: url.trim(),
      coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop&q=80',
      duration: 30,
      license: '웹 음원 링크 (저작권 무료)',
      isCustom: true
    };
    setCustomBgms((prev) => [customTrack, ...prev]);
    setSelectedBgm(customTrack);
    handleTogglePreviewAudio(customTrack);
    showToast(`"${cleanTitle}" 음원이 적용되었습니다! 🎵`, 'success');
  };

  // Handle direct navigation to requested section (photo, video, schedule, location)
  useEffect(() => {
    if (isOpen && initialMode) {
      if (initialMode === 'photo') {
        setShowPhotoPicker(true);
        setShowVideoPicker(false);
        setShowSchedulePicker(false);
        setShowLocationInput(false);
        setShowPollCreator(false);
        setShowFeelings(false);
        setTimeout(() => {
          document.getElementById('post-photo-drawer')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 120);
      } else if (initialMode === 'video') {
        setShowVideoPicker(true);
        setShowPhotoPicker(false);
        setShowSchedulePicker(false);
        setShowLocationInput(false);
        setShowPollCreator(false);
        setShowFeelings(false);
        setTimeout(() => {
          document.getElementById('post-video-drawer')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 120);
      } else if (initialMode === 'schedule') {
        setShowSchedulePicker(true);
        setIsScheduled(true);
        setShowPhotoPicker(false);
        setShowVideoPicker(false);
        setShowLocationInput(false);
        setShowPollCreator(false);
        setShowFeelings(false);
        setTimeout(() => {
          document.getElementById('post-schedule-settings-panel')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 120);
      } else if (initialMode === 'location') {
        setShowLocationInput(true);
        setShowPhotoPicker(false);
        setShowVideoPicker(false);
        setShowSchedulePicker(false);
        setShowPollCreator(false);
        setShowFeelings(false);
        setTimeout(() => {
          document.getElementById('post-location-drawer')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 120);
      }
    }
  }, [isOpen, initialMode]);

  // Computed scheduled datetime string & validation
  const targetScheduledISO = useMemo(() => {
    if (!isScheduled) return undefined;
    try {
      if (!scheduleDate || !scheduleTime) return undefined;
      const dt = new Date(`${scheduleDate}T${scheduleTime}:00`);
      if (isNaN(dt.getTime())) return undefined;
      return dt.toISOString();
    } catch {
      return undefined;
    }
  }, [isScheduled, scheduleDate, scheduleTime]);

  const isScheduleInFuture = useMemo(() => {
    if (!isScheduled) return true;
    if (!targetScheduledISO) return false;
    // Must be at least 30 seconds in the future
    return new Date(targetScheduledISO).getTime() > Date.now() + 30 * 1000;
  }, [isScheduled, targetScheduledISO]);

  // Schedule Quick Preset Handlers
  const handleSetPresetMinutes = (minutes: number) => {
    const d = new Date(Date.now() + minutes * 60 * 1000);
    const dateStr = d.toISOString().slice(0, 10);
    const timeStr = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    setScheduleDate(dateStr);
    setScheduleTime(timeStr);
    setIsScheduled(true);
  };

  const handleSetPresetTomorrow = (hour: number, minute: number = 0) => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const timeStr = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    setScheduleDate(dateStr);
    setScheduleTime(timeStr);
    setIsScheduled(true);
  };

  const handleSetPresetDaysAhead = (days: number, hour: number, minute: number = 0) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const timeStr = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    setScheduleDate(dateStr);
    setScheduleTime(timeStr);
    setIsScheduled(true);
  };

  const todayStr = new Date().toISOString().slice(0, 10);
  const myScheduledCount = scheduledPosts.filter((p) => p.authorId === currentUser.id).length;

  if (!isOpen) return null;

  // Unified media item handlers (up to 10 total)
  const addMediaItem = (type: 'image' | 'video', url: string, thumbnail?: string) => {
    if (attachedMedia.length >= 10) {
      showToast('사진 및 동영상은 최대 10개까지 첨부할 수 있습니다.', 'info');
      return;
    }
    const newItem: PostMediaItem = {
      id: `media_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      type,
      url,
      thumbnail
    };
    setAttachedMedia((prev) => [...prev, newItem]);
    showToast(`${type === 'video' ? '동영상' : '사진'}이 첨부되었습니다 (${attachedMedia.length + 1}/10)`, 'success');
  };

  const removeMediaItem = (id: string) => {
    setAttachedMedia((prev) => prev.filter((item) => item.id !== id));
  };

  const moveMediaItem = (index: number, direction: 'left' | 'right') => {
    setAttachedMedia((prev) => {
      const targetIndex = direction === 'left' ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= prev.length) return prev;
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[targetIndex];
      copy[targetIndex] = temp;
      return copy;
    });
  };

  const handleAddCustomPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (customPhotoUrl.trim()) {
      if (attachedMedia.length >= 10) {
        showToast('사진 및 동영상은 최대 10개까지 첨부할 수 있습니다.', 'info');
        return;
      }
      addMediaItem('image', customPhotoUrl.trim());
      setCustomPhotoUrl('');
    }
  };

  const handlePhotoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFiles = e.target.files;
    if (!rawFiles || rawFiles.length === 0) return;
    const filesArray = Array.from(rawFiles);
    if (photoInputRef.current) {
      photoInputRef.current.value = '';
    }

    const currentCount = attachedMediaRef.current.length;
    const remainingSlots = 10 - currentCount;
    if (remainingSlots <= 0) {
      showToast('최대 10개까지 첨부할 수 있습니다.', 'info');
      return;
    }
    const filesToProcess = filesArray.slice(0, remainingSlots);

    setIsProcessingMedia(true);
    let addedCount = 0;
    try {
      for (let i = 0; i < filesToProcess.length; i++) {
        const file = filesToProcess[i];
        setProcessingStatusText(`사진 최적화 및 업로드 중 (${i + 1}/${filesToProcess.length})...`);
        try {
          const uploadRes = await uploadMediaFile(file, (msg) => {
            setProcessingStatusText(`사진 (${i + 1}/${filesToProcess.length}): ${msg}`);
          });
          const newItem: PostMediaItem = {
            id: `media_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 9)}`,
            type: 'image',
            url: uploadRes.url,
            thumbnail: uploadRes.thumbnail
          };
          setAttachedMedia((prev) => {
            if (prev.length >= 10) return prev;
            const updated = [...prev, newItem];
            attachedMediaRef.current = updated;
            return updated;
          });
          addedCount++;
        } catch (itemErr) {
          console.error(`[PhotoUpload] ${file.name} 업로드 오류:`, itemErr);
        }
      }
      if (addedCount > 0) {
        showToast(`사진 ${addedCount}장이 안전하게 추가되었습니다.`, 'success');
      }
    } catch (err) {
      console.error('Error optimizing photo files:', err);
      showToast('사진 처리 중 문제가 발생했습니다.', 'error');
    } finally {
      setIsProcessingMedia(false);
      setProcessingStatusText('');
      if (photoInputRef.current) {
        photoInputRef.current.value = '';
      }
    }
  };

  // Video handlers
  const handleAddCustomVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (customVideoUrl.trim()) {
      if (attachedMedia.length >= 10) {
        showToast('사진 및 동영상은 최대 10개까지 첨부할 수 있습니다.', 'info');
        return;
      }
      addMediaItem('video', customVideoUrl.trim());
      setCustomVideoUrl('');
      setShowVideoPicker(false);
    }
  };

  const handleVideoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFiles = e.target.files;
    if (!rawFiles || rawFiles.length === 0) return;

    // Convert to a concrete File[] array immediately to preserve full file list
    const fileArray = Array.from(rawFiles);

    // Reset input immediately so the exact same files can be re-selected if needed
    if (videoInputRef.current) {
      videoInputRef.current.value = '';
    }

    const currentMediaCount = attachedMediaRef.current.length;
    const remainingSlots = 10 - currentMediaCount;
    if (remainingSlots <= 0) {
      showToast('동영상 및 사진은 최대 10개까지 첨부할 수 있습니다.', 'info');
      return;
    }

    const filesToProcess = fileArray.slice(0, remainingSlots);
    if (fileArray.length > remainingSlots) {
      showToast(`최대 첨부 한도(10개)로 인해 ${remainingSlots}개의 동영상만 추가됩니다.`, 'info');
    }

    setIsProcessingMedia(true);
    let successfullyAddedCount = 0;

    try {
      for (let i = 0; i < filesToProcess.length; i++) {
        const file = filesToProcess[i];
        const validation = validateVideoFileForExoPlayer(file);
        if (validation.warnings.length > 0) {
          console.info('[ExoPlayerCodecCheck]', file.name, validation.warnings);
        }
        setProcessingStatusText(`동영상 업로드 및 H.264 최적화 중 (${i + 1}/${filesToProcess.length}): ${file.name}...`);

        try {
          const uploadRes = await uploadMediaFile(file, (msg) => {
            setProcessingStatusText(`동영상 (${i + 1}/${filesToProcess.length}): ${msg}`);
          });

          let realVideoUrl = uploadRes.url;
          // If fallback occurred to blob, perform emergency direct Base64 synchronization to secure a server URL
          if (realVideoUrl.startsWith('blob:')) {
            try {
              setProcessingStatusText(`동영상 (${i + 1}/${filesToProcess.length}): 영구 보존 인코딩 전송 중...`);
              const b64 = await new Promise<string>((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result as string);
                reader.onerror = reject;
                reader.readAsDataURL(file);
              });
              const b64Res = await fetch('/api/sync/upload-base64', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  name: file.name,
                  type: file.type || 'video/mp4',
                  data: b64,
                }),
              });
              if (b64Res.ok) {
                const b64Data = await b64Res.json();
                if (b64Data.success && b64Data.url) {
                  realVideoUrl = b64Data.url;
                }
              }
            } catch (syncErr) {
              console.warn('[VideoUpload] Emergency server sync failed:', syncErr);
            }
          }

          const newMediaItem: PostMediaItem = {
            id: `media_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 9)}`,
            type: 'video',
            url: realVideoUrl,
            thumbnail: uploadRes.thumbnail
          };

          setAttachedMedia((prev) => {
            if (prev.length >= 10) return prev;
            const updated = [...prev, newMediaItem];
            attachedMediaRef.current = updated;
            return updated;
          });

          successfullyAddedCount++;
        } catch (itemErr) {
          console.error(`[VideoUpload] 파일(${file.name}) 처리 중 오류:`, itemErr);
          try {
            const blobUrl = URL.createObjectURL(file);
            const fallbackItem: PostMediaItem = {
              id: `media_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 9)}`,
              type: 'video',
              url: blobUrl,
            };
            setAttachedMedia((prev) => {
              if (prev.length >= 10) return prev;
              const updated = [...prev, fallbackItem];
              attachedMediaRef.current = updated;
              return updated;
            });
            successfullyAddedCount++;
          } catch {}
        }
      }

      setShowVideoPicker(false);
      if (successfullyAddedCount > 0) {
        showToast(`동영상 ${successfullyAddedCount}개가 성공적으로 첨부되었습니다.`, 'success');
      }
    } catch (err) {
      console.error('Error in handleVideoFileUpload:', err);
      showToast('동영상 처리 중 문제가 발생했습니다.', 'error');
    } finally {
      setIsProcessingMedia(false);
      setProcessingStatusText('');
      if (videoInputRef.current) {
        videoInputRef.current.value = '';
      }
    }
  };

  // Poll handlers
  const handlePollOptionChange = (index: number, val: string) => {
    const updated = [...pollOptions];
    updated[index] = val;
    setPollOptions(updated);
  };

  const handleAddPollOption = () => {
    if (pollOptions.length < 4) {
      setPollOptions((prev) => [...prev, '']);
    }
  };

  const handleRemovePollOption = (index: number) => {
    if (pollOptions.length > 2) {
      setPollOptions((prev) => prev.filter((_, i) => i !== index));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const hasContent = content.trim().length > 0;
    const hasMedia = attachedMedia.length > 0;
    const hasPoll = showPollCreator && pollQuestion.trim().length > 0;

    if (!hasContent && !hasMedia && !hasPoll) return;
    if (isScheduled && !isScheduleInFuture) return;

    const tags = extractHashtags(content);
    const resolvedImages = attachedMedia.filter((m) => m.type === 'image').map((m) => m.url);
    const firstVideo = attachedMedia.find((m) => m.type === 'video');

    const result = createPost({
      content,
      images: resolvedImages.length > 0 ? resolvedImages : undefined,
      video: firstVideo ? firstVideo.url : undefined,
      videoThumbnail: firstVideo ? firstVideo.thumbnail : undefined,
      mediaItems: attachedMedia.length > 0 ? attachedMedia : undefined,
      tags: tags.length > 0 ? tags : undefined,
      pollQuestion: showPollCreator && pollQuestion.trim() ? pollQuestion : undefined,
      pollOptions: showPollCreator ? pollOptions.filter((o) => o.trim().length > 0) : undefined,
      feeling,
      location: location.trim() || undefined,
      bgm: selectedBgm || undefined,
      visibility,
      regionalScope,
      scheduledAt: isScheduled && targetScheduledISO ? targetScheduledISO : undefined
    });

    // If blocked by spam filter, keep modal open with current content so user can edit!
    if ((result as any)?.success === false) {
      return;
    }

    // Reset
    setContent('');
    setAttachedMedia([]);
    setShowPhotoPicker(false);
    setShowVideoPicker(false);
    setShowPollCreator(false);
    setPollQuestion('');
    setPollOptions(['', '']);
    setFeeling(undefined);
    setLocation('');
    setLocationSource(null);
    setRegionalScope('national');
    setIsScheduled(false);
    setShowSchedulePicker(false);
    setShowLocationInput(false);
    setSelectedBgm(null);
    setShowBgmDrawer(false);
    if (postBgmAudioRef.current) {
      postBgmAudioRef.current.pause();
      setPreviewingBgmId(null);
    }
    onClose();
  };

  const isSubmitDisabled =
    isProcessingMedia ||
    (!content.trim() &&
      attachedMedia.length === 0 &&
      !pollQuestion.trim()) ||
    (isScheduled && !isScheduleInFuture);

  return (
    <>
      <div
        id="create-post-modal"
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-150"
        onClick={handleCloseModal}
      >
        <div
          className="w-full max-w-xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50 max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-3">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="h-11 w-11 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                referrerPolicy="no-referrer"
              />
              <div>
                <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white">
                  <span>{currentUser.name}</span>
                  {feeling && (() => {
                    const cat = findMoodCategoryByItem(feeling);
                    return (
                      <span className={`inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full font-medium border animate-in fade-in duration-150 ${cat?.colorClass.badge || 'bg-blue-50 text-blue-700 border-blue-200'}`}>
                        <span>{cat?.emoji || '✨'}</span>
                        <span className="font-bold">{cat?.name ? `${cat.name} · ` : ''}</span>
                        <span>{feeling}</span>
                        <button
                          type="button"
                          onClick={() => setFeeling(undefined)}
                          className="ml-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-0.5"
                          title="기분 지우기"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    );
                  })()}
                </div>
                {/* Visibility & Schedule Indicators */}
                <div className="flex items-center flex-wrap gap-1.5 mt-0.5">
                  <button
                    type="button"
                    onClick={() => setVisibility(visibility === 'public' ? 'followers' : 'public')}
                    className="flex items-center gap-1 rounded-full bg-slate-100 dark:bg-slate-800 px-2 py-0.5 text-[11px] font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 transition-colors"
                  >
                    {visibility === 'public' ? (
                      <>
                        <Globe className="h-3 w-3 text-blue-500" />
                        <span>전체 공개</span>
                      </>
                    ) : (
                      <>
                        <Lock className="h-3 w-3 text-amber-500" />
                        <span>팔로워 공개</span>
                      </>
                    )}
                  </button>

                  {/* Regional Scope Badge */}
                  <span
                    id="create-post-scope-header-badge"
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold border ${currentScopeConfig.badgeClass}`}
                    title={`공개 지역 범위: ${currentScopeConfig.label} (${currentScopeConfig.description})`}
                  >
                    <span>{currentScopeConfig.emoji}</span>
                    <span>{currentScopeConfig.label}</span>
                  </span>

                  {isScheduled && (
                    <span className="flex items-center gap-1 rounded-full bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 border border-indigo-200/60 dark:border-indigo-800/60">
                      <Clock className="h-3 w-3 text-indigo-500" />
                      <span>예약 전송 활성</span>
                    </span>
                  )}

                  {/* Auto-detected or manual location badge */}
                  {(location || isDetectingLocation) && (
                    <div
                      id="create-post-location-badge"
                      className="flex items-center gap-1.5 text-[11px] bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200/70 dark:border-blue-800/70 px-2.5 py-0.5 rounded-full animate-in fade-in duration-150"
                    >
                      {isDetectingLocation ? (
                        <>
                          <Loader2 className="h-3 w-3 animate-spin text-blue-500 shrink-0" />
                          <span className="font-medium">위치 자동 감지 중...</span>
                        </>
                      ) : (
                        <>
                          <MapPin className="h-3 w-3 text-blue-600 dark:text-blue-400 shrink-0" />
                          <button
                            type="button"
                            onClick={() => setShowLocationInput(true)}
                            className="hover:underline font-semibold max-w-[130px] sm:max-w-xs truncate text-left cursor-pointer"
                            title="클릭하여 위치 수정 또는 설정"
                          >
                            {location}
                          </button>
                          {locationSource === 'gps' && (
                            <span className="text-[9px] bg-blue-200/80 dark:bg-blue-900/80 text-blue-800 dark:text-blue-200 px-1 py-0.2 rounded font-bold">
                              GPS
                            </span>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              setLocation('');
                              setLocationSource(null);
                            }}
                            className="ml-0.5 text-blue-400 hover:text-blue-600 dark:hover:text-blue-200 transition-colors p-0.5 cursor-pointer"
                            title="위치 제외"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </>
                      )}
                    </div>
                  )}

                  {/* Selected BGM badge */}
                  {selectedBgm && (
                    <div
                      id="create-post-bgm-badge"
                      className="flex items-center gap-1.5 text-[11px] bg-amber-50 text-amber-800 dark:bg-amber-950/60 dark:text-amber-200 border border-amber-200/80 dark:border-amber-800/70 px-2.5 py-0.5 rounded-full animate-in fade-in duration-150"
                    >
                      <button
                        type="button"
                        onClick={(e) => handleTogglePreviewAudio(selectedBgm, e)}
                        className="cursor-pointer hover:opacity-80 flex items-center gap-1"
                        title={previewingBgmId === selectedBgm.id ? '미리듣기 정지' : '미리듣기 재생'}
                      >
                        <Music className={`h-3 w-3 text-amber-600 dark:text-amber-400 shrink-0 ${previewingBgmId === selectedBgm.id ? 'animate-spin [animation-duration:6s]' : ''}`} />
                        <span className="font-semibold max-w-[130px] sm:max-w-xs truncate text-left">
                          {selectedBgm.title}
                        </span>
                        <span className="text-[9px] bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 px-1 py-0.2 rounded font-bold">
                          CC0
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSelectBgm(null)}
                        className="ml-0.5 text-amber-500 hover:text-amber-700 dark:hover:text-amber-300 transition-colors p-0.5 cursor-pointer"
                        title="음악 제거"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {myScheduledCount > 0 && (
                <button
                  type="button"
                  id="view-scheduled-posts-btn"
                  onClick={() => setShowScheduledListModal(true)}
                  className="flex items-center gap-1 rounded-full bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:text-indigo-400 dark:hover:bg-indigo-900/60 transition-colors cursor-pointer"
                  title="예약된 게시물 목록 보기"
                >
                  <CalendarClock className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">예약 글</span>
                  <span className="rounded-full bg-indigo-600 px-1.5 py-0.2 text-[10px] text-white">
                    {myScheduledCount}
                  </span>
                </button>
              )}

              <button
                type="button"
                onClick={handleCloseModal}
                className="rounded-full p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>

        {/* Content Area */}
        <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-4">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="어떤 생각을 하고 계신가요? 텍스트, 사진, 동영상과 함께 #해시태그를 남겨보세요..."
            rows={4}
            className="w-full resize-none bg-transparent text-base text-slate-900 placeholder-slate-400 focus:outline-none dark:text-white dark:placeholder-slate-500"
          />

          {/* Media Processing Loading Banner */}
          {isProcessingMedia && (
            <div className="flex items-center gap-2.5 rounded-xl border border-blue-200 bg-blue-50/80 px-3.5 py-2.5 dark:border-blue-900/60 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 animate-pulse">
              <Loader2 className="h-4 w-4 animate-spin text-blue-600 dark:text-blue-400 shrink-0" />
              <div className="flex-1 text-xs">
                <span className="font-semibold">{processingStatusText || '미디어 최적화 처리 중...'}</span>
                <span className="text-[11px] text-blue-500 dark:text-blue-400 block">
                  고화질 유지 및 브라우저 메모리 부하 방지를 위해 안전하게 변환 중입니다.
                </span>
              </div>
            </div>
          )}

          {/* Instagram-style Media Carousel & Reorder Management (Photos & Videos up to 10) */}
          {attachedMedia.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <span className="text-sm">📸</span>
                  <span>미디어 미리보기 ({attachedMedia.length}/10개)</span>
                  {attachedMedia.length >= 10 && (
                    <span className="text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300 px-2 py-0.5 rounded-full">
                      최대 첨부 완료
                    </span>
                  )}
                </span>
                <button
                  type="button"
                  onClick={() => setAttachedMedia([])}
                  className="text-xs text-rose-500 hover:text-rose-600 dark:text-rose-400 font-semibold hover:underline cursor-pointer"
                >
                  모두 지우기
                </button>
              </div>

              {/* Instagram Carousel with Dots Below and Swipe */}
              <div className="w-full">
                <InstagramMediaCarousel
                  mediaItems={attachedMedia}
                  postId="create_modal_preview"
                  compact={true}
                  isPostInView={true}
                />
              </div>

              {/* Attached Media Thumbnail Reorder & Management Strip */}
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/50 p-2.5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                    순서 변경(← / →) 및 삭제 (좌우로 밀어서 피드에 노출되는 순서)
                  </span>
                  {attachedMedia.length < 10 && (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setShowPhotoPicker(true);
                          setShowVideoPicker(false);
                        }}
                        className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                      >
                        <Plus className="h-3 w-3" />
                        사진 추가
                      </button>
                      <span className="text-slate-300 dark:text-slate-600">|</span>
                      <button
                        type="button"
                        onClick={() => {
                          setShowVideoPicker(true);
                          setShowPhotoPicker(false);
                        }}
                        className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                      >
                        <Plus className="h-3 w-3" />
                        동영상 추가
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 scrollbar-thin">
                  {attachedMedia.map((item, idx) => (
                    <div
                      key={item.id}
                      className="group relative flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 border-slate-200 dark:border-slate-700 bg-slate-950 flex flex-col justify-between shadow-sm"
                    >
                      {item.type === 'video' ? (
                        item.thumbnail ? (
                          <img
                            src={item.thumbnail}
                            alt={`Media ${idx + 1}`}
                            className="w-full h-full object-cover pointer-events-none"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center text-slate-400 pointer-events-none">
                            <Film className="h-6 w-6 text-slate-500 mb-0.5" />
                            <span className="text-[9px] font-semibold">동영상</span>
                          </div>
                        )
                      ) : (
                        <img
                          src={item.url}
                          alt={`Media ${idx + 1}`}
                          className="w-full h-full object-cover pointer-events-none"
                          referrerPolicy="no-referrer"
                        />
                      )}

                      {/* Top Badges: Index Number & Type */}
                      <div className="absolute top-1 left-1 right-1 flex items-center justify-between pointer-events-none">
                        <span className="h-4 min-w-[16px] px-1 rounded bg-black/75 text-[10px] font-extrabold text-white flex items-center justify-center">
                          {idx + 1}
                        </span>
                        <span className="h-4 px-1 rounded bg-black/75 text-[9px] text-white flex items-center justify-center">
                          {item.type === 'video' ? '🎥' : '📷'}
                        </span>
                      </div>

                      {/* Delete Button */}
                      <button
                        type="button"
                        onClick={() => removeMediaItem(item.id)}
                        className="absolute top-1 right-1 h-5 w-5 rounded-full bg-rose-600/90 text-white flex items-center justify-center shadow hover:bg-rose-700 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                        title="삭제"
                      >
                        <X className="h-3 w-3" />
                      </button>

                      {/* Bottom Reorder Controls */}
                      <div className="absolute bottom-0 inset-x-0 bg-black/75 py-0.5 px-1 flex items-center justify-between text-white opacity-90 group-hover:opacity-100">
                        <button
                          type="button"
                          onClick={() => moveMediaItem(idx, 'left')}
                          disabled={idx === 0}
                          className="disabled:opacity-20 hover:text-blue-400 p-0.5 cursor-pointer disabled:cursor-not-allowed"
                          title="왼쪽으로 이동"
                        >
                          <ArrowLeft className="h-3 w-3" />
                        </button>
                        <span className="text-[9px] text-slate-300 font-mono">
                          {idx + 1}/{attachedMedia.length}
                        </span>
                        <button
                          type="button"
                          onClick={() => moveMediaItem(idx, 'right')}
                          disabled={idx === attachedMedia.length - 1}
                          className="disabled:opacity-20 hover:text-blue-400 p-0.5 cursor-pointer disabled:cursor-not-allowed"
                          title="오른쪽으로 이동"
                        >
                          <ArrowRight className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Add more button tile if less than 10 */}
                  {attachedMedia.length < 10 && (
                    <button
                      type="button"
                      onClick={() => setShowPhotoPicker(true)}
                      className="flex-shrink-0 w-20 h-20 rounded-lg border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 hover:bg-blue-50/50 dark:hover:bg-blue-950/30 flex flex-col items-center justify-center gap-1 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 transition-all cursor-pointer"
                    >
                      <Plus className="h-5 w-5" />
                      <span className="text-[10px] font-bold">
                        {attachedMedia.length}/10
                      </span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Hidden File Inputs */}
          <input
            ref={photoInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handlePhotoFileUpload}
          />
          <input
            ref={videoInputRef}
            type="file"
            accept="video/*,video/mp4,video/webm,video/quicktime,video/x-matroska,video/3gpp,.mp4,.mov,.webm,.mkv,.3gp,.avi,.m4v"
            multiple
            className="hidden"
            onChange={handleVideoFileUpload}
          />

          {/* Video Picker Drawer */}
          {showVideoPicker && (
            <div
              id="post-video-drawer"
              className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-800/60 animate-in fade-in duration-100"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <Video className="h-4 w-4 text-blue-600" />
                  동영상 첨부 (현재 {attachedMedia.length}/10개 첨부됨 - MP4, WebM, MOV 및 YouTube 지원)
                </span>
                <button
                  type="button"
                  onClick={() => setShowVideoPicker(false)}
                  className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  닫기
                </button>
              </div>

              {/* Local File Upload Button & URL input */}
              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={() => videoInputRef.current?.click()}
                  disabled={attachedMedia.length >= 10}
                  className="flex items-center justify-center gap-1.5 rounded-lg border border-dashed border-blue-400 bg-blue-50/50 px-3.5 py-2 text-xs font-bold text-blue-600 hover:bg-blue-100 dark:border-blue-700 dark:bg-blue-950/40 dark:text-blue-300 transition-colors disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
                >
                  <Upload className="h-3.5 w-3.5" />
                  <span>내 기기에서 동영상 파일 선택 (MP4, MOV, WebM 등)</span>
                </button>
                <div className="flex-1 flex gap-2">
                  <input
                    type="url"
                    value={customVideoUrl}
                    onChange={(e) => setCustomVideoUrl(e.target.value)}
                    placeholder="동영상 URL 또는 YouTube 영상 링크..."
                    disabled={attachedMedia.length >= 10}
                    className="flex-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-white focus:outline-none focus:border-blue-500 disabled:opacity-50"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomVideo}
                    disabled={!customVideoUrl.trim() || attachedMedia.length >= 10}
                    className="rounded-lg bg-blue-600 disabled:opacity-50 px-3 py-1.5 text-xs font-bold text-white hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    추가
                  </button>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-2">
                * 사진과 동영상을 원하는 조합으로 총 10개까지 자유롭게 첨부할 수 있습니다.
              </p>
            </div>
          )}

          {/* Photo Picker Drawer */}
          {showPhotoPicker && (
            <div
              id="post-photo-drawer"
              className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 dark:border-slate-800 dark:bg-slate-800/60 animate-in fade-in duration-100"
            >
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <ImageIcon className="h-4 w-4 text-emerald-500" />
                  사진 첨부 (현재 {attachedMedia.length}/10개 첨부됨)
                </span>
                <button
                  type="button"
                  onClick={() => setShowPhotoPicker(false)}
                  className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  닫기
                </button>
              </div>

              {/* File upload + URL input */}
              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={() => photoInputRef.current?.click()}
                  disabled={attachedMedia.length >= 10}
                  className="flex items-center justify-center gap-1.5 rounded-lg border border-dashed border-emerald-400 bg-emerald-50/50 px-3.5 py-2 text-xs font-bold text-emerald-600 hover:bg-emerald-100 dark:border-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 transition-colors disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
                >
                  <Upload className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-300" />
                  <span>내 기기에서 사진 파일 선택 (여러 장 가능)</span>
                </button>
                <div className="flex-1 flex gap-2">
                  <input
                    type="url"
                    value={customPhotoUrl}
                    onChange={(e) => setCustomPhotoUrl(e.target.value)}
                    placeholder="이미지 URL 직접 입력..."
                    disabled={attachedMedia.length >= 10}
                    className="flex-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-white focus:outline-none focus:border-emerald-500 disabled:opacity-50"
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomPhoto}
                    disabled={!customPhotoUrl.trim() || attachedMedia.length >= 10}
                    className="rounded-lg bg-emerald-600 disabled:opacity-50 px-3 py-1.5 text-xs font-bold text-white hover:bg-emerald-700 transition-colors cursor-pointer"
                  >
                    추가
                  </button>
                </div>
              </div>

              {/* Quick Sample Photo Recommendations */}
              <div className="mt-3 pt-2.5 border-t border-slate-200 dark:border-slate-700/60">
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1.5">
                  📸 추천 샘플 사진 바로 추가:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🌅 제주 일몰
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🌊 푸른 파도
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1477959858617-67f30bc75b82?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🏙️ 시티 야경
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    ☕️ 카페 감성
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🌸 봄 벚꽃길
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🏔️ 설산 풍경
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🐱 귀여운 고양이
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🍣 일식 요리
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    ⛺️ 감성 캠핑
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1561214115-f2f134cc4912?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🎨 전시회 관람
                  </button>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-2">
                * 기기에서 직접 촬영 또는 저장된 사진 파일 및 동영상을 총 10개까지 올릴 수 있습니다.
              </p>
            </div>
          )}

          {/* Poll Creator */}
          {showPollCreator && (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-800/60 animate-in fade-in duration-100">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <BarChart2 className="h-4 w-4 text-blue-600" />
                  투표 만들기
                </span>
                <button
                  type="button"
                  onClick={() => setShowPollCreator(false)}
                  className="text-xs text-rose-500 hover:underline"
                >
                  투표 삭제
                </button>
              </div>

              <input
                type="text"
                value={pollQuestion}
                onChange={(e) => setPollQuestion(e.target.value)}
                placeholder="투표 질문을 입력하세요 (예: 다음 주 모임 장소는?)"
                className="w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm text-slate-900 mb-3 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              />

              <div className="flex flex-col gap-2">
                {pollOptions.map((opt, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <input
                      type="text"
                      value={opt}
                      onChange={(e) => handlePollOptionChange(index, e.target.value)}
                      placeholder={`선택지 ${index + 1}`}
                      className="flex-1 rounded-lg border border-slate-200 bg-white px-3.5 py-1.5 text-sm text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                    />
                    {pollOptions.length > 2 && (
                      <button
                        type="button"
                        onClick={() => handleRemovePollOption(index)}
                        className="text-slate-400 hover:text-rose-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>

              {pollOptions.length < 4 && (
                <button
                  type="button"
                  onClick={handleAddPollOption}
                  className="mt-2.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                >
                  <Plus className="h-3.5 w-3.5" />
                  선택지 추가 (최대 4개)
                </button>
              )}
            </div>
          )}

          {/* Feeling / Mood Picker Drawer with 3 Major Categories & Subcategories */}
          {showFeelings && (
            <div
              id="post-feeling-drawer"
              className="rounded-xl border border-slate-200 bg-slate-50/90 dark:border-slate-800 dark:bg-slate-900/80 p-3.5 space-y-3 animate-in fade-in slide-in-from-top-2 duration-150"
            >
              {/* Drawer Header */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-100">
                  <Smile className="h-4 w-4 text-amber-500" />
                  <span>기분 상태 선택</span>
                  {feeling && (
                    <span className="text-[11px] font-normal text-slate-500 dark:text-slate-400 ml-1">
                      (선택: <span className="font-semibold text-blue-600 dark:text-blue-400">{feeling}</span>)
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {feeling && (
                    <button
                      type="button"
                      onClick={() => setFeeling(undefined)}
                      className="text-[11px] text-rose-500 hover:text-rose-600 dark:text-rose-400 font-medium hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <X className="h-3 w-3" />
                      기분 초기화
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setShowFeelings(false)}
                    className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    닫기
                  </button>
                </div>
              </div>

              {/* 3 Major Category Tabs */}
              <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-800">
                {MOOD_CATEGORIES.map((cat) => {
                  const isTabActive = selectedMoodCategory === cat.id;
                  const hasSelectionInThisCat = cat.items.includes(feeling || '');
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedMoodCategory(cat.id)}
                      className={`relative py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer select-none ${
                        isTabActive
                          ? cat.colorClass.tabActive
                          : `${cat.colorClass.tabInactive} bg-transparent`
                      }`}
                    >
                      <span className="text-sm">{cat.emoji}</span>
                      <span>{cat.name}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full font-medium ${
                          isTabActive
                            ? 'bg-white/20 text-white'
                            : 'bg-slate-300/80 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {cat.items.length}
                      </span>
                      {hasSelectionInThisCat && !isTabActive && (
                        <span className="absolute -top-1 -right-1 flex h-2 w-2">
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Subcategories (Small Category chips) for the active Major Category */}
              {(() => {
                const currentCat =
                  MOOD_CATEGORIES.find((c) => c.id === selectedMoodCategory) || MOOD_CATEGORIES[0];
                return (
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 px-0.5">
                      <span>{currentCat.description}</span>
                      <span className="font-medium text-slate-400">
                        {currentCat.name} 감정 ({currentCat.items.length}개)
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {currentCat.items.map((item) => {
                        const isSelected = feeling === item;
                        return (
                          <button
                            key={item}
                            type="button"
                            onClick={() => {
                              setFeeling(isSelected ? undefined : item);
                            }}
                            className={`rounded-full px-3 py-1.5 text-xs transition-all flex items-center gap-1 cursor-pointer select-none ${
                              isSelected
                                ? currentCat.colorClass.chipActive
                                : currentCat.colorClass.chipInactive
                            }`}
                          >
                            {isSelected && <Check className="h-3 w-3 shrink-0" />}
                            <span>{item}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Location Input Drawer & Controls */}
          {showLocationInput && (
            <div
              id="post-location-drawer"
              className="rounded-xl border border-blue-200/80 bg-blue-50/50 p-3.5 dark:border-blue-900/60 dark:bg-blue-950/30 animate-in fade-in slide-in-from-top-2 duration-150 space-y-2.5"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white">
                  <MapPin className="h-4 w-4 text-blue-600" />
                  <span>게시물 위치 정보</span>
                  {isDetectingLocation && (
                    <span className="flex items-center gap-1 text-[11px] font-normal text-blue-600 dark:text-blue-400 ml-1">
                      <Loader2 className="h-3 w-3 animate-spin" />
                      <span>현재 위치 감지 중...</span>
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={handleRefreshLocation}
                  disabled={isDetectingLocation}
                  className="flex items-center gap-1 text-[11px] font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400 hover:underline disabled:opacity-50 cursor-pointer"
                  title="현재 GPS 및 거주 지역으로 위치 다시 감지"
                >
                  <RotateCw className={`h-3 w-3 ${isDetectingLocation ? 'animate-spin' : ''}`} />
                  <span>위치 다시 감지</span>
                </button>
              </div>

              {/* 주소 직접 입력란 */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => {
                      setLocation(e.target.value);
                      setLocationSource('manual');
                    }}
                    placeholder="위치 직접 입력 (예: 서울 성수동, 강남역 카페, 부산 해운대)"
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                  />
                  {location && (
                    <button
                      type="button"
                      onClick={() => {
                        setLocation('');
                        setLocationSource(null);
                      }}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
                      title="지우기"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setShowLocationInput(false)}
                  className="rounded-lg bg-blue-600 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-blue-700 transition-colors shrink-0 cursor-pointer"
                >
                  완료
                </button>
              </div>

              {/* 주소입력란 아래: 위치 자동 추가 체크박스 */}
              <div className="flex items-center justify-between pt-0.5">
                <label
                  className="inline-flex items-center gap-1.5 text-[11px] text-slate-600 dark:text-slate-400 cursor-pointer select-none"
                  title="게시물 작성 창을 열 때마다 현재 위치를 자동으로 추가합니다"
                >
                  <input
                    type="checkbox"
                    checked={isAutoLocationEnabled}
                    onChange={(e) => handleToggleAutoLocation(e.target.checked)}
                    className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-3.5 w-3.5"
                  />
                  <span className="font-medium">위치 자동 추가</span>
                </label>
              </div>
            </div>
          )}

          {/* Schedule Picker Drawer / Panel */}
          {(showSchedulePicker || isScheduled) && (
            <div
              id="post-schedule-settings-panel"
              className="rounded-xl border border-indigo-200 bg-indigo-50/60 p-4 dark:border-indigo-900/60 dark:bg-indigo-950/40 animate-in fade-in slide-in-from-top-2 duration-150"
            >
              <div className="flex items-center justify-between pb-2 mb-3 border-b border-indigo-200/60 dark:border-indigo-800/60">
                <div className="flex items-center gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-indigo-600 text-white">
                    <Clock className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span>게시물 예약 전송</span>
                      <span className="rounded-full bg-indigo-200/80 px-1.5 py-0.2 text-[10px] font-bold text-indigo-800 dark:bg-indigo-900 dark:text-indigo-300">
                        {isScheduled ? '예약 ON' : '설정 중'}
                      </span>
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      설정한 날짜와 시간에 게시물이 자동으로 피드에 게시됩니다
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {isScheduled ? (
                    <button
                      type="button"
                      id="disable-schedule-btn"
                      onClick={() => {
                        setIsScheduled(false);
                        setShowSchedulePicker(false);
                      }}
                      className="rounded-lg px-2.5 py-1 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                    >
                      예약 끄기
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setIsScheduled(true)}
                      className="rounded-lg bg-indigo-600 px-2.5 py-1 text-xs font-bold text-white hover:bg-indigo-700 transition-colors cursor-pointer"
                    >
                      예약 켜기
                    </button>
                  )}
                </div>
              </div>

              {/* Quick Presets */}
              <div className="mb-3">
                <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300 block mb-1.5">
                  ⚡️ 빠른 시간 선택
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleSetPresetMinutes(30)}
                    className="rounded-lg border border-indigo-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    +30분 후
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetPresetMinutes(60)}
                    className="rounded-lg border border-indigo-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    +1시간 후
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetPresetMinutes(180)}
                    className="rounded-lg border border-indigo-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    +3시간 후
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetPresetTomorrow(9, 0)}
                    className="rounded-lg border border-indigo-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    내일 오전 9:00
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetPresetTomorrow(18, 0)}
                    className="rounded-lg border border-indigo-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    내일 오후 6:00
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSetPresetDaysAhead(2, 9, 0)}
                    className="rounded-lg border border-indigo-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    모레 오전 9:00
                  </button>
                </div>
              </div>

              {/* Date & Time Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-3">
                <div>
                  <label
                    htmlFor="schedule-date-input"
                    className="block text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1 flex items-center gap-1"
                  >
                    <Calendar className="h-3 w-3 text-indigo-500" />
                    <span>예약 날짜</span>
                  </label>
                  <input
                    type="date"
                    id="schedule-date-input"
                    min={todayStr}
                    value={scheduleDate}
                    onChange={(e) => {
                      setScheduleDate(e.target.value);
                      setIsScheduled(true);
                    }}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label
                    htmlFor="schedule-time-input"
                    className="block text-[11px] font-semibold text-slate-600 dark:text-slate-300 mb-1 flex items-center gap-1"
                  >
                    <Clock className="h-3 w-3 text-indigo-500" />
                    <span>예약 시간</span>
                  </label>
                  <input
                    type="time"
                    id="schedule-time-input"
                    value={scheduleTime}
                    onChange={(e) => {
                      setScheduleTime(e.target.value);
                      setIsScheduled(true);
                    }}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              {/* Scheduling Status Banner */}
              {isScheduled && (
                <div>
                  {isScheduleInFuture && targetScheduledISO ? (
                    <div className="flex items-center gap-2 rounded-lg bg-indigo-100/80 px-3 py-2 text-xs text-indigo-900 dark:bg-indigo-900/50 dark:text-indigo-200">
                      <Sparkles className="h-4 w-4 text-indigo-600 dark:text-indigo-400 flex-shrink-0" />
                      <div className="flex-1">
                        <span className="font-bold">발행 예정: </span>
                        <span>{formatScheduledDateTime(targetScheduledISO)}</span>
                        <span className="ml-1.5 text-[11px] text-indigo-700 dark:text-indigo-300 font-semibold">
                          ({formatScheduledCountdown(targetScheduledISO)} 후)
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 rounded-lg bg-rose-50 px-3 py-2 text-xs text-rose-700 dark:bg-rose-950/50 dark:text-rose-300 border border-rose-200 dark:border-rose-900/50">
                      <AlertCircle className="h-4 w-4 text-rose-500 flex-shrink-0" />
                      <span>현재 시간보다 미래의 시간을 선택해주세요.</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Dedicated Regional Scope Selection (게시물 공개 지역 범위 선택 버튼) */}
          <div
            id="regional-scope-section"
            className="rounded-2xl border border-slate-200/90 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/50 p-3.5 space-y-2.5 transition-all"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="text-sm">📍</span>
                <span className="text-xs font-bold text-slate-900 dark:text-white">
                  게시물 공개 지역 선택
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:inline">
                  (공개 범위를 선택하세요)
                </span>
              </div>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${currentScopeConfig.badgeClass}`}>
                {currentScopeConfig.emoji} {currentScopeConfig.label} 선택됨
              </span>
            </div>

            {/* 4 Separate Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {REGIONAL_SCOPES.map((scope) => {
                const isSelected = regionalScope === scope.id;
                return (
                  <button
                    key={scope.id}
                    type="button"
                    id={`regional-scope-btn-${scope.id}`}
                    onClick={() => setRegionalScope(scope.id)}
                    className={`group relative flex flex-col items-start p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? `${scope.activeBtnClass} shadow-xs`
                        : 'bg-white dark:bg-slate-800/80 border-slate-200/90 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-1">
                      <span className="text-base">{scope.emoji}</span>
                      {isSelected ? (
                        <Check className="h-3.5 w-3.5 shrink-0" />
                      ) : (
                        <span className="h-3.5 w-3.5 rounded-full border border-slate-300 dark:border-slate-600" />
                      )}
                    </div>
                    <span className={`text-xs font-bold ${isSelected ? 'font-extrabold' : 'text-slate-800 dark:text-slate-200'}`}>
                      {scope.label}
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                      {scope.description}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Selected scope detail help text */}
            <div className="flex items-start gap-1.5 px-1 text-[11px] text-slate-500 dark:text-slate-400">
              <span className="font-semibold text-slate-700 dark:text-slate-300 shrink-0">
                💡 {currentScopeConfig.label}:
              </span>
              <span>{currentScopeConfig.detail}</span>
            </div>
          </div>

          {/* Background Music (BGM) Drawer */}
          {showBgmDrawer && (() => {
            const allBgms: StoryBgm[] = [...customBgms, ...PRESET_STORY_BGMS];
            const filteredBgms = allBgms.filter((bgm) => {
              if (activeBgmCategory === 'custom') {
                if (!bgm.isCustom) return false;
              } else if (activeBgmCategory === 'lofi') {
                if (!bgm.genre.toLowerCase().includes('lo-fi') && !bgm.id.includes('lofi')) return false;
              } else if (activeBgmCategory === 'acoustic') {
                if (!bgm.genre.toLowerCase().includes('acoustic') && !bgm.id.includes('acoustic')) return false;
              } else if (activeBgmCategory === 'piano') {
                if (!bgm.genre.toLowerCase().includes('piano') && !bgm.id.includes('piano')) return false;
              } else if (activeBgmCategory === 'synth') {
                if (!bgm.genre.toLowerCase().includes('synth') && !bgm.genre.toLowerCase().includes('citypop') && !bgm.id.includes('synth')) return false;
              } else if (activeBgmCategory === 'tropical') {
                if (!bgm.genre.toLowerCase().includes('tropical') && !bgm.id.includes('tropical')) return false;
              } else if (activeBgmCategory === 'ambient') {
                if (!bgm.genre.toLowerCase().includes('ambient') && !bgm.id.includes('ambient')) return false;
              } else if (activeBgmCategory === 'jazz') {
                if (!bgm.genre.toLowerCase().includes('jazz') && !bgm.id.includes('jazz')) return false;
              } else if (activeBgmCategory === 'indie') {
                if (!bgm.genre.toLowerCase().includes('folk') && !bgm.genre.toLowerCase().includes('indie') && !bgm.id.includes('indie')) return false;
              } else if (activeBgmCategory === 'upbeat') {
                if (!bgm.genre.toLowerCase().includes('upbeat') && !bgm.genre.toLowerCase().includes('pop') && !bgm.id.includes('upbeat')) return false;
              }
              if (bgmSearchQuery.trim()) {
                const q = bgmSearchQuery.trim().toLowerCase();
                return (
                  bgm.title.toLowerCase().includes(q) ||
                  bgm.artist.toLowerCase().includes(q) ||
                  bgm.genre.toLowerCase().includes(q) ||
                  (bgm.license && bgm.license.toLowerCase().includes(q))
                );
              }
              return true;
            });

            return (
              <div
                id="post-bgm-drawer"
                className="rounded-xl border border-amber-200 bg-amber-50/70 p-3.5 dark:border-amber-900/60 dark:bg-amber-950/30 animate-in fade-in slide-in-from-top-2 duration-150 space-y-3"
              >
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white">
                    <Music className="h-4 w-4 text-amber-500" />
                    <span>게시물 배경음악 (BGM)</span>
                    {selectedBgm && (
                      <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-500" />
                        <span>선택됨: {selectedBgm.title}</span>
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedBgm && (
                      <button
                        type="button"
                        onClick={() => handleSelectBgm(null)}
                        className="text-[11px] font-medium text-slate-500 hover:text-slate-700 dark:text-slate-400 cursor-pointer"
                      >
                        음악 제거
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setShowBgmDrawer(false)}
                      className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Copyright-Free Trust Banner */}
                <div className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 dark:from-emerald-950/50 dark:via-teal-950/40 dark:to-emerald-950/50 border border-emerald-200/80 dark:border-emerald-800/60 flex items-start gap-2.5">
                  <div className="p-1 rounded-lg bg-emerald-600 text-white shrink-0 mt-0.5 shadow-xs">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                      100% 저작권 무료 (CC0 / Royalty-Free) 안심 음원
                    </p>
                    <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80 leading-relaxed mt-0.5">
                      상업적·개인용 제한 없이 피드 게시물에 자유롭게 사용 가능합니다. 소장 중인 무료 음악 파일(MP3, WAV 등)도 직접 추가해보세요!
                    </p>
                  </div>
                </div>

                {/* Action Bar: Upload Custom Audio & External Link Toggle */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => audioFileInputRef.current?.click()}
                    className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold shadow-sm shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>내 저작권 무료 음원 올리기 (MP3/WAV)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowCustomAudioUrlInput((prev) => !prev)}
                    className="px-2.5 py-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1 transition-all cursor-pointer"
                    title="웹 음원 URL 주소 직접 입력"
                  >
                    <span>웹 링크</span>
                    {showCustomAudioUrlInput ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  </button>
                </div>

                {/* Collapsible External Audio URL Input */}
                {showCustomAudioUrlInput && (
                  <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 animate-in fade-in duration-150 space-y-2">
                    <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                      🔗 외부 저작권 무료 음원 주소(URL) 직접 등록
                    </span>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={customAudioTitleInput}
                        onChange={(e) => setCustomAudioTitleInput(e.target.value)}
                        placeholder="음원 제목 (예: 감성 카페 피아노)"
                        className="sm:w-1/3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                      />
                      <input
                        type="url"
                        value={customAudioUrlInput}
                        onChange={(e) => setCustomAudioUrlInput(e.target.value)}
                        placeholder="https://... (.mp3, .wav, .m4a 등 오디오 주소)"
                        className="flex-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                      />
                      <button
                        type="button"
                        disabled={!customAudioUrlInput.trim()}
                        onClick={() => {
                          if (!customAudioUrlInput.trim()) return;
                          handleAddCustomAudioUrl(customAudioUrlInput.trim(), customAudioTitleInput.trim() || undefined);
                          setCustomAudioUrlInput('');
                          setCustomAudioTitleInput('');
                          setShowCustomAudioUrlInput(false);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold transition-all cursor-pointer shrink-0"
                      >
                        등록 및 적용
                      </button>
                    </div>
                  </div>
                )}

                {/* Search Input Bar */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={bgmSearchQuery}
                    onChange={(e) => setBgmSearchQuery(e.target.value)}
                    placeholder="음악 제목, 아티스트, 장르 검색..."
                    className="w-full pl-8 pr-7 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-amber-500 transition-colors"
                  />
                  {bgmSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setBgmSearchQuery('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Category Filter Pills */}
                <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar">
                  {COPYRIGHT_FREE_CATEGORIES.map((cat) => {
                    const isActive = activeBgmCategory === cat.id;
                    const count = cat.id === 'custom' ? customBgms.length : undefined;
                    if (cat.id === 'custom' && customBgms.length === 0) return null;

                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setActiveBgmCategory(cat.id)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 ${
                          isActive
                            ? 'bg-amber-600 text-white shadow-xs'
                            : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-750 border border-slate-200/80 dark:border-slate-700'
                        }`}
                      >
                        <span>{cat.label}</span>
                        {count !== undefined && (
                          <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold ${isActive ? 'bg-amber-700 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                            {count}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Track Cards Grid */}
                {filteredBgms.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
                    {filteredBgms.map((bgm) => {
                      const isSelected = selectedBgm?.id === bgm.id;
                      const isPreviewing = previewingBgmId === bgm.id;

                      return (
                        <div
                          key={bgm.id}
                          onClick={() => handleSelectBgm(bgm)}
                          className={`relative flex items-center justify-between p-2 rounded-xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'border-amber-500 bg-amber-100/70 dark:bg-amber-950/60 ring-1 ring-amber-500/60 shadow-xs'
                              : 'border-slate-200/90 bg-white hover:border-amber-300 dark:border-slate-750 dark:bg-slate-850 dark:hover:border-slate-600'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0 pr-2">
                            <div className="relative h-8 w-8 rounded-lg overflow-hidden bg-slate-900 shrink-0 shadow-xs">
                              {bgm.coverUrl ? (
                                <img
                                  src={bgm.coverUrl}
                                  alt={bgm.title}
                                  className="h-full w-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                <Disc className="h-full w-full p-1.5 text-amber-400" />
                              )}
                              {isSelected && (
                                <div className="absolute inset-0 bg-amber-600/50 flex items-center justify-center text-white backdrop-blur-[0.5px]">
                                  <Check className="h-3.5 w-3.5 stroke-[3]" />
                                </div>
                              )}
                            </div>

                            <div className="min-w-0 text-left">
                              <p className={`text-xs font-bold truncate leading-tight ${isSelected ? 'text-amber-900 dark:text-amber-200' : 'text-slate-800 dark:text-slate-200'}`}>
                                {bgm.title}
                              </p>
                              <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                                {bgm.artist} • <span className="text-amber-600 dark:text-amber-400 font-medium">{bgm.genre}</span>
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={(e) => handleTogglePreviewAudio(bgm, e)}
                              title={isPreviewing ? '미리듣기 일시정지' : '미리듣기 재생'}
                              className={`h-7 w-7 rounded-full flex items-center justify-center shrink-0 transition-all cursor-pointer ${
                                isPreviewing
                                  ? 'bg-amber-500 text-white shadow-sm scale-105'
                                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300'
                              }`}
                            >
                              {isPreviewing ? (
                                <Pause className="w-3 h-3 fill-current" />
                              ) : (
                                <Play className="w-3 h-3 fill-current ml-0.5" />
                              )}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-6 text-xs text-slate-500 dark:text-slate-400">
                    검색된 음원이 없습니다.
                  </div>
                )}
              </div>
            );
          })()}

          {/* Hidden Audio File Input */}
          <input
            ref={audioFileInputRef}
            type="file"
            accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleProcessAudioFile(file);
            }}
            className="hidden"
          />

          {/* Action Toolbar */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center flex-wrap gap-1">
              <button
                type="button"
                id="post-attach-photo-btn"
                title="사진 첨부"
                onClick={() => {
                  setShowPhotoPicker((prev) => !prev);
                  setShowVideoPicker(false);
                }}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-emerald-50 hover:text-emerald-600 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-emerald-400 transition-colors cursor-pointer ${
                  showPhotoPicker || attachedMedia.some((m) => m.type === 'image') ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 font-bold' : ''
                }`}
              >
                <ImageIcon className="h-4 w-4 text-emerald-500" />
                <span className="hidden sm:inline">사진</span>
                {attachedMedia.some((m) => m.type === 'image') && (
                  <span className="ml-0.5 rounded-full bg-emerald-600 px-1.5 py-0.2 text-[10px] text-white">
                    {attachedMedia.filter((m) => m.type === 'image').length}
                  </span>
                )}
              </button>

              <button
                type="button"
                id="post-attach-video-btn"
                title="동영상 첨부"
                onClick={() => {
                  const willOpen = !showVideoPicker;
                  setShowVideoPicker(willOpen);
                  setShowPhotoPicker(false);
                  if (willOpen) {
                    videoInputRef.current?.click();
                  }
                }}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-blue-50 hover:text-blue-600 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-blue-400 transition-colors cursor-pointer ${
                  showVideoPicker || attachedMedia.some((m) => m.type === 'video') ? 'bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400 font-bold' : ''
                }`}
              >
                <Video className="h-4 w-4 text-blue-500" />
                <span className="hidden sm:inline">동영상</span>
                {attachedMedia.some((m) => m.type === 'video') && (
                  <span className="ml-0.5 rounded-full bg-blue-600 px-1.5 py-0.2 text-[10px] text-white">
                    {attachedMedia.filter((m) => m.type === 'video').length}
                  </span>
                )}
              </button>

              <button
                type="button"
                id="post-attach-schedule-btn"
                title="게시물 예약 전송"
                onClick={() => {
                  setShowSchedulePicker((prev) => !prev);
                  if (!isScheduled) setIsScheduled(true);
                }}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-indigo-400 transition-colors cursor-pointer ${
                  showSchedulePicker || isScheduled
                    ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400 font-bold ring-1 ring-indigo-300 dark:ring-indigo-700'
                    : ''
                }`}
              >
                <Clock className="h-4 w-4 text-indigo-500" />
                <span className="hidden sm:inline">예약</span>
                {isScheduled && (
                  <span className="ml-0.5 rounded-full bg-indigo-600 px-1.5 py-0.2 text-[10px] text-white">
                    ON
                  </span>
                )}
              </button>

              <button
                type="button"
                id="post-attach-poll-btn"
                title="투표 추가"
                onClick={() => setShowPollCreator((prev) => !prev)}
                className={`p-2 rounded-lg text-slate-500 hover:bg-blue-50 hover:text-blue-600 dark:hover:bg-slate-800 dark:hover:text-blue-400 transition-colors ${
                  showPollCreator ? 'bg-blue-50 text-blue-600 dark:bg-slate-800' : ''
                }`}
              >
                <BarChart2 className="h-4 w-4 text-purple-500" />
              </button>

              <button
                type="button"
                id="post-attach-feeling-btn"
                title={feeling ? `선택된 기분: ${feeling} (클릭하여 수정)` : '기분 상태 선택'}
                onClick={() => setShowFeelings((prev) => !prev)}
                className={`relative p-2 rounded-lg text-slate-500 hover:bg-amber-50 hover:text-amber-600 dark:hover:bg-slate-800 dark:hover:text-amber-400 transition-colors ${
                  feeling || showFeelings
                    ? 'bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-300'
                    : ''
                }`}
              >
                <Smile className="h-4 w-4 text-amber-500" />
                {feeling && (
                  <span className="absolute -top-1 -right-1 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                  </span>
                )}
              </button>

              <button
                type="button"
                id="post-attach-location-btn"
                title={location ? `설정된 위치: ${location} (클릭하여 수정)` : '위치 추가'}
                onClick={() => setShowLocationInput((prev) => !prev)}
                className={`relative p-2 rounded-lg text-slate-500 hover:bg-blue-50 hover:text-blue-600 dark:hover:bg-slate-800 dark:hover:text-blue-400 transition-colors ${
                  location || showLocationInput ? 'bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400' : ''
                }`}
              >
                <MapPin className="h-4 w-4 text-red-500" />
                {location && (
                  <span className="absolute -top-1 -right-1 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-600"></span>
                  </span>
                )}
              </button>

              <button
                type="button"
                id="post-attach-music-btn"
                title={selectedBgm ? `선택된 음악: ${selectedBgm.title} (클릭하여 수정)` : '저작권 무료 배경음악 (BGM) 추가'}
                onClick={() => {
                  setShowBgmDrawer((prev) => !prev);
                  setShowPhotoPicker(false);
                  setShowVideoPicker(false);
                  setShowPollCreator(false);
                  setShowFeelings(false);
                  setShowLocationInput(false);
                }}
                className={`relative flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-600 hover:bg-amber-50 hover:text-amber-600 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-amber-400 transition-colors cursor-pointer ${
                  selectedBgm || showBgmDrawer
                    ? 'bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400 font-bold ring-1 ring-amber-300 dark:ring-amber-700'
                    : ''
                }`}
              >
                <Music className="h-4 w-4 text-amber-500" />
                <span className="hidden sm:inline">음악</span>
                {selectedBgm && (
                  <span className="ml-0.5 rounded-full bg-amber-600 px-1.5 py-0.2 text-[10px] text-white">
                    ON
                  </span>
                )}
              </button>
            </div>

            {/* Submit / Schedule Post Button */}
            <button
              type="submit"
              id="submit-post-btn"
              disabled={isSubmitDisabled}
              className={`flex items-center gap-1.5 rounded-lg px-5 py-2.5 text-sm font-bold text-white shadow-md active:scale-95 disabled:opacity-40 transition-all cursor-pointer ${
                isScheduled
                  ? 'bg-indigo-600 shadow-indigo-600/25 hover:bg-indigo-700'
                  : 'bg-blue-600 shadow-blue-600/25 hover:bg-blue-700'
              }`}
            >
              {isScheduled ? (
                <>
                  <Clock className="h-4 w-4" />
                  <span>예약하기</span>
                </>
              ) : (
                <span>게시하기</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>

    {/* Scheduled Posts List Modal */}
    <ScheduledPostsModal
      isOpen={showScheduledListModal}
      onClose={() => setShowScheduledListModal(false)}
      onOpenCreatePost={() => {
        setShowSchedulePicker(true);
        setIsScheduled(true);
      }}
    />
  </>
  );
};

