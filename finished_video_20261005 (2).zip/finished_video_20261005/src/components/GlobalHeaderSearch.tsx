import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useSocial } from '../context/SocialContext';
import { TRENDING_TOPICS } from '../data/mockData';
import { formatNumber } from '../utils/formatters';
import {
  Search,
  X,
  User as UserIcon,
  Hash,
  Flame,
  FileText,
  Clock,
  ArrowRight,
  Sparkles,
  TrendingUp,
  CheckCircle2,
  UserPlus,
  Check,
  CornerDownLeft,
  SlidersHorizontal,
  Compass
} from 'lucide-react';
import { User, Post, TrendingTopic } from '../types';

type SearchCategory = 'all' | 'users' | 'hashtags' | 'trending' | 'posts';

interface GlobalHeaderSearchProps {
  className?: string;
  isMobileModal?: boolean;
  onCloseMobile?: () => void;
}

export const GlobalHeaderSearch: React.FC<GlobalHeaderSearchProps> = ({
  className = '',
  isMobileModal = false,
  onCloseMobile
}) => {
  const {
    users,
    posts,
    currentUser,
    toggleFollow,
    searchQuery,
    setSearchQuery,
    setActiveTab,
    setActiveTag,
    setViewingUserId,
    isAuthenticated,
    openAuthModal,
    isDarkMode
  } = useSocial();

  const [localQuery, setLocalQuery] = useState(searchQuery || '');
  const [isOpen, setIsOpen] = useState(isMobileModal);
  const [activeCategory, setActiveCategory] = useState<SearchCategory>('all');
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('pulse_recent_searches');
      return saved ? JSON.parse(saved) : ['AI개발', '이지수', '#오운완', '제주도여행'];
    } catch {
      return ['AI개발', '이지수', '#오운완', '제주도여행'];
    }
  });

  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync external search query if changed
  useEffect(() => {
    if (searchQuery !== localQuery && !isOpen) {
      setLocalQuery(searchQuery);
    }
  }, [searchQuery]);

  // Save recent searches to localStorage
  const saveRecentSearch = (term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;
    setRecentSearches((prev) => {
      const next = [trimmed, ...prev.filter((t) => t.toLowerCase() !== trimmed.toLowerCase())].slice(0, 8);
      try {
        localStorage.setItem('pulse_recent_searches', JSON.stringify(next));
      } catch (err) {
        console.error(err);
      }
      return next;
    });
  };

  const removeRecentSearch = (term: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches((prev) => {
      const next = prev.filter((t) => t !== term);
      try {
        localStorage.setItem('pulse_recent_searches', JSON.stringify(next));
      } catch (err) {
        console.error(err);
      }
      return next;
    });
  };

  const clearAllRecent = (e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches([]);
    try {
      localStorage.removeItem('pulse_recent_searches');
    } catch (err) {
      console.error(err);
    }
  };

  // Global keyboard shortcut (Cmd+K / Ctrl+K or /)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      } else if (e.key === '/' && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      } else if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
        if (onCloseMobile) onCloseMobile();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onCloseMobile]);

  // Click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        if (!isMobileModal) {
          setIsOpen(false);
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMobileModal]);

  // Extract all hashtags across posts and mock topics
  const allHashtags = useMemo(() => {
    const tagMap = new Map<string, number>();
    posts.forEach((p) => {
      p.tags?.forEach((tag) => {
        const cleanTag = tag.replace(/^#/, '');
        tagMap.set(cleanTag, (tagMap.get(cleanTag) || 0) + 1);
      });
    });
    TRENDING_TOPICS.forEach((t) => {
      const cleanTag = t.tag.replace(/^#/, '');
      if (!tagMap.has(cleanTag)) {
        tagMap.set(cleanTag, Math.floor(t.postCount / 1000) || 5);
      }
    });
    return Array.from(tagMap.entries()).map(([tag, count]) => ({
      tag,
      count
    }));
  }, [posts]);

  // Filtered search results
  const searchResults = useMemo(() => {
    const q = localQuery.trim().toLowerCase();
    const cleanQ = q.replace(/^#/, '');

    if (!q) {
      return {
        users: [],
        hashtags: [],
        trending: TRENDING_TOPICS.slice(0, 5),
        posts: []
      };
    }

    // 1. User search
    const matchedUsers = users.filter((u) => {
      const nameMatch = u.name.toLowerCase().includes(q);
      const handleMatch = u.handle.toLowerCase().includes(cleanQ);
      const bioMatch = u.bio?.toLowerCase().includes(q);
      const roleMatch = u.role?.toLowerCase().includes(q);
      const interestMatch = u.interests?.some((i) => i.toLowerCase().includes(q));
      return nameMatch || handleMatch || bioMatch || roleMatch || interestMatch;
    });

    // 2. Hashtags search
    const matchedHashtags = allHashtags.filter(({ tag }) =>
      tag.toLowerCase().includes(cleanQ)
    );

    // 3. Trending topics search
    const matchedTrending = TRENDING_TOPICS.filter((t) =>
      t.tag.toLowerCase().includes(cleanQ) ||
      t.category.toLowerCase().includes(q)
    );

    // 4. Posts search
    const matchedPosts = posts.filter((p) => {
      const contentMatch = p.content.toLowerCase().includes(q);
      const authorMatch = p.authorName.toLowerCase().includes(q) || p.authorHandle.toLowerCase().includes(cleanQ);
      const tagMatch = p.tags?.some((t) => t.toLowerCase().includes(cleanQ));
      return contentMatch || authorMatch || tagMatch;
    });

    return {
      users: matchedUsers,
      hashtags: matchedHashtags,
      trending: matchedTrending,
      posts: matchedPosts
    };
  }, [localQuery, users, posts, allHashtags]);

  // Navigation handlers
  const handleSelectUser = (user: User) => {
    saveRecentSearch(user.name);
    setViewingUserId(user.id);
    setActiveTab('profile');
    setIsOpen(false);
    if (onCloseMobile) onCloseMobile();
  };

  const handleSelectHashtag = (tag: string) => {
    saveRecentSearch(`#${tag}`);
    setActiveTag(tag);
    setSearchQuery(tag);
    setActiveTab('explore');
    setIsOpen(false);
    if (onCloseMobile) onCloseMobile();
  };

  const handleSelectTrending = (topic: TrendingTopic) => {
    saveRecentSearch(topic.tag);
    setActiveTag(topic.tag);
    setSearchQuery(topic.tag);
    setActiveTab('explore');
    setIsOpen(false);
    if (onCloseMobile) onCloseMobile();
  };

  const handleSelectPost = (post: Post) => {
    saveRecentSearch(localQuery || post.authorName);
    setSearchQuery(post.id);
    setActiveTab('feed');
    setIsOpen(false);
    if (onCloseMobile) onCloseMobile();
  };

  const handleFullSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = localQuery.trim();
    if (!query) return;

    saveRecentSearch(query);
    setSearchQuery(query);
    if (query.startsWith('#')) {
      setActiveTag(query.replace(/^#/, ''));
    }
    setActiveTab('explore');
    setIsOpen(false);
    if (onCloseMobile) onCloseMobile();
  };

  const totalResultsCount =
    searchResults.users.length +
    searchResults.hashtags.length +
    searchResults.trending.length +
    searchResults.posts.length;

  return (
    <div ref={containerRef} className={`relative w-full ${className}`}>
      {/* Search Input Bar */}
      <form onSubmit={handleFullSearchSubmit} className="relative w-full min-w-0">
        <div className="relative flex items-center min-w-0 w-full">
          <Search className="absolute left-3 h-4 w-4 text-slate-400 dark:text-slate-500 pointer-events-none transition-colors" />

          <input
            ref={inputRef}
            id="global-header-search-input"
            type="text"
            value={localQuery}
            onChange={(e) => {
              setLocalQuery(e.target.value);
              setIsOpen(true);
              setSelectedIndex(-1);
            }}
            onFocus={() => setIsOpen(true)}
            placeholder="프로필, #해시태그, 인기 토픽 검색..."
            style={{
              color: isDarkMode ? '#f8fafc' : '#0f172a',
              backgroundColor: isDarkMode ? '#1e293b' : '#f1f5f9'
            }}
            className="w-full h-10 rounded-2xl border border-slate-200/90 dark:border-slate-700/80 py-2 pl-9 pr-9 sm:pr-10 text-sm font-medium text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 caret-indigo-600 dark:caret-indigo-400 shadow-xs transition-all duration-150 focus:border-indigo-500 focus:outline-none focus:ring-3 focus:ring-indigo-500/20 dark:focus:ring-indigo-500/25 min-w-0"
          />

          {/* Right Action Icons */}
          <div className="absolute right-2.5 flex items-center gap-1 shrink-0">
            {localQuery ? (
              <button
                type="button"
                id="clear-global-search-btn"
                onClick={() => {
                  setLocalQuery('');
                  setSearchQuery('');
                  inputRef.current?.focus();
                }}
                className="rounded-full p-1 text-slate-400 hover:bg-slate-200/60 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"
                title="검색어 지우기"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            ) : (
              <div className="hidden md:flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-slate-200/60 dark:bg-slate-800 text-[10px] font-semibold text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700/60">
                <kbd className="font-sans">⌘K</kbd>
              </div>
            )}
          </div>
        </div>
      </form>

      {/* Dropdown Results Overlay */}
      {isOpen && (
        <div
          id="global-search-dropdown"
          className="absolute left-0 right-0 top-full mt-2 max-h-[80vh] w-full min-w-[320px] md:min-w-[420px] overflow-hidden rounded-2xl border border-slate-200/90 bg-white/95 backdrop-blur-xl shadow-2xl ring-1 ring-slate-900/5 dark:border-slate-800 dark:bg-slate-900/95 dark:shadow-slate-950/80 z-50 animate-in fade-in zoom-in-98 duration-150"
        >
          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1 border-b border-slate-100 dark:border-slate-800/80 px-3 py-2 overflow-x-auto scrollbar-none bg-slate-50/50 dark:bg-slate-900/50">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeCategory === 'all'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              전체 {localQuery.trim() && `(${totalResultsCount})`}
            </button>
            <button
              onClick={() => setActiveCategory('users')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeCategory === 'users'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <UserIcon className="w-3 h-3" />
              프로필 {localQuery.trim() && `(${searchResults.users.length})`}
            </button>
            <button
              onClick={() => setActiveCategory('hashtags')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeCategory === 'hashtags'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <Hash className="w-3 h-3" />
              해시태그 {localQuery.trim() && `(${searchResults.hashtags.length})`}
            </button>
            <button
              onClick={() => setActiveCategory('trending')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeCategory === 'trending'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <Flame className="w-3 h-3 text-rose-500" />
              트렌드
            </button>
            <button
              onClick={() => setActiveCategory('posts')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                activeCategory === 'posts'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/60 dark:hover:bg-slate-800'
              }`}
            >
              <FileText className="w-3 h-3" />
              게시물 {localQuery.trim() && `(${searchResults.posts.length})`}
            </button>
          </div>

          <div className="max-h-[60vh] overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/80 p-1">
            {/* 1. Empty Query State: Recent Searches & Suggested Trending */}
            {!localQuery.trim() && (
              <div className="p-3 space-y-4">
                {/* Recent Searches */}
                {recentSearches.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-2 px-1">
                      <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-indigo-500" />
                        최근 검색어
                      </span>
                      <button
                        onClick={clearAllRecent}
                        className="text-[11px] text-slate-400 hover:text-rose-500 transition-colors font-medium"
                      >
                        모두 삭제
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {recentSearches.map((term, i) => (
                        <div
                          key={i}
                          onClick={() => {
                            setLocalQuery(term);
                            setSearchQuery(term);
                            if (term.startsWith('#')) {
                              setActiveTag(term.replace(/^#/, ''));
                            }
                            setActiveTab('explore');
                            setIsOpen(false);
                            if (onCloseMobile) onCloseMobile();
                          }}
                          className="group flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 text-xs font-medium cursor-pointer transition-colors border border-transparent hover:border-indigo-200 dark:hover:border-indigo-800"
                        >
                          <span>{term}</span>
                          <button
                            type="button"
                            onClick={(e) => removeRecentSearch(term, e)}
                            className="text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300 hover:text-rose-500 p-0.5 rounded-full"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Popular Trending Topics Preview */}
                <div>
                  <div className="flex items-center justify-between mb-2 px-1">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                      <TrendingUp className="w-3.5 h-3.5 text-rose-500" />
                      실시간 추천 인기 토픽
                    </span>
                    <button
                      onClick={() => {
                        setActiveTab('explore');
                        setIsOpen(false);
                        if (onCloseMobile) onCloseMobile();
                      }}
                      className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      전체 보기
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
                    {TRENDING_TOPICS.slice(0, 4).map((topic, i) => (
                      <button
                        key={topic.id}
                        onClick={() => handleSelectTrending(topic)}
                        className="flex items-center justify-between p-2 rounded-xl text-left hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors group"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 w-4 text-center">
                            {i + 1}
                          </span>
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate group-hover:text-indigo-600 dark:group-hover:text-indigo-400 flex items-center gap-1">
                              #{topic.tag}
                              {topic.isHot && (
                                <span className="text-[10px] px-1 py-0.2 rounded bg-rose-100 dark:bg-rose-950/60 text-rose-600 font-bold">
                                  HOT
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-400 truncate">
                              {topic.category} · {formatNumber(topic.postCount)}개
                            </div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Popular Suggested Profiles */}
                <div>
                  <div className="flex items-center justify-between mb-2 px-1">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                      <UserIcon className="w-3.5 h-3.5 text-emerald-500" />
                      추천 크리에이터
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {users.slice(0, 2).map((user) => {
                      const isFollowing = currentUser.followingIds?.includes(user.id);
                      return (
                        <div
                          key={user.id}
                          onClick={() => handleSelectUser(user)}
                          className="flex items-center justify-between p-2 rounded-xl bg-slate-50/70 dark:bg-slate-800/40 hover:bg-indigo-50/50 dark:hover:bg-indigo-950/30 cursor-pointer border border-slate-100 dark:border-slate-800 transition-colors"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <img
                              src={user.avatar}
                              alt={user.name}
                              className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                              referrerPolicy="no-referrer"
                            />
                            <div className="min-w-0">
                              <div className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate flex items-center gap-1">
                                {user.name}
                                {user.isVerified && <CheckCircle2 className="w-3 h-3 text-indigo-500 fill-indigo-500 text-white" />}
                              </div>
                              <div className="text-[11px] text-slate-400 truncate">@{user.handle}</div>
                            </div>
                          </div>

                          {user.id !== currentUser.id && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (!isAuthenticated) {
                                  openAuthModal('login');
                                  return;
                                }
                                toggleFollow(user.id, user.name, user.handle);
                              }}
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold shrink-0 transition-all cursor-pointer ${
                                isFollowing
                                  ? 'border border-slate-300 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-300'
                                  : 'bg-blue-600 text-white hover:bg-blue-700 shadow-xs'
                              }`}
                            >
                              {isFollowing ? '팔로잉' : '팔로우'}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* 2. Active Query Results */}
            {localQuery.trim() && (
              <>
                {/* 2-1. Profiles Result Section */}
                {(activeCategory === 'all' || activeCategory === 'users') && searchResults.users.length > 0 && (
                  <div className="p-2 space-y-1">
                    <div className="flex items-center justify-between px-2 py-1">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                        <UserIcon className="w-3 h-3 text-indigo-500" />
                        프로필 ({searchResults.users.length})
                      </span>
                    </div>

                    {searchResults.users.map((user) => {
                      const isFollowing = currentUser.followingIds?.includes(user.id);
                      return (
                        <div
                          key={user.id}
                          onClick={() => handleSelectUser(user)}
                          className="flex items-center justify-between p-2.5 rounded-xl hover:bg-indigo-50/60 dark:hover:bg-indigo-950/40 cursor-pointer group transition-colors"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="relative shrink-0">
                              <img
                                src={user.avatar}
                                alt={user.name}
                                className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                                referrerPolicy="no-referrer"
                              />
                              {user.isVerified && (
                                <span className="absolute -bottom-0.5 -right-0.5 bg-white dark:bg-slate-900 rounded-full p-0.5">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 fill-indigo-600 text-white" />
                                </span>
                              )}
                            </div>

                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 truncate">
                                  {user.name}
                                </span>
                                <span className="text-[11px] text-slate-400 truncate">@{user.handle}</span>
                                {user.role && (
                                  <span className="hidden sm:inline-block text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 font-medium">
                                    {user.role}
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-xs mt-0.5">
                                {user.statusMessage || user.bio}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            {user.id !== currentUser.id && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (!isAuthenticated) {
                                    openAuthModal('login');
                                    return;
                                  }
                                  toggleFollow(user.id, user.name, user.handle);
                                }}
                                className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                                  isFollowing
                                    ? 'border border-slate-300 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-300'
                                    : 'bg-blue-600 text-white hover:bg-blue-700 shadow-xs active:scale-95'
                                }`}
                              >
                                {isFollowing ? '팔로잉' : '팔로우'}
                              </button>
                            )}
                            <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-indigo-500 group-hover:translate-x-0.5 transition-all" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* 2-2. Hashtags Result Section */}
                {(activeCategory === 'all' || activeCategory === 'hashtags') && searchResults.hashtags.length > 0 && (
                  <div className="p-2 space-y-1">
                    <div className="flex items-center justify-between px-2 py-1">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Hash className="w-3 h-3 text-indigo-500" />
                        해시태그 ({searchResults.hashtags.length})
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
                      {searchResults.hashtags.map(({ tag, count }) => (
                        <div
                          key={tag}
                          onClick={() => handleSelectHashtag(tag)}
                          className="flex items-center justify-between p-2 rounded-xl hover:bg-indigo-50/60 dark:hover:bg-indigo-950/40 cursor-pointer group transition-colors"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0">
                              <Hash className="w-4 h-4" />
                            </div>
                            <div className="min-w-0">
                              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 truncate block">
                                #{tag}
                              </span>
                              <span className="text-[10px] text-slate-400">
                                {count}개의 게시물
                              </span>
                            </div>
                          </div>
                          <ArrowRight className="w-3.5 h-3.5 text-slate-300 group-hover:text-indigo-500 group-hover:translate-x-0.5 transition-all shrink-0" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 2-3. Trending Topics Result Section */}
                {(activeCategory === 'all' || activeCategory === 'trending') && searchResults.trending.length > 0 && (
                  <div className="p-2 space-y-1">
                    <div className="flex items-center justify-between px-2 py-1">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Flame className="w-3 h-3 text-rose-500" />
                        실시간 트렌드 ({searchResults.trending.length})
                      </span>
                    </div>

                    {searchResults.trending.map((topic) => (
                      <div
                        key={topic.id}
                        onClick={() => handleSelectTrending(topic)}
                        className="flex items-center justify-between p-2.5 rounded-xl hover:bg-rose-50/50 dark:hover:bg-rose-950/30 cursor-pointer group transition-colors"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/60 flex items-center justify-center text-rose-600 dark:text-rose-400 shrink-0">
                            <TrendingUp className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-rose-600 dark:group-hover:text-rose-400 truncate">
                                #{topic.tag}
                              </span>
                              {topic.isHot && (
                                <span className="text-[9px] px-1 py-0.2 rounded bg-rose-100 dark:bg-rose-900/60 text-rose-600 font-bold">
                                  HOT
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400">
                              {topic.category} · {formatNumber(topic.postCount)}개 언급
                            </span>
                          </div>
                        </div>

                        <span className="text-xs font-semibold text-rose-600 dark:text-rose-400 group-hover:underline text-[11px] shrink-0">
                          탐색
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* 2-4. Posts Result Section */}
                {(activeCategory === 'all' || activeCategory === 'posts') && searchResults.posts.length > 0 && (
                  <div className="p-2 space-y-1">
                    <div className="flex items-center justify-between px-2 py-1">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                        <FileText className="w-3 h-3 text-indigo-500" />
                        게시물 ({searchResults.posts.length})
                      </span>
                    </div>

                    {searchResults.posts.slice(0, 3).map((post) => (
                      <div
                        key={post.id}
                        onClick={() => handleSelectPost(post)}
                        className="flex items-start gap-2.5 p-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer group transition-colors"
                      >
                        <img
                          src={post.authorAvatar}
                          alt={post.authorName}
                          className="w-7 h-7 rounded-full object-cover mt-0.5 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1">
                            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                              {post.authorName}
                            </span>
                            <span className="text-[10px] text-slate-400">@{post.authorHandle}</span>
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mt-0.5">
                            {post.content}
                          </p>
                          {post.tags && post.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-1">
                              {post.tags.slice(0, 3).map((tag, idx) => (
                                <span key={idx} className="text-[10px] text-indigo-500">
                                  #{tag.replace(/^#/, '')}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 2-5. No Results State */}
                {totalResultsCount === 0 && (
                  <div className="py-8 px-4 text-center">
                    <div className="w-12 h-12 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-2 text-slate-400">
                      <Search className="w-6 h-6" />
                    </div>
                    <p className="text-sm font-bold text-slate-800 dark:text-slate-200">
                      "{localQuery}" 검색 결과가 없습니다
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      다른 키워드, 사용자 핸들 또는 #해시태그로 다시 검색해보세요.
                    </p>
                    <div className="flex justify-center gap-2 mt-3">
                      <button
                        onClick={() => handleSelectHashtag('AI개발')}
                        className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-indigo-600 font-medium"
                      >
                        #AI개발
                      </button>
                      <button
                        onClick={() => handleSelectHashtag('오운완')}
                        className="text-xs px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-indigo-600 font-medium"
                      >
                        #오운완
                      </button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Bottom Submit Action Bar */}
          {localQuery.trim() && (
            <div className="p-2 bg-slate-50/80 dark:bg-slate-900/80 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-400 px-2 flex items-center gap-1">
                <CornerDownLeft className="w-3 h-3" />
                <span>Enter를 눌러 탐색 탭에서 전체 검색</span>
              </span>
              <button
                onClick={() => handleFullSearchSubmit()}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs flex items-center gap-1 transition-colors"
              >
                <span>탐색 결과 보기</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
