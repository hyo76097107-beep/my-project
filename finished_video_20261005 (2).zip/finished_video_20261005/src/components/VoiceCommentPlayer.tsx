import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Mic, Volume2 } from 'lucide-react';
import { formatAudioDuration } from '../utils/audioUtils';

interface VoiceCommentPlayerProps {
  audioUrl: string;
  duration?: number;
}

export const VoiceCommentPlayer: React.FC<VoiceCommentPlayerProps> = ({
  audioUrl,
  duration = 5
}) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [actualDuration, setActualDuration] = useState<number>(duration || 5);
  const [playbackRate, setPlaybackRate] = useState<number>(1);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleLoadedMetadata = () => {
      if (audio.duration && !isNaN(audio.duration) && isFinite(audio.duration)) {
        setActualDuration(audio.duration);
      }
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
    };
  }, [audioUrl]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio
        .play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch((err) => {
          console.error('Audio play error:', err);
        });
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const targetTime = parseFloat(e.target.value);
    setCurrentTime(targetTime);
    if (audioRef.current) {
      audioRef.current.currentTime = targetTime;
    }
  };

  const toggleSpeed = () => {
    const speeds = [1, 1.25, 1.5, 2];
    const currentIndex = speeds.indexOf(playbackRate);
    const nextSpeed = speeds[(currentIndex + 1) % speeds.length];
    setPlaybackRate(nextSpeed);
    if (audioRef.current) {
      audioRef.current.playbackRate = nextSpeed;
    }
  };

  const progressPercent = actualDuration > 0 ? (currentTime / actualDuration) * 100 : 0;

  // Generate pseudo-waveform bars based on audioUrl hash
  const barCount = 18;
  const bars = Array.from({ length: barCount }, (_, i) => {
    const hash = (audioUrl.charCodeAt(i % audioUrl.length) || 50) + i * 17;
    return 20 + (hash % 65); // height percentage between 20% and 85%
  });

  return (
    <div
      id="voice-comment-player"
      className="mt-1.5 flex flex-col gap-1.5 rounded-2xl border border-indigo-100 bg-gradient-to-r from-indigo-50/80 to-blue-50/60 p-2.5 dark:border-indigo-900/50 dark:from-indigo-950/40 dark:to-slate-900/60 max-w-sm"
    >
      <audio ref={audioRef} src={audioUrl} preload="metadata" />

      <div className="flex items-center gap-2.5">
        {/* Play/Pause Button */}
        <button
          type="button"
          onClick={togglePlay}
          className="flex h-8 w-8 items-center justify-center rounded-full bg-indigo-600 text-white shadow-xs hover:bg-indigo-700 active:scale-95 transition-all flex-shrink-0 cursor-pointer"
          title={isPlaying ? '일시 정지' : '음성 댓글 재생'}
        >
          {isPlaying ? (
            <Pause className="h-4 w-4 fill-white" />
          ) : (
            <Play className="h-4 w-4 fill-white ml-0.5" />
          )}
        </button>

        {/* Waveform & Scrubber */}
        <div className="flex-1 flex flex-col justify-center gap-1 min-w-0">
          <div className="relative flex items-center gap-0.5 h-6 cursor-pointer">
            {/* Visualizer bars */}
            <div className="absolute inset-0 flex items-center justify-between pointer-events-none px-0.5">
              {bars.map((height, idx) => {
                const barProgress = (idx / barCount) * 100;
                const isPassed = barProgress <= progressPercent;
                return (
                  <span
                    key={idx}
                    className={`w-1 rounded-full transition-all duration-150 ${
                      isPassed
                        ? 'bg-indigo-600 dark:bg-indigo-400'
                        : 'bg-indigo-200 dark:bg-indigo-900/80'
                    } ${isPlaying && isPassed ? 'animate-pulse' : ''}`}
                    style={{ height: `${height}%` }}
                  />
                );
              })}
            </div>

            {/* Invisible Range Input for scrubbing */}
            <input
              type="range"
              min={0}
              max={actualDuration || 1}
              step={0.1}
              value={currentTime}
              onChange={handleSeek}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
            />
          </div>

          {/* Time and Info */}
          <div className="flex items-center justify-between text-[10px] font-medium text-slate-500 dark:text-slate-400">
            <span className="flex items-center gap-1 font-mono">
              <Mic className="h-2.5 w-2.5 text-indigo-500" />
              {formatAudioDuration(currentTime)} / {formatAudioDuration(actualDuration)}
            </span>

            <button
              type="button"
              onClick={toggleSpeed}
              className="rounded px-1 text-[9px] font-bold text-indigo-600 hover:bg-indigo-100/70 dark:text-indigo-400 dark:hover:bg-indigo-950 transition-colors"
              title="재생 속도 변경"
            >
              {playbackRate}x
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
