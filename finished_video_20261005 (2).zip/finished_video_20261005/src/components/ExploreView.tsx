import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { PostCard } from './PostCard';
import {
  Search,
  TrendingUp,
  Flame,
  Users,
  CheckCircle,
  Hash,
  Sparkles
} from 'lucide-react';
import { TRENDING_TOPICS } from '../data/mockData';
import { formatNumber } from '../utils/formatters';

export const ExploreView: React.FC = () => {
  const {
    posts,
    deletedPostIds,
    users,
    currentUser,
    toggleFollow,
    searchQuery,
    setSearchQuery,
    setViewingUserId,
    setActiveTab,
    setActiveTag,
    activeTag,
    isDarkMode
  } = useSocial();

  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: '전체 트렌드' },
    { id: 'tech', label: 'IT & 개발' },
    { id: 'food', label: '맛집 & 카페' },
    { id: 'travel', label: '여행 & 사진' },
    { id: 'fitness', label: '운동 & 건강' }
  ];

  // Search filtering
  const matchingUsers = searchQuery.trim()
    ? users.filter(
        (u) =>
          u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.handle.toLowerCase().includes(searchQuery.toLowerCase()) ||
          u.bio.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (u.role && u.role.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (u.statusMessage && u.statusMessage.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (u.interests && u.interests.some((i) => i.toLowerCase().includes(searchQuery.toLowerCase())))
      )
    : [];

  const explorePosts = posts.filter((post) => {
    if ((deletedPostIds || []).includes(post.id) || (post as any).isDeleted) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchText = post.content.toLowerCase().includes(q);
      const matchAuthor = post.authorName.toLowerCase().includes(q) || post.authorHandle.toLowerCase().includes(q);
      const matchTag = post.tags?.some((t) => t.toLowerCase().includes(q));
      return matchText || matchAuthor || matchTag;
    }
    if (activeTag) {
      return post.tags?.includes(activeTag) || post.content.includes(activeTag);
    }
    return true;
  });

  const handleUserClick = (userId: string) => {
    setViewingUserId(userId);
    setActiveTab('profile');
  };

  const handleTopicClick = (tag: string) => {
    setSearchQuery(tag);
    setActiveTag(tag);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Search Input Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
        <input
          type="text"
          id="explore-search-input"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="키워드, #해시태그, 사용자 검색..."
          style={{
            color: isDarkMode ? '#f8fafc' : '#0f172a',
            backgroundColor: isDarkMode ? '#0f172a' : '#ffffff'
          }}
          className="w-full rounded-xl border border-slate-200 dark:border-slate-800 py-3.5 pl-12 pr-4 text-sm font-medium text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 caret-indigo-600 dark:caret-indigo-400 shadow-sm ring-1 ring-slate-200/50 dark:ring-slate-800/50 focus:border-indigo-500 focus:outline-none"
        />
        {searchQuery && (
          <button
            onClick={() => {
              setSearchQuery('');
              setActiveTag(null);
            }}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            초기화
          </button>
        )}
      </div>

      {/* If matching users found in search */}
      {matchingUsers.length > 0 && (
        <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <Users className="h-4 w-4 text-blue-600" />
            사용자 검색 결과 ({matchingUsers.length})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {matchingUsers.map((user) => {
              const isFollowing = currentUser.followingIds?.includes(user.id) ?? false;
              return (
                <div
                  key={user.id}
                  className="flex flex-col justify-between p-3 rounded-xl border border-slate-100 bg-slate-50/60 dark:border-slate-800 dark:bg-slate-800/40 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors gap-2.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div
                      onClick={() => handleUserClick(user.id)}
                      className="flex items-center gap-3 min-w-0 cursor-pointer group"
                    >
                      <img
                        src={user.avatar}
                        alt={user.name}
                        className="h-10 w-10 rounded-full object-cover border border-slate-200 dark:border-slate-700 group-hover:ring-2 group-hover:ring-blue-500 transition-all flex-shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1 font-bold text-sm text-slate-900 dark:text-white truncate group-hover:text-blue-600">
                          <span>{user.name}</span>
                          {user.isVerified && (
                            <CheckCircle className="h-3.5 w-3.5 fill-blue-600 text-white flex-shrink-0" />
                          )}
                          {user.role && (
                            <span className="text-[10px] bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300 px-1.5 py-0.2 rounded-full font-normal">
                              {user.role}
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-slate-400 truncate">@{user.handle}</div>
                      </div>
                    </div>

                    {user.id !== currentUser.id && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFollow(user.id, user.name, user.handle);
                        }}
                        className={`rounded-full px-3 py-1 text-xs font-semibold flex-shrink-0 transition-all cursor-pointer ${
                          isFollowing
                            ? 'border border-slate-300 bg-slate-100 text-slate-700 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-rose-950/40 dark:hover:text-rose-400'
                            : 'bg-blue-600 text-white hover:bg-blue-700 shadow-xs active:scale-95'
                        }`}
                      >
                        {isFollowing ? '팔로잉' : '팔로우'}
                      </button>
                    )}
                  </div>

                  {/* Interests tags preview */}
                  {user.interests && user.interests.length > 0 && (
                    <div className="flex flex-wrap gap-1 pt-1 border-t border-slate-200/50 dark:border-slate-700/50">
                      {user.interests.slice(0, 3).map((t, idx) => (
                        <span
                          key={idx}
                          onClick={() => handleTopicClick(t)}
                          className="cursor-pointer rounded-md bg-blue-50 px-2 py-0.5 text-[10px] font-medium text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 hover:bg-blue-100"
                        >
                          #{t}
                        </span>
                      ))}
                      {user.interests.length > 3 && (
                        <span className="text-[10px] text-slate-400 self-center">
                          +{user.interests.length - 3}
                        </span>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Trending Topics Banner */}
      {!searchQuery && (
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-50 text-rose-600 dark:bg-rose-950 dark:text-rose-400">
                <Flame className="h-4 w-4" />
              </div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                실시간 인기 트렌드
              </h2>
            </div>
            <span className="text-xs text-slate-400">대한민국 기준</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {TRENDING_TOPICS.map((topic, idx) => (
              <div
                key={topic.id}
                onClick={() => handleTopicClick(topic.tag)}
                className="flex flex-col justify-between p-3 rounded-xl bg-slate-50 hover:bg-blue-50/60 dark:bg-slate-800/60 dark:hover:bg-slate-800 cursor-pointer border border-slate-100 dark:border-slate-800 hover:border-blue-200 transition-all group"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-400">
                      {idx + 1}위 • {topic.category}
                    </span>
                    {topic.isHot && (
                      <span className="flex items-center text-[10px] font-bold text-rose-500 bg-rose-100 dark:bg-rose-950/60 px-1.5 py-0.2 rounded-full">
                        🔥 HOT
                      </span>
                    )}
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white mt-1 group-hover:text-blue-600 dark:group-hover:text-blue-400">
                    #{topic.tag}
                  </h4>
                </div>
                <p className="text-[11px] text-slate-400 mt-2">
                  게시물 {formatNumber(topic.postCount)}개
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Explore Posts Timeline */}
      <section className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Sparkles className="h-4 w-4 text-blue-600" />
            {searchQuery ? `"${searchQuery}" 검색 결과` : '지금 주목받는 게시물'}
          </h3>
          <span className="text-xs text-slate-400">총 {explorePosts.length}개</span>
        </div>

        {explorePosts.length === 0 ? (
          <div className="rounded-2xl border border-slate-200 bg-white p-10 text-center ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
            <p className="font-bold text-slate-700 dark:text-slate-300">
              일치하는 게시물이 없습니다
            </p>
            <p className="text-xs text-slate-400 mt-1">다른 검색어나 해시태그로 찾아보세요.</p>
          </div>
        ) : (
          explorePosts.map((post) => <PostCard key={post.id} post={post} />)
        )}
      </section>
    </div>
  );
};
