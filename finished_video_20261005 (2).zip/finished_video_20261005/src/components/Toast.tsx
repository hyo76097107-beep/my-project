import React from 'react';
import { useSocial } from '../context/SocialContext';
import { CheckCircle2, AlertCircle, Info } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toast } = useSocial();

  if (!toast) return null;

  const icons = {
    success: <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />,
    error: <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />,
    info: <Info className="w-4 h-4 text-indigo-500 shrink-0" />
  };

  const bgStyles = {
    success: 'bg-emerald-50 dark:bg-emerald-950/80 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200',
    error: 'bg-rose-50 dark:bg-rose-950/80 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200',
    info: 'bg-zinc-900 dark:bg-zinc-100 border-zinc-800 dark:border-zinc-200 text-white dark:text-zinc-900'
  };

  const isTop = toast.position === 'top';

  return (
    <div
      id="app-toast-container"
      className={`fixed left-1/2 -translate-x-1/2 z-[99999] pointer-events-none transition-all duration-300 ${
        isTop
          ? 'top-5 md:top-6 animate-in fade-in slide-in-from-top-6 duration-200'
          : 'bottom-20 md:bottom-6 animate-in fade-in slide-in-from-bottom-4 duration-200'
      }`}
    >
      <div
        id="app-toast-inner"
        className={`flex items-center gap-2.5 px-4.5 py-3 rounded-2xl border shadow-2xl text-xs font-bold backdrop-blur-md ${
          bgStyles[toast.type || 'info']
        }`}
      >
        {icons[toast.type || 'info']}
        <span>{toast.message}</span>
      </div>
    </div>
  );
};
