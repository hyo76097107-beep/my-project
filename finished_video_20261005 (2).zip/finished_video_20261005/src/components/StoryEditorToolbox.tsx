import React, { useState } from 'react';
import {
  StoryFilterPreset,
  StoryTextOverlay,
  StoryStickerOverlay,
  StoryBgm
} from '../types';
import { STORY_FILTER_PRESETS } from '../data/storyFiltersData';
import {
  STORY_STICKER_CATEGORIES,
  PRESET_TEXT_COLORS,
  PRESET_TEXT_STYLES
} from '../data/storyStickersData';
import { PRESET_POST_PHOTOS } from '../data/mockData';
import { PRESET_STORY_BGMS, COPYRIGHT_FREE_CATEGORIES } from '../data/storyBgmData';
import {
  Wand2,
  Type,
  Smile,
  Image as ImageIcon,
  Music,
  Plus,
  Trash2,
  Check,
  Disc,
  Play,
  Pause,
  RotateCw,
  Maximize2,
  Camera,
  Upload,
  Smartphone,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Sparkles,
  Film,
  ShieldCheck,
  Search,
  FileAudio
} from 'lucide-react';

export type StoryEditorSubTab = 'filters' | 'text' | 'stickers' | 'media' | 'bgm';

interface StoryEditorToolboxProps {
  currentSubTab: StoryEditorSubTab;
  onChangeSubTab: (tab: StoryEditorSubTab) => void;
  // Filters
  filterId: string;
  onSelectFilter: (id: string) => void;
  // Text Overlays
  textOverlays: StoryTextOverlay[];
  onAddText: (text: string, color: string, styleType: any, fontSize: any) => void;
  onUpdateText: (id: string, updates: Partial<StoryTextOverlay>) => void;
  onDeleteOverlay: (type: 'text' | 'sticker', id: string) => void;
  selectedItemId: string | null;
  selectedItemType: 'text' | 'sticker' | null;
  onSelectItem: (item: { type: 'text' | 'sticker'; id: string } | null) => void;
  // Stickers
  stickerOverlays: StoryStickerOverlay[];
  onAddSticker: (content: string, type: 'badge' | 'emoji' | 'sticker') => void;
  onUpdateSticker: (id: string, updates: Partial<StoryStickerOverlay>) => void;
  // Media
  selectedPhoto: string;
  customUrl: string;
  onSelectPhoto: (url: string) => void;
  onChangeCustomUrl: (url: string) => void;
  mediaType?: 'image' | 'video';
  // Camera & Device Gallery Triggers
  onTriggerCamera?: () => void;
  onTriggerGallery?: () => void;
  onTriggerVideo?: () => void;
  onTriggerLiveCamera?: () => void;
  isUploadingPhoto?: boolean;
  uploadStatusText?: string;
  // BGM
  selectedBgm: StoryBgm | null;
  onSelectBgm: (bgm: StoryBgm | null) => void;
  previewingBgmId: string | null;
  onTogglePreviewAudio: (bgm: StoryBgm, e?: React.MouseEvent) => void;
  customBgms?: StoryBgm[];
  onTriggerUploadAudio?: () => void;
  onAddCustomAudioUrl?: (url: string, title?: string) => void;
  onDeleteCustomBgm?: (id: string) => void;
}

export const StoryEditorToolbox: React.FC<StoryEditorToolboxProps> = ({
  currentSubTab,
  onChangeSubTab,
  filterId,
  onSelectFilter,
  textOverlays,
  onAddText,
  onUpdateText,
  onDeleteOverlay,
  selectedItemId,
  selectedItemType,
  onSelectItem,
  stickerOverlays,
  onAddSticker,
  onUpdateSticker,
  selectedPhoto,
  customUrl,
  onSelectPhoto,
  onChangeCustomUrl,
  mediaType = 'image',
  onTriggerCamera,
  onTriggerGallery,
  onTriggerVideo,
  onTriggerLiveCamera,
  isUploadingPhoto = false,
  uploadStatusText = '',
  selectedBgm,
  onSelectBgm,
  previewingBgmId,
  onTogglePreviewAudio,
  customBgms = [],
  onTriggerUploadAudio,
  onAddCustomAudioUrl,
  onDeleteCustomBgm
}) => {
  // Local state for new text creation
  const [newText, setNewText] = useState('');
  const [selectedColor, setSelectedColor] = useState('#ffffff');
  const [selectedStyle, setSelectedStyle] = useState<'badge' | 'highlight' | 'neon' | 'modern' | 'classic'>('badge');
  const [selectedFontSize, setSelectedFontSize] = useState<'sm' | 'base' | 'lg' | 'xl' | '2xl'>('lg');
  const [activeStickerCategory, setActiveStickerCategory] = useState<string>('badges');
  const [showSamplesAccordion, setShowSamplesAccordion] = useState(false);
  const [showUrlAccordion, setShowUrlAccordion] = useState(false);

  // BGM Filter & Custom Upload States
  const [bgmSearchQuery, setBgmSearchQuery] = useState('');
  const [activeBgmCategory, setActiveBgmCategory] = useState<string>('all');
  const [showCustomAudioUrlAccordion, setShowCustomAudioUrlAccordion] = useState(false);
  const [customAudioUrlInput, setCustomAudioUrlInput] = useState('');
  const [customAudioTitleInput, setCustomAudioTitleInput] = useState('');

  // Currently selected item in canvas
  const selectedTextItem =
    selectedItemType === 'text'
      ? textOverlays.find((t) => t.id === selectedItemId)
      : null;

  const selectedStickerItem =
    selectedItemType === 'sticker'
      ? stickerOverlays.find((s) => s.id === selectedItemId)
      : null;

  const handleCreateText = (e?: React.FormEvent | React.MouseEvent | React.KeyboardEvent) => {
    e?.preventDefault();
    if (!newText.trim()) return;
    onAddText(newText.trim(), selectedColor, selectedStyle, selectedFontSize);
    setNewText('');
  };

  return (
    <div id="story-editor-toolbox" className="flex flex-col gap-2.5">
      {/* Sub-Tab Selector Buttons */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar border-b border-slate-100 dark:border-slate-800">
        <button
          type="button"
          onClick={() => onChangeSubTab('filters')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
            currentSubTab === 'filters'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Wand2 className="w-3.5 h-3.5" />
          <span>필터 적용</span>
          {filterId !== 'normal' && (
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          )}
        </button>

        <button
          type="button"
          onClick={() => onChangeSubTab('text')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
            currentSubTab === 'text'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Type className="w-3.5 h-3.5" />
          <span>텍스트</span>
          {textOverlays.length > 0 && (
            <span className="px-1 py-0.2 rounded-full bg-blue-500 text-white text-[10px] font-bold">
              {textOverlays.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => onChangeSubTab('stickers')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
            currentSubTab === 'stickers'
              ? 'bg-pink-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Smile className="w-3.5 h-3.5" />
          <span>스티커/이모지</span>
          {stickerOverlays.length > 0 && (
            <span className="px-1 py-0.2 rounded-full bg-pink-500 text-white text-[10px] font-bold">
              {stickerOverlays.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => onChangeSubTab('media')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
            currentSubTab === 'media'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Camera className="w-3.5 h-3.5" />
          <span>사진 / 촬영</span>
          {(customUrl || selectedPhoto) && (
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          )}
        </button>

        <button
          type="button"
          onClick={() => onChangeSubTab('bgm')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
            currentSubTab === 'bgm'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Music className="w-3.5 h-3.5" />
          <span>배경음악</span>
          {selectedBgm && (
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          )}
        </button>
      </div>

      {/* SUBTAB 1: FILTERS */}
      {currentSubTab === 'filters' && (
        <div className="flex flex-col gap-2 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
            <span className="flex items-center gap-1">
              <Wand2 className="w-3.5 h-3.5 text-purple-500" />
              스토리 무드 필터 선택
            </span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              클릭 즉시 캔버스에 적용됩니다
            </span>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-3 gap-2">
            {STORY_FILTER_PRESETS.map((preset) => {
              const isSelected = filterId === preset.id;

              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => onSelectFilter(preset.id)}
                  className={`flex flex-col items-center justify-center p-2 rounded-lg border text-center transition-all cursor-pointer ${
                    isSelected
                      ? 'border-purple-600 bg-purple-50 dark:bg-purple-950/40 text-purple-900 dark:text-purple-200 ring-2 ring-purple-500/40 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-purple-300 dark:border-slate-700 dark:bg-slate-850 dark:hover:border-slate-600 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-1 font-bold text-xs">
                    {isSelected && <Check className="w-3 h-3 text-purple-600 dark:text-purple-400 stroke-[3]" />}
                    <span>{preset.name}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                    {preset.tag}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* SUBTAB 2: TEXT OVERLAYS */}
      {currentSubTab === 'text' && (
        <div className="flex flex-col gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
          {/* If a text item is selected on the canvas, show edit controls for it */}
          {selectedTextItem ? (
            <div className="flex flex-col gap-2 p-2.5 rounded-lg bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 animate-in fade-in">
              <div className="flex items-center justify-between text-xs font-bold text-blue-900 dark:text-blue-200">
                <span>선택된 텍스트 수정 중</span>
                <button
                  type="button"
                  onClick={() => onSelectItem(null)}
                  className="text-[11px] text-slate-500 hover:text-slate-700 dark:text-slate-400 underline"
                >
                  새 텍스트 작성으로 전환
                </button>
              </div>

              <input
                type="text"
                value={selectedTextItem.text}
                onChange={(e) =>
                  onUpdateText(selectedTextItem.id, { text: e.target.value })
                }
                className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs sm:text-sm text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
              />

              {/* Quick Style & Color for selected */}
              <div className="flex items-center justify-between gap-2 flex-wrap pt-1">
                <div className="flex items-center gap-1">
                  <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">색상:</span>
                  {PRESET_TEXT_COLORS.map((c) => (
                    <button
                      key={c.value}
                      type="button"
                      onClick={() => onUpdateText(selectedTextItem.id, { color: c.value })}
                      style={{ backgroundColor: c.value }}
                      className={`h-5 w-5 rounded-full ring-1 ring-black/20 hover:scale-110 transition-transform ${
                        selectedTextItem.color === c.value ? 'ring-2 ring-blue-500 scale-110' : ''
                      }`}
                      title={c.name}
                    />
                  ))}
                </div>

                <button
                  type="button"
                  onClick={() => onDeleteOverlay('text', selectedTextItem.id)}
                  className="px-2 py-1 rounded-md bg-rose-50 text-rose-600 hover:bg-rose-100 text-xs font-semibold flex items-center gap-1 ml-auto"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>삭제</span>
                </button>
              </div>
            </div>
          ) : (
            /* Add New Text Form (Container) */
            <div className="flex flex-col gap-2.5">
              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleCreateText(e);
                    }
                  }}
                  placeholder="스토리에 띄울 텍스트를 입력하세요..."
                  maxLength={60}
                  className="flex-1 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs sm:text-sm text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                />
                <button
                  type="button"
                  onClick={handleCreateText}
                  disabled={!newText.trim()}
                  className="px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center gap-1 shadow-xs transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>추가</span>
                </button>
              </div>

              {/* Color Palette */}
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">색상:</span>
                <div className="flex items-center gap-1">
                  {PRESET_TEXT_COLORS.map((c) => (
                    <button
                      key={c.value}
                      type="button"
                      onClick={() => setSelectedColor(c.value)}
                      style={{ backgroundColor: c.value }}
                      className={`h-5 w-5 rounded-full ring-1 ring-black/20 hover:scale-110 transition-transform ${
                        selectedColor === c.value ? 'ring-2 ring-blue-500 scale-110' : ''
                      }`}
                      title={c.name}
                    />
                  ))}
                </div>
              </div>

              {/* Style & Font Size Selector */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                    배경 스타일
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {PRESET_TEXT_STYLES.map((st) => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => setSelectedStyle(st.id as any)}
                        className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                          selectedStyle === st.id
                            ? 'bg-blue-600 text-white font-bold'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {st.name}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block mb-1">
                    글자 크기
                  </span>
                  <div className="flex items-center gap-1">
                    {[
                      { id: 'sm', label: '소' },
                      { id: 'base', label: '중' },
                      { id: 'lg', label: '대' },
                      { id: 'xl', label: '특대' }
                    ].map((fs) => (
                      <button
                        key={fs.id}
                        type="button"
                        onClick={() => setSelectedFontSize(fs.id as any)}
                        className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                          selectedFontSize === fs.id
                            ? 'bg-blue-600 text-white font-bold'
                            : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {fs.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* List of active text overlays */}
          {textOverlays.length > 0 && (
            <div className="border-t border-slate-200 dark:border-slate-700/60 pt-2">
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block mb-1.5">
                배치된 텍스트 목록 ({textOverlays.length}개 - 캔버스에서 드래그하여 이동 가능)
              </span>
              <div className="flex flex-wrap gap-1.5">
                {textOverlays.map((t) => (
                  <div
                    key={t.id}
                    onClick={() => onSelectItem({ type: 'text', id: t.id })}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs cursor-pointer border transition-all ${
                      selectedItemId === t.id && selectedItemType === 'text'
                        ? 'bg-blue-100 dark:bg-blue-950 border-blue-500 text-blue-900 dark:text-blue-100 font-bold'
                        : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-blue-300'
                    }`}
                  >
                    <span className="truncate max-w-[140px]">{t.text}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteOverlay('text', t.id);
                      }}
                      className="text-slate-400 hover:text-rose-500"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUBTAB 3: STICKERS & EMOJIS */}
      {currentSubTab === 'stickers' && (
        <div className="flex flex-col gap-2.5 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
          {/* If a sticker is selected, show scale & rotate controller */}
          {selectedStickerItem && (
            <div className="p-2.5 rounded-lg bg-pink-50/70 dark:bg-pink-950/40 border border-pink-200 dark:border-pink-800/60 animate-in fade-in mb-1">
              <div className="flex items-center justify-between text-xs font-bold text-pink-900 dark:text-pink-200 mb-2">
                <span>선택된 스티커 조절 [{selectedStickerItem.content}]</span>
                <button
                  type="button"
                  onClick={() => onDeleteOverlay('sticker', selectedStickerItem.id)}
                  className="px-2 py-0.5 rounded bg-rose-100 text-rose-700 dark:bg-rose-900/60 dark:text-rose-300 text-[11px] font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>삭제</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between text-[10px] text-slate-600 dark:text-slate-400 mb-1">
                    <span className="flex items-center gap-1">
                      <Maximize2 className="w-3 h-3" /> 크기 확대/축소
                    </span>
                    <span>{Math.round((selectedStickerItem.scale || 1) * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0.6"
                    max="2.2"
                    step="0.1"
                    value={selectedStickerItem.scale || 1}
                    onChange={(e) =>
                      onUpdateSticker(selectedStickerItem.id, {
                        scale: parseFloat(e.target.value)
                      })
                    }
                    className="w-full accent-pink-600"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-[10px] text-slate-600 dark:text-slate-400 mb-1">
                    <span className="flex items-center gap-1">
                      <RotateCw className="w-3 h-3" /> 회전 각도
                    </span>
                    <span>{selectedStickerItem.rotation || 0}°</span>
                  </div>
                  <input
                    type="range"
                    min="-45"
                    max="45"
                    step="5"
                    value={selectedStickerItem.rotation || 0}
                    onChange={(e) =>
                      onUpdateSticker(selectedStickerItem.id, {
                        rotation: parseInt(e.target.value)
                      })
                    }
                    className="w-full accent-pink-600"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Sticker Category Buttons */}
          <div className="flex items-center gap-1">
            {STORY_STICKER_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setActiveStickerCategory(cat.id)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  activeStickerCategory === cat.id
                    ? 'bg-pink-600 text-white font-bold'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* Stickers Grid */}
          <div className="grid grid-cols-4 sm:grid-cols-5 gap-2 max-h-36 overflow-y-auto p-1 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700">
            {STORY_STICKER_CATEGORIES.find((c) => c.id === activeStickerCategory)?.items.map(
              (item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onAddSticker(item.content, item.type)}
                  className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 border border-transparent hover:border-pink-300 flex items-center justify-center transition-all active:scale-90 cursor-pointer"
                  title={`${item.label} 스티커 추가`}
                >
                  {item.type === 'badge' ? (
                    <span className="text-[11px] font-black px-2 py-0.5 rounded bg-slate-900 text-white shadow-xs whitespace-nowrap">
                      {item.content}
                    </span>
                  ) : (
                    <span className="text-2xl">{item.content}</span>
                  )}
                </button>
              )
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 4: MEDIA SELECTION */}
      {currentSubTab === 'media' && (
        <div className="flex flex-col gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
          {/* Section 1: Main Photo & Video Actions (Camera & Gallery & Video) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <Camera className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                <span>스토리 사진 및 동영상 등록 (촬영 & 앨범)</span>
              </label>
              {(customUrl || selectedPhoto) && (
                <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                  {mediaType === 'video' ? <Film className="w-3 h-3 text-emerald-500" /> : null}
                  <span>✓ {mediaType === 'video' ? '동영상 적용됨' : '사진 적용됨'}</span>
                </span>
              )}
            </div>

            {/* Uploading Status Banner */}
            {isUploadingPhoto && (
              <div className="mb-2.5 p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 flex items-center gap-2.5 text-blue-800 dark:text-blue-200">
                <div className="w-4 h-4 rounded-full border-2 border-blue-600 border-t-transparent animate-spin shrink-0" />
                <span className="text-xs font-semibold">{uploadStatusText || '미디어 최적화 및 업로드 중...'}</span>
              </div>
            )}

            {/* Primary Action Buttons: Camera, Gallery Photo, Video */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {/* 1. Camera Capture Button */}
              {onTriggerCamera && (
                <button
                  type="button"
                  id="story-camera-trigger-btn"
                  onClick={onTriggerCamera}
                  disabled={isUploadingPhoto}
                  className="flex items-center sm:flex-col sm:items-start gap-2.5 sm:gap-1.5 p-2.5 rounded-xl bg-gradient-to-r sm:bg-gradient-to-br from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-md shadow-blue-600/20 active:scale-95 transition-all text-left cursor-pointer group disabled:opacity-50"
                >
                  <div className="p-1.5 rounded-lg bg-white/20 text-white group-hover:scale-110 transition-transform shrink-0">
                    <Camera className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold leading-tight">카메라 촬영</span>
                    <span className="text-[10px] text-blue-100 opacity-90">휴대폰으로 바로 찍기</span>
                  </div>
                </button>
              )}

              {/* 2. Gallery / Saved Photo Button */}
              {onTriggerGallery && (
                <button
                  type="button"
                  id="story-gallery-trigger-btn"
                  onClick={onTriggerGallery}
                  disabled={isUploadingPhoto}
                  className="flex items-center sm:flex-col sm:items-start gap-2.5 sm:gap-1.5 p-2.5 rounded-xl bg-gradient-to-r sm:bg-gradient-to-br from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-md shadow-purple-600/20 active:scale-95 transition-all text-left cursor-pointer group disabled:opacity-50"
                >
                  <div className="p-1.5 rounded-lg bg-white/20 text-white group-hover:scale-110 transition-transform shrink-0">
                    <ImageIcon className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold leading-tight">저장된 사진</span>
                    <span className="text-[10px] text-purple-100 opacity-90">앨범에서 사진 선택</span>
                  </div>
                </button>
              )}

              {/* 3. Saved Video Button */}
              {onTriggerVideo && (
                <button
                  type="button"
                  id="story-video-trigger-btn"
                  onClick={onTriggerVideo}
                  disabled={isUploadingPhoto}
                  className="flex items-center sm:flex-col sm:items-start gap-2.5 sm:gap-1.5 p-2.5 rounded-xl bg-gradient-to-r sm:bg-gradient-to-br from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-md shadow-emerald-600/20 active:scale-95 transition-all text-left cursor-pointer group disabled:opacity-50"
                >
                  <div className="p-1.5 rounded-lg bg-white/20 text-white group-hover:scale-110 transition-transform shrink-0">
                    <Film className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold leading-tight">저장된 동영상</span>
                    <span className="text-[10px] text-emerald-100 opacity-90">앨범에서 비디오 올리기</span>
                  </div>
                </button>
              )}
            </div>

            {/* Optional Live Web Viewfinder */}
            {onTriggerLiveCamera && (
              <div className="mt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={onTriggerLiveCamera}
                  className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Smartphone className="w-3.5 h-3.5 text-blue-500" />
                  <span>실시간 뷰파인더 카메라 열기</span>
                </button>
                <span className="text-[10px] text-slate-400">사진 드래그&드롭 지원</span>
              </div>
            )}
          </div>

          {/* Section 2: Collapsible Custom Image URL */}
          <div className="pt-1 border-t border-slate-200/80 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setShowUrlAccordion((prev) => !prev)}
              className="w-full flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 py-1 transition-colors cursor-pointer"
            >
              <span>🔗 웹 이미지 주소(URL) 직접 입력</span>
              {showUrlAccordion ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {showUrlAccordion && (
              <div className="pt-1.5 animate-in fade-in duration-150">
                <input
                  type="url"
                  value={customUrl}
                  onChange={(e) => {
                    onChangeCustomUrl(e.target.value);
                    onSelectPhoto('');
                  }}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:placeholder:text-slate-500"
                />
              </div>
            )}
          </div>

          {/* Section 3: Collapsible Sample Photos (Optional - Not forced) */}
          <div className="pt-1 border-t border-slate-200/80 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setShowSamplesAccordion((prev) => !prev)}
              className="w-full flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 py-1 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>추천 샘플 사진 둘러보기 (선택 사항)</span>
              </div>
              {showSamplesAccordion ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>

            {showSamplesAccordion && (
              <div className="pt-2 animate-in fade-in duration-150">
                <p className="text-[11px] text-slate-400 mb-2">
                  자신의 사진 대신 샘플 이미지를 사용해보고 싶을 때 선택할 수 있습니다.
                </p>
                <div className="grid grid-cols-6 gap-2">
                  {PRESET_POST_PHOTOS.map((photo, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        onSelectPhoto(photo);
                        onChangeCustomUrl('');
                      }}
                      className={`relative aspect-square overflow-hidden rounded-lg border-2 transition-all cursor-pointer ${
                        customUrl === '' && selectedPhoto === photo
                          ? 'border-indigo-600 scale-105 shadow-sm'
                          : 'border-transparent opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={photo}
                        alt={`Preset ${i}`}
                        className="h-full w-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      {customUrl === '' && selectedPhoto === photo && (
                        <div className="absolute inset-0 flex items-center justify-center bg-indigo-600/40 text-white">
                          <Check className="h-4 w-4 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUBTAB 5: BGM SELECTOR */}
      {currentSubTab === 'bgm' && (() => {
        const allBgms: StoryBgm[] = [...(customBgms || []), ...PRESET_STORY_BGMS];

        const filteredBgms = allBgms.filter((bgm) => {
          // Category match
          if (activeBgmCategory === 'custom') {
            if (!bgm.isCustom) return false;
          } else if (activeBgmCategory === 'lofi') {
            if (!bgm.genre.toLowerCase().includes('lo-fi') && !bgm.id.includes('lofi')) return false;
          } else if (activeBgmCategory === 'acoustic') {
            if (!bgm.genre.toLowerCase().includes('acoustic') && !bgm.id.includes('acoustic')) return false;
          } else if (activeBgmCategory === 'piano') {
            if (!bgm.genre.toLowerCase().includes('piano') && !bgm.id.includes('piano')) return false;
          } else if (activeBgmCategory === 'synth') {
            if (!bgm.genre.toLowerCase().includes('synth') && !bgm.genre.toLowerCase().includes('citypop') && !bgm.id.includes('synth')) return false;
          } else if (activeBgmCategory === 'tropical') {
            if (!bgm.genre.toLowerCase().includes('tropical') && !bgm.id.includes('tropical')) return false;
          } else if (activeBgmCategory === 'ambient') {
            if (!bgm.genre.toLowerCase().includes('ambient') && !bgm.id.includes('ambient')) return false;
          } else if (activeBgmCategory === 'jazz') {
            if (!bgm.genre.toLowerCase().includes('jazz') && !bgm.id.includes('jazz')) return false;
          } else if (activeBgmCategory === 'indie') {
            if (!bgm.genre.toLowerCase().includes('folk') && !bgm.genre.toLowerCase().includes('indie') && !bgm.id.includes('indie')) return false;
          } else if (activeBgmCategory === 'upbeat') {
            if (!bgm.genre.toLowerCase().includes('upbeat') && !bgm.genre.toLowerCase().includes('pop') && !bgm.id.includes('upbeat')) return false;
          }

          // Search query match
          if (bgmSearchQuery.trim()) {
            const q = bgmSearchQuery.trim().toLowerCase();
            const matchTitle = bgm.title.toLowerCase().includes(q);
            const matchArtist = bgm.artist.toLowerCase().includes(q);
            const matchGenre = bgm.genre.toLowerCase().includes(q);
            const matchLicense = bgm.license?.toLowerCase().includes(q);
            return matchTitle || matchArtist || matchGenre || matchLicense;
          }

          return true;
        });

        return (
          <div className="flex flex-col gap-2.5 rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-800/40">
            {/* Header: Title + No Music Option */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
                <Music className="w-4 h-4 text-amber-500" />
                <span>저작권 무료 배경음악 (BGM)</span>
                {selectedBgm && (
                  <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-500" />
                    <span>선택됨: {selectedBgm.title}</span>
                  </span>
                )}
              </div>
              <button
                type="button"
                onClick={() => onSelectBgm(null)}
                className={`text-[11px] font-medium px-2 py-0.5 rounded-md transition-colors cursor-pointer ${
                  selectedBgm === null
                    ? 'bg-slate-200 text-slate-800 dark:bg-slate-700 dark:text-white font-bold'
                    : 'text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                음악 없음
              </button>
            </div>

            {/* Copyright-Free Trust Banner */}
            <div className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 dark:from-emerald-950/50 dark:via-teal-950/40 dark:to-emerald-950/50 border border-emerald-200/80 dark:border-emerald-800/60 flex items-start gap-2.5">
              <div className="p-1 rounded-lg bg-emerald-600 text-white shrink-0 mt-0.5 shadow-xs">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                  100% 저작권 무료 (CC0 / Royalty-Free) 안심 음원
                </p>
                <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80 leading-relaxed mt-0.5">
                  상업적·개인용 제한 없이 SNS 영상에 자유롭게 사용 가능합니다. 소장 중인 무료 음악 파일(MP3, WAV 등)도 직접 추가해보세요!
                </p>
              </div>
            </div>

            {/* Action Bar: Upload Custom Audio & External Link Toggle */}
            <div className="flex items-center gap-2">
              {onTriggerUploadAudio && (
                <button
                  type="button"
                  id="upload-custom-bgm-btn"
                  onClick={onTriggerUploadAudio}
                  className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold shadow-sm shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>내 저작권 무료 음원 올리기 (MP3/WAV)</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setShowCustomAudioUrlAccordion((prev) => !prev)}
                className="px-2.5 py-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1 transition-all cursor-pointer"
                title="웹 음원 URL 주소 직접 입력"
              >
                <span>웹 링크</span>
                {showCustomAudioUrlAccordion ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            </div>

            {/* Collapsible External Audio URL Input */}
            {showCustomAudioUrlAccordion && (
              <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 animate-in fade-in duration-150 space-y-2">
                <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                  🔗 외부 저작권 무료 음원 주소(URL) 직접 등록
                </span>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={customAudioTitleInput}
                    onChange={(e) => setCustomAudioTitleInput(e.target.value)}
                    placeholder="음원 제목 (예: 감성 카페 피아노)"
                    className="sm:w-1/3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                  <input
                    type="url"
                    value={customAudioUrlInput}
                    onChange={(e) => setCustomAudioUrlInput(e.target.value)}
                    placeholder="https://... (.mp3, .wav, .m4a 등 오디오 주소)"
                    className="flex-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    disabled={!customAudioUrlInput.trim()}
                    onClick={() => {
                      if (!customAudioUrlInput.trim()) return;
                      onAddCustomAudioUrl?.(customAudioUrlInput.trim(), customAudioTitleInput.trim() || undefined);
                      setCustomAudioUrlInput('');
                      setCustomAudioTitleInput('');
                      setShowCustomAudioUrlAccordion(false);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold transition-all cursor-pointer shrink-0"
                  >
                    등록 및 적용
                  </button>
                </div>
              </div>
            )}

            {/* Search Input Bar */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={bgmSearchQuery}
                onChange={(e) => setBgmSearchQuery(e.target.value)}
                placeholder="음악 제목, 아티스트, 장르 검색..."
                className="w-full pl-8 pr-7 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-amber-500 transition-colors"
              />
              {bgmSearchQuery && (
                <button
                  type="button"
                  onClick={() => setBgmSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar">
              {COPYRIGHT_FREE_CATEGORIES.map((cat) => {
                const isActive = activeBgmCategory === cat.id;
                const count = cat.id === 'custom' ? (customBgms?.length || 0) : undefined;
                if (cat.id === 'custom' && (customBgms?.length || 0) === 0) return null;

                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setActiveBgmCategory(cat.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 ${
                      isActive
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-750 border border-slate-200/80 dark:border-slate-700'
                    }`}
                  >
                    <span>{cat.label}</span>
                    {count !== undefined && (
                      <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold ${isActive ? 'bg-amber-700 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                        {count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Track Cards Grid */}
            {filteredBgms.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
                {filteredBgms.map((bgm) => {
                  const isSelected = selectedBgm?.id === bgm.id;
                  const isPreviewing = previewingBgmId === bgm.id;

                  return (
                    <div
                      key={bgm.id}
                      onClick={() => onSelectBgm(bgm)}
                      className={`relative flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-amber-500 bg-amber-50/80 dark:bg-amber-950/40 ring-1 ring-amber-500/60 shadow-xs'
                          : 'border-slate-200/90 bg-white hover:border-amber-300 dark:border-slate-750 dark:bg-slate-850 dark:hover:border-slate-600'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0 pr-2">
                        {/* Cover Image / Disc */}
                        <div className="relative h-9 w-9 rounded-lg overflow-hidden bg-slate-900 shrink-0 shadow-xs">
                          {bgm.coverUrl ? (
                            <img
                              src={bgm.coverUrl}
                              alt={bgm.title}
                              className="h-full w-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <Disc className="h-full w-full p-2 text-amber-400" />
                          )}
                          {isSelected && (
                            <div className="absolute inset-0 bg-amber-600/50 flex items-center justify-center text-white backdrop-blur-[0.5px]">
                              <Check className="h-4 w-4 stroke-[3]" />
                            </div>
                          )}
                        </div>

                        {/* Title, Artist, License */}
                        <div className="min-w-0 truncate text-left">
                          <p className={`text-xs font-bold truncate leading-tight ${isSelected ? 'text-amber-900 dark:text-amber-200' : 'text-slate-800 dark:text-slate-200'}`}>
                            {bgm.title}
                          </p>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                            {bgm.artist} • <span className="text-amber-600 dark:text-amber-400 font-medium">{bgm.genre}</span>
                          </p>
                          <div className="mt-1 flex items-center gap-1">
                            <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100/80 dark:bg-emerald-950/70 px-1.5 py-0.5 rounded border border-emerald-200/50 dark:border-emerald-800/40">
                              <ShieldCheck className="w-2.5 h-2.5 text-emerald-500" />
                              <span>{bgm.license || '저작권 무료'}</span>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Right controls: Delete if custom, Preview toggle */}
                      <div className="flex items-center gap-1 shrink-0">
                        {bgm.isCustom && onDeleteCustomBgm && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeleteCustomBgm(bgm.id);
                            }}
                            title="음원 삭제"
                            className="p-1 rounded-md text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={(e) => onTogglePreviewAudio(bgm, e)}
                          title={isPreviewing ? '미리듣기 일시정지' : '미리듣기 재생'}
                          className={`h-7 w-7 rounded-full flex items-center justify-center shrink-0 transition-all cursor-pointer ${
                            isPreviewing
                              ? 'bg-amber-500 text-white shadow-sm scale-105'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {isPreviewing ? (
                            <Pause className="w-3 h-3 fill-current" />
                          ) : (
                            <Play className="w-3 h-3 fill-current ml-0.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-white dark:bg-slate-850 text-center border border-slate-200 dark:border-slate-800">
                <FileAudio className="w-6 h-6 text-slate-400 mx-auto mb-1.5" />
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  일치하는 저작권 무료 음원이 없습니다
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setBgmSearchQuery('');
                    setActiveBgmCategory('all');
                  }}
                  className="mt-2 text-[11px] text-blue-600 dark:text-blue-400 underline cursor-pointer"
                >
                  전체 음원 목록 보기
                </button>
              </div>
            )}
          </div>
        );
      })()}
    </div>
  );
};
