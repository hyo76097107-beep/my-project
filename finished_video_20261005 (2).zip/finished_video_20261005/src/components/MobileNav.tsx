import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { ActiveTab } from '../types';
import { GlobalHeaderSearch } from './GlobalHeaderSearch';
import { ThemeSwitchMenu } from './ThemeSwitchMenu';
import {
  Home,
  Compass,
  Bell,
  MessageCircle,
  User,
  Plus,
  Sparkles,
  Sun,
  Moon,
  Users,
  Check,
  LogIn,
  UserPlus,
  LogOut,
  Search,
  X,
  ShieldCheck,
  ShieldAlert,
  Database,
  Bookmark
} from 'lucide-react';

interface MobileNavProps {
  onOpenCreatePost: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ onOpenCreatePost }) => {
  const {
    currentUser,
    posts,
    activeTab,
    setActiveTab,
    unreadNotificationsCount,
    unreadMessagesCount,
    isDarkMode,
    toggleDarkMode,
    setViewingUserId,
    isAuthenticated,
    openAuthModal,
    logout,
    openEditSignupInfoModal,
    unlockSuperAdminDatabase
  } = useSocial();

  const [showUserSwitcher, setShowUserSwitcher] = useState(false);
  const [showMobileSearch, setShowMobileSearch] = useState(false);

  const myBookmarksCount = posts.filter((p) => p.bookmarks?.includes(currentUser.id)).length;

  const handleTabClick = (tab: ActiveTab) => {
    if (tab === 'profile') {
      if (!isAuthenticated) {
        openAuthModal('login');
        return;
      }
      setViewingUserId(currentUser.id);
    }
    setActiveTab(tab);
  };

  return (
    <>
      {/* Mobile Top Header */}
      <header className="sticky top-0 z-40 flex items-center justify-between border-b border-neutral-200 bg-white/90 px-4 py-3 backdrop-blur-md dark:border-neutral-800 dark:bg-neutral-900/90 md:hidden">
        <div
          id="mobile-logo-btn"
          onClick={() => handleTabClick('feed')}
          className="flex items-center gap-2 cursor-pointer"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-sm font-bold text-sm">
            M
          </div>
          <span className="text-base font-bold tracking-tight text-neutral-900 dark:text-white">
            마음
          </span>
        </div>

        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            /* User Switcher button */
            <button
              id="mobile-user-switch-toggle"
              onClick={() => setShowUserSwitcher((prev) => !prev)}
              className="flex items-center gap-1.5 rounded-full border border-neutral-200 bg-neutral-100 px-2.5 py-1 text-xs font-semibold text-neutral-700 dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-200"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="h-5 w-5 rounded-full object-cover"
                referrerPolicy="no-referrer"
              />
              <span className="max-w-[70px] truncate">{currentUser.name}</span>
            </button>
          ) : (
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <button
                onClick={() => openAuthModal('login')}
                className="px-2.5 py-1 text-xs font-bold bg-indigo-600 text-white rounded-lg shadow-xs whitespace-nowrap"
              >
                로그인
              </button>
              <button
                onClick={() => openAuthModal('signup')}
                className="px-2 py-1 text-xs font-semibold text-neutral-600 dark:text-neutral-300 hover:text-indigo-600 border border-neutral-200 dark:border-neutral-700 rounded-lg whitespace-nowrap"
              >
                회원가입
              </button>
            </div>
          )}

          {/* Mobile Search Button */}
          <button
            id="mobile-search-toggle"
            onClick={() => setShowMobileSearch(true)}
            title="검색"
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-neutral-200 text-neutral-600 hover:bg-neutral-100 dark:border-neutral-800 dark:text-neutral-300 dark:hover:bg-neutral-800"
          >
            <Search className="h-4 w-4" />
          </button>

          {/* Dark / Light / System Auto Theme Toggle */}
          <ThemeSwitchMenu idPrefix="mobile-theme" variant="mobile" />
        </div>
      </header>

      {/* Mobile Global Search Modal Overlay */}
      {showMobileSearch && (
        <div className="fixed inset-0 z-50 flex flex-col bg-white/95 dark:bg-slate-900/95 backdrop-blur-md p-4 md:hidden animate-in fade-in duration-150">
          <div className="flex items-center justify-between gap-3 mb-3">
            <div className="flex-1">
              <GlobalHeaderSearch
                isMobileModal={true}
                onCloseMobile={() => setShowMobileSearch(false)}
              />
            </div>
            <button
              onClick={() => setShowMobileSearch(false)}
              className="p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800 shrink-0"
              title="닫기"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Mobile User Switcher Modal/Backdrop */}
      {showUserSwitcher && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 md:hidden backdrop-blur-xs"
          onClick={() => setShowUserSwitcher(false)}
        >
          <div
            className="w-full max-w-xs rounded-2xl border border-neutral-200 bg-white p-4 shadow-2xl dark:border-neutral-800 dark:bg-neutral-900 animate-in zoom-in-95 duration-150 space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100 dark:border-neutral-800">
              <span className="text-sm font-bold text-neutral-800 dark:text-neutral-200 flex items-center gap-1.5">
                <Users className="h-4 w-4 text-indigo-500" />
                계정관리
              </span>
              <span className="text-[10px] bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 px-1.5 py-0.5 rounded font-medium flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                현재 로그인 계정
              </span>
            </div>

            {/* Current Logged In Account Details (No switching to other accounts) */}
            <div className="p-3 bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-200 dark:border-neutral-700 rounded-xl">
              <div className="flex items-center gap-2.5 min-w-0">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="h-10 w-10 rounded-full object-cover shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-bold text-neutral-900 dark:text-neutral-100 truncate flex items-center gap-1">
                    {currentUser.name}
                    {currentUser.isAdmin && (
                      <span className="text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 px-1.5 py-0.2 rounded font-normal">
                        관리자
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-neutral-400 truncate">@{currentUser.handle}</div>
                </div>
                <Check className="h-4 w-4 text-emerald-500 shrink-0" />
              </div>
            </div>

            <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800 flex flex-col gap-1.5">
              {/* My Bookmarks Quick Access */}
              <button
                type="button"
                id="mobile-user-bookmarks-btn"
                onClick={() => {
                  setShowUserSwitcher(false);
                  handleTabClick('bookmarks');
                }}
                className="w-full flex items-center justify-between px-2.5 py-1.5 text-xs text-indigo-700 bg-indigo-50 dark:bg-indigo-950/60 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 rounded-lg transition-colors font-bold border border-indigo-200/70 dark:border-indigo-800/70"
              >
                <div className="flex items-center gap-1.5">
                  <Bookmark className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  <span>내 북마크 보관함</span>
                </div>
                <span className="bg-indigo-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                  {myBookmarksCount}개
                </span>
              </button>

              <button
                type="button"
                id="mobile-edit-signup-info-btn"
                onClick={() => {
                  setShowUserSwitcher(false);
                  openEditSignupInfoModal();
                }}
                className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-indigo-700 bg-indigo-50 dark:bg-indigo-950/60 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 rounded-lg transition-colors font-bold border border-indigo-200/70 dark:border-indigo-800/70"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span>회원가입 정보 수정</span>
              </button>

              {/* Super Admin Database Buttons */}
              {(currentUser?.isAdmin || currentUser?.handle === 'admin') && (
                <div className="flex flex-col gap-1.5">
                  <button
                    type="button"
                    id="mobile-db-management-btn"
                    onClick={() => {
                      setShowUserSwitcher(false);
                      unlockSuperAdminDatabase();
                      setActiveTab('database');
                    }}
                    className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-emerald-700 bg-emerald-50 dark:bg-emerald-950/60 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 rounded-lg transition-colors font-bold border border-emerald-200/70 dark:border-emerald-800/70"
                  >
                    <Database className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>데이타베이스(DB) 콘솔</span>
                  </button>

                  <button
                    type="button"
                    id="mobile-admin-page-btn"
                    onClick={() => {
                      setShowUserSwitcher(false);
                      setActiveTab('admin');
                    }}
                    className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs text-indigo-700 bg-indigo-50 dark:bg-indigo-950/60 dark:text-indigo-300 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 rounded-lg transition-colors font-bold border border-indigo-200/70 dark:border-indigo-800/70"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    <span>관리자페이지</span>
                  </button>
                </div>
              )}

              <button
                onClick={() => {
                  setShowUserSwitcher(false);
                  logout();
                  openAuthModal('signup');
                }}
                className="w-full flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-lg cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <span>새 계정 회원가입</span>
              </button>

              <button
                onClick={() => {
                  setShowUserSwitcher(false);
                  logout();
                }}
                className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg"
              >
                <LogOut className="w-4 h-4" />
                <span>로그아웃</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Mobile Post Button (Hidden on messages, admin, and database pages to avoid overlapping UI) */}
      {activeTab !== 'messages' && activeTab !== 'admin' && activeTab !== 'database' && (
        <button
          id="mobile-floating-create-post"
          onClick={() => {
            if (!isAuthenticated) {
              openAuthModal('login');
              return;
            }
            onOpenCreatePost();
          }}
          aria-label="게시물 작성"
          title="게시물 작성"
          className="fixed right-4 bottom-20 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-xl shadow-indigo-600/40 active:scale-95 transition-transform md:hidden"
        >
          <Plus className="h-7 w-7" />
        </button>
      )}

      {/* Mobile Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 flex h-16 items-center justify-around border-t border-neutral-200 bg-white/95 backdrop-blur-lg px-2 dark:border-neutral-800 dark:bg-neutral-900/95 md:hidden">
        <button
          id="mobile-nav-feed"
          onClick={() => handleTabClick('feed')}
          className={`flex flex-col items-center justify-center gap-1 p-2 ${
            activeTab === 'feed'
              ? 'text-indigo-600 dark:text-indigo-400'
              : 'text-neutral-500 dark:text-neutral-400'
          }`}
        >
          <Home className={`h-5 w-5 ${activeTab === 'feed' ? 'stroke-[2.5px]' : ''}`} />
          <span className="text-[10px] font-semibold">홈</span>
        </button>

        <button
          id="mobile-nav-explore"
          onClick={() => handleTabClick('explore')}
          className={`flex flex-col items-center justify-center gap-1 p-2 ${
            activeTab === 'explore'
              ? 'text-indigo-600 dark:text-indigo-400'
              : 'text-neutral-500 dark:text-neutral-400'
          }`}
        >
          <Compass className={`h-5 w-5 ${activeTab === 'explore' ? 'stroke-[2.5px]' : ''}`} />
          <span className="text-[10px] font-semibold">탐색</span>
        </button>

        <button
          id="mobile-nav-bookmarks"
          onClick={() => handleTabClick('bookmarks')}
          className={`relative flex flex-col items-center justify-center gap-1 p-2 ${
            activeTab === 'bookmarks'
              ? 'text-indigo-600 dark:text-indigo-400'
              : 'text-neutral-500 dark:text-neutral-400'
          }`}
        >
          <Bookmark className={`h-5 w-5 ${activeTab === 'bookmarks' ? 'stroke-[2.5px]' : ''}`} />
          {myBookmarksCount > 0 && (
            <span className="absolute top-1 right-2 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-indigo-600 px-1 text-[9px] font-bold text-white">
              {myBookmarksCount}
            </span>
          )}
          <span className="text-[10px] font-semibold">북마크</span>
        </button>

        <button
          id="mobile-nav-notifications"
          onClick={() => handleTabClick('notifications')}
          className={`relative flex flex-col items-center justify-center gap-1 p-2 ${
            activeTab === 'notifications'
              ? 'text-indigo-600 dark:text-indigo-400'
              : 'text-neutral-500 dark:text-neutral-400'
          }`}
        >
          <Bell className={`h-5 w-5 ${activeTab === 'notifications' ? 'stroke-[2.5px]' : ''}`} />
          {unreadNotificationsCount > 0 && (
            <span className="absolute top-1 right-2 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-rose-500 px-1 text-[9px] font-bold text-white">
              {unreadNotificationsCount}
            </span>
          )}
          <span className="text-[10px] font-semibold">알림</span>
        </button>

        <button
          id="mobile-nav-messages"
          onClick={() => handleTabClick('messages')}
          className={`relative flex flex-col items-center justify-center gap-1 p-2 ${
            activeTab === 'messages'
              ? 'text-indigo-600 dark:text-indigo-400'
              : 'text-neutral-500 dark:text-neutral-400'
          }`}
        >
          <MessageCircle className={`h-5 w-5 ${activeTab === 'messages' ? 'stroke-[2.5px]' : ''}`} />
          {unreadMessagesCount > 0 && (
            <span className="absolute top-1 right-2 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-indigo-600 px-1 text-[9px] font-bold text-white">
              {unreadMessagesCount}
            </span>
          )}
          <span className="text-[10px] font-semibold">메시지</span>
        </button>

        <button
          id="mobile-nav-profile"
          onClick={() => handleTabClick('profile')}
          className={`flex flex-col items-center justify-center gap-1 p-2 ${
            activeTab === 'profile'
              ? 'text-indigo-600 dark:text-indigo-400'
              : 'text-neutral-500 dark:text-neutral-400'
          }`}
        >
          <User className={`h-5 w-5 ${activeTab === 'profile' ? 'stroke-[2.5px]' : ''}`} />
          <span className="text-[10px] font-semibold">프로필</span>
        </button>

        {(currentUser?.isAdmin || currentUser?.handle === 'admin') && (
          <>
            <button
              id="mobile-nav-admin"
              onClick={() => handleTabClick('admin')}
              className={`flex flex-col items-center justify-center gap-1 p-2 ${
                activeTab === 'admin'
                  ? 'text-rose-600 dark:text-rose-400 font-bold'
                  : 'text-rose-500/80 dark:text-rose-400/80'
              }`}
            >
              <ShieldAlert className={`h-5 w-5 ${activeTab === 'admin' ? 'stroke-[2.5px]' : ''}`} />
              <span className="text-[10px] font-bold">관리자</span>
            </button>

            <button
              id="mobile-nav-database"
              onClick={() => handleTabClick('database')}
              className={`flex flex-col items-center justify-center gap-1 p-2 ${
                activeTab === 'database'
                  ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                  : 'text-emerald-600/80 dark:text-emerald-400/80'
              }`}
            >
              <Database className={`h-5 w-5 ${activeTab === 'database' ? 'stroke-[2.5px]' : ''}`} />
              <span className="text-[10px] font-bold">DB수정</span>
            </button>
          </>
        )}
      </nav>
    </>
  );
};

