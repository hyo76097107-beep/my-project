import React, { useEffect, useState } from 'react';
import { useSocial } from '../context/SocialContext';
import { Laptop, Moon, Sun, X } from 'lucide-react';

export const SystemThemeToast: React.FC = () => {
  const { systemThemeNotice, dismissSystemThemeNotice } = useSocial();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (systemThemeNotice) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  }, [systemThemeNotice]);

  if (!systemThemeNotice || !isVisible) return null;

  const isDark = systemThemeNotice.mode === 'dark';

  return (
    <aside
      id="system-theme-top-notification"
      role="status"
      aria-live="polite"
      aria-label="시스템 설정에 따른 테마 변경 안내"
      className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] w-[92%] max-w-md pointer-events-auto transition-all duration-300 animate-in fade-in slide-in-from-top-4"
    >
      <div className="flex items-center justify-between gap-3 px-4 py-3 rounded-2xl border shadow-xl backdrop-blur-md transition-all border-indigo-200/90 bg-white/95 text-slate-800 dark:border-indigo-800/80 dark:bg-slate-900/95 dark:text-slate-100 ring-1 ring-black/5 dark:ring-white/10">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/60 dark:text-indigo-400">
            {isDark ? (
              <Moon className="h-4 w-4 text-indigo-400 animate-in spin-in-180 duration-300" />
            ) : (
              <Sun className="h-4 w-4 text-amber-500 animate-in spin-in-180 duration-300" />
            )}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-indigo-100 text-indigo-700 dark:bg-indigo-900/60 dark:text-indigo-300">
                <Laptop className="w-2.5 h-2.5" />
                시스템 테마 감지
              </span>
              <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400">
                {isDark ? '밤(다크) 모드' : '낮(라이트) 모드'}
              </span>
            </div>
            <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 mt-0.5 truncate">
              {systemThemeNotice.message}
            </p>
          </div>
        </div>

        <button
          type="button"
          id="close-system-theme-notice-btn"
          onClick={dismissSystemThemeNotice}
          className="shrink-0 p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:text-slate-500 dark:hover:text-slate-200 dark:hover:bg-slate-800 transition-colors"
          title="알림 닫기"
          aria-label="알림 닫기"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
};
