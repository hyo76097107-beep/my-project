import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { useSocial } from '../context/SocialContext';
import { Post, Comment, PostMediaItem } from '../types';
import { InstagramMediaCarousel } from './InstagramMediaCarousel';
import {
  Heart,
  MessageCircle,
  Repeat2,
  Bookmark,
  Share2,
  MoreHorizontal,
  Trash2,
  MapPin,
  CheckCircle,
  BarChart2,
  Send,
  Lock,
  Globe,
  CornerDownRight,
  Sparkles,
  Users,
  Play,
  Copy,
  Check,
  Edit3,
  Mic,
  Printer,
  ShieldAlert,
  Ban,
  EyeOff,
  Eye,
  AlertTriangle,
  Music,
  Pause,
  Disc,
  ShieldCheck,
  Loader2
} from 'lucide-react';
import { formatRelativeTime, formatNumber } from '../utils/formatters';
import { ShareModal } from './ShareModal';
import { getRegionalScopeConfig, RegionalScope } from '../data/regionalScope';
import { EditPostModal } from './EditPostModal';
import { VoiceCommentPlayer } from './VoiceCommentPlayer';
import { VoiceCommentRecorder } from './VoiceCommentRecorder';
import { PrintPostModal } from './PrintPostModal';
import { PostTranslator } from './PostTranslator';
import { findMoodCategoryByItem } from '../data/feelingCategories';
import { resolveBgmAudioUrl } from '../data/storyBgmData';

interface PostCardProps {
  post: Post;
  onTagClick?: (tag: string) => void;
  onAuthorClick?: (authorId: string) => void;
  onScopeClick?: (scope: RegionalScope) => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onTagClick, onAuthorClick, onScopeClick }) => {
  const {
    currentUser,
    isAuthenticated,
    deletePost,
    toggleBlockPost,
    toggleLike,
    toggleBookmark,
    toggleRepost,
    votePoll,
    comments,
    addComment,
    toggleCommentLike,
    toggleFollow,
    setViewingUserId,
    setActiveTab,
    setActiveTag,
    showToast
  } = useSocial();

  const [showComments, setShowComments] = useState(false);
  const [commentInput, setCommentInput] = useState('');
  const [replyingToComment, setReplyingToComment] = useState<Comment | null>(null);
  const [isVoiceRecordingOpen, setIsVoiceRecordingOpen] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [showBlockedContent, setShowBlockedContent] = useState(false);
  const [showBlockReasonModal, setShowBlockReasonModal] = useState(false);
  const [blockReasonInput, setBlockReasonInput] = useState('운영 정책 및 커뮤니티 가이드라인 위반');
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Background Music (BGM) state
  const postBgmAudioRef = useRef<HTMLAudioElement | null>(null);
  const [isBgmPlaying, setIsBgmPlaying] = useState(false);
  const [isBgmLoading, setIsBgmLoading] = useState(false);

  // Stop BGM when unmounted
  useEffect(() => {
    return () => {
      if (postBgmAudioRef.current) {
        postBgmAudioRef.current.pause();
        postBgmAudioRef.current = null;
      }
    };
  }, []);

  const togglePostBgm = async (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!post.bgm) return;

    if (isBgmPlaying) {
      if (postBgmAudioRef.current) {
        postBgmAudioRef.current.pause();
      }
      setIsBgmPlaying(false);
      return;
    }

    setIsBgmLoading(true);
    try {
      let audioUrl = post.bgm.audioUrl;
      if (!audioUrl || (!audioUrl.startsWith('blob:') && !audioUrl.startsWith('data:') && !audioUrl.startsWith('http'))) {
        audioUrl = await resolveBgmAudioUrl(post.bgm);
      }
      if (!audioUrl) {
        showToast('음원 파일을 불러오지 못했습니다.', 'error');
        return;
      }

      if (!postBgmAudioRef.current || postBgmAudioRef.current.src !== audioUrl) {
        if (postBgmAudioRef.current) {
          postBgmAudioRef.current.pause();
        }
        const audio = new Audio(audioUrl);
        audio.loop = true;
        audio.volume = 0.55;
        audio.onended = () => setIsBgmPlaying(false);
        postBgmAudioRef.current = audio;
      }

      await postBgmAudioRef.current.play();
      setIsBgmPlaying(true);
    } catch (err) {
      console.warn('[PostCard] BGM playback error:', err);
      setIsBgmPlaying(false);
    } finally {
      setIsBgmLoading(false);
    }
  };

  // Unified media state & viewport visibility
  const postCardRef = useRef<HTMLDivElement | null>(null);
  const [isPostInView, setIsPostInView] = useState(true);
  const [showHeartAnimation, setShowHeartAnimation] = useState(false);

  // Fallback to verified local video assets if external URL is broken or forbidden
  const resolvedVideoSrc = useMemo(() => {
    if (!post.video) return undefined;
    if (typeof post.video === 'string') {
      const raw = post.video.trim();
      if (raw.startsWith('content://') || raw.startsWith('file://')) {
        return '/videos/sample_nature.mp4';
      }
      if (raw.startsWith('blob:') || raw.startsWith('data:')) {
        return raw;
      }
      if (raw.includes('uploads/')) {
        const idx = raw.indexOf('uploads/');
        return `/${raw.substring(idx)}`;
      }
      if (raw.includes('videos/')) {
        const idx = raw.indexOf('videos/');
        return `/${raw.substring(idx)}`;
      }
      if (raw.includes(':3000')) {
        const path = raw.substring(raw.indexOf(':3000') + 5);
        return path.startsWith('/') ? path : `/${path}`;
      }
      if (raw.includes('commondatastorage.googleapis.com')) {
        if (raw.includes('Escapes') || raw.includes('Bullrun') || post.id === 'post_video_2') {
          return '/videos/sample_tokyo.mp4';
        }
        return '/videos/sample_fitness.mp4';
      }
    }
    return post.video;
  }, [post.video, post.id]);

  // Unified media items (photos and/or videos, up to 10 total)
  const postMediaItems = useMemo<PostMediaItem[]>(() => {
    if (post.mediaItems && post.mediaItems.length > 0) {
      return post.mediaItems.map((m, idx) => {
        let u = (m.url || '').trim();
        let itemType: 'image' | 'video' = m.type;
        if (!itemType) {
          itemType = (u.includes('videos/') || u.endsWith('.mp4') || u.endsWith('.webm') || u.endsWith('.mov')) ? 'video' : 'image';
        }
        if (u.startsWith('blob:') || u.startsWith('data:')) {
          // Keep blob / data URLs intact for instant local playback
        } else if (u.startsWith('content://') || u.startsWith('file://')) {
          u = itemType === 'video' ? '/videos/sample_nature.mp4' : u;
        } else if (u.includes('uploads/')) {
          u = `/${u.substring(u.indexOf('uploads/'))}`;
        } else if (u.includes('videos/')) {
          u = `/${u.substring(u.indexOf('videos/'))}`;
        } else if (u.includes(':3000')) {
          u = u.substring(u.indexOf(':3000') + 5);
        } else if (u.includes('commondatastorage.googleapis.com')) {
          u = u.includes('tokyo') || post.id === 'post_video_2' ? '/videos/sample_tokyo.mp4' : '/videos/sample_fitness.mp4';
        }
        if (u.startsWith('uploads/')) u = `/${u}`;
        if (u.startsWith('videos/')) u = `/${u}`;
        return {
          ...m,
          id: m.id || `${post.id}_m_${idx}`,
          type: itemType,
          url: u
        };
      });
    }
    const items: PostMediaItem[] = [];
    if (post.video) {
      items.push({
        id: `${post.id}_vid`,
        type: 'video',
        url: resolvedVideoSrc || post.video,
        thumbnail: post.videoThumbnail
      });
    }
    if (Array.isArray(post.videoUrls) && post.videoUrls.length > 0) {
      post.videoUrls.forEach((vUrl, idx) => {
        let resolved = (vUrl || '').trim();
        if (resolved.startsWith('blob:') || resolved.startsWith('data:')) {
          // Keep blob / data URLs intact
        } else if (resolved.startsWith('content://') || resolved.startsWith('file://')) {
          resolved = '/videos/sample_nature.mp4';
        } else if (resolved.includes('uploads/')) {
          resolved = `/${resolved.substring(resolved.indexOf('uploads/'))}`;
        } else if (resolved.includes('videos/')) {
          resolved = `/${resolved.substring(resolved.indexOf('videos/'))}`;
        } else if (resolved.includes(':3000')) {
          resolved = resolved.substring(resolved.indexOf(':3000') + 5);
        } else if (resolved.includes('commondatastorage.googleapis.com')) {
          resolved = resolved.includes('tokyo') || post.id === 'post_video_2' ? '/videos/sample_tokyo.mp4' : '/videos/sample_fitness.mp4';
        }
        if (resolved.startsWith('uploads/')) resolved = `/${resolved}`;
        if (resolved.startsWith('videos/')) resolved = `/${resolved}`;
        if (resolved && !items.some((it) => it.url === resolved)) {
          items.push({
            id: `${post.id}_vid_${idx}`,
            type: 'video',
            url: resolved
          });
        }
      });
    }
    if (post.images && post.images.length > 0) {
      post.images.forEach((img, idx) => {
        items.push({
          id: `${post.id}_img_${idx}`,
          type: 'image',
          url: img
        });
      });
    }
    return items;
  }, [post.mediaItems, post.video, post.videoUrls, post.videoThumbnail, post.images, resolvedVideoSrc, post.id]);

  // Viewport observation for autoplay and lazy loading
  useEffect(() => {
    const el = postCardRef.current;
    if (!el || typeof IntersectionObserver === 'undefined') return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          setIsPostInView(entry.isIntersecting && entry.intersectionRatio >= 0.05);
        });
      },
      { threshold: [0, 0.05, 0.2] }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // 최고관리자 권한 확인: 반드시 로그인 상태(isAuthenticated)이며 관리자 플래그(isAdmin 또는 handle 'admin')를 가진 계정만 인정
  const isSuperAdmin = Boolean(
    isAuthenticated && (currentUser?.isAdmin === true || currentUser?.handle === 'admin')
  );
  const isAdmin = isSuperAdmin;
  const isOwnPost = Boolean(isAuthenticated && post.authorId === currentUser.id);
  const canManagePost = isOwnPost || isSuperAdmin;
  const canEditPost = isSuperAdmin || (isOwnPost && !post.isBlocked);

  const isLiked = post.likes?.includes(currentUser.id) ?? false;
  const isBookmarked = post.bookmarks?.includes(currentUser.id) ?? false;
  const isReposted = post.reposts?.includes(currentUser.id) ?? false;
  const isFollowingAuthor = currentUser.followingIds?.includes(post.authorId) ?? false;

  const postComments = comments.filter((c) => c.postId === post.id);

  // Hierarchical comments: ensures replies to comments/replies appear directly under their target
  interface HierarchicalCommentItem {
    comm: Comment;
    depth: number;
    parentComm?: Comment;
  }

  const hierarchicalComments = useMemo<HierarchicalCommentItem[]>(() => {
    const postComms = comments.filter((c) => c.postId === post.id);
    const commMap = new Map<string, Comment>();
    const childrenMap = new Map<string, Comment[]>();

    postComms.forEach((c) => commMap.set(c.id, c));

    postComms.forEach((c) => {
      if (c.parentId && commMap.has(c.parentId)) {
        const list = childrenMap.get(c.parentId) || [];
        list.push(c);
        childrenMap.set(c.parentId, list);
      }
    });

    const result: HierarchicalCommentItem[] = [];

    const traverse = (item: Comment, depth: number, parent?: Comment) => {
      result.push({ comm: item, depth, parentComm: parent });
      const children = childrenMap.get(item.id) || [];
      // Chronological sort: older first, newer replies below
      children.sort(
        (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
      );
      children.forEach((child) => traverse(child, depth + 1, item));
    };

    // Root comments: comments where parentId is absent or parentId is not in commMap
    const rootComments = postComms.filter(
      (c) => !c.parentId || !commMap.has(c.parentId)
    );
    rootComments.sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );

    rootComments.forEach((root) => traverse(root, 0));

    return result;
  }, [comments, post.id]);

  // Poll calculation
  const hasVotedPoll = post.poll?.options?.some((opt) => opt.votes?.includes(currentUser.id)) ?? false;

  const handleProfileClick = () => {
    if (onAuthorClick) {
      onAuthorClick(post.authorId);
    } else {
      setViewingUserId(post.authorId);
      setActiveTab('profile');
    }
  };

  const handleHashtagClick = (tag: string) => {
    const cleanTag = tag.replace('#', '');
    if (onTagClick) {
      onTagClick(cleanTag);
    } else {
      setActiveTag(cleanTag);
      setActiveTab('explore');
    }
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentInput.trim()) return;

    const trimmed = commentInput.trim();
    const replyTargetHandle = replyingToComment ? `@${replyingToComment.authorHandle}` : '';
    const finalContent = replyingToComment
      ? trimmed.startsWith(replyTargetHandle)
        ? trimmed
        : `${replyTargetHandle} ${trimmed}`
      : trimmed;

    addComment(
      post.id,
      finalContent,
      replyingToComment?.id
    );

    setCommentInput('');
    setReplyingToComment(null);
  };

  const handleCopyLink = async () => {
    const postUrl = `${window.location.origin}${window.location.pathname}?post=${post.id}`;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(postUrl);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = postUrl;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopiedLink(true);
      showToast('게시물 링크가 복사되었습니다!', 'success');
      setTimeout(() => setCopiedLink(false), 2000);
    } catch (err) {
      console.error(err);
      showToast('링크 복사에 실패했습니다.', 'error');
    }
    setShowMenu(false);
  };

  // Render text with clickable hashtags
  const renderFormattedContent = (content: string) => {
    const words = content.split(/(\s+)/);
    return words.map((word, idx) => {
      if (word.startsWith('#') && word.length > 1) {
        return (
          <button
            key={idx}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleHashtagClick(word);
            }}
            className="font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer inline"
          >
            {word}
          </button>
        );
      }
      return <span key={idx}>{word}</span>;
    });
  };

  return (
    <article
      ref={postCardRef}
      id={`post-card-${post.id}`}
      className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm ring-1 ring-slate-200/50 transition-all hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50 dark:hover:border-slate-700"
    >
      {/* Header: Author Info & Actions */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div
            onClick={handleProfileClick}
            className="cursor-pointer group relative"
          >
            <img
              src={post.authorAvatar}
              alt={post.authorName}
              className="h-11 w-11 rounded-full object-cover border border-slate-200 dark:border-slate-700 group-hover:ring-2 group-hover:ring-blue-500 transition-all"
              referrerPolicy="no-referrer"
            />
          </div>

          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span
                onClick={handleProfileClick}
                className="font-bold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer text-sm md:text-base leading-tight"
              >
                {post.authorName}
              </span>
              {post.authorVerified && (
                <CheckCircle className="h-4 w-4 fill-blue-600 text-white" />
              )}
              <span className="text-xs text-slate-400">@{post.authorHandle}</span>
              <span className="text-xs text-slate-300 dark:text-slate-600">•</span>
              <span className="text-xs text-slate-400">{formatRelativeTime(post.createdAt)}</span>
              {post.isEdited && (
                <span className="text-[11px] font-medium text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.2 rounded">
                  수정됨
                </span>
              )}
              {post.isBlocked && (
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-300 dark:border-amber-800">
                  <Ban className="w-3 h-3 text-amber-600 dark:text-amber-400" />
                  관리자 차단(블라인드)
                </span>
              )}
            </div>

            {/* Sub-meta: feeling, location, visibility, following priority badge */}
            <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
              {isFollowingAuthor && !isOwnPost && (
                <span className="inline-flex items-center gap-1 rounded-full bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 text-[11px] font-bold text-blue-600 dark:text-blue-400 border border-blue-200/60 dark:border-blue-900/60">
                  <Users className="h-3 w-3" />
                  팔로잉
                </span>
              )}
              {post.feeling && (() => {
                const cat = findMoodCategoryByItem(post.feeling);
                return (
                  <span
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium border ${
                      cat?.colorClass.badge ||
                      'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-transparent'
                    }`}
                  >
                    <span>{cat?.emoji || '✨'}</span>
                    <span>{post.feeling}</span>
                  </span>
                );
              })()}
              {post.location && (
                <span className="inline-flex items-center gap-0.5 text-[11px] text-slate-400">
                  <MapPin className="h-3 w-3" />
                  {post.location}
                </span>
              )}
              {post.regionalScope && (() => {
                const scope = getRegionalScopeConfig(post.regionalScope);
                return (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onScopeClick?.(post.regionalScope!);
                    }}
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium border transition-all cursor-pointer hover:opacity-85 hover:scale-[1.02] active:scale-[0.98] ${scope.badgeClass}`}
                    title={`공개 지역: ${scope.label} - 클릭 시 이 지역 범위 게시물만 모아보기`}
                  >
                    <span>{scope.emoji}</span>
                    <span>{scope.label}</span>
                  </button>
                );
              })()}
              {post.visibility === 'followers' && (
                <span className="inline-flex items-center gap-0.5 text-[11px] text-amber-500 bg-amber-50 dark:bg-amber-950/40 px-1.5 py-0.2 rounded">
                  <Lock className="h-2.5 w-2.5" />
                  팔로워 전용
                </span>
              )}
              {post.bgm && (
                <span
                  onClick={togglePostBgm}
                  className="inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-medium bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200/80 dark:border-amber-900/60 cursor-pointer hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-colors"
                  title="클릭하여 음악 재생/일시정지"
                >
                  <Music className={`w-3 h-3 text-amber-500 ${isBgmPlaying ? 'animate-spin [animation-duration:6s]' : ''}`} />
                  <span className="font-semibold">{post.bgm.title}</span>
                  <span className="text-[10px] text-amber-600/70 dark:text-amber-400/70 hidden sm:inline">• {post.bgm.artist}</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Right Menu Button / Follow Shortcut */}
        <div className="relative flex items-center gap-2">
          {!isOwnPost && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                toggleFollow(post.authorId, post.authorName, post.authorHandle);
              }}
              className={`rounded-full px-3 py-1 text-xs font-semibold transition-all cursor-pointer ${
                isFollowingAuthor
                  ? 'border border-slate-300 bg-slate-100 text-slate-700 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-rose-950/40 dark:hover:text-rose-400'
                  : 'bg-blue-600 text-white hover:bg-blue-700 shadow-xs active:scale-95'
              }`}
            >
              {isFollowingAuthor ? '팔로잉' : '팔로우'}
            </button>
          )}

          <div className="relative">
            <button
              id={`post-menu-btn-${post.id}`}
              onClick={() => setShowMenu((prev) => !prev)}
              className="p-1.5 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <MoreHorizontal className="h-5 w-5" />
            </button>

            {showMenu && (
              <div
                className="absolute right-0 top-8 z-30 w-36 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl dark:border-slate-800 dark:bg-slate-900 animate-in fade-in zoom-in-95 duration-100"
                onClick={() => setShowMenu(false)}
              >
                <button
                  onClick={() => {
                    setShowMenu(false);
                    setIsShareModalOpen(true);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  <Share2 className="h-3.5 w-3.5 text-indigo-500" />
                  <span>게시물 공유</span>
                </button>
                <button
                  onClick={handleCopyLink}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
                >
                  {copiedLink ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                  <span>{copiedLink ? '복사 완료!' : '링크 복사'}</span>
                </button>
                <button
                  id={`post-menu-print-btn-${post.id}`}
                  onClick={() => {
                    setShowMenu(false);
                    setIsPrintModalOpen(true);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
                >
                  <Printer className="h-3.5 w-3.5 text-blue-500" />
                  <span>인쇄하기 (PDF)</span>
                </button>
                {/* Edit Post: Author (only when not blocked) or Super Admin */}
                {canEditPost && (
                  <button
                    id={`edit-post-btn-${post.id}`}
                    onClick={() => {
                      setShowMenu(false);
                      setIsEditModalOpen(true);
                    }}
                    className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    <Edit3 className="h-3.5 w-3.5 text-blue-500" />
                    <span>게시물 수정</span>
                    {isSuperAdmin && !isOwnPost && (
                      <span className="ml-auto text-[9px] font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-1.5 py-0.5 rounded">
                        관리자
                      </span>
                    )}
                  </button>
                )}

                {/* Super Admin only: Block / Blind Toggle */}
                {isSuperAdmin && (
                  <button
                    id={`admin-block-btn-${post.id}`}
                    onClick={() => {
                      setShowMenu(false);
                      if (post.isBlocked) {
                        toggleBlockPost(post.id);
                      } else {
                        setShowBlockReasonModal(true);
                      }
                    }}
                    className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold cursor-pointer ${
                      post.isBlocked
                        ? 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                        : 'text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/40'
                    }`}
                  >
                    {post.isBlocked ? (
                      <>
                        <Eye className="h-3.5 w-3.5 text-emerald-500" />
                        <span>차단 해제</span>
                        <span className="ml-auto text-[9px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded">
                          공개
                        </span>
                      </>
                    ) : (
                      <>
                        <Ban className="h-3.5 w-3.5 text-amber-500" />
                        <span>게시물 차단</span>
                        <span className="ml-auto text-[9px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-1.5 py-0.5 rounded">
                          관리자
                        </span>
                      </>
                    )}
                  </button>
                )}

                {/* Delete Post: Author or Admin */}
                {canManagePost && (
                  <button
                    id={`delete-post-btn-${post.id}`}
                    onClick={() => {
                      setShowMenu(false);
                      setShowDeleteConfirmModal(true);
                    }}
                    className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>게시물 삭제</span>
                    {isAdmin && !isOwnPost && (
                      <span className="ml-auto text-[9px] font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-1.5 py-0.5 rounded">
                        관리자
                      </span>
                    )}
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Post Blocked Banner (when post is blocked by Admin) */}
      {post.isBlocked && (
        <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50/90 p-3.5 dark:border-amber-900/60 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 text-xs">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <p className="font-bold text-slate-900 dark:text-white text-xs">
                  최고관리자에 의해 차단(블라인드)된 게시물입니다
                </p>
                {/* 최고관리자 전용: 일반회원에게는 '차단 즉시 해제' 버튼을 절대 노출하지 않음 */}
                {isSuperAdmin && (
                  <button
                    type="button"
                    onClick={() => toggleBlockPost(post.id)}
                    className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300 hover:underline cursor-pointer inline-flex items-center gap-1"
                  >
                    <Eye className="w-3 h-3" />
                    <span>차단 즉시 해제</span>
                  </button>
                )}
              </div>
              <p className="mt-1 text-slate-600 dark:text-slate-300">
                <span className="font-semibold text-slate-700 dark:text-slate-200">차단 사유:</span> {post.blockReason || '운영 정책 및 커뮤니티 가이드라인 위반'}
              </p>
              {post.blockedBy && (
                <p className="mt-0.5 text-[10px] text-slate-400 dark:text-slate-500">
                  처리자: {post.blockedBy} {post.blockedAt ? `(${formatRelativeTime(post.blockedAt)})` : ''}
                </p>
              )}
              {/* 최고관리자만 원문 확인 가능: 일반회원에게는 '원문 내용 확인하기' 버튼을 절대 노출하지 않음 */}
              {isSuperAdmin ? (
                <div className="mt-2.5 pt-2 border-t border-amber-200/70 dark:border-amber-900/40 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                    <span className="font-semibold text-amber-700 dark:text-amber-300">[최고관리자 전용]</span>
                    {showBlockedContent ? '차단된 원본 내용이 펼쳐져 있습니다.' : '일반 사용자에게는 내용이 숨김 처리됩니다.'}
                  </span>
                  <button
                    type="button"
                    id={`toggle-blocked-content-btn-${post.id}`}
                    onClick={() => setShowBlockedContent(!showBlockedContent)}
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 dark:text-amber-300 hover:text-amber-800 dark:hover:text-amber-200 bg-amber-100/80 dark:bg-amber-900/40 px-2 py-1 rounded-md transition-colors cursor-pointer"
                  >
                    {showBlockedContent ? (
                      <>
                        <EyeOff className="w-3 h-3" />
                        <span>내용 다시 숨기기</span>
                      </>
                    ) : (
                      <>
                        <Eye className="w-3 h-3" />
                        <span>원문 내용 확인하기</span>
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <div className="mt-2.5 pt-2 border-t border-amber-200/70 dark:border-amber-900/40 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>안전한 커뮤니티 환경을 위해 차단된 원본 내용은 열람할 수 없습니다.</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Post Text Body & Media (Hidden when post is blocked unless super admin toggles view) */}
      {(!post.isBlocked || (isSuperAdmin && showBlockedContent)) && (
        <>
          {/* Post Text Body */}
          {post.content && (
            <>
              <div className="mt-3 text-slate-800 dark:text-slate-200 text-sm md:text-base leading-relaxed whitespace-pre-wrap">
                {renderFormattedContent(post.content)}
              </div>
              <PostTranslator postId={post.id} content={post.content} />
            </>
          )}

          {/* Background Music (BGM) Player Card */}
          {post.bgm && (
            <div
              id={`post-bgm-bar-${post.id}`}
              onClick={togglePostBgm}
              className={`mt-3 flex items-center justify-between p-2.5 rounded-xl border transition-all cursor-pointer select-none ${
                isBgmPlaying
                  ? 'border-amber-400 bg-amber-50/90 dark:border-amber-700 dark:bg-amber-950/40 shadow-xs ring-1 ring-amber-400/50'
                  : 'border-slate-200 bg-slate-50/90 hover:border-amber-300 dark:border-slate-800 dark:bg-slate-850/60'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0 pr-2">
                {/* Vinyl / Cover Art with spinning effect */}
                <div className="relative h-10 w-10 rounded-lg overflow-hidden bg-slate-900 shrink-0 shadow-xs flex items-center justify-center">
                  {post.bgm.coverUrl ? (
                    <img
                      src={post.bgm.coverUrl}
                      alt={post.bgm.title}
                      className={`h-full w-full object-cover ${isBgmPlaying ? 'animate-spin [animation-duration:8s]' : ''}`}
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <Disc className={`h-6 w-6 text-amber-400 ${isBgmPlaying ? 'animate-spin [animation-duration:8s]' : ''}`} />
                  )}
                  {/* Center hole of vinyl */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-2.5 h-2.5 rounded-full bg-white dark:bg-slate-900 border border-slate-700/50" />
                  </div>
                </div>

                {/* Info: Title, Artist, License */}
                <div className="min-w-0 text-left">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {post.bgm.title}
                    </p>
                    <span className="inline-flex items-center gap-0.5 text-[9px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100/80 dark:bg-emerald-950/70 px-1.5 py-0.2 rounded border border-emerald-200/50 dark:border-emerald-800/40 shrink-0">
                      <ShieldCheck className="w-2.5 h-2.5 text-emerald-500" />
                      <span>{post.bgm.license || '100% 저작권 무료 (CC0)'}</span>
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                    {post.bgm.artist} • <span className="text-amber-600 dark:text-amber-400 font-medium">{post.bgm.genre}</span>
                  </p>
                </div>
              </div>

              {/* Right controls: Equalizer waves & Play/Pause button */}
              <div className="flex items-center gap-2 shrink-0">
                {/* Animated Equalizer Waves when playing */}
                <div className="flex items-end gap-0.5 h-4 px-1" title={isBgmPlaying ? '음악 재생 중' : '정지됨'}>
                  <span className={`w-0.5 rounded-full bg-amber-500 transition-all duration-150 ${isBgmPlaying ? 'h-3 animate-pulse' : 'h-1.5 opacity-40'}`} />
                  <span className={`w-0.5 rounded-full bg-amber-500 transition-all duration-150 ${isBgmPlaying ? 'h-4 animate-pulse [animation-delay:150ms]' : 'h-2 opacity-40'}`} />
                  <span className={`w-0.5 rounded-full bg-amber-500 transition-all duration-150 ${isBgmPlaying ? 'h-2.5 animate-pulse [animation-delay:300ms]' : 'h-1 opacity-40'}`} />
                  <span className={`w-0.5 rounded-full bg-amber-500 transition-all duration-150 ${isBgmPlaying ? 'h-3.5 animate-pulse [animation-delay:450ms]' : 'h-2 opacity-40'}`} />
                </div>

                <button
                  type="button"
                  onClick={togglePostBgm}
                  title={isBgmPlaying ? '음악 일시정지' : '음악 재생'}
                  className={`h-8 w-8 rounded-full flex items-center justify-center transition-all cursor-pointer shadow-xs ${
                    isBgmPlaying
                      ? 'bg-amber-500 text-white hover:bg-amber-600 scale-105'
                      : 'bg-white hover:bg-slate-100 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {isBgmLoading ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-amber-500" />
                  ) : isBgmPlaying ? (
                    <Pause className="w-3.5 h-3.5 fill-current" />
                  ) : (
                    <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Poll Component */}
          {post.poll && (
            <div className="mt-4 rounded-2xl border border-slate-200 bg-slate-50/80 p-4 dark:border-slate-800 dark:bg-slate-800/40">
              <div className="flex items-center justify-between gap-2 mb-3">
                <p className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <BarChart2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                  <span>{post.poll.question}</span>
                </p>
                {hasVotedPoll && (
                  <span className="shrink-0 text-[11px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-full border border-blue-200 dark:border-blue-800">
                    투표 완료
                  </span>
                )}
              </div>

              <div className="flex flex-col gap-2">
                {post.poll.options.map((opt) => {
                  const voteCount = opt.votes?.length || 0;
                  const percent =
                    post.poll!.totalVotes > 0
                      ? Math.round((voteCount / post.poll!.totalVotes) * 100)
                      : 0;
                  const hasSelected = opt.votes?.includes(currentUser.id) ?? false;

                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => votePoll(post.id, opt.id)}
                      className={`group relative overflow-hidden rounded-xl border p-3 text-left transition-all cursor-pointer ${
                        hasSelected
                          ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/40 shadow-sm ring-1 ring-blue-500/20'
                          : 'border-slate-200 bg-white hover:border-blue-400 hover:bg-slate-50/90 dark:border-slate-700 dark:bg-slate-800 dark:hover:bg-slate-750'
                      }`}
                    >
                      {/* Progress Bar Background */}
                      {post.poll!.totalVotes > 0 && (
                        <div
                          className={`absolute top-0 bottom-0 left-0 transition-all duration-500 ease-out ${
                            hasSelected
                              ? 'bg-blue-200/70 dark:bg-blue-900/60'
                              : 'bg-slate-200/60 dark:bg-slate-700/50'
                          }`}
                          style={{ width: `${percent}%` }}
                        />
                      )}

                      <div className="relative z-10 flex items-center justify-between">
                        <span className="text-xs md:text-sm font-medium text-slate-900 dark:text-white flex items-center gap-2">
                          <span
                            className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] font-bold transition-colors shrink-0 ${
                              hasSelected
                                ? 'border-blue-600 bg-blue-600 text-white'
                                : 'border-slate-300 dark:border-slate-600 group-hover:border-blue-400 text-transparent'
                            }`}
                          >
                            ✓
                          </span>
                          <span>{opt.text}</span>
                        </span>
                        <span className="text-xs font-bold text-slate-600 dark:text-slate-300 shrink-0 ml-2">
                          {percent}% <span className="font-normal text-slate-400">({voteCount}표)</span>
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                <span>
                  {hasVotedPoll
                    ? '💡 다른 항목을 눌러 투표를 변경하거나 취소할 수 있습니다'
                    : '👆 원하는 항목을 클릭하여 바로 투표에 참여하세요'}
                </span>
                <span className="font-medium shrink-0 ml-2">총 {post.poll.totalVotes}명 참여</span>
              </div>
            </div>
          )}

          {/* Instagram-style Media Carousel (Photos & Videos up to 10 with swipe & dots below) */}
          {postMediaItems.length > 0 && (
            <InstagramMediaCarousel
              mediaItems={postMediaItems}
              postId={post.id}
              isPostInView={isPostInView}
              onDoubleTapLike={() => {
                if (!isAuthenticated) {
                  showToast('로그인한 회원만 좋아요를 누를 수 있습니다.', 'info');
                  return;
                }
                if (isOwnPost) {
                  showToast('자신의 게시물에는 좋아요를 누를 수 없습니다. (가짜 좋아요 방지)', 'info');
                  return;
                }
                if (currentUser.isBanned) {
                  showToast('이용 정지된 회원은 좋아요를 누를 수 없습니다.', 'error');
                  return;
                }
                if (!isLiked) {
                  toggleLike(post.id);
                }
                setShowHeartAnimation(true);
                setTimeout(() => setShowHeartAnimation(false), 800);
              }}
              showHeartAnimation={showHeartAnimation}
            />
          )}

          {/* Hashtag Badges */}
          {post.tags && post.tags.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {post.tags.map((t, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleHashtagClick(t)}
                  className="inline-flex items-center rounded-lg bg-blue-50/70 dark:bg-blue-950/40 px-2 py-0.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-100 transition-colors"
                >
                  #{t.replace('#', '')}
                </button>
              ))}
            </div>
          )}
        </>
      )}

      {/* Action Bar (Like, Comment, Repost, Bookmark, Share) */}
      <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3 dark:border-slate-800/80">
        {/* Like Button */}
        <button
          id={`post-like-btn-${post.id}`}
          onClick={() => {
            if (!isAuthenticated) {
              showToast('로그인한 회원만 좋아요를 누를 수 있습니다.', 'info');
              return;
            }
            if (isOwnPost) {
              showToast('자신의 게시물에는 좋아요를 누를 수 없습니다. (가짜 좋아요 방지)', 'info');
              return;
            }
            if (currentUser.isBanned) {
              showToast('이용 정지된 회원은 좋아요를 누를 수 없습니다.', 'error');
              return;
            }
            toggleLike(post.id);
          }}
          className={`group flex items-center gap-1.5 text-xs font-semibold transition-colors ${
            isLiked
              ? 'text-rose-600 dark:text-rose-500'
              : 'text-slate-500 hover:text-rose-600 dark:text-slate-400'
          }`}
        >
          <div className="p-2 rounded-full group-hover:bg-rose-50 dark:group-hover:bg-rose-950/30 transition-colors">
            <Heart
              className={`h-4 w-4 ${
                isLiked ? 'fill-rose-500 stroke-rose-500 scale-110' : 'group-hover:scale-110'
              } transition-transform`}
            />
          </div>
          <span>{post.likes.length > 0 ? formatNumber(post.likes.length) : '좋아요'}</span>
        </button>

        {/* Comment Button */}
        <button
          id={`post-comment-btn-${post.id}`}
          onClick={() => setShowComments((prev) => !prev)}
          className={`group flex items-center gap-1.5 text-xs font-semibold transition-colors ${
            showComments
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-blue-600 dark:text-slate-400'
          }`}
        >
          <div className="p-2 rounded-full group-hover:bg-blue-50 dark:group-hover:bg-blue-950/30 transition-colors">
            <MessageCircle className="h-4 w-4 group-hover:scale-110 transition-transform" />
          </div>
          <span>{postComments.length > 0 ? formatNumber(postComments.length) : '댓글'}</span>
        </button>

        {/* Repost Button */}
        <button
          id={`post-repost-btn-${post.id}`}
          onClick={() => toggleRepost(post.id)}
          className={`group flex items-center gap-1.5 text-xs font-semibold transition-colors ${
            isReposted
              ? 'text-emerald-600 dark:text-emerald-400'
              : 'text-slate-500 hover:text-emerald-600 dark:text-slate-400'
          }`}
        >
          <div className="p-2 rounded-full group-hover:bg-emerald-50 dark:group-hover:bg-emerald-950/30 transition-colors">
            <Repeat2
              className={`h-4 w-4 ${isReposted ? 'scale-110 font-bold' : 'group-hover:scale-110'} transition-transform`}
            />
          </div>
          <span>{post.reposts.length > 0 ? formatNumber(post.reposts.length) : '리포스트'}</span>
        </button>

        {/* Bookmark Button */}
        <button
          id={`post-bookmark-btn-${post.id}`}
          onClick={() => toggleBookmark(post.id)}
          className={`group flex items-center gap-1.5 text-xs font-semibold transition-colors ${
            isBookmarked
              ? 'text-blue-600 dark:text-blue-400'
              : 'text-slate-500 hover:text-blue-600 dark:text-slate-400'
          }`}
        >
          <div className="p-2 rounded-full group-hover:bg-blue-50 dark:group-hover:bg-blue-950/30 transition-colors">
            <Bookmark
              className={`h-4 w-4 ${
                isBookmarked ? 'fill-blue-600 stroke-blue-600' : 'group-hover:scale-110'
              } transition-transform`}
            />
          </div>
          <span className="hidden sm:inline">저장</span>
        </button>

        {/* Share Button */}
        <button
          id={`post-share-btn-${post.id}`}
          onClick={() => setIsShareModalOpen(true)}
          title="게시물 공유하기 (링크 복사 / Web Share / SNS)"
          className="group flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400 transition-colors cursor-pointer"
        >
          <div className="p-2 rounded-full group-hover:bg-indigo-50 dark:group-hover:bg-indigo-950/30 transition-colors">
            <Share2 className="h-4 w-4 group-hover:scale-110 transition-transform" />
          </div>
          <span className="hidden sm:inline">공유</span>
        </button>

        {/* Print / PDF Button */}
        <button
          id={`post-print-btn-${post.id}`}
          onClick={() => setIsPrintModalOpen(true)}
          title="게시물 인쇄하기 / PDF로 저장"
          className="group flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400 transition-colors cursor-pointer"
        >
          <div className="p-2 rounded-full group-hover:bg-blue-50 dark:group-hover:bg-blue-950/30 transition-colors">
            <Printer className="h-4 w-4 group-hover:scale-110 transition-transform text-slate-500 group-hover:text-blue-600 dark:text-slate-400 dark:group-hover:text-blue-400" />
          </div>
          <span className="hidden sm:inline">인쇄</span>
        </button>
      </div>

      {/* Share Modal Dialog */}
      <ShareModal
        post={post}
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />

      {/* Print / PDF Export Modal Dialog */}
      <PrintPostModal
        post={post}
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
      />

      {/* Edit Post Modal Dialog (Author if not blocked, or Super Admin) */}
      {canEditPost && (
        <EditPostModal
          post={post}
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
        />
      )}

      {/* Admin Block Reason Input Dialog */}
      {isSuperAdmin && showBlockReasonModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setShowBlockReasonModal(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-100 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400">
                <Ban className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900 dark:text-white">
                  게시물 차단(블라인드) 설정
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {post.authorName} (@{post.authorHandle})님의 게시물
                </p>
              </div>
            </div>

            <div className="mt-4 space-y-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                차단 사유 선택 또는 직접 입력
              </label>

              <div className="flex flex-wrap gap-1.5">
                {[
                  '운영 정책 및 커뮤니티 가이드라인 위반',
                  '부적절한 홍보 / 스팸성 게시물',
                  '욕설, 비방 및 혐오 표현 포함',
                  '허위 사실 유포 및 사칭 의심',
                  '음란물 및 유해 콘텐츠 포함'
                ].map((reasonOption) => (
                  <button
                    key={reasonOption}
                    type="button"
                    onClick={() => setBlockReasonInput(reasonOption)}
                    className={`rounded-lg px-2.5 py-1 text-xs transition-colors cursor-pointer ${
                      blockReasonInput === reasonOption
                        ? 'bg-amber-500 text-white font-bold'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {reasonOption}
                  </button>
                ))}
              </div>

              <textarea
                value={blockReasonInput}
                onChange={(e) => setBlockReasonInput(e.target.value)}
                placeholder="차단 사유를 상세하게 작성해주세요..."
                rows={3}
                className="w-full rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-900 focus:border-amber-500 focus:bg-white focus:text-slate-900 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:focus:bg-slate-800 dark:focus:text-white"
              />

              <p className="text-[11px] text-slate-400 dark:text-slate-500">
                ⚠️ 차단된 게시물은 일반 피드에서 내용이 블라인드 처리되며, 차단 사유가 표시됩니다. 언제든 다시 차단 해제할 수 있습니다.
              </p>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowBlockReasonModal(false)}
                className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer"
              >
                취소
              </button>
              <button
                type="button"
                onClick={() => {
                  toggleBlockPost(post.id, blockReasonInput.trim() || '운영 정책 및 커뮤니티 가이드라인 위반');
                  setShowBlockReasonModal(false);
                }}
                className="rounded-xl bg-amber-600 px-4 py-2 text-xs font-bold text-white hover:bg-amber-700 transition-colors shadow-sm cursor-pointer"
              >
                게시물 차단 적용
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Post Confirmation Modal */}
      {showDeleteConfirmModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setShowDeleteConfirmModal(false)}
        >
          <div
            className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-150 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400">
                <Trash2 className="h-5 w-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900 dark:text-white">
                  게시물 삭제 확인
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {isAdmin && !isOwnPost ? '최고 관리자 권한으로 삭제합니다.' : '작성하신 게시물을 영구 삭제합니다.'}
                </p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300">
              <p className="line-clamp-2 italic">"{post.content}"</p>
              <p className="mt-2 text-rose-600 dark:text-rose-400 font-medium text-[11px]">
                ⚠️ 삭제 시 메인 피드와 탐색, 프로필 등 모든 화면에서 즉시 사라지며 복구할 수 없습니다.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setShowDeleteConfirmModal(false)}
                className="rounded-xl px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 cursor-pointer disabled:opacity-50"
              >
                취소
              </button>
              <button
                type="button"
                id={`confirm-delete-btn-${post.id}`}
                disabled={isDeleting}
                onClick={() => {
                  setIsDeleting(true);
                  deletePost(post.id);
                  setTimeout(() => {
                    setIsDeleting(false);
                    setShowDeleteConfirmModal(false);
                  }, 200);
                }}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-700 transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeleting ? '삭제 중...' : '게시물 영구 삭제'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Comments Drawer / Accordion */}
      {showComments && (
        <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 animate-in fade-in duration-150">
          {/* Voice Comment Recording Panel OR Text Input Form */}
          {isVoiceRecordingOpen ? (
            <div className="mb-4">
              <VoiceCommentRecorder
                initialText={commentInput}
                onSendVoice={(audioUrl, duration, text) => {
                  const finalContent = text
                    ? replyingToComment
                      ? `@${replyingToComment.authorHandle} ${text}`
                      : text
                    : '';
                  addComment(
                    post.id,
                    finalContent,
                    replyingToComment?.id,
                    audioUrl,
                    duration
                  );
                  setIsVoiceRecordingOpen(false);
                  setCommentInput('');
                  setReplyingToComment(null);
                }}
                onCancel={() => setIsVoiceRecordingOpen(false)}
              />
            </div>
          ) : (
            <form onSubmit={handleCommentSubmit} className="flex items-center gap-2 mb-4">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="h-8 w-8 rounded-full object-cover flex-shrink-0"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 min-w-0 flex flex-col">
                {replyingToComment && (
                  <div className="flex items-center justify-between bg-blue-50 dark:bg-blue-950/70 px-3 py-1.5 rounded-t-xl text-[11px] text-blue-700 dark:text-blue-200 border-t border-x border-slate-200 dark:border-slate-700 font-medium">
                    <span className="truncate">
                      @{replyingToComment.authorHandle}님에게 답글 작성 중...
                    </span>
                    <button
                      type="button"
                      onClick={() => setReplyingToComment(null)}
                      className="text-blue-500 hover:text-blue-700 dark:text-blue-300 dark:hover:text-blue-100 font-bold ml-2 cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>
                )}
                <div className="relative">
                  <input
                    type="text"
                    id={`post-comment-input-${post.id}`}
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                    placeholder={
                      replyingToComment
                        ? `@${replyingToComment.authorHandle}님에게 답글...`
                        : '댓글을 입력하거나 마이크로 음성을 남겨보세요...'
                    }
                    className={`w-full border border-slate-200 bg-slate-50 pl-4 pr-10 py-2 text-xs md:text-sm text-slate-900 placeholder-slate-400 focus:border-blue-500 focus:bg-white focus:text-slate-900 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder-slate-400 dark:focus:bg-slate-800 dark:focus:text-white dark:focus:border-blue-400 ${
                      replyingToComment ? 'rounded-b-xl border-t-0' : 'rounded-full'
                    }`}
                  />
                  {/* Microphone Icon Button (accurately positioned inside the reply input field) */}
                  <button
                    type="button"
                    id={`post-comment-mic-btn-${post.id}`}
                    onClick={() => setIsVoiceRecordingOpen(true)}
                    title="음성 메시지로 댓글 녹음하기"
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 flex h-6 w-6 items-center justify-center rounded-full text-slate-400 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/60 dark:hover:text-indigo-400 transition-colors cursor-pointer"
                  >
                    <Mic className="h-4 w-4 text-indigo-500" />
                  </button>
                </div>
              </div>
              <button
                type="submit"
                id={`post-comment-submit-btn-${post.id}`}
                disabled={!commentInput.trim()}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-600 text-white disabled:opacity-40 hover:bg-blue-700 transition-colors flex-shrink-0 cursor-pointer"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          )}

          {/* Comments List */}
          {hierarchicalComments.length === 0 ? (
            <p className="text-center py-4 text-xs text-slate-400">
              첫 번째 댓글을 남겨 소통을 시작해보세요! 💬
            </p>
          ) : (
            <div className="flex flex-col gap-2.5">
              {hierarchicalComments.map(({ comm, depth, parentComm }) => {
                const isCommentLiked = comm.likes?.includes(currentUser.id) ?? false;
                const isNested = depth > 0;
                const isDeepNested = depth >= 2;

                return (
                  <div
                    key={comm.id}
                    className={`flex items-start gap-2.5 transition-all ${
                      isDeepNested
                        ? 'pl-10 md:pl-12 relative'
                        : isNested
                        ? 'pl-6 md:pl-7 relative'
                        : 'pl-0'
                    }`}
                  >
                    {isNested && (
                      <div className="absolute left-1.5 md:left-2 top-2.5 flex items-center text-indigo-400/80 dark:text-indigo-400/60">
                        <CornerDownRight className="h-3.5 w-3.5" />
                      </div>
                    )}
                    <img
                      src={comm.authorAvatar}
                      alt={comm.authorName}
                      className={`${
                        isDeepNested ? 'h-6 w-6' : isNested ? 'h-6.5 w-6.5' : 'h-7 w-7'
                      } rounded-full object-cover flex-shrink-0 mt-0.5`}
                      referrerPolicy="no-referrer"
                    />
                    <div
                      className={`flex-1 rounded-xl p-3 transition-colors ${
                        isDeepNested
                          ? 'bg-indigo-50/50 dark:bg-slate-800/90 border border-indigo-100/70 dark:border-indigo-900/50 shadow-xs'
                          : isNested
                          ? 'bg-slate-50/90 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-700/60'
                          : 'bg-slate-50 dark:bg-slate-800/75 border border-slate-100/80 dark:border-slate-700/40'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs font-bold text-slate-900 dark:text-white">
                            {comm.authorName}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            @{comm.authorHandle}
                          </span>
                          {parentComm && (
                            <span className="inline-flex items-center gap-0.5 rounded px-1.5 py-0.2 text-[9px] font-medium bg-blue-100/70 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
                              @{parentComm.authorHandle}님에게
                            </span>
                          )}
                          <span className="text-[10px] text-slate-300 dark:text-slate-600">
                            •
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {formatRelativeTime(comm.createdAt)}
                          </span>
                          {comm.audioUrl && (
                            <span className="inline-flex items-center gap-0.5 rounded-md bg-indigo-100/80 px-1.5 py-0.2 text-[9px] font-bold text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                              <Mic className="h-2.5 w-2.5" />
                              음성 댓글
                            </span>
                          )}
                        </div>

                        <button
                          onClick={() => toggleCommentLike(comm.id)}
                          className={`flex items-center gap-1 text-[11px] ${
                            isCommentLiked
                              ? 'text-rose-600'
                              : 'text-slate-400 hover:text-rose-500'
                          }`}
                        >
                          <Heart
                            className={`h-3 w-3 ${isCommentLiked ? 'fill-rose-500' : ''}`}
                          />
                          {comm.likes.length > 0 && <span>{comm.likes.length}</span>}
                        </button>
                      </div>

                      {/* Text content if present */}
                      {comm.content && comm.content !== '🎙️ 음성 댓글' && (
                        <p className="mt-1.5 text-xs text-slate-900 dark:text-slate-100 leading-relaxed font-normal break-words">
                          {comm.content}
                        </p>
                      )}

                      {/* Voice Audio Player */}
                      {comm.audioUrl && (
                        <VoiceCommentPlayer
                          audioUrl={comm.audioUrl}
                          duration={comm.audioDuration}
                        />
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          setReplyingToComment(comm);
                          setIsVoiceRecordingOpen(false);
                        }}
                        className="mt-1.5 text-[10px] font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer flex items-center gap-1"
                      >
                        <CornerDownRight className="h-2.5 w-2.5" />
                        <span>답글 달기</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </article>
  );
};
