import React, { useState } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  X,
  Camera,
  Sparkles,
  Plus,
  Trash2,
  Check,
  Tag,
  User as UserIcon,
  Image as ImageIcon,
  Heart,
  Globe,
  MapPin,
  Smile,
  Instagram,
  Github,
  Layers,
  CheckCircle,
  ShieldCheck
} from 'lucide-react';
import {
  PRESET_AVATARS,
  PRESET_BANNERS,
  POPULAR_INTEREST_CATEGORIES,
  PRESET_FEATURED_PHOTOS
} from '../data/mockData';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type EditTab = 'info' | 'visuals' | 'interests' | 'featured';

export const EditProfileModal: React.FC<EditProfileModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, updateProfile, openEditSignupInfoModal } = useSocial();

  const [activeTab, setActiveTab] = useState<EditTab>('info');

  // Form State
  const [name, setName] = useState(currentUser.name || '');
  const [handle, setHandle] = useState(currentUser.handle || '');
  const [bio, setBio] = useState(currentUser.bio || '');
  const [statusMessage, setStatusMessage] = useState(currentUser.statusMessage || '');
  const [location, setLocation] = useState(currentUser.location || '');
  const [website, setWebsite] = useState(currentUser.website || '');
  const [githubUrl, setGithubUrl] = useState(currentUser.githubUrl || '');
  const [instagramUrl, setInstagramUrl] = useState(currentUser.instagramUrl || '');
  const [role, setRole] = useState(currentUser.role || '');
  const [avatar, setAvatar] = useState(currentUser.avatar || '');
  const [banner, setBanner] = useState(currentUser.banner || '');
  const [interests, setInterests] = useState<string[]>(currentUser.interests || []);
  const [featuredPhotos, setFeaturedPhotos] = useState<string[]>(
    currentUser.featuredPhotos || []
  );

  // Helper inputs
  const [customInterest, setCustomInterest] = useState('');
  const [customFeaturedUrl, setCustomFeaturedUrl] = useState('');

  if (!isOpen) return null;

  const handleAddInterest = (tag: string) => {
    const trimmed = tag.trim();
    if (!trimmed) return;
    if (interests.includes(trimmed)) return;
    if (interests.length >= 12) return;
    setInterests([...interests, trimmed]);
    setCustomInterest('');
  };

  const handleRemoveInterest = (tagToRemove: string) => {
    setInterests(interests.filter((t) => t !== tagToRemove));
  };

  const handleAddFeaturedPhoto = (photoUrl: string) => {
    const trimmed = photoUrl.trim();
    if (!trimmed) return;
    if (featuredPhotos.includes(trimmed)) return;
    if (featuredPhotos.length >= 6) return;
    setFeaturedPhotos([...featuredPhotos, trimmed]);
    setCustomFeaturedUrl('');
  };

  const handleRemoveFeaturedPhoto = (urlToRemove: string) => {
    setFeaturedPhotos(featuredPhotos.filter((url) => url !== urlToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name: name.trim(),
      handle: handle.trim(),
      bio: bio.trim(),
      statusMessage: statusMessage.trim() || undefined,
      location: location.trim() || undefined,
      website: website.trim() || undefined,
      githubUrl: githubUrl.trim() || undefined,
      instagramUrl: instagramUrl.trim() || undefined,
      role: role.trim() || undefined,
      avatar,
      banner,
      interests,
      featuredPhotos
    });
    onClose();
  };

  return (
    <div
      id="edit-profile-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50 max-h-[90vh] overflow-y-auto flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                개인화 프로필 설정
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                내 정보, 대표 사진, 관심사를 설정하여 나만의 프로필을 완성하세요
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Banner linking to Edit Signup Info */}
        <div className="mt-3 flex items-center justify-between gap-2.5 rounded-xl border border-indigo-200/80 bg-indigo-50/70 p-3 text-xs dark:border-indigo-900/60 dark:bg-indigo-950/40">
          <div className="flex items-center gap-2 min-w-0">
            <ShieldCheck className="h-4 w-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <p className="text-slate-700 dark:text-slate-300 truncate">
              가입 이메일, 비밀번호, 아이디, 활동지역 등 <strong>회원가입 시 입력했던 계정 정보</strong>를 수정하시겠어요?
            </p>
          </div>
          <button
            type="button"
            id="edit-profile-to-signup-info-btn"
            onClick={() => {
              onClose();
              openEditSignupInfoModal();
            }}
            className="shrink-0 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition-colors whitespace-nowrap cursor-pointer"
          >
            회원가입 정보 수정 열기
          </button>
        </div>

        {/* Live Preview Card Mini */}
        <div className="my-4 rounded-xl border border-slate-200 bg-slate-50 p-3.5 dark:border-slate-800 dark:bg-slate-800/40">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              실시간 미리보기
            </span>
            {statusMessage && (
              <span className="text-xs bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-200 px-2 py-0.5 rounded-full font-medium truncate max-w-[200px]">
                💭 {statusMessage}
              </span>
            )}
          </div>
          <div className="relative h-20 w-full rounded-lg overflow-hidden bg-slate-300 dark:bg-slate-700">
            <img
              src={banner}
              alt="Banner preview"
              className="h-full w-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex items-end gap-3 -mt-6 px-3">
            <img
              src={avatar}
              alt="Avatar preview"
              className="h-12 w-12 rounded-full object-cover border-2 border-white shadow-md dark:border-slate-900"
              referrerPolicy="no-referrer"
            />
            <div className="pb-1 min-w-0 flex-1">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="font-bold text-sm text-slate-900 dark:text-white truncate">
                  {name || '이름 없음'}
                </span>
                {role && (
                  <span className="text-[10px] bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300 px-2 py-0.2 rounded-full">
                    {role}
                  </span>
                )}
              </div>
              <span className="text-xs text-slate-400 block truncate">@{handle}</span>
            </div>
          </div>
          {interests.length > 0 && (
            <div className="mt-2.5 flex flex-wrap gap-1 px-3">
              {interests.slice(0, 5).map((t, idx) => (
                <span
                  key={idx}
                  className="rounded-md bg-blue-50 px-2 py-0.5 text-[11px] font-medium text-blue-700 dark:bg-blue-950/60 dark:text-blue-300"
                >
                  #{t}
                </span>
              ))}
              {interests.length > 5 && (
                <span className="text-[10px] text-slate-400 self-center">
                  +{interests.length - 5}개 더보기
                </span>
              )}
            </div>
          )}
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 mb-4">
          <button
            type="button"
            onClick={() => setActiveTab('info')}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'info'
                ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400'
            }`}
          >
            <UserIcon className="h-4 w-4" />
            <span>기본 정보</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('visuals')}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'visuals'
                ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400'
            }`}
          >
            <Camera className="h-4 w-4" />
            <span>프로필 사진 & 커버</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('interests')}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'interests'
                ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400'
            }`}
          >
            <Tag className="h-4 w-4" />
            <span>관심사 & 취미 ({interests.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('featured')}
            className={`flex items-center gap-1.5 py-2.5 px-3 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'featured'
                ? 'border-blue-600 text-blue-600 dark:border-blue-400 dark:text-blue-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400'
            }`}
          >
            <Layers className="h-4 w-4" />
            <span>대표 사진첩 ({featuredPhotos.length}/6)</span>
          </button>
        </div>

        {/* Tab Content Form */}
        <form onSubmit={handleSubmit} className="flex-1 flex flex-col justify-between">
          <div className="flex flex-col gap-4">
            {/* TAB 1: BASIC INFO */}
            {activeTab === 'info' && (
              <div className="flex flex-col gap-3.5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                      이름 *
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      placeholder="이름 입력"
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:bg-white focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                      아이디 (@handle) *
                    </label>
                    <input
                      type="text"
                      value={handle}
                      onChange={(e) => setHandle(e.target.value)}
                      required
                      placeholder="username"
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:bg-white focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                      직업 / 역할 (Role)
                    </label>
                    <input
                      type="text"
                      value={role}
                      onChange={(e) => setRole(e.target.value)}
                      placeholder="예: 프론트엔드 개발자, 포토그래퍼, 학생"
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 focus:bg-white focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block flex items-center gap-1">
                      <Smile className="h-3.5 w-3.5 text-blue-500" />
                      오늘의 상태 메시지 / 기분
                    </label>
                    <input
                      type="text"
                      value={statusMessage}
                      onChange={(e) => setStatusMessage(e.target.value)}
                      placeholder="예: 새로운 프로젝트 구상 중 💡"
                      maxLength={40}
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                    소개글 (Bio)
                  </label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    rows={3}
                    placeholder="자신을 자유롭게 소개해보세요..."
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5 text-slate-400" />
                      위치
                    </label>
                    <input
                      type="text"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      placeholder="예: 서울 강남구"
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block flex items-center gap-1">
                      <Globe className="h-3.5 w-3.5 text-slate-400" />
                      웹사이트
                    </label>
                    <input
                      type="url"
                      value={website}
                      onChange={(e) => setWebsite(e.target.value)}
                      placeholder="https://mywebsite.com"
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block flex items-center gap-1">
                      <Github className="h-3.5 w-3.5 text-slate-700 dark:text-slate-300" />
                      GitHub 링크
                    </label>
                    <input
                      type="url"
                      value={githubUrl}
                      onChange={(e) => setGithubUrl(e.target.value)}
                      placeholder="https://github.com/..."
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block flex items-center gap-1">
                      <Instagram className="h-3.5 w-3.5 text-pink-500" />
                      Instagram 링크
                    </label>
                    <input
                      type="url"
                      value={instagramUrl}
                      onChange={(e) => setInstagramUrl(e.target.value)}
                      placeholder="https://instagram.com/..."
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: VISUALS (AVATAR & COVER) */}
            {activeTab === 'visuals' && (
              <div className="flex flex-col gap-5">
                {/* Avatar Section */}
                <div>
                  <label className="text-xs font-bold text-slate-800 dark:text-slate-200 mb-2 block">
                    아바타 프로필 사진 선택
                  </label>
                  <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 mb-3">
                    {PRESET_AVATARS.map((pAvatar, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setAvatar(pAvatar)}
                        className={`relative aspect-square rounded-full overflow-hidden border-2 transition-all ${
                          avatar === pAvatar
                            ? 'border-blue-600 ring-2 ring-blue-600/30 scale-105 shadow-md'
                            : 'border-transparent opacity-75 hover:opacity-100'
                        }`}
                      >
                        <img
                          src={pAvatar}
                          alt={`Avatar preset ${idx + 1}`}
                          className="h-full w-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        {avatar === pAvatar && (
                          <div className="absolute inset-0 flex items-center justify-center bg-blue-600/30 text-white">
                            <Check className="h-3.5 w-3.5 stroke-[3]" />
                          </div>
                        )}
                      </button>
                    ))}
                  </div>

                  <label className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1 block">
                    직접 아바타 이미지 URL 입력
                  </label>
                  <input
                    type="url"
                    value={avatar}
                    onChange={(e) => setAvatar(e.target.value)}
                    placeholder="https://..."
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                  />
                </div>

                {/* Banner Section */}
                <div>
                  <label className="text-xs font-bold text-slate-800 dark:text-slate-200 mb-2 block">
                    프로필 배경 커버 테마 선택
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-3">
                    {PRESET_BANNERS.map((pBanner, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setBanner(pBanner.url)}
                        className={`relative h-20 rounded-xl overflow-hidden border-2 transition-all text-left group ${
                          banner === pBanner.url
                            ? 'border-blue-600 ring-2 ring-blue-600/30 shadow-md'
                            : 'border-slate-200 dark:border-slate-700 opacity-85 hover:opacity-100'
                        }`}
                      >
                        <img
                          src={pBanner.url}
                          alt={pBanner.name}
                          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-200"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end p-2">
                          <span className="text-[11px] font-bold text-white leading-tight">
                            {pBanner.name}
                          </span>
                        </div>
                        {banner === pBanner.url && (
                          <div className="absolute top-1.5 right-1.5 h-5 w-5 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-sm">
                            <Check className="h-3 w-3 stroke-[3]" />
                          </div>
                        )}
                      </button>
                    ))}
                  </div>

                  <label className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1 block">
                    직접 배경 커버 이미지 URL 입력
                  </label>
                  <input
                    type="url"
                    value={banner}
                    onChange={(e) => setBanner(e.target.value)}
                    placeholder="https://..."
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                  />
                </div>
              </div>
            )}

            {/* TAB 3: INTERESTS & TAGS */}
            {activeTab === 'interests' && (
              <div className="flex flex-col gap-4">
                {/* Active tags */}
                <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-slate-800 dark:bg-slate-800/40">
                  <div className="flex items-center justify-between mb-2.5">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      내 관심사 태그 ({interests.length}/12)
                    </span>
                    {interests.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setInterests([])}
                        className="text-[11px] text-rose-500 hover:underline"
                      >
                        모두 지우기
                      </button>
                    )}
                  </div>

                  {interests.length === 0 ? (
                    <p className="text-xs text-slate-400 py-2">
                      아직 추가된 관심사가 없습니다. 아래 추천 태그를 클릭하거나 직접 입력하세요.
                    </p>
                  ) : (
                    <div className="flex flex-wrap gap-1.5">
                      {interests.map((tag) => (
                        <span
                          key={tag}
                          className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-2.5 py-1 text-xs font-semibold text-white shadow-xs"
                        >
                          #{tag}
                          <button
                            type="button"
                            onClick={() => handleRemoveInterest(tag)}
                            className="hover:text-blue-200"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Custom tag input */}
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                    관심사 직접 입력하여 추가
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={customInterest}
                      onChange={(e) => setCustomInterest(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddInterest(customInterest);
                        }
                      }}
                      placeholder="예: 클라이밍, 인공지능, 브런치 맛집..."
                      maxLength={20}
                      className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                    />
                    <button
                      type="button"
                      onClick={() => handleAddInterest(customInterest)}
                      disabled={!customInterest.trim() || interests.includes(customInterest.trim())}
                      className="flex items-center gap-1 rounded-lg bg-blue-600 px-4 py-2 text-xs font-bold text-white hover:bg-blue-700 disabled:opacity-40 transition-colors"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>추가</span>
                    </button>
                  </div>
                </div>

                {/* Popular Interest Categories */}
                <div className="flex flex-col gap-3">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    카테고리별 추천 관심사
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {POPULAR_INTEREST_CATEGORIES.map((cat) => (
                      <div
                        key={cat.category}
                        className="rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-800/60"
                      >
                        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200 mb-2">
                          <span>{cat.icon}</span>
                          <span>{cat.category}</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {cat.tags.map((t) => {
                            const isSelected = interests.includes(t);
                            return (
                              <button
                                key={t}
                                type="button"
                                onClick={() =>
                                  isSelected ? handleRemoveInterest(t) : handleAddInterest(t)
                                }
                                className={`rounded-md px-2 py-1 text-[11px] font-medium transition-all ${
                                  isSelected
                                    ? 'bg-blue-100 text-blue-700 border border-blue-300 dark:bg-blue-900/60 dark:text-blue-200 dark:border-blue-700'
                                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-700/60 dark:text-slate-300 dark:hover:bg-slate-700'
                                }`}
                              >
                                {isSelected ? '✓ ' : '+ '}#{t}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: FEATURED SHOWCASE PHOTOS */}
            {activeTab === 'featured' && (
              <div className="flex flex-col gap-4">
                <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-slate-800 dark:bg-slate-800/40">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      현재 등록된 대표 사진 ({featuredPhotos.length}/6)
                    </span>
                    <span className="text-[11px] text-slate-400">
                      프로필 상단에 하이라이트 사진으로 노출됩니다
                    </span>
                  </div>

                  {featuredPhotos.length === 0 ? (
                    <p className="text-xs text-slate-400 py-3 text-center">
                      등록된 대표 사진이 없습니다. 아래 추천 사진을 선택하거나 직접 추가하세요.
                    </p>
                  ) : (
                    <div className="grid grid-cols-3 gap-2">
                      {featuredPhotos.map((url, i) => (
                        <div
                          key={i}
                          className="relative aspect-square rounded-lg overflow-hidden group border border-slate-200 dark:border-slate-700"
                        >
                          <img
                            src={url}
                            alt={`Featured ${i + 1}`}
                            className="h-full w-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <button
                            type="button"
                            onClick={() => handleRemoveFeaturedPhoto(url)}
                            className="absolute top-1.5 right-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-slate-900/70 text-white hover:bg-rose-600 transition-colors"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Add Custom Featured Photo */}
                <div>
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 block">
                    대표 사진 직접 URL 추가
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={customFeaturedUrl}
                      onChange={(e) => setCustomFeaturedUrl(e.target.value)}
                      placeholder="https://images.unsplash.com/..."
                      className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:bg-white focus:text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-white dark:placeholder:text-slate-500 dark:focus:bg-slate-900 dark:focus:text-white dark:focus:border-blue-500"
                    />
                    <button
                      type="button"
                      onClick={() => handleAddFeaturedPhoto(customFeaturedUrl)}
                      disabled={
                        !customFeaturedUrl.trim() ||
                        featuredPhotos.includes(customFeaturedUrl.trim()) ||
                        featuredPhotos.length >= 6
                      }
                      className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-bold text-white hover:bg-blue-700 disabled:opacity-40 transition-colors"
                    >
                      추가
                    </button>
                  </div>
                </div>

                {/* Preset Featured Photos Picker */}
                <div>
                  <label className="text-xs font-bold text-slate-800 dark:text-slate-200 mb-2 block">
                    추천 갤러리 사진에서 선택
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {PRESET_FEATURED_PHOTOS.map((pPhoto, idx) => {
                      const isAdded = featuredPhotos.includes(pPhoto);
                      return (
                        <button
                          key={idx}
                          type="button"
                          disabled={isAdded && featuredPhotos.length >= 6}
                          onClick={() =>
                            isAdded
                              ? handleRemoveFeaturedPhoto(pPhoto)
                              : handleAddFeaturedPhoto(pPhoto)
                          }
                          className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                            isAdded
                              ? 'border-blue-600 ring-2 ring-blue-600/30'
                              : 'border-transparent opacity-80 hover:opacity-100'
                          }`}
                        >
                          <img
                            src={pPhoto}
                            alt={`Preset ${idx + 1}`}
                            className="h-full w-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          {isAdded && (
                            <div className="absolute inset-0 flex items-center justify-center bg-blue-600/40 text-white font-bold text-xs">
                              <CheckCircle className="h-5 w-5 fill-blue-600 text-white" />
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer Submit Buttons */}
          <div className="flex items-center justify-between pt-6 border-t border-slate-100 dark:border-slate-800 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 transition-colors"
            >
              취소
            </button>
            <div className="flex gap-2">
              <button
                type="submit"
                id="save-profile-btn"
                className="rounded-lg bg-blue-600 px-6 py-2 text-xs md:text-sm font-bold text-white shadow-md shadow-blue-600/25 hover:bg-blue-700 active:scale-95 transition-all"
              >
                변경사항 저장하기
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
