import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useSocial } from '../context/SocialContext';
import { Post, PostMediaItem } from '../types';
import { InstagramMediaCarousel } from './InstagramMediaCarousel';
import {
  X,
  Image as ImageIcon,
  Video,
  Smile,
  MapPin,
  Globe,
  Lock,
  Plus,
  Trash2,
  Upload,
  Play,
  CheckCircle,
  Film,
  Edit3,
  RotateCw,
  Loader2,
  Check,
  ShieldAlert,
  ArrowLeft,
  ArrowRight,
  Music,
  Disc,
  ShieldCheck,
  Pause,
  Search,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { extractHashtags } from '../utils/formatters';
import { compressImageFile, generateVideoThumbnail } from '../utils/imageCompressor';
import { uploadMediaFile } from '../services/mediaUpload';
import { getAutoLocation } from '../utils/geolocation';
import { MOOD_CATEGORIES, MoodCategoryId, findMoodCategoryByItem } from '../data/feelingCategories';
import { REGIONAL_SCOPES, getRegionalScopeConfig, RegionalScope } from '../data/regionalScope';
import { StoryBgm } from '../types';
import { resolveBgmAudioUrl, PRESET_STORY_BGMS, COPYRIGHT_FREE_CATEGORIES } from '../data/storyBgmData';

interface EditPostModalProps {
  post: Post;
  isOpen: boolean;
  onClose: () => void;
}

export const EditPostModal: React.FC<EditPostModalProps> = ({ post, isOpen, onClose }) => {
  const { currentUser, updatePost } = useSocial();
  
  const getInitialMedia = useCallback((): PostMediaItem[] => {
    if (post.mediaItems && post.mediaItems.length > 0) {
      return [...post.mediaItems];
    }
    const list: PostMediaItem[] = [];
    if (post.video) {
      list.push({
        id: `${post.id}_vid`,
        type: 'video',
        url: post.video,
        thumbnail: post.videoThumbnail
      });
    }
    if (post.images && post.images.length > 0) {
      post.images.forEach((img, idx) => {
        list.push({
          id: `${post.id}_img_${idx}`,
          type: 'image',
          url: img
        });
      });
    }
    return list;
  }, [post]);

  const [content, setContent] = useState(post.content || '');
  const [attachedMedia, setAttachedMedia] = useState<PostMediaItem[]>(getInitialMedia);
  const attachedMediaRef = useRef<PostMediaItem[]>(attachedMedia);
  useEffect(() => {
    attachedMediaRef.current = attachedMedia;
  }, [attachedMedia]);

  const [isProcessingMedia, setIsProcessingMedia] = useState(false);
  const [processingStatusText, setProcessingStatusText] = useState('');
  const [customPhotoUrl, setCustomPhotoUrl] = useState('');
  const [showPhotoPicker, setShowPhotoPicker] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  const [customVideoUrl, setCustomVideoUrl] = useState('');
  const [showVideoPicker, setShowVideoPicker] = useState(false);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const [feeling, setFeeling] = useState<string | undefined>(post.feeling);
  const [showFeelings, setShowFeelings] = useState(false);
  const [selectedMoodCategory, setSelectedMoodCategory] = useState<MoodCategoryId>(() => {
    const cat = findMoodCategoryByItem(post.feeling);
    return cat ? cat.id : 'positive';
  });
  const [location, setLocation] = useState(post.location || '');
  const [showLocationInput, setShowLocationInput] = useState(Boolean(post.location));
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [visibility, setVisibility] = useState<'public' | 'followers'>(post.visibility || 'public');
  const [regionalScope, setRegionalScope] = useState<RegionalScope>(post.regionalScope || 'national');
  const currentScopeConfig = getRegionalScopeConfig(regionalScope);

  // Reset/sync state when post changes or modal opens
  useEffect(() => {
    if (isOpen) {
      setContent(post.content || '');
      setAttachedMedia(getInitialMedia());
      setFeeling(post.feeling);
      setLocation(post.location || '');
      setShowLocationInput(Boolean(post.location));
      setVisibility(post.visibility || 'public');
      setRegionalScope(post.regionalScope || 'national');
      setSelectedBgm(post.bgm || null);
      setShowPhotoPicker(false);
      setShowVideoPicker(false);
      setShowFeelings(false);
      setShowBgmDrawer(false);
    }
  }, [isOpen, post, getInitialMedia]);

  // Background Music (BGM) state
  const [selectedBgm, setSelectedBgm] = useState<StoryBgm | null>(post.bgm || null);
  const [showBgmDrawer, setShowBgmDrawer] = useState(false);
  const [bgmSearchQuery, setBgmSearchQuery] = useState('');
  const [activeBgmCategory, setActiveBgmCategory] = useState<string>('all');
  const [previewingBgmId, setPreviewingBgmId] = useState<string | null>(null);
  const [customBgms, setCustomBgms] = useState<StoryBgm[]>([]);
  const [showCustomAudioUrlInput, setShowCustomAudioUrlInput] = useState(false);
  const [customAudioUrlInput, setCustomAudioUrlInput] = useState('');
  const [customAudioTitleInput, setCustomAudioTitleInput] = useState('');
  const postBgmAudioRef = useRef<HTMLAudioElement | null>(null);
  const audioFileInputRef = useRef<HTMLInputElement | null>(null);

  // Stop preview audio when modal closes or unmounts
  useEffect(() => {
    return () => {
      if (postBgmAudioRef.current) {
        postBgmAudioRef.current.pause();
        postBgmAudioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (!isOpen && postBgmAudioRef.current) {
      postBgmAudioRef.current.pause();
      setPreviewingBgmId(null);
    }
  }, [isOpen]);

  const handleTogglePreviewAudio = async (bgm: StoryBgm, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (previewingBgmId === bgm.id) {
      postBgmAudioRef.current?.pause();
      setPreviewingBgmId(null);
      return;
    }

    if (postBgmAudioRef.current) {
      postBgmAudioRef.current.pause();
    }

    let url = bgm.audioUrl;
    if (!url || (!url.startsWith('blob:') && !url.startsWith('data:') && !url.startsWith('http'))) {
      url = await resolveBgmAudioUrl(bgm);
    }
    if (!url) return;

    const audio = new Audio(url);
    audio.volume = 0.6;
    audio.play().catch(() => {});
    audio.onended = () => setPreviewingBgmId(null);
    postBgmAudioRef.current = audio;
    setPreviewingBgmId(bgm.id);
  };

  const handleSelectBgm = async (bgm: StoryBgm | null) => {
    if (bgm) {
      let resolved = bgm;
      if (!bgm.audioUrl || (!bgm.audioUrl.startsWith('blob:') && !bgm.audioUrl.startsWith('data:') && !bgm.audioUrl.startsWith('http'))) {
        const url = await resolveBgmAudioUrl(bgm);
        resolved = { ...bgm, audioUrl: url };
      }
      setSelectedBgm(resolved);
      handleTogglePreviewAudio(resolved);
    } else {
      setSelectedBgm(null);
      if (postBgmAudioRef.current) {
        postBgmAudioRef.current.pause();
        setPreviewingBgmId(null);
      }
    }
  };

  const handleProcessAudioFile = async (file: File) => {
    if (!file.type.startsWith('audio/') && !/\.(mp3|wav|m4a|aac|ogg|flac)$/i.test(file.name)) {
      return;
    }
    if (file.size > 50 * 1024 * 1024) {
      return;
    }
    const localUrl = URL.createObjectURL(file);
    const cleanTitle = file.name.replace(/\.[^/.]+$/, '');
    const customTrack: StoryBgm = {
      id: `custom_bgm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      title: cleanTitle,
      artist: currentUser.name || '직접 등록한 음원',
      genre: '사용자 BGM',
      audioUrl: localUrl,
      coverUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&auto=format&fit=crop&q=80',
      duration: 30,
      license: '사용자 직접 등록 (저작권 무료)',
      isCustom: true
    };
    setCustomBgms((prev) => [customTrack, ...prev]);
    setSelectedBgm(customTrack);
    handleTogglePreviewAudio(customTrack);

    try {
      const uploadRes = await uploadMediaFile(file);
      if (uploadRes && uploadRes.url) {
        customTrack.audioUrl = uploadRes.url;
        setSelectedBgm((curr) => (curr?.id === customTrack.id ? { ...curr, audioUrl: uploadRes.url } : curr));
        setCustomBgms((prev) => prev.map((b) => (b.id === customTrack.id ? { ...b, audioUrl: uploadRes.url } : b)));
      }
    } catch (err) {
      console.warn('[AudioUpload] Server upload fallback to local URL:', err);
    } finally {
      if (audioFileInputRef.current) audioFileInputRef.current.value = '';
    }
  };

  const handleAddCustomAudioUrl = (url: string, title?: string) => {
    if (!url.trim()) return;
    const cleanTitle = title?.trim() || '외부 웹 음원';
    const customTrack: StoryBgm = {
      id: `custom_url_${Date.now()}`,
      title: cleanTitle,
      artist: '외부 웹 링크',
      genre: '웹 BGM',
      audioUrl: url.trim(),
      coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&auto=format&fit=crop&q=80',
      duration: 30,
      license: '웹 음원 링크 (저작권 무료)',
      isCustom: true
    };
    setCustomBgms((prev) => [customTrack, ...prev]);
    setSelectedBgm(customTrack);
    handleTogglePreviewAudio(customTrack);
  };

  if (!isOpen) return null;

  const addMediaItem = (type: 'image' | 'video', url: string, thumbnail?: string) => {
    if (attachedMedia.length >= 10) return;
    const newItem: PostMediaItem = {
      id: `media_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      type,
      url,
      thumbnail
    };
    setAttachedMedia((prev) => [...prev, newItem]);
  };

  const removeMediaItem = (id: string) => {
    setAttachedMedia((prev) => prev.filter((p) => p.id !== id));
  };

  const moveMediaItem = (index: number, direction: 'left' | 'right') => {
    setAttachedMedia((prev) => {
      const targetIndex = direction === 'left' ? index - 1 : index + 1;
      if (targetIndex < 0 || targetIndex >= prev.length) return prev;
      const copy = [...prev];
      const temp = copy[index];
      copy[index] = copy[targetIndex];
      copy[targetIndex] = temp;
      return copy;
    });
  };

  const handleAddCustomPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (customPhotoUrl.trim() && attachedMedia.length < 10) {
      addMediaItem('image', customPhotoUrl.trim());
      setCustomPhotoUrl('');
    }
  };

  const handlePhotoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const remainingSlots = 10 - attachedMedia.length;
    if (remainingSlots <= 0) return;
    const filesToProcess: File[] = (Array.from(files) as File[]).slice(0, remainingSlots);

    setIsProcessingMedia(true);
    setProcessingStatusText(`사진 ${filesToProcess.length}장 서버 업로드 중...`);
    try {
      const processedItems: PostMediaItem[] = [];
      for (let i = 0; i < filesToProcess.length; i++) {
        const file = filesToProcess[i];
        setProcessingStatusText(`사진 처리 중 (${i + 1}/${filesToProcess.length})...`);
        const uploadRes = await uploadMediaFile(file, (msg) => {
          setProcessingStatusText(`사진 (${i + 1}/${filesToProcess.length}): ${msg}`);
        });
        processedItems.push({
          id: `media_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
          type: 'image',
          url: uploadRes.url,
          thumbnail: uploadRes.thumbnail
        });
      }
      setAttachedMedia((prev) => {
        const merged = [...prev, ...processedItems];
        return merged.slice(0, 10);
      });
    } catch (err) {
      console.error('Error optimizing photo files in edit modal:', err);
    } finally {
      setIsProcessingMedia(false);
      setProcessingStatusText('');
      if (photoInputRef.current) photoInputRef.current.value = '';
    }
  };

  const handleAddCustomVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (customVideoUrl.trim() && attachedMedia.length < 10) {
      addMediaItem('video', customVideoUrl.trim());
      setCustomVideoUrl('');
      setShowVideoPicker(false);
    }
  };

  const handleVideoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawFiles = e.target.files;
    if (!rawFiles || rawFiles.length === 0) return;

    const fileArray = Array.from(rawFiles);
    if (videoInputRef.current) {
      videoInputRef.current.value = '';
    }

    const currentMediaCount = attachedMediaRef.current.length;
    const remainingSlots = 10 - currentMediaCount;
    if (remainingSlots <= 0) return;

    const filesToProcess = fileArray.slice(0, remainingSlots);

    setIsProcessingMedia(true);
    let successfullyAddedCount = 0;

    try {
      for (let i = 0; i < filesToProcess.length; i++) {
        const file = filesToProcess[i];
        setProcessingStatusText(`동영상 전송 준비 중 (${i + 1}/${filesToProcess.length}): ${file.name || '동영상'}...`);

        try {
          const uploadRes = await uploadMediaFile(file, (msg) => {
            setProcessingStatusText(`동영상 (${i + 1}/${filesToProcess.length}): ${msg}`);
          });

          const newMediaItem: PostMediaItem = {
            id: `media_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 9)}`,
            type: 'video',
            url: uploadRes.url,
            thumbnail: uploadRes.thumbnail
          };

          setAttachedMedia((prev) => {
            if (prev.length >= 10) return prev;
            const updated = [...prev, newMediaItem];
            attachedMediaRef.current = updated;
            return updated;
          });

          successfullyAddedCount++;
        } catch (itemErr) {
          console.error(`[EditVideoUpload] 파일(${file.name}) 처리 중 오류:`, itemErr);
          try {
            const blobUrl = URL.createObjectURL(file);
            const fallbackItem: PostMediaItem = {
              id: `media_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 9)}`,
              type: 'video',
              url: blobUrl,
            };
            setAttachedMedia((prev) => {
              if (prev.length >= 10) return prev;
              const updated = [...prev, fallbackItem];
              attachedMediaRef.current = updated;
              return updated;
            });
          } catch {}
        }
      }

      setShowVideoPicker(false);
    } catch (err) {
      console.error('Error processing video files in edit modal:', err);
    } finally {
      setIsProcessingMedia(false);
      setProcessingStatusText('');
      if (videoInputRef.current) {
        videoInputRef.current.value = '';
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && attachedMedia.length === 0) {
      return;
    }

    const tags = extractHashtags(content);
    const resolvedImages = attachedMedia.filter((m) => m.type === 'image').map((m) => m.url);
    const firstVideo = attachedMedia.find((m) => m.type === 'video');

    updatePost(post.id, {
      content: content.trim(),
      images: resolvedImages.length > 0 ? resolvedImages : undefined,
      video: firstVideo ? firstVideo.url : undefined,
      videoThumbnail: firstVideo ? firstVideo.thumbnail : undefined,
      mediaItems: attachedMedia.length > 0 ? attachedMedia : undefined,
      tags: tags.length > 0 ? tags : undefined,
      feeling: feeling,
      location: location.trim() || undefined,
      bgm: selectedBgm,
      visibility: visibility,
      regionalScope: regionalScope
    });

    onClose();
  };

  const isSaveDisabled = !content.trim() && attachedMedia.length === 0;

  return (
    <div
      id="edit-post-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="edit-post-modal-container"
        className="w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className={`p-1.5 rounded-lg ${
              currentUser.isAdmin || currentUser.handle === 'admin'
                ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400'
                : 'bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400'
            }`}>
              {currentUser.isAdmin || currentUser.handle === 'admin' ? (
                <ShieldAlert className="w-4 h-4" />
              ) : (
                <Edit3 className="w-4 h-4" />
              )}
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                게시물 수정
                {(currentUser.isAdmin || currentUser.handle === 'admin') && post.authorId !== currentUser.id && (
                  <span className="text-[11px] font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900/60 px-2 py-0.5 rounded-full">
                    최고관리자 권한
                  </span>
                )}
              </h3>
              {(currentUser.isAdmin || currentUser.handle === 'admin') && post.authorId !== currentUser.id && (
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  작성자: <span className="font-semibold text-slate-700 dark:text-slate-300">{post.authorName}</span> (@{post.authorHandle})
                </p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {/* Author Info & Visibility Selector */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src={post.authorAvatar || currentUser.avatar}
                alt={post.authorName || currentUser.name}
                className="h-10 w-10 rounded-full object-cover ring-2 ring-blue-500/20"
              />
              <div>
                <p className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  {post.authorName || currentUser.name}
                  {post.authorId !== currentUser.id && (
                    <span className="text-[10px] text-slate-400 font-normal">
                      (원작성자)
                    </span>
                  )}
                </p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <button
                    type="button"
                    onClick={() => setVisibility(visibility === 'public' ? 'followers' : 'public')}
                    className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full transition-colors"
                  >
                    {visibility === 'public' ? (
                      <>
                        <Globe className="w-3 h-3 text-blue-500" />
                        <span>전체 공개</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-3 h-3 text-amber-500" />
                        <span>팔로워 전용</span>
                      </>
                    )}
                  </button>
                  <span
                    className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold border ${currentScopeConfig.badgeClass}`}
                    title={`공개 지역 범위: ${currentScopeConfig.label}`}
                  >
                    <span>{currentScopeConfig.emoji}</span>
                    <span>{currentScopeConfig.label}</span>
                  </span>
                  {feeling && (() => {
                    const cat = findMoodCategoryByItem(feeling);
                    return (
                      <span className={`inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full font-medium border animate-in fade-in duration-150 ${cat?.colorClass.badge || 'bg-blue-50 text-blue-700 border-blue-200'}`}>
                        <span>{cat?.emoji || '✨'}</span>
                        <span className="font-bold">{cat?.name ? `${cat.name} · ` : ''}</span>
                        <span>{feeling}</span>
                        <button
                          type="button"
                          onClick={() => setFeeling(undefined)}
                          className="ml-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-0.5"
                          title="기분 지우기"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    );
                  })()}
                  {selectedBgm && (
                    <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full font-medium border bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 border-amber-200/80 dark:border-amber-800/70 animate-in fade-in duration-150">
                      <button
                        type="button"
                        onClick={(e) => handleTogglePreviewAudio(selectedBgm, e)}
                        className="cursor-pointer hover:opacity-80 flex items-center gap-1"
                        title={previewingBgmId === selectedBgm.id ? '미리듣기 정지' : '미리듣기 재생'}
                      >
                        <Music className={`h-3 w-3 text-amber-600 dark:text-amber-400 shrink-0 ${previewingBgmId === selectedBgm.id ? 'animate-spin [animation-duration:6s]' : ''}`} />
                        <span className="font-semibold max-w-[120px] truncate">{selectedBgm.title}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSelectBgm(null)}
                        className="ml-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-0.5"
                        title="음악 제거"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Text Area */}
          <div className="relative">
            <textarea
              id="edit-post-textarea"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="수정할 내용을 입력하세요... (#해시태그 가능)"
              rows={4}
              className="w-full resize-none border-0 bg-transparent p-0 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-0 dark:text-white dark:placeholder-slate-500 text-sm md:text-base leading-relaxed"
            />
          </div>

          {/* Location Bar (if open or active) */}
          {showLocationInput && (
            <div className="flex items-center gap-2 rounded-xl bg-slate-50 p-2.5 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700">
              <MapPin className="h-4 w-4 text-rose-500 shrink-0" />
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="위치 추가 (예: 서울 강남구, 제주도)"
                className="flex-1 bg-transparent text-xs text-slate-900 focus:outline-none dark:text-white placeholder-slate-400"
              />
              <button
                type="button"
                onClick={async () => {
                  setIsDetectingLocation(true);
                  try {
                    const result = await getAutoLocation(currentUser.location);
                    setLocation(result.address);
                  } finally {
                    setIsDetectingLocation(false);
                  }
                }}
                disabled={isDetectingLocation}
                className="flex items-center gap-1 text-[11px] text-blue-600 dark:text-blue-400 hover:underline px-1.5 py-0.5"
                title="현재 위치로 자동 감지"
              >
                <RotateCw className={`h-3 w-3 ${isDetectingLocation ? 'animate-spin' : ''}`} />
                <span className="hidden sm:inline">현재 위치</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setLocation('');
                  setShowLocationInput(false);
                }}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                title="위치 삭제"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {/* Media Processing Loading Banner */}
          {isProcessingMedia && (
            <div className="flex items-center gap-2.5 rounded-xl border border-blue-200 bg-blue-50/80 px-3.5 py-2.5 dark:border-blue-900/60 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 animate-pulse">
              <Loader2 className="h-4 w-4 animate-spin text-blue-600 dark:text-blue-400 shrink-0" />
              <div className="flex-1 text-xs">
                <span className="font-semibold">{processingStatusText || '미디어 최적화 처리 중...'}</span>
                <span className="text-[11px] text-blue-500 dark:text-blue-400 block">
                  고화질 유지 및 브라우저 메모리 부하 방지를 위해 안전하게 변환 중입니다.
                </span>
              </div>
            </div>
          )}

          {/* Instagram-style Media Carousel & Reorder Management (Photos & Videos up to 10) */}
          {attachedMedia.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                  <span className="text-sm">📸</span>
                  <span>첨부 미디어 미리보기 ({attachedMedia.length}/10개)</span>
                  {attachedMedia.length >= 10 && (
                    <span className="text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300 px-2 py-0.5 rounded-full">
                      최대 10개
                    </span>
                  )}
                </span>
                <button
                  type="button"
                  onClick={() => setAttachedMedia([])}
                  className="text-xs text-rose-500 hover:text-rose-600 dark:text-rose-400 font-semibold hover:underline cursor-pointer"
                >
                  모두 삭제
                </button>
              </div>

              {/* Instagram Carousel with Dots Below and Swipe */}
              <div className="w-full">
                <InstagramMediaCarousel
                  mediaItems={attachedMedia}
                  postId={`edit_${post.id}`}
                  compact={true}
                  isPostInView={true}
                />
              </div>

              {/* Attached Media Thumbnail Reorder & Management Strip */}
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/50 p-2.5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                    순서 변경(← / →) 및 삭제 (피드 노출 순서)
                  </span>
                  {attachedMedia.length < 10 && (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setShowPhotoPicker(true);
                          setShowVideoPicker(false);
                        }}
                        className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                      >
                        <Plus className="h-3 w-3" />
                        사진 추가
                      </button>
                      <span className="text-slate-300 dark:text-slate-600">|</span>
                      <button
                        type="button"
                        onClick={() => {
                          setShowVideoPicker(true);
                          setShowPhotoPicker(false);
                        }}
                        className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-0.5 cursor-pointer"
                      >
                        <Plus className="h-3 w-3" />
                        동영상 추가
                      </button>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5 scrollbar-thin">
                  {attachedMedia.map((item, idx) => (
                    <div
                      key={item.id}
                      className="group relative flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 border-slate-200 dark:border-slate-700 bg-slate-950 flex flex-col justify-between shadow-sm"
                    >
                      {item.type === 'video' ? (
                        item.thumbnail ? (
                          <img
                            src={item.thumbnail}
                            alt={`Media ${idx + 1}`}
                            className="w-full h-full object-cover pointer-events-none"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center text-slate-400 pointer-events-none">
                            <Film className="h-6 w-6 text-slate-500 mb-0.5" />
                            <span className="text-[9px] font-semibold">동영상</span>
                          </div>
                        )
                      ) : (
                        <img
                          src={item.url}
                          alt={`Media ${idx + 1}`}
                          className="w-full h-full object-cover pointer-events-none"
                          referrerPolicy="no-referrer"
                        />
                      )}

                      {/* Top Badges: Index Number & Type */}
                      <div className="absolute top-1 left-1 right-1 flex items-center justify-between pointer-events-none">
                        <span className="h-4 min-w-[16px] px-1 rounded bg-black/75 text-[10px] font-extrabold text-white flex items-center justify-center">
                          {idx + 1}
                        </span>
                        <span className="h-4 px-1 rounded bg-black/75 text-[9px] text-white flex items-center justify-center">
                          {item.type === 'video' ? '🎥' : '📷'}
                        </span>
                      </div>

                      {/* Delete Button */}
                      <button
                        type="button"
                        onClick={() => removeMediaItem(item.id)}
                        className="absolute top-1 right-1 h-5 w-5 rounded-full bg-rose-600/90 text-white flex items-center justify-center shadow hover:bg-rose-700 transition-colors opacity-0 group-hover:opacity-100 cursor-pointer"
                        title="삭제"
                      >
                        <X className="h-3 w-3" />
                      </button>

                      {/* Bottom Reorder Controls */}
                      <div className="absolute bottom-0 inset-x-0 bg-black/75 py-0.5 px-1 flex items-center justify-between text-white opacity-90 group-hover:opacity-100">
                        <button
                          type="button"
                          onClick={() => moveMediaItem(idx, 'left')}
                          disabled={idx === 0}
                          className="disabled:opacity-20 hover:text-blue-400 p-0.5 cursor-pointer disabled:cursor-not-allowed"
                          title="왼쪽으로 이동"
                        >
                          <ArrowLeft className="h-3 w-3" />
                        </button>
                        <span className="text-[9px] text-slate-300 font-mono">
                          {idx + 1}/{attachedMedia.length}
                        </span>
                        <button
                          type="button"
                          onClick={() => moveMediaItem(idx, 'right')}
                          disabled={idx === attachedMedia.length - 1}
                          className="disabled:opacity-20 hover:text-blue-400 p-0.5 cursor-pointer disabled:cursor-not-allowed"
                          title="오른쪽으로 이동"
                        >
                          <ArrowRight className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Add more button tile if less than 10 */}
                  {attachedMedia.length < 10 && (
                    <button
                      type="button"
                      onClick={() => setShowPhotoPicker(true)}
                      className="flex-shrink-0 w-20 h-20 rounded-lg border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 hover:bg-blue-50/50 dark:hover:bg-blue-950/30 flex flex-col items-center justify-center gap-1 text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 transition-all cursor-pointer"
                    >
                      <Plus className="h-5 w-5" />
                      <span className="text-[10px] font-bold">
                        {attachedMedia.length}/10
                      </span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Hidden File Inputs */}
          <input
            ref={photoInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handlePhotoFileUpload}
          />
          <input
            ref={videoInputRef}
            type="file"
            accept="video/*,video/mp4,video/webm,video/quicktime,video/x-matroska,video/3gpp,.mp4,.mov,.webm,.mkv,.3gp,.avi,.m4v"
            multiple
            className="hidden"
            onChange={handleVideoFileUpload}
          />

          {/* Photo Picker Drawer */}
          {showPhotoPicker && (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 dark:border-slate-800 dark:bg-slate-800/50 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
                  사진 추가 (현재 {attachedMedia.length}/10개 첨부됨)
                </span>
                <button
                  type="button"
                  onClick={() => setShowPhotoPicker(false)}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Upload or URL */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => photoInputRef.current?.click()}
                  disabled={attachedMedia.length >= 10}
                  className="px-3 py-1.5 text-xs bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-slate-100 text-slate-700 dark:text-slate-200 rounded-lg flex items-center gap-1.5 shrink-0 font-medium transition-colors disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
                >
                  <Upload className="w-3.5 h-3.5 text-blue-500" />
                  파일 업로드 (여러 장 가능)
                </button>
                <form onSubmit={handleAddCustomPhoto} className="flex-1 flex items-center gap-1.5">
                  <input
                    type="url"
                    value={customPhotoUrl}
                    onChange={(e) => setCustomPhotoUrl(e.target.value)}
                    placeholder="또는 이미지 URL 직접 입력"
                    disabled={attachedMedia.length >= 10}
                    className="flex-1 px-2.5 py-1 text-xs bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:border-blue-500 disabled:opacity-50"
                  />
                  <button
                    type="submit"
                    disabled={!customPhotoUrl.trim() || attachedMedia.length >= 10}
                    className="px-2.5 py-1 text-xs bg-blue-600 disabled:opacity-50 text-white rounded-lg font-medium cursor-pointer"
                  >
                    추가
                  </button>
                </form>
              </div>

              {/* Quick Sample Photo Recommendations */}
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700/60">
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 block mb-1">
                  📸 추천 샘플 사진 추가:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2 py-0.5 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🌅 제주 일몰
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1519046904884-53103b34b206?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2 py-0.5 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🌊 푸른 파도
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1477959858617-67f30bc75b82?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2 py-0.5 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🏙️ 시티 야경
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2 py-0.5 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    ☕️ 카페 감성
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2 py-0.5 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🌸 봄 벚꽃길
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2 py-0.5 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🏔️ 설산 풍경
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2 py-0.5 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🐱 귀여운 고양이
                  </button>
                  <button
                    type="button"
                    disabled={attachedMedia.length >= 10}
                    onClick={() => {
                      addMediaItem('image', 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=800&auto=format&fit=crop&q=80');
                    }}
                    className="px-2 py-0.5 text-[11px] font-medium rounded-md bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-100 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    🍣 일식 요리
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Video Picker Drawer */}
          {showVideoPicker && (
            <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 dark:border-slate-800 dark:bg-slate-800/50 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
                  동영상 추가 (현재 {attachedMedia.length}/10개 첨부됨)
                </span>
                <button
                  type="button"
                  onClick={() => setShowVideoPicker(false)}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Upload or URL */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => videoInputRef.current?.click()}
                  disabled={attachedMedia.length >= 10}
                  className="px-3 py-1.5 text-xs bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 hover:bg-slate-100 text-slate-700 dark:text-slate-200 rounded-lg flex items-center gap-1.5 shrink-0 font-medium transition-colors disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed"
                >
                  <Upload className="w-3.5 h-3.5 text-indigo-500" />
                  파일 업로드 (여러 개 가능)
                </button>
                <form onSubmit={handleAddCustomVideo} className="flex-1 flex items-center gap-1.5">
                  <input
                    type="url"
                    value={customVideoUrl}
                    onChange={(e) => setCustomVideoUrl(e.target.value)}
                    placeholder="동영상 URL 또는 YouTube 영상 링크..."
                    disabled={attachedMedia.length >= 10}
                    className="flex-1 px-2.5 py-1 text-xs bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500 disabled:opacity-50"
                  />
                  <button
                    type="submit"
                    disabled={!customVideoUrl.trim() || attachedMedia.length >= 10}
                    className="px-2.5 py-1 text-xs bg-indigo-600 disabled:opacity-50 text-white rounded-lg font-medium cursor-pointer"
                  >
                    추가
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* Feeling / Mood Picker Drawer with 3 Major Categories & Subcategories */}
          {showFeelings && (
            <div
              id="edit-post-feeling-drawer"
              className="rounded-xl border border-slate-200 bg-slate-50/90 p-3.5 dark:border-slate-800 dark:bg-slate-850 space-y-3 animate-in fade-in slide-in-from-top-2 duration-150"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-100">
                  <Smile className="h-4 w-4 text-amber-500" />
                  <span>기분 상태 선택</span>
                  {feeling && (
                    <span className="text-[11px] font-normal text-slate-500 dark:text-slate-400 ml-1">
                      (선택: <span className="font-semibold text-blue-600 dark:text-blue-400">{feeling}</span>)
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {feeling && (
                    <button
                      type="button"
                      onClick={() => setFeeling(undefined)}
                      className="text-[11px] text-rose-500 hover:text-rose-600 dark:text-rose-400 font-medium hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <X className="h-3 w-3" />
                      기분 초기화
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setShowFeelings(false)}
                    className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                  >
                    닫기
                  </button>
                </div>
              </div>

              {/* 3 Major Category Tabs */}
              <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-800">
                {MOOD_CATEGORIES.map((cat) => {
                  const isTabActive = selectedMoodCategory === cat.id;
                  const hasSelectionInThisCat = cat.items.includes(feeling || '');
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedMoodCategory(cat.id)}
                      className={`relative py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer select-none ${
                        isTabActive
                          ? cat.colorClass.tabActive
                          : `${cat.colorClass.tabInactive} bg-transparent`
                      }`}
                    >
                      <span className="text-sm">{cat.emoji}</span>
                      <span>{cat.name}</span>
                      <span
                        className={`text-[10px] px-1.5 py-0.2 rounded-full font-medium ${
                          isTabActive
                            ? 'bg-white/20 text-white'
                            : 'bg-slate-300/80 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        {cat.items.length}
                      </span>
                      {hasSelectionInThisCat && !isTabActive && (
                        <span className="absolute -top-1 -right-1 flex h-2 w-2">
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Subcategories (Small Category chips) for the active Major Category */}
              {(() => {
                const currentCat =
                  MOOD_CATEGORIES.find((c) => c.id === selectedMoodCategory) || MOOD_CATEGORIES[0];
                return (
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 px-0.5">
                      <span>{currentCat.description}</span>
                      <span className="font-medium text-slate-400">
                        {currentCat.name} 감정 ({currentCat.items.length}개)
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {currentCat.items.map((item) => {
                        const isSelected = feeling === item;
                        return (
                          <button
                            key={item}
                            type="button"
                            onClick={() => {
                              setFeeling(isSelected ? undefined : item);
                            }}
                            className={`rounded-full px-3 py-1.5 text-xs transition-all flex items-center gap-1 cursor-pointer select-none ${
                              isSelected
                                ? currentCat.colorClass.chipActive
                                : currentCat.colorClass.chipInactive
                            }`}
                          >
                            {isSelected && <Check className="h-3 w-3 shrink-0" />}
                            <span>{item}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Poll Notice if post has poll */}
          {post.poll && (
            <div className="rounded-xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/60 p-3 text-xs text-blue-700 dark:text-blue-300">
              <p className="font-semibold flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-blue-500" />
                투표 포함 게시물: "{post.poll.question}"
              </p>
              <p className="text-[11px] text-blue-600/80 dark:text-blue-400/80 mt-0.5">
                공정한 투표 결과를 위해 투표 문항과 참여 데이터는 수정 시 보존됩니다.
              </p>
            </div>
          )}

          {/* Regional Scope Selection (게시물 공개 지역 범위 선택 버튼) */}
          <div
            id="edit-regional-scope-section"
            className="rounded-xl border border-slate-200/90 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/50 p-3 space-y-2"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="text-xs">📍</span>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                  게시물 공개 지역 범위
                </span>
              </div>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${currentScopeConfig.badgeClass}`}>
                {currentScopeConfig.emoji} {currentScopeConfig.label}
              </span>
            </div>

            {/* 4 Separate Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {REGIONAL_SCOPES.map((scope) => {
                const isSelected = regionalScope === scope.id;
                return (
                  <button
                    key={scope.id}
                    type="button"
                    id={`edit-scope-btn-${scope.id}`}
                    onClick={() => setRegionalScope(scope.id)}
                    className={`group relative flex flex-col items-start p-2 rounded-lg border text-left transition-all cursor-pointer ${
                      isSelected
                        ? `${scope.activeBtnClass} shadow-xs`
                        : 'bg-white dark:bg-slate-800/80 border-slate-200/90 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full mb-0.5">
                      <span className="text-sm">{scope.emoji}</span>
                      {isSelected ? (
                        <Check className="h-3 w-3 shrink-0" />
                      ) : (
                        <span className="h-3 w-3 rounded-full border border-slate-300 dark:border-slate-600" />
                      )}
                    </div>
                    <span className={`text-xs font-bold ${isSelected ? 'font-extrabold' : 'text-slate-800 dark:text-slate-200'}`}>
                      {scope.label}
                    </span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                      {scope.description}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Background Music (BGM) Drawer */}
          {showBgmDrawer && (() => {
            const allBgms: StoryBgm[] = [...customBgms, ...PRESET_STORY_BGMS];
            const filteredBgms = allBgms.filter((bgm) => {
              if (activeBgmCategory === 'custom') {
                if (!bgm.isCustom) return false;
              } else if (activeBgmCategory === 'lofi') {
                if (!bgm.genre.toLowerCase().includes('lo-fi') && !bgm.id.includes('lofi')) return false;
              } else if (activeBgmCategory === 'acoustic') {
                if (!bgm.genre.toLowerCase().includes('acoustic') && !bgm.id.includes('acoustic')) return false;
              } else if (activeBgmCategory === 'piano') {
                if (!bgm.genre.toLowerCase().includes('piano') && !bgm.id.includes('piano')) return false;
              } else if (activeBgmCategory === 'synth') {
                if (!bgm.genre.toLowerCase().includes('synth') && !bgm.genre.toLowerCase().includes('citypop') && !bgm.id.includes('synth')) return false;
              } else if (activeBgmCategory === 'tropical') {
                if (!bgm.genre.toLowerCase().includes('tropical') && !bgm.id.includes('tropical')) return false;
              } else if (activeBgmCategory === 'ambient') {
                if (!bgm.genre.toLowerCase().includes('ambient') && !bgm.id.includes('ambient')) return false;
              } else if (activeBgmCategory === 'jazz') {
                if (!bgm.genre.toLowerCase().includes('jazz') && !bgm.id.includes('jazz')) return false;
              } else if (activeBgmCategory === 'indie') {
                if (!bgm.genre.toLowerCase().includes('folk') && !bgm.genre.toLowerCase().includes('indie') && !bgm.id.includes('indie')) return false;
              } else if (activeBgmCategory === 'upbeat') {
                if (!bgm.genre.toLowerCase().includes('upbeat') && !bgm.genre.toLowerCase().includes('pop') && !bgm.id.includes('upbeat')) return false;
              }
              if (bgmSearchQuery.trim()) {
                const q = bgmSearchQuery.trim().toLowerCase();
                return (
                  bgm.title.toLowerCase().includes(q) ||
                  bgm.artist.toLowerCase().includes(q) ||
                  bgm.genre.toLowerCase().includes(q) ||
                  (bgm.license && bgm.license.toLowerCase().includes(q))
                );
              }
              return true;
            });

            return (
              <div
                id="edit-post-bgm-drawer"
                className="rounded-xl border border-amber-200 bg-amber-50/70 p-3.5 dark:border-amber-900/60 dark:bg-amber-950/30 animate-in fade-in slide-in-from-top-2 duration-150 space-y-3"
              >
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900 dark:text-white">
                    <Music className="h-4 w-4 text-amber-500" />
                    <span>게시물 배경음악 (BGM)</span>
                    {selectedBgm && (
                      <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-500" />
                        <span>선택됨: {selectedBgm.title}</span>
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedBgm && (
                      <button
                        type="button"
                        onClick={() => handleSelectBgm(null)}
                        className="text-[11px] font-medium text-slate-500 hover:text-slate-700 dark:text-slate-400 cursor-pointer"
                      >
                        음악 제거
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setShowBgmDrawer(false)}
                      className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Copyright-Free Trust Banner */}
                <div className="p-2.5 rounded-xl bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 dark:from-emerald-950/50 dark:via-teal-950/40 dark:to-emerald-950/50 border border-emerald-200/80 dark:border-emerald-800/60 flex items-start gap-2.5">
                  <div className="p-1 rounded-lg bg-emerald-600 text-white shrink-0 mt-0.5 shadow-xs">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                      100% 저작권 무료 (CC0 / Royalty-Free) 안심 음원
                    </p>
                    <p className="text-[11px] text-emerald-800/80 dark:text-emerald-300/80 leading-relaxed mt-0.5">
                      상업적·개인용 제한 없이 피드 게시물에 자유롭게 사용 가능합니다. 소장 중인 무료 음악 파일(MP3, WAV 등)도 직접 추가해보세요!
                    </p>
                  </div>
                </div>

                {/* Action Bar: Upload Custom Audio & External Link Toggle */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => audioFileInputRef.current?.click()}
                    className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-bold shadow-sm shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>내 저작권 무료 음원 올리기 (MP3/WAV)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowCustomAudioUrlInput((prev) => !prev)}
                    className="px-2.5 py-2 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1 transition-all cursor-pointer"
                    title="웹 음원 URL 주소 직접 입력"
                  >
                    <span>웹 링크</span>
                    {showCustomAudioUrlInput ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  </button>
                </div>

                {/* Collapsible External Audio URL Input */}
                {showCustomAudioUrlInput && (
                  <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 animate-in fade-in duration-150 space-y-2">
                    <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block">
                      🔗 외부 저작권 무료 음원 주소(URL) 직접 등록
                    </span>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <input
                        type="text"
                        value={customAudioTitleInput}
                        onChange={(e) => setCustomAudioTitleInput(e.target.value)}
                        placeholder="음원 제목 (예: 감성 카페 피아노)"
                        className="sm:w-1/3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                      />
                      <input
                        type="url"
                        value={customAudioUrlInput}
                        onChange={(e) => setCustomAudioUrlInput(e.target.value)}
                        placeholder="https://... (.mp3, .wav, .m4a 등 오디오 주소)"
                        className="flex-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-2.5 py-1.5 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                      />
                      <button
                        type="button"
                        disabled={!customAudioUrlInput.trim()}
                        onClick={() => {
                          if (!customAudioUrlInput.trim()) return;
                          handleAddCustomAudioUrl(customAudioUrlInput.trim(), customAudioTitleInput.trim() || undefined);
                          setCustomAudioUrlInput('');
                          setCustomAudioTitleInput('');
                          setShowCustomAudioUrlInput(false);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold transition-all cursor-pointer shrink-0"
                      >
                        등록 및 적용
                      </button>
                    </div>
                  </div>
                )}

                {/* Search Input Bar */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={bgmSearchQuery}
                    onChange={(e) => setBgmSearchQuery(e.target.value)}
                    placeholder="음악 제목, 아티스트, 장르 검색..."
                    className="w-full pl-8 pr-7 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-amber-500 transition-colors"
                  />
                  {bgmSearchQuery && (
                    <button
                      type="button"
                      onClick={() => setBgmSearchQuery('')}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-xs"
                    >
                      ✕
                    </button>
                  )}
                </div>

                {/* Category Filter Pills */}
                <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar">
                  {COPYRIGHT_FREE_CATEGORIES.map((cat) => {
                    const isActive = activeBgmCategory === cat.id;
                    const count = cat.id === 'custom' ? customBgms.length : undefined;
                    if (cat.id === 'custom' && customBgms.length === 0) return null;

                    return (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setActiveBgmCategory(cat.id)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 ${
                          isActive
                            ? 'bg-amber-600 text-white shadow-xs'
                            : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-750 border border-slate-200/80 dark:border-slate-700'
                        }`}
                      >
                        <span>{cat.label}</span>
                        {count !== undefined && (
                          <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold ${isActive ? 'bg-amber-700 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300'}`}>
                            {count}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Track Cards Grid */}
                {filteredBgms.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto pr-1">
                    {filteredBgms.map((bgm) => {
                      const isSelected = selectedBgm?.id === bgm.id;
                      const isPreviewing = previewingBgmId === bgm.id;

                      return (
                        <div
                          key={bgm.id}
                          onClick={() => handleSelectBgm(bgm)}
                          className={`relative flex items-center justify-between p-2 rounded-xl border transition-all cursor-pointer ${
                            isSelected
                              ? 'border-amber-500 bg-amber-100/70 dark:bg-amber-950/60 ring-1 ring-amber-500/60 shadow-xs'
                              : 'border-slate-200/90 bg-white hover:border-amber-300 dark:border-slate-750 dark:bg-slate-850 dark:hover:border-slate-600'
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0 pr-2">
                            <div className="relative h-8 w-8 rounded-lg overflow-hidden bg-slate-900 shrink-0 shadow-xs">
                              {bgm.coverUrl ? (
                                <img
                                  src={bgm.coverUrl}
                                  alt={bgm.title}
                                  className="h-full w-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                <Disc className="h-full w-full p-1.5 text-amber-400" />
                              )}
                              {isSelected && (
                                <div className="absolute inset-0 bg-amber-600/50 flex items-center justify-center text-white backdrop-blur-[0.5px]">
                                  <Check className="h-3.5 w-3.5 stroke-[3]" />
                                </div>
                              )}
                            </div>

                            <div className="min-w-0 text-left">
                              <p className={`text-xs font-bold truncate leading-tight ${isSelected ? 'text-amber-900 dark:text-amber-200' : 'text-slate-800 dark:text-slate-200'}`}>
                                {bgm.title}
                              </p>
                              <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                                {bgm.artist} • <span className="text-amber-600 dark:text-amber-400 font-medium">{bgm.genre}</span>
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              onClick={(e) => handleTogglePreviewAudio(bgm, e)}
                              title={isPreviewing ? '미리듣기 일시정지' : '미리듣기 재생'}
                              className={`h-7 w-7 rounded-full flex items-center justify-center shrink-0 transition-all cursor-pointer ${
                                isPreviewing
                                  ? 'bg-amber-500 text-white shadow-sm scale-105'
                                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300'
                              }`}
                            >
                              {isPreviewing ? (
                                <Pause className="w-3 h-3 fill-current" />
                              ) : (
                                <Play className="w-3 h-3 fill-current ml-0.5" />
                              )}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-6 text-xs text-slate-500 dark:text-slate-400">
                    검색된 음원이 없습니다.
                  </div>
                )}
              </div>
            );
          })()}

          {/* Hidden Audio File Input */}
          <input
            ref={audioFileInputRef}
            type="file"
            accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleProcessAudioFile(file);
            }}
            className="hidden"
          />
        </div>

        {/* Footer Toolbar & Actions */}
        <div className="border-t border-slate-100 px-5 py-3.5 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-900/50">
          {/* Quick Tool Attachments */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => {
                setShowPhotoPicker((prev) => !prev);
                setShowVideoPicker(false);
                setShowFeelings(false);
              }}
              title="사진 추가"
              className={`rounded-full p-2 transition-colors cursor-pointer relative ${
                showPhotoPicker || attachedMedia.some((m) => m.type === 'image')
                  ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400'
                  : 'text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <ImageIcon className="h-5 w-5" />
              {attachedMedia.some((m) => m.type === 'image') && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] px-1 items-center justify-center rounded-full bg-emerald-600 text-[10px] font-bold text-white shadow-xs">
                  {attachedMedia.filter((m) => m.type === 'image').length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                const willOpen = !showVideoPicker;
                setShowVideoPicker(willOpen);
                setShowPhotoPicker(false);
                setShowFeelings(false);
                if (willOpen) {
                  videoInputRef.current?.click();
                }
              }}
              title="동영상 추가"
              className={`rounded-full p-2 transition-colors cursor-pointer relative ${
                showVideoPicker || attachedMedia.some((m) => m.type === 'video')
                  ? 'bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400'
                  : 'text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <Video className="h-5 w-5" />
              {attachedMedia.some((m) => m.type === 'video') && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] px-1 items-center justify-center rounded-full bg-blue-600 text-[10px] font-bold text-white shadow-xs">
                  {attachedMedia.filter((m) => m.type === 'video').length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                setShowFeelings((prev) => !prev);
                setShowPhotoPicker(false);
                setShowVideoPicker(false);
              }}
              title="기분 추가"
              className={`rounded-full p-2 transition-colors ${
                feeling
                  ? 'bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400'
                  : 'text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <Smile className="h-5 w-5" />
            </button>

            <button
              type="button"
              onClick={() => {
                setShowLocationInput((prev) => !prev);
              }}
              title="위치 추가"
              className={`rounded-full p-2 transition-colors ${
                location || showLocationInput
                  ? 'bg-rose-50 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400'
                  : 'text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <MapPin className="h-5 w-5" />
            </button>

            <button
              type="button"
              id="edit-post-attach-music-btn"
              onClick={() => {
                setShowBgmDrawer((prev) => !prev);
                setShowPhotoPicker(false);
                setShowVideoPicker(false);
                setShowFeelings(false);
                setShowLocationInput(false);
              }}
              title={selectedBgm ? `선택된 음악: ${selectedBgm.title} (클릭하여 수정)` : '저작권 무료 배경음악 (BGM) 추가'}
              className={`rounded-full p-2 transition-colors cursor-pointer relative ${
                selectedBgm || showBgmDrawer
                  ? 'bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400 ring-1 ring-amber-300 dark:ring-amber-700'
                  : 'text-slate-500 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-400 dark:hover:bg-slate-800'
              }`}
            >
              <Music className="h-5 w-5" />
              {selectedBgm && (
                <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] px-1 items-center justify-center rounded-full bg-amber-600 text-[10px] font-bold text-white shadow-xs">
                  ON
                </span>
              )}
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs md:text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
            >
              취소
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isSaveDisabled}
              className="px-5 py-2 text-xs md:text-sm font-bold bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl shadow-md shadow-blue-600/20 active:scale-95 transition-all cursor-pointer"
            >
              수정 완료
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
