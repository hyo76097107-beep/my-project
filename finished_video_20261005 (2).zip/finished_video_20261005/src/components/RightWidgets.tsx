import React, { useState, useMemo } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  Search,
  Flame,
  UserPlus,
  CheckCircle,
  TrendingUp,
  Hash,
  X,
  Compass,
  LayoutGrid,
  Cpu,
  Newspaper,
  Trophy,
  Utensils,
  Sparkles,
  Plane,
  Film,
  Plus,
  Check,
  Bell
} from 'lucide-react';
import { TRENDING_TOPICS } from '../data/mockData';
import { formatNumber } from '../utils/formatters';
import { TrendCategoryKey } from '../types';

interface CategoryBadgeConfig {
  label: string;
  shortLabel: string;
  icon: React.ComponentType<{ className?: string }>;
  bgClass: string;
  textClass: string;
  borderClass: string;
  darkBgClass: string;
  darkTextClass: string;
  darkBorderClass: string;
}

const CATEGORY_STYLES: Record<TrendCategoryKey, CategoryBadgeConfig> = {
  tech: {
    label: '테크 & 개발',
    shortLabel: 'Tech',
    icon: Cpu,
    bgClass: 'bg-cyan-50',
    textClass: 'text-cyan-700',
    borderClass: 'border-cyan-200',
    darkBgClass: 'dark:bg-cyan-950/60',
    darkTextClass: 'dark:text-cyan-300',
    darkBorderClass: 'dark:border-cyan-800/60'
  },
  news: {
    label: '뉴스 & 시사',
    shortLabel: 'News',
    icon: Newspaper,
    bgClass: 'bg-blue-50',
    textClass: 'text-blue-700',
    borderClass: 'border-blue-200',
    darkBgClass: 'dark:bg-blue-950/60',
    darkTextClass: 'dark:text-blue-300',
    darkBorderClass: 'dark:border-blue-800/60'
  },
  sports: {
    label: '스포츠 & 헬스',
    shortLabel: 'Sports',
    icon: Trophy,
    bgClass: 'bg-amber-50',
    textClass: 'text-amber-700',
    borderClass: 'border-amber-200',
    darkBgClass: 'dark:bg-amber-950/60',
    darkTextClass: 'dark:text-amber-300',
    darkBorderClass: 'dark:border-amber-800/60'
  },
  food: {
    label: '푸드 & 미식',
    shortLabel: 'Food',
    icon: Utensils,
    bgClass: 'bg-emerald-50',
    textClass: 'text-emerald-700',
    borderClass: 'border-emerald-200',
    darkBgClass: 'dark:bg-emerald-950/60',
    darkTextClass: 'dark:text-emerald-300',
    darkBorderClass: 'dark:border-emerald-800/60'
  },
  lifestyle: {
    label: '라이프스타일',
    shortLabel: 'Life',
    icon: Sparkles,
    bgClass: 'bg-purple-50',
    textClass: 'text-purple-700',
    borderClass: 'border-purple-200',
    darkBgClass: 'dark:bg-purple-950/60',
    darkTextClass: 'dark:text-purple-300',
    darkBorderClass: 'dark:border-purple-800/60'
  },
  travel: {
    label: '여행 & 아웃도어',
    shortLabel: 'Travel',
    icon: Plane,
    bgClass: 'bg-sky-50',
    textClass: 'text-sky-700',
    borderClass: 'border-sky-200',
    darkBgClass: 'dark:bg-sky-950/60',
    darkTextClass: 'dark:text-sky-300',
    darkBorderClass: 'dark:border-sky-800/60'
  },
  entertainment: {
    label: '엔터테인먼트',
    shortLabel: 'Media',
    icon: Film,
    bgClass: 'bg-rose-50',
    textClass: 'text-rose-700',
    borderClass: 'border-rose-200',
    darkBgClass: 'dark:bg-rose-950/60',
    darkTextClass: 'dark:text-rose-300',
    darkBorderClass: 'dark:border-rose-800/60'
  }
};

export const RightWidgets: React.FC = () => {
  const {
    currentUser,
    users,
    toggleFollow,
    searchQuery,
    setSearchQuery,
    setActiveTab,
    activeTab,
    activeTag,
    setActiveTag,
    setViewingUserId,
    setActiveChatUserId,
    followedTopics,
    toggleFollowTopic,
    isFollowingTopic,
    isDarkMode
  } = useSocial();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showAllTopics, setShowAllTopics] = useState<boolean>(false);

  const suggestedUsers = users.filter((u) => u.id !== currentUser.id);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setActiveTab('explore');
    }
  };

  // Filter in Feed vs Explore
  const handleTagClick = (tag: string, target: 'feed' | 'explore' = 'feed') => {
    if (activeTag === tag && activeTab === target) {
      setActiveTag(null);
    } else {
      setActiveTag(tag);
      setActiveTab(target);
    }
  };

  const handleClearTagFilter = () => {
    setActiveTag(null);
  };

  const handleUserClick = (userId: string) => {
    setViewingUserId(userId);
    setActiveTab('profile');
  };

  // Category filters definition with icons and visual tags
  const filterTabs: Array<{ id: string; label: string; icon?: React.ComponentType<{ className?: string }> }> = [
    { id: 'all', label: '전체' },
    { id: 'following', label: '구독중', icon: Bell },
    { id: 'news', label: 'News', icon: Newspaper },
    { id: 'tech', label: 'Tech', icon: Cpu },
    { id: 'sports', label: 'Sports', icon: Trophy },
    { id: 'food', label: 'Food', icon: Utensils },
    { id: 'lifestyle', label: 'Life', icon: Sparkles }
  ];

  const filteredTopics = useMemo(() => {
    if (selectedCategory === 'all') return TRENDING_TOPICS;
    if (selectedCategory === 'following') {
      return TRENDING_TOPICS.filter((t) => isFollowingTopic(t.tag));
    }
    return TRENDING_TOPICS.filter((t) => t.categoryType === selectedCategory);
  }, [selectedCategory, followedTopics]);

  const displayedTopics = showAllTopics ? filteredTopics : filteredTopics.slice(0, 5);

  // Quick hashtag chips with category types
  const popularChips: Array<{ tag: string; category: TrendCategoryKey }> = [
    { tag: 'AI개발', category: 'tech' },
    { tag: '오운완', category: 'sports' },
    { tag: '실시간이슈', category: 'news' },
    { tag: '성수동맛집', category: 'food' },
    { tag: '사이드프로젝트', category: 'tech' },
    { tag: '홈베이킹', category: 'food' }
  ];

  return (
    <aside className="sticky top-0 h-screen w-72 lg:w-80 flex-col gap-4 p-4 hidden lg:flex overflow-y-auto scrollbar-none z-20">
      {/* 1. Global Search Box */}
      <form onSubmit={handleSearchSubmit} className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
        <input
          type="text"
          id="right-search-input"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="검색어 또는 #해시태그"
          style={{
            color: isDarkMode ? '#f8fafc' : '#0f172a',
            backgroundColor: isDarkMode ? '#0f172a' : '#ffffff'
          }}
          className="w-full rounded-xl border border-slate-200 dark:border-slate-800 py-2.5 pl-10 pr-4 text-sm font-medium text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 caret-indigo-600 dark:caret-indigo-400 shadow-xs ring-1 ring-slate-200/50 dark:ring-slate-800/50 focus:border-indigo-500 focus:outline-none"
        />
      </form>

      {/* 2. Trending Hashtags & Categorized Topics Widget */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
        <div className="flex items-center justify-between mb-2.5 px-0.5">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
            <Flame className="h-4 w-4 text-rose-500 fill-rose-500/20" />
            실시간 트렌드 & 해시태그
          </h3>
          <button
            onClick={() => setShowAllTopics((prev) => !prev)}
            className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 hover:underline"
          >
            {showAllTopics ? '접기' : '더보기'}
          </button>
        </div>

        {/* Active Tag Filter Status Banner (if any) */}
        {activeTag && (
          <div className="flex items-center justify-between mb-3 px-2.5 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800/60 text-xs">
            <div className="flex items-center gap-1.5 text-blue-700 dark:text-blue-300 font-semibold truncate">
              <Hash className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">#{activeTag} 필터 적용 중</span>
            </div>
            <button
              onClick={handleClearTagFilter}
              title="필터 해제"
              className="p-1 rounded-md text-blue-600 hover:bg-blue-100 dark:text-blue-400 dark:hover:bg-blue-900/60 transition-colors"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        {/* Category Pills with Icons */}
        <div className="flex items-center gap-1 overflow-x-auto pb-2 scrollbar-none mb-1.5">
          {filterTabs.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            const badgeCount = cat.id === 'following' ? followedTopics.length : undefined;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold whitespace-nowrap transition-colors ${
                  isSelected
                    ? 'bg-slate-900 text-white dark:bg-indigo-600'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700'
                }`}
              >
                {Icon && <Icon className="h-3 w-3" />}
                <span>{cat.label}</span>
                {badgeCount !== undefined && badgeCount > 0 && (
                  <span className={`px-1 py-0.2 rounded-full text-[9px] font-extrabold ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                  }`}>
                    {badgeCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Ranked Topic List with Visual Categorization Badges & Follow Action */}
        <div className="flex flex-col gap-1.5">
          {displayedTopics.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-400 dark:text-slate-500">
              {selectedCategory === 'following'
                ? '아직 구독 중인 트렌드가 없습니다. 관심 있는 트렌드의 [팔로우] 버튼을 눌러보세요!'
                : '해당 카테고리의 트렌드가 없습니다.'}
            </div>
          ) : (
            displayedTopics.map((topic, i) => {
              const isCurrentTagActive = activeTag === topic.tag;
              const isSubscribed = isFollowingTopic(topic.tag);
              const style = topic.categoryType ? CATEGORY_STYLES[topic.categoryType] : CATEGORY_STYLES.tech;
              const IconComponent = style.icon;

              return (
                <div
                  key={topic.id}
                  id={`trending-topic-item-${topic.id}`}
                  className={`group flex items-start justify-between p-2.5 rounded-xl transition-all ${
                    isCurrentTagActive
                      ? 'bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800/80 shadow-xs'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/70 border border-transparent'
                  }`}
                >
                  <div
                    onClick={() => handleTagClick(topic.tag, 'feed')}
                    className="flex-1 min-w-0 cursor-pointer"
                  >
                    {/* Header Row: Rank, Category Visual Tag, and Hot Badge */}
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[10px] text-slate-400 font-bold">
                        {i + 1}위
                      </span>

                      {/* Visual Category Tag Badge */}
                      <span
                        className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold border ${style.bgClass} ${style.textClass} ${style.borderClass} ${style.darkBgClass} ${style.darkTextClass} ${style.darkBorderClass}`}
                      >
                        <IconComponent className="h-2.5 w-2.5" />
                        <span>{style.shortLabel}</span>
                      </span>

                      {topic.isHot && (
                        <span className="inline-flex items-center gap-0.5 px-1 py-0.2 rounded text-[9px] font-extrabold bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400">
                          HOT
                        </span>
                      )}
                    </div>

                    {/* Hashtag & Description */}
                    <p
                      className={`font-bold text-xs truncate transition-colors ${
                        isCurrentTagActive
                          ? 'text-blue-600 dark:text-blue-400 font-extrabold'
                          : 'text-slate-800 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400'
                      }`}
                    >
                      #{topic.tag}
                    </p>
                    {topic.description && (
                      <p className="text-[10px] text-slate-400 dark:text-slate-500 line-clamp-1 mt-0.5 leading-snug">
                        {topic.description}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-1 shrink-0 ml-2 pt-0.5">
                    {/* Trend Follow / Subscribe Action Button */}
                    <button
                      type="button"
                      id={`follow-trend-btn-${topic.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFollowTopic(topic.tag);
                      }}
                      title={
                        isSubscribed
                          ? `'#${topic.tag}' 트렌드 구독 취소`
                          : `'#${topic.tag}' 트렌드 팔로우 및 새 소식 구독`
                      }
                      className={`inline-flex items-center gap-0.5 px-2 py-1 rounded-lg text-[10px] font-semibold transition-all ${
                        isSubscribed
                          ? 'bg-blue-50 text-blue-600 border border-blue-200 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200 dark:bg-blue-950/70 dark:text-blue-300 dark:border-blue-800/80 dark:hover:bg-rose-950/60 dark:hover:text-rose-300'
                          : 'bg-slate-100 text-slate-600 hover:bg-blue-600 hover:text-white dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-blue-600 dark:hover:text-white border border-transparent'
                      }`}
                    >
                      {isSubscribed ? (
                        <>
                          <Check className="h-3 w-3 shrink-0" />
                          <span>구독중</span>
                        </>
                      ) : (
                        <>
                          <Plus className="h-3 w-3 shrink-0" />
                          <span>팔로우</span>
                        </>
                      )}
                    </button>

                    {/* Quick Action: Filter in Feed */}
                    <button
                      type="button"
                      onClick={() => handleTagClick(topic.tag, 'feed')}
                      title="피드에서 이 해시태그로 필터링"
                      className="p-1 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/50 dark:hover:text-blue-400 transition-colors"
                    >
                      <LayoutGrid className="h-3.5 w-3.5" />
                    </button>

                    {/* Quick Action: Search in Explore */}
                    <button
                      type="button"
                      onClick={() => handleTagClick(topic.tag, 'explore')}
                      title="탐색 탭에서 전체 검색"
                      className="p-1 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/50 dark:hover:text-indigo-400 transition-colors"
                    >
                      <Compass className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Quick Tag Cloud Chips with Category Color Accents */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center gap-1 text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1.5">
            <TrendingUp className="h-3.5 w-3.5 text-blue-500" />
            <span>분야별 빠른 태그</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {popularChips.map((chip) => {
              const isChipActive = activeTag === chip.tag;
              const catStyle = CATEGORY_STYLES[chip.category];
              return (
                <button
                  key={chip.tag}
                  onClick={() => handleTagClick(chip.tag, 'feed')}
                  className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold transition-all ${
                    isChipActive
                      ? 'bg-blue-600 text-white shadow-xs'
                      : `bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700`
                  }`}
                >
                  <span className={`h-1.5 w-1.5 rounded-full ${isChipActive ? 'bg-white' : catStyle.textClass.replace('text-', 'bg-')}`} />
                  <span>#{chip.tag}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. Suggested Follows Widget */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
        <div className="flex items-center justify-between mb-3 px-0.5">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
            <UserPlus className="h-4 w-4 text-blue-600" />
            추천 팔로우
          </h3>
          <span className="text-[11px] text-slate-400">멤버</span>
        </div>

        <div className="flex flex-col gap-3">
          {suggestedUsers.slice(0, 3).map((user) => {
            const isFollowing = currentUser.followingIds?.includes(user.id);
            return (
              <div key={user.id} className="flex items-center justify-between gap-2">
                <div
                  onClick={() => handleUserClick(user.id)}
                  className="flex items-center gap-2.5 min-w-0 cursor-pointer group"
                >
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="h-9 w-9 rounded-full object-cover border border-slate-200 dark:border-slate-700 group-hover:ring-2 group-hover:ring-blue-500 transition-all shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1">
                      <span className="font-bold text-xs text-slate-900 dark:text-white group-hover:text-blue-600 truncate">
                        {user.name}
                      </span>
                      {user.isVerified && (
                        <CheckCircle className="h-3 w-3 fill-blue-600 text-white shrink-0" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 truncate">@{user.handle}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFollow(user.id, user.name, user.handle);
                  }}
                  className={`rounded-full px-3 py-1 text-xs font-semibold transition-all shrink-0 cursor-pointer ${
                    isFollowing
                      ? 'border border-slate-300 bg-slate-100 text-slate-700 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-300 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-rose-950/40 dark:hover:text-rose-400'
                      : 'bg-blue-600 text-white hover:bg-blue-700 shadow-xs active:scale-95'
                  }`}
                >
                  {isFollowing ? '팔로잉' : '팔로우'}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Active Friends & Quick Chat */}
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-xs ring-1 ring-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:ring-slate-800/50">
        <h3 className="font-bold text-xs text-slate-500 uppercase tracking-wider mb-2.5 px-0.5 flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          현재 접속 중인 친구
        </h3>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {suggestedUsers.map((u) => (
            <div
              key={u.id}
              onClick={() => {
                setActiveChatUserId(u.id);
                setActiveTab('messages');
              }}
              title={`${u.name}님과 대화하기`}
              className="relative cursor-pointer hover:scale-110 transition-transform shrink-0"
            >
              <img
                src={u.avatar}
                alt={u.name}
                className="h-10 w-10 rounded-full object-cover border-2 border-white dark:border-slate-800 shadow-xs"
                referrerPolicy="no-referrer"
              />
              <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-800" />
            </div>
          ))}
        </div>
      </div>

      {/* Footer Info */}
      <div className="px-2 text-[11px] text-slate-400 leading-relaxed">
        <p>© 2026 마음 • 소셜 네트워크 플랫폼</p>
        <p className="mt-0.5">이용약관 • 개인정보처리방침 • 쿠키 설정</p>
      </div>
    </aside>
  );
};

