import React, { useState, useRef, useEffect } from 'react';
import { useSocial } from '../context/SocialContext';
import {
  X,
  LogIn,
  UserPlus,
  Zap,
  Mail,
  Lock,
  User,
  AtSign,
  Eye,
  EyeOff,
  CheckCircle,
  AlertCircle,
  Upload,
  Camera,
  ShieldCheck,
  ShieldAlert,
  Check,
  MapPin,
  RotateCw,
  Loader2,
  Navigation,
  Phone,
  MessageSquare,
  Smartphone,
  Info,
  LogOut,
  Calendar,
  Search,
  KeyRound,
  ArrowLeft,
  HelpCircle,
  Send,
  RefreshCw
} from 'lucide-react';
import { AuthMode } from '../types';
import { getAutoLocation } from '../utils/geolocation';
import { formatPhoneNumber, isValidKoreanPhoneNumber } from '../utils/smsVerification';
import { isValidEmailAddress } from '../utils/emailVerification';

const DEFAULT_PERSON_AVATAR =
  'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"%3E%3Crect width="128" height="128" rx="64" fill="%23E2E8F0"/%3E%3Cpath d="M64 26a24 24 0 1 0 0 48 24 24 0 0 0 0-48zm0 58c-26.7 0-49 14.3-53 36 3.6 5 8 9.4 13 13 11 7 24.8 11 40 11s29-4 40-11c5-3.6 9.4-8 13-13-4-21.7-26.3-36-53-36z" fill="%2394A3B8"/%3E%3C/svg%3E';

const POPULAR_INTERESTS = [
  '인공지능',
  '모바일',
  '가전',
  '프로그래밍',
  '과학 이슈',
  '영화',
  '드라마',
  '방송',
  '음악/K-POP',
  '웹툰/만화',
  '책/독서',
  '요리/맛집',
  '반려동물',
  '여행/캠핑',
  '인테리어/반셀프',
  '반려식물',
  '트렌드 패션',
  '화장품',
  '스킨케어',
  '쇼핑 할인 혜택',
  '주식',
  '부동산',
  '가상화폐',
  '금융/저축',
  '창업/부업',
  '축구',
  '야구',
  '골프',
  '헬스/피트니스',
  '등산',
  '러닝/마라톤',
  '격투',
  '미술',
  '사진',
  '악기',
  '공예',
  '공연/전시',
  '외국어',
  '직무 역량',
  '자격증',
  '취업/이직'
];

const POPULAR_ROLES = [
  '학생',
  '직장인/회사원',
  '전문직',
  '공무원',
  '자영업/사업',
  '프리랜서',
  '전업주부',
  '무직/기타'
];

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalMode,
    setAuthModalMode,
    login,
    signup,
    sendSmsVerificationCode,
    verifySmsCode,
    smsGatewayInfo,
    sendEmailVerificationCode,
    verifyEmailCode,
    emailGatewayInfo,
    signupAuthConfig,
    users,
    kickedUsers,
    authNotice,
    dismissAuthNotice,
    isAuthenticated,
    currentUser,
    logout,
    terminateSession,
    findUserIdentifier,
    sendResetPasswordCode,
    verifyResetPasswordCode,
    resetUserPassword
  } = useSocial();

  // Mode: 'login' | 'signup' | 'demo'
  const mode = authModalMode;

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginRemember, setLoginRemember] = useState(true);
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Signup form state
  const [signupName, setSignupName] = useState('');
  const [signupHandle, setSignupHandle] = useState('');
  const [signupEmail, setSignupEmail] = useState('');

  // Email 6-Digit Code Verification State (Signup)
  const [isEmailVerified, setIsEmailVerified] = useState(false);
  const [emailCodeSent, setEmailCodeSent] = useState(false);
  const [emailCodeInput, setEmailCodeInput] = useState('');
  const [emailCountdown, setEmailCountdown] = useState(0);
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [isVerifyingEmail, setIsVerifyingEmail] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [emailSuccessMsg, setEmailSuccessMsg] = useState<string | null>(null);
  const [receivedEmailPreview, setReceivedEmailPreview] = useState<{
    subject: string;
    code?: string;
    isRealEmail: boolean;
    provider?: string;
  } | null>(null);

  // Phone & SMS Verification
  const [signupPhone, setSignupPhone] = useState('');
  const [isPhoneVerified, setIsPhoneVerified] = useState(false);
  const [smsCodeSent, setSmsCodeSent] = useState(false);
  const [smsCodeInput, setSmsCodeInput] = useState('');
  const [smsCountdown, setSmsCountdown] = useState(0);
  const [isSendingSms, setIsSendingSms] = useState(false);
  const [isVerifyingSms, setIsVerifyingSms] = useState(false);
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [phoneSuccessMsg, setPhoneSuccessMsg] = useState<string | null>(null);

  const [signupPassword, setSignupPassword] = useState('');
  const [signupPasswordConfirm, setSignupPasswordConfirm] = useState('');
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [signupLocation, setSignupLocation] = useState('');
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [locationSource, setLocationSource] = useState<'gps' | 'profile' | 'preset' | 'manual' | null>(null);
  const [signupRole, setSignupRole] = useState('직장인/회사원');
  const [signupBio, setSignupBio] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(DEFAULT_PERSON_AVATAR);
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');
  const [selectedInterests, setSelectedInterests] = useState<string[]>([
    '인공지능',
    '프로그래밍'
  ]);
  const [signupError, setSignupError] = useState<string | null>(null);
  const [isSigningUp, setIsSigningUp] = useState(false);

  // Age 14+ Verification States (개인정보 보호법 제22조의2)
  const [signupBirthdate, setSignupBirthdate] = useState('2000-01-01');
  const [isOver14Confirmed, setIsOver14Confirmed] = useState(false);

  // Calculate Korean International Age (만 나이)
  const calculateAge = (dateStr: string): number | null => {
    if (!dateStr) return null;
    const birth = new Date(dateStr);
    if (isNaN(birth.getTime())) return null;
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  // ================= Find ID State =================
  const [findIdMethod, setFindIdMethod] = useState<'phone' | 'email'>('phone');
  const [findIdName, setFindIdName] = useState('');
  const [findIdPhone, setFindIdPhone] = useState('');
  const [findIdEmail, setFindIdEmail] = useState('');
  const [findIdCodeInput, setFindIdCodeInput] = useState('');
  const [isFindIdCodeSent, setIsFindIdCodeSent] = useState(false);
  const [isFindIdCodeVerified, setIsFindIdCodeVerified] = useState(false);
  const [findIdCountdown, setFindIdCountdown] = useState(0);
  const [isSendingFindIdCode, setIsSendingFindIdCode] = useState(false);
  const [isVerifyingFindIdCode, setIsVerifyingFindIdCode] = useState(false);
  const [findIdError, setFindIdError] = useState<string | null>(null);
  const [foundUser, setFoundUser] = useState<{
    id: string;
    name: string;
    handle: string;
    email: string;
    phoneNumber?: string;
    joinedDate?: string;
    createdAt?: string;
  } | null>(null);

  // ================= Reset Password State =================
  const [resetStep, setResetStep] = useState<1 | 2 | 3 | 4>(1); // 1: ID & Method -> 2: Code -> 3: New PW -> 4: Success
  const [resetIdentifier, setResetIdentifier] = useState('');
  const [resetMethod, setResetMethod] = useState<'sms' | 'email'>('sms');
  const [resetTargetUser, setResetTargetUser] = useState<typeof users[0] | null>(null);
  const [resetTargetContact, setResetTargetContact] = useState('');
  const [resetCodeInput, setResetCodeInput] = useState('');
  const [resetCountdown, setResetCountdown] = useState(0);
  const [isSendingResetCode, setIsSendingResetCode] = useState(false);
  const [isVerifyingResetCode, setIsVerifyingResetCode] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [newPasswordConfirm, setNewPasswordConfirm] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetSuccessMessage, setResetSuccessMessage] = useState<string | null>(null);

  // Countdown timer for Find ID
  useEffect(() => {
    let timer: any;
    if (findIdCountdown > 0) {
      timer = setInterval(() => {
        setFindIdCountdown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [findIdCountdown]);

  // Countdown timer for Reset Password
  useEffect(() => {
    let timer: any;
    if (resetCountdown > 0) {
      timer = setInterval(() => {
        setResetCountdown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [resetCountdown]);

  // Countdown timer for SMS verification
  useEffect(() => {
    let timer: any;
    if (smsCountdown > 0) {
      timer = setInterval(() => {
        setSmsCountdown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [smsCountdown]);

  // Countdown timer for Email verification (Signup)
  useEffect(() => {
    let timer: any;
    if (emailCountdown > 0) {
      timer = setInterval(() => {
        setEmailCountdown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [emailCountdown]);

  // Auto-detect user's location via GPS / Reverse Geocoding
  const detectLocation = async () => {
    setIsDetectingLocation(true);
    try {
      const loc = await getAutoLocation();
      if (loc && loc.address) {
        setSignupLocation(loc.address);
        setLocationSource(loc.source);
      }
    } catch (err) {
      console.warn('Failed to detect location during signup:', err);
      if (!signupLocation) {
        setSignupLocation('서울 강남구');
        setLocationSource('preset');
      }
    } finally {
      setIsDetectingLocation(false);
    }
  };

  // Automatically fetch location when signup mode opens
  useEffect(() => {
    if (isAuthModalOpen && mode === 'signup' && !signupLocation) {
      detectLocation();
    }
  }, [isAuthModalOpen, mode]);

  // Reset errors when modal opens or mode switches
  useEffect(() => {
    setLoginError(null);
    setSignupError(null);
  }, [mode, isAuthModalOpen]);

  if (!isAuthModalOpen) return null;

  // Handle Login Submit
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);

    setTimeout(() => {
      const result = login(loginIdentifier, loginPassword);
      setIsLoggingIn(false);
      if (!result.success) {
        setLoginError(result.error || '로그인에 실패했습니다.');
      }
    }, 400);
  };

  // Handle Quick Demo Login
  const handleQuickDemoLogin = (userItem: typeof users[0]) => {
    if (userItem.isBanned) {
      setLoginIdentifier(userItem.handle);
      setAuthModalMode('login');
      const banDateStr = userItem.bannedAt ? new Date(userItem.bannedAt).toLocaleString('ko-KR') : '';
      setLoginError(`[이용 정지 계정]\n최고관리자에 의해 서비스 이용이 정지(차단)된 계정입니다.\n\n• 정지 사유: ${userItem.banReason || '운영 정책 위반'}\n• 정지 일시: ${banDateStr || '최근 처리됨'}\n\n계정 정지 상태에서는 서비스를 이용하실 수 없습니다. 관리자에게 문의하세요.`);
      return;
    }
    if (isAuthenticated) {
      terminateSession('새로운 계정 체험을 위해 기존 세션이 종료되었습니다.');
    }
    setLoginIdentifier(userItem.handle);
    setLoginPassword(userItem.password || 'password123');
    login(userItem.handle, userItem.password || 'password123');
  };

  // Handle Tab Switch (로그인 와중에 다시 로그인/회원가입/아이디찾기/비번찾기 버튼 클릭 시 세션 종료)
  const handleTabSwitch = (targetMode: AuthMode) => {
    if (isAuthenticated) {
      terminateSession(
        targetMode === 'login'
          ? '새로운 로그인을 위해 기존 세션이 종료되었습니다.'
          : targetMode === 'signup'
          ? '새로운 회원가입을 위해 기존 세션이 종료되었습니다.'
          : '작업 전환을 위해 기존 세션이 종료되었습니다.'
      );
    }
    setAuthModalMode(targetMode);
  };

  // ================= Find ID Handlers =================
  const handleSendFindIdCode = async () => {
    setFindIdError(null);
    if (!findIdName.trim()) {
      setFindIdError('가입 시 등록한 이름을 입력해주세요.');
      return;
    }

    const contactVal = findIdMethod === 'phone' ? findIdPhone : findIdEmail;
    if (!contactVal.trim()) {
      setFindIdError(findIdMethod === 'phone' ? '휴대폰 번호를 입력해주세요.' : '이메일 주소를 입력해주세요.');
      return;
    }

    // Check if account exists first
    const checkRes = findUserIdentifier(findIdName, contactVal, findIdMethod);
    if (!checkRes.success) {
      setFindIdError(checkRes.error || '일치하는 가입 정보를 찾을 수 없습니다.');
      return;
    }

    setIsSendingFindIdCode(true);
    try {
      if (findIdMethod === 'phone') {
        const phoneDigits = contactVal.replace(/\D/g, '');
        const res = await fetch('/api/sms/send-verification', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phoneNumber: phoneDigits })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          setFindIdError(data.error || '인증문자 발송에 실패했습니다.');
          return;
        }
        setIsFindIdCodeSent(true);
        setFindIdCountdown(180);
      } else {
        const res = await fetch('/api/email/send-verification', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: contactVal.trim().toLowerCase(), purpose: '아이디 찾기' })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          setFindIdError(data.error || '이메일 인증번호 발송에 실패했습니다.');
          return;
        }
        setIsFindIdCodeSent(true);
        setFindIdCountdown(180);
      }
    } catch (e: any) {
      setFindIdError(e.message || '인증번호 발송 처리 중 오류가 발생했습니다.');
    } finally {
      setIsSendingFindIdCode(false);
    }
  };

  const handleVerifyFindIdCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setFindIdError(null);

    const contactVal = findIdMethod === 'phone' ? findIdPhone : findIdEmail;
    if (!findIdCodeInput.trim()) {
      setFindIdError('6자리 인증번호를 입력해주세요.');
      return;
    }

    setIsVerifyingFindIdCode(true);
    try {
      if (findIdMethod === 'phone') {
        const phoneDigits = contactVal.replace(/\D/g, '');
        const res = await fetch('/api/sms/verify-code', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phoneNumber: phoneDigits, code: findIdCodeInput.trim() })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          setFindIdError(data.error || '인증번호가 일치하지 않습니다.');
          return;
        }
      } else {
        const res = await fetch('/api/email/verify-code', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: contactVal.trim().toLowerCase(), code: findIdCodeInput.trim() })
        });
        const data = await res.json();
        if (!res.ok || !data.success) {
          setFindIdError(data.error || '인증번호가 일치하지 않습니다.');
          return;
        }
      }

      setIsFindIdCodeVerified(true);
      const userRes = findUserIdentifier(findIdName, contactVal, findIdMethod);
      if (userRes.success && userRes.user) {
        setFoundUser(userRes.user);
      } else {
        setFindIdError(userRes.error || '가입된 계정 정보를 조회할 수 없습니다.');
      }
    } catch (err: any) {
      setFindIdError(err.message || '인증 처리 중 오류가 발생했습니다.');
    } finally {
      setIsVerifyingFindIdCode(false);
    }
  };

  const handleDirectFindId = (e: React.FormEvent) => {
    e.preventDefault();
    setFindIdError(null);
    if (!findIdName.trim()) {
      setFindIdError('이름을 입력해주세요.');
      return;
    }
    const contactVal = findIdMethod === 'phone' ? findIdPhone : findIdEmail;
    if (!contactVal.trim()) {
      setFindIdError(findIdMethod === 'phone' ? '휴대폰 번호를 입력해주세요.' : '이메일 주소를 입력해주세요.');
      return;
    }

    const res = findUserIdentifier(findIdName, contactVal, findIdMethod);
    if (res.success && res.user) {
      setFoundUser(res.user);
    } else {
      setFindIdError(res.error || '입력하신 정보와 일치하는 계정을 찾을 수 없습니다.');
    }
  };

  // ================= Reset Password Handlers =================
  const handleSendResetPasswordCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    if (!resetIdentifier.trim()) {
      setResetError('비밀번호를 재설정할 계정 아이디를 입력해주세요.');
      return;
    }

    setIsSendingResetCode(true);
    try {
      const res = await sendResetPasswordCode(resetIdentifier.trim(), 'sms');
      if (!res.success) {
        setResetError(res.error || 'SMS 인증번호 발송에 실패했습니다.');
        return;
      }
      setResetTargetUser(res.user || null);
      setResetTargetContact(res.target || '');
      setResetStep(2);
      setResetCountdown(180);
    } catch (err: any) {
      setResetError(err.message || '인증코드 발송 오류');
    } finally {
      setIsSendingResetCode(false);
    }
  };

  const handleVerifyResetCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);
    if (!resetCodeInput.trim()) {
      setResetError('6자리 SMS 인증번호를 입력해주세요.');
      return;
    }

    setIsVerifyingResetCode(true);
    try {
      const res = await verifyResetPasswordCode(resetTargetContact, resetCodeInput.trim(), 'sms');
      if (!res.success) {
        setResetError(res.error || '인증번호가 일치하지 않습니다.');
        return;
      }
      setResetStep(3);
    } catch (err: any) {
      setResetError(err.message || '인증 확인 오류');
    } finally {
      setIsVerifyingResetCode(false);
    }
  };

  const handleResetPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetError(null);

    if (!newPassword || newPassword.length < 4) {
      setResetError('비밀번호는 최소 4자 이상으로 입력해주세요.');
      return;
    }
    if (newPassword !== newPasswordConfirm) {
      setResetError('새 비밀번호와 비밀번호 확인 입력이 일치하지 않습니다.');
      return;
    }
    if (!resetTargetUser) {
      setResetError('대상 계정 정보가 없습니다. 처음부터 다시 시도해주세요.');
      return;
    }

    setIsResettingPassword(true);
    try {
      const res = await resetUserPassword(resetTargetUser.id, newPassword);
      if (!res.success) {
        setResetError(res.error || '비밀번호 재설정에 실패했습니다.');
        return;
      }
      setResetStep(4);
      setResetSuccessMessage('비밀번호가 성공적으로 변경되었습니다!');
    } catch (err: any) {
      setResetError(err.message || '비밀번호 변경 처리 중 오류가 발생했습니다.');
    } finally {
      setIsResettingPassword(false);
    }
  };

  // Handle Interest Toggle
  const toggleInterest = (tag: string) => {
    setSelectedInterests((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  // Handle File Upload for Avatar
  const handleAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setSignupError('이미지 파일 크기는 5MB 이하여야 합니다.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setSelectedAvatar(event.target.result as string);
          setCustomAvatarUrl('');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle Send SMS Verification Code
  const handleSendSmsCode = async () => {
    setPhoneError(null);
    setPhoneSuccessMsg(null);

    const digits = signupPhone.replace(/\D/g, '');
    if (!digits) {
      setPhoneError('휴대폰 번호를 입력해주세요.');
      return;
    }
    if (!isValidKoreanPhoneNumber(signupPhone)) {
      setPhoneError('올바른 한국 휴대폰 번호(010-XXXX-XXXX)를 입력해주세요.');
      return;
    }

    setIsSendingSms(true);
    try {
      const res = await sendSmsVerificationCode(signupPhone);
      setIsSendingSms(false);
      if (res.success) {
        setSmsCodeSent(true);
        setIsPhoneVerified(false);
        setSmsCodeInput('');
        setSmsCountdown(180); // 3 minutes

        if (res.isRealSmsSent) {
          setPhoneSuccessMsg(
            `📱 [${signupPhone}] 본인 휴대폰 문자메시지로 6자리 인증번호가 실제 발송되었습니다. 수신된 문자를 확인해주세요.`
          );
        } else {
          setPhoneSuccessMsg(
            `📱 [${signupPhone}] 번호로 SMS 인증 문자가 발송되었습니다. 수신된 문자메시지의 인증번호 6자리를 입력해주세요.`
          );
        }
      } else {
        setPhoneError(res.error || '인증번호 발송에 실패했습니다.');
      }
    } catch (err: any) {
      setIsSendingSms(false);
      setPhoneError('인증번호 요청 중 오류가 발생했습니다.');
    }
  };

  // Handle Verify SMS Code
  const handleVerifySmsCode = async () => {
    setPhoneError(null);
    setPhoneSuccessMsg(null);

    if (!smsCodeInput.trim()) {
      setPhoneError('인증번호 6자리를 입력해주세요.');
      return;
    }

    setIsVerifyingSms(true);
    try {
      const res = await verifySmsCode(signupPhone, smsCodeInput);
      setIsVerifyingSms(false);
      if (res.success) {
        setIsPhoneVerified(true);
        setPhoneSuccessMsg('휴대폰 번호 본인인증이 완료되었습니다! ✅');
      } else {
        setPhoneError(res.error || '인증번호가 일치하지 않습니다. 다시 확인해주세요.');
      }
    } catch (err) {
      setIsVerifyingSms(false);
      setPhoneError('인증 확인 처리 중 통신 오류가 발생했습니다.');
    }
  };

  // Handle Send Email Verification Code (Signup)
  const handleSendEmailCode = async () => {
    setEmailError(null);
    setEmailSuccessMsg(null);
    setReceivedEmailPreview(null);

    const cleanEmail = signupEmail.trim().toLowerCase();
    if (!cleanEmail) {
      setEmailError('이메일 주소를 입력해주세요.');
      return;
    }
    if (!isValidEmailAddress(cleanEmail)) {
      setEmailError('올바른 이메일 주소 형식(예: user@example.com)을 입력해주세요.');
      return;
    }

    const emailExists = users.some((u) => u.email && u.email.toLowerCase() === cleanEmail);
    if (emailExists) {
      setEmailError('이미 가입된 이메일 주소입니다. 로그인 탭에서 이메일 인증 로그인을 이용해주세요.');
      return;
    }

    setIsSendingEmail(true);
    try {
      const res = await sendEmailVerificationCode(cleanEmail, '회원가입');
      setIsSendingEmail(false);
      if (res.success) {
        setEmailCodeSent(true);
        setIsEmailVerified(false);
        setEmailCodeInput('');
        setEmailCountdown(300); // 5 minutes
        setReceivedEmailPreview({
          subject: res.emailSubject || `[마음(Maeum)] 회원가입 인증번호 [${res.simulatedCode || '******'}]`,
          code: res.simulatedCode,
          isRealEmail: !!res.isRealEmailSent,
          provider: res.provider,
        });

        if (res.isRealEmailSent) {
          setEmailSuccessMsg(`✉️ [${cleanEmail}] 주소로 6자리 인증번호가 실제 발송되었습니다. 수신함을 확인해주세요.`);
        } else {
          setEmailSuccessMsg(`✉️ [${cleanEmail}] 주소로 6자리 인증번호가 발송되었습니다. 수신된 코드를 입력해주세요.`);
        }
      } else {
        setEmailError(res.error || '이메일 인증번호 발송에 실패했습니다.');
      }
    } catch (err: any) {
      setIsSendingEmail(false);
      setEmailError('인증번호 요청 중 통신 오류가 발생했습니다.');
    }
  };

  // Handle Verify Email Code (Signup)
  const handleVerifyEmailCode = async () => {
    setEmailError(null);
    setEmailSuccessMsg(null);

    const cleanCode = emailCodeInput.trim();
    if (!cleanCode || cleanCode.length !== 6) {
      setEmailError('숫자 6자리 인증번호를 정확히 입력해주세요.');
      return;
    }

    setIsVerifyingEmail(true);
    try {
      const res = await verifyEmailCode(signupEmail, cleanCode);
      setIsVerifyingEmail(false);
      if (res.success) {
        setIsEmailVerified(true);
        setEmailSuccessMsg('이메일 본인인증이 성공적으로 완료되었습니다! ✅');
        setReceivedEmailPreview(null);
      } else {
        setEmailError(res.error || '인증번호가 일치하지 않습니다. 다시 확인해주세요.');
      }
    } catch (err) {
      setIsVerifyingEmail(false);
      setEmailError('인증 확인 처리 중 통신 오류가 발생했습니다.');
    }
  };

  // Handle Signup Submit
  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSignupError(null);

    // Basic Validations
    if (!signupName.trim()) {
      setSignupError('이름을 입력해주세요.');
      return;
    }
    if (!signupHandle.trim()) {
      setSignupError('사용자 아이디(핸들)를 입력해주세요.');
      return;
    }
    if (!signupEmail.trim() || !signupEmail.includes('@')) {
      setSignupError('유효한 이메일 주소를 입력해주세요.');
      return;
    }

    const verificationMethod = signupAuthConfig?.verificationMethod || 'sms';

    // Phone & SMS verification check (Primary Verification)
    if (verificationMethod !== 'none') {
      if (!signupPhone.trim()) {
        setSignupError('휴대폰 번호는 필수 입력 항목입니다.');
        return;
      }
      if (!isPhoneVerified) {
        setSignupError('휴대폰 본인인증(SMS 문자 6자리 코드 확인)을 완료해주세요.');
        return;
      }
    }

    if (signupPassword.length < 4) {
      setSignupError('비밀번호는 최소 4자 이상 입력해주세요.');
      return;
    }
    if (signupPassword !== signupPasswordConfirm) {
      setSignupError('비밀번호와 비밀번호 확인이 일치하지 않습니다.');
      return;
    }
    if (!signupLocation.trim()) {
      setSignupError('주거지는 필수 의무 입력 항목입니다. 현재 위치를 감지하거나 직접 입력해주세요.');
      return;
    }

    // 만 14세 이상 연령 확인 검증
    if (!isOver14Confirmed) {
      setSignupError('만 14세 이상 확인(필수) 동의 항목에 체크해주세요.');
      return;
    }

    if (signupBirthdate) {
      const age = calculateAge(signupBirthdate);
      if (age !== null && age < 14) {
        setSignupError(`만 14세 미만(현재 만 ${age}세)은 관련 법률(개인정보 보호법 제22조의2)에 따라 가입이 제한됩니다. 만 14세 이상만 회원가입이 가능합니다.`);
        return;
      }
    }

    setIsSigningUp(true);
    setTimeout(() => {
      const avatarToUse = customAvatarUrl.trim() || selectedAvatar;
      const result = signup({
        name: signupName,
        handle: signupHandle,
        email: signupEmail,
        emailVerified: isEmailVerified,
        phoneNumber: signupPhone,
        phoneVerified: isPhoneVerified,
        password: signupPassword,
        location: signupLocation.trim(),
        avatar: avatarToUse,
        bio: signupBio,
        role: signupRole,
        interests: selectedInterests,
        birthdate: signupBirthdate,
        isOver14Confirmed: isOver14Confirmed
      });
      setIsSigningUp(false);
      if (!result.success) {
        setSignupError(result.error || '회원가입에 실패했습니다.');
      } else {
        setLoginIdentifier(signupHandle.trim().toLowerCase().replace(/^@/, ''));
        setLoginPassword('');
        setAuthModalMode('login');
      }
    }, 450);
  };

  // Password strength calculation
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, text: '비밀번호를 입력해주세요', color: 'bg-zinc-200 dark:bg-zinc-700' };
    if (pass.length < 4) return { score: 1, text: '매우 취약 (4자 이상 필요)', color: 'bg-rose-500' };
    if (pass.length < 8) return { score: 2, text: '보통', color: 'bg-amber-500' };
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pass);
    const hasNum = /[0-9]/.test(pass);
    if (hasSpecial && hasNum && pass.length >= 8) return { score: 4, text: '아주 강력함 🛡️', color: 'bg-emerald-500' };
    return { score: 3, text: '안전함 👍', color: 'bg-blue-500' };
  };

  const passwordStrength = getPasswordStrength(signupPassword);

  return (
    <div
      id="auth-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeAuthModal();
      }}
    >
      <div
        id="auth-modal-card"
        className="relative w-full max-w-xl max-h-[92vh] flex flex-col bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-2xl shadow-2xl overflow-hidden"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-100 dark:border-zinc-800/80 bg-zinc-50/70 dark:bg-zinc-900/80">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-600 flex items-center justify-center shadow-md shadow-indigo-500/20 text-white font-bold text-lg">
              M
            </div>
            <div>
              <h2 className="text-base font-bold text-zinc-900 dark:text-white flex items-center gap-1.5">
                마음 계정
              </h2>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                실시간 소통과 미디어가 흐르는 소셜 네트워크
              </p>
            </div>
          </div>
          <button
            id="close-auth-modal-btn"
            onClick={closeAuthModal}
            className="p-1.5 text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-200/60 dark:hover:bg-zinc-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-zinc-100 dark:border-zinc-800 bg-white dark:bg-zinc-900 px-6 pt-3 gap-2 overflow-x-auto">
          {!isAuthenticated ? (
            <button
              id="auth-tab-login"
              onClick={() => handleTabSwitch('login')}
              className={`flex items-center gap-2 pb-3 px-3 text-sm font-semibold border-b-2 transition-all shrink-0 ${
                mode === 'login'
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                  : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
              }`}
            >
              <LogIn className="w-4 h-4" />
              로그인
            </button>
          ) : (
            <button
              id="auth-tab-session"
              onClick={() => setAuthModalMode('login')}
              className={`flex items-center gap-2 pb-3 px-3 text-sm font-semibold border-b-2 transition-all shrink-0 ${
                mode === 'login'
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                  : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              현재 세션 상태
            </button>
          )}

          <button
            id="auth-tab-signup"
            onClick={() => handleTabSwitch('signup')}
            className={`flex items-center gap-2 pb-3 px-3 text-sm font-semibold border-b-2 transition-all shrink-0 ${
              mode === 'signup'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            회원가입
          </button>

          <button
            id="auth-tab-find-id"
            onClick={() => {
              setFoundUser(null);
              setFindIdError(null);
              handleTabSwitch('find-id');
            }}
            className={`flex items-center gap-2 pb-3 px-3 text-sm font-semibold border-b-2 transition-all shrink-0 ${
              mode === 'find-id'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <Search className="w-4 h-4" />
            아이디 찾기
          </button>

          <button
            id="auth-tab-reset-password"
            onClick={() => {
              setResetStep(1);
              setResetError(null);
              handleTabSwitch('reset-password');
            }}
            className={`flex items-center gap-2 pb-3 px-3 text-sm font-semibold border-b-2 transition-all shrink-0 ${
              mode === 'reset-password'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            비밀번호 찾기
          </button>
        </div>

        {/* Modal Body */}
        <div className="overflow-y-auto px-6 py-5 space-y-5 flex-1 max-h-[calc(92vh-140px)]">
          {/* Super Admin Kick / Suspension Notice Banner */}
          {authNotice && (
            <div className="p-4 bg-rose-50 dark:bg-rose-950/60 border-2 border-rose-500/80 dark:border-rose-600 rounded-2xl text-rose-900 dark:text-rose-100 text-xs shadow-lg animate-in slide-in-from-top-2 duration-200 space-y-2.5">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 font-black text-sm text-rose-700 dark:text-rose-300">
                  <ShieldAlert className="w-5 h-5 shrink-0 text-rose-600 dark:text-rose-400" />
                  <span>{authNotice.title}</span>
                </div>
                <button
                  type="button"
                  onClick={dismissAuthNotice}
                  className="text-rose-400 hover:text-rose-600 dark:hover:text-rose-200 p-1 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-900/50 transition-colors"
                  title="닫기"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="p-3 bg-white/80 dark:bg-black/40 rounded-xl border border-rose-200/80 dark:border-rose-800/70 space-y-1">
                <p className="font-bold text-xs text-rose-800 dark:text-rose-200 flex items-start gap-1.5">
                  <span className="shrink-0">{authNotice.type === 'kicked' ? '강퇴 사유:' : '정지 사유:'}</span>
                  <span className="text-rose-600 dark:text-rose-400 font-extrabold">{authNotice.reason}</span>
                </p>
                {authNotice.date && (
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                    처리 일시: {new Date(authNotice.date).toLocaleString('ko-KR')}
                  </p>
                )}
                {authNotice.by && (
                  <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                    처리 담당: {authNotice.by}
                  </p>
                )}
              </div>
              <p className="text-[11px] font-semibold text-rose-700 dark:text-rose-300">
                🚫 최고관리자의 조치로 인해 해당 계정으로는 서비스에 접속하거나 이용하실 수 없습니다.
              </p>
            </div>
          )}

          {/* ======================= LOGIN VIEW ======================= */}
          {mode === 'login' && (
            <div className="space-y-4">
              {isAuthenticated ? (
                /* 로그인되어 있는 경우: 로그인 버튼을 숨기고 세션 안내 및 세션 종료 버튼 제공 */
                <div id="login-already-authenticated" className="p-6 bg-slate-50 dark:bg-zinc-800/70 border border-slate-200 dark:border-zinc-700/80 rounded-2xl text-center space-y-4 animate-in fade-in">
                  <div className="mx-auto w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-zinc-900 dark:text-white">
                      현재 로그인되어 있습니다
                    </h3>
                    <p className="text-xs text-zinc-600 dark:text-zinc-300 mt-1">
                      <strong className="text-indigo-600 dark:text-indigo-400">{currentUser.name}</strong> (@{currentUser.handle}) 계정으로 활성화된 세션입니다.
                    </p>
                    <p className="text-[11px] text-zinc-400 dark:text-zinc-500 mt-1">
                      다른 계정으로 새로 로그인하시려면 먼저 기존 세션을 종료해주세요.
                    </p>
                  </div>
                  <div className="flex items-center justify-center gap-2 pt-2">
                    <button
                      type="button"
                      id="terminate-current-session-btn"
                      onClick={() => logout()}
                      className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>세션 종료 및 로그아웃</span>
                    </button>
                    <button
                      type="button"
                      onClick={closeAuthModal}
                      className="px-4 py-2.5 bg-zinc-200 dark:bg-zinc-700 hover:bg-zinc-300 dark:hover:bg-zinc-600 text-zinc-800 dark:text-zinc-200 text-xs font-bold rounded-xl transition-all cursor-pointer"
                    >
                      닫기
                    </button>
                  </div>
                </div>
              ) : (
                /* 미로그인 상태: 정상 로그인 폼과 로그인하기 버튼 표시 */
                <>
                  <div className="space-y-1">
                    <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
                      다시 오신 것을 환영합니다 👋
                    </h3>
                    <p className="text-xs text-zinc-500 dark:text-zinc-400">
                      아이디와 비밀번호로 안전하게 로그인하세요.
                    </p>
                  </div>

                  {/* Password Login Form */}
                  <form onSubmit={handleLoginSubmit} className="space-y-4">
                    {loginError && (
                      <div className="p-4 bg-rose-50 dark:bg-rose-950/50 border-2 border-rose-400 dark:border-rose-600/70 rounded-2xl flex items-start gap-3 text-rose-800 dark:text-rose-200 text-xs shadow-md animate-in fade-in">
                        <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5 text-rose-600 dark:text-rose-400" />
                        <div className="space-y-1.5 flex-1">
                          <p className="font-black text-sm text-rose-900 dark:text-rose-100 flex items-center gap-1.5">
                            {loginError.includes('강제 탈퇴')
                              ? '🚫 계정 강제 탈퇴(영구 제명) 안내'
                              : loginError.includes('이용 정지')
                              ? '🛑 서비스 이용 정지(차단) 안내'
                              : '로그인 오류 안내'}
                          </p>
                          <div className="leading-relaxed whitespace-pre-line font-medium text-xs text-rose-700 dark:text-rose-300 bg-white/70 dark:bg-black/30 p-2.5 rounded-xl border border-rose-200/80 dark:border-rose-800/60">
                            {loginError}
                          </div>
                          {(loginError.includes('강제 탈퇴') || loginError.includes('이용 정지')) && (
                            <p className="text-[11px] text-rose-600 dark:text-rose-400 font-bold">
                              ⚠️ 최고관리자의 권한으로 계정 접속 및 서비스 이용이 엄격히 차단되었습니다.
                            </p>
                          )}
                        </div>
                      </div>
                    )}

                    {/* ID / Email Input */}
                    <div className="space-y-1.5">
                      <label
                        htmlFor="login-identifier"
                        className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                      >
                        아이디 또는 이메일
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                          <AtSign className="w-4 h-4" />
                        </div>
                        <input
                          id="login-identifier"
                          type="text"
                          required
                          value={loginIdentifier}
                          onChange={(e) => setLoginIdentifier(e.target.value)}
                          placeholder="예: minwoo_dev 또는 minwoo@pulse.io"
                          className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                        />
                      </div>
                    </div>

                    {/* Password Input */}
                    <div className="space-y-1.5">
                      <label
                        htmlFor="login-password"
                        className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                      >
                        비밀번호
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                          <Lock className="w-4 h-4" />
                        </div>
                        <input
                          id="login-password"
                          type={showLoginPassword ? 'text' : 'password'}
                          required
                          value={loginPassword}
                          onChange={(e) => setLoginPassword(e.target.value)}
                          placeholder="비밀번호를 입력하세요"
                          className="w-full pl-10 pr-10 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                        />
                        <button
                          type="button"
                          onClick={() => setShowLoginPassword((prev) => !prev)}
                          className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 cursor-pointer"
                        >
                          {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Remember Me & Find ID / Password Links */}
                    <div className="flex items-center justify-between flex-wrap gap-2 pt-1 text-xs">
                      <label className="flex items-center gap-2 cursor-pointer select-none">
                        <input
                          type="checkbox"
                          checked={loginRemember}
                          onChange={(e) => setLoginRemember(e.target.checked)}
                          className="w-4 h-4 text-indigo-600 rounded border-zinc-300 dark:border-zinc-700 focus:ring-indigo-500 dark:bg-zinc-800"
                        />
                        <span className="text-xs text-zinc-600 dark:text-zinc-400">
                          로그인 상태 유지
                        </span>
                      </label>
                      <div className="flex items-center gap-2 text-zinc-500 dark:text-zinc-400 font-medium text-xs">
                        <button
                          type="button"
                          id="btn-find-id-link"
                          onClick={() => {
                            setFoundUser(null);
                            setFindIdError(null);
                            handleTabSwitch('find-id');
                          }}
                          className="hover:text-indigo-600 dark:hover:text-indigo-400 hover:underline transition-colors cursor-pointer"
                        >
                          아이디 찾기
                        </button>
                        <span className="text-zinc-300 dark:text-zinc-700 select-none">|</span>
                        <button
                          type="button"
                          id="btn-find-pw-link"
                          onClick={() => {
                            setResetStep(1);
                            setResetError(null);
                            handleTabSwitch('reset-password');
                          }}
                          className="hover:text-indigo-600 dark:hover:text-indigo-400 hover:underline transition-colors cursor-pointer"
                        >
                          비밀번호 찾기
                        </button>
                      </div>
                    </div>

                    {/* Submit Button */}
                    <button
                      id="login-submit-btn"
                      type="submit"
                      disabled={isLoggingIn}
                      className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-semibold text-sm rounded-xl shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all active:scale-[0.99] cursor-pointer"
                    >
                      {isLoggingIn ? (
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <LogIn className="w-4 h-4" />
                          로그인하기
                        </>
                      )}
                    </button>
                  </form>

                  {/* Switch to Signup */}
                  <div className="pt-2 text-center">
                    <p className="text-xs text-zinc-500 dark:text-zinc-400">
                      아직 계정이 없으신가요?{' '}
                      <button
                        type="button"
                        onClick={() => handleTabSwitch('signup')}
                        className="font-bold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                      >
                        회원가입하기
                      </button>
                    </p>
                  </div>
                </>
              )}
            </div>
          )}

          {/* ======================= SIGNUP VIEW ======================= */}
          {mode === 'signup' && (
            <form onSubmit={handleSignupSubmit} className="space-y-4">
              <div className="space-y-1">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h3 className="text-lg font-bold text-zinc-900 dark:text-white">
                    마음 계정 생성 🎉
                  </h3>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
                    <Smartphone className="w-3 h-3" />
                    <span>휴대폰 SMS 본인인증 필수</span>
                  </span>
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  안전한 커뮤니티 이용을 위해 휴대폰 SMS 문자로 발송되는 6자리 본인확인 인증번호를 입력해주세요.
                </p>
              </div>

              {signupError && (
                <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 rounded-xl flex items-start gap-2.5 text-rose-700 dark:text-rose-300 text-xs animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{signupError}</span>
                </div>
              )}

              {/* Basic Fields Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Full Name */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="signup-name"
                    className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                  >
                    이름 (실명 또는 닉네임) *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                      <User className="w-4 h-4" />
                    </div>
                    <input
                      id="signup-name"
                      type="text"
                      required
                      value={signupName}
                      onChange={(e) => setSignupName(e.target.value)}
                      placeholder="예: 홍길동"
                      className="w-full pl-10 pr-3 py-2 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                    />
                  </div>
                </div>

                {/* Handle (@username) */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="signup-handle"
                    className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                  >
                    아이디 (핸들) *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                      <AtSign className="w-4 h-4" />
                    </div>
                    <input
                      id="signup-handle"
                      type="text"
                      required
                      value={signupHandle}
                      onChange={(e) => setSignupHandle(e.target.value.replace(/\s+/g, ''))}
                      placeholder="예: gildong_dev"
                      className="w-full pl-10 pr-3 py-2 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* Email Address Input (Standard clean input, no email verification buttons) */}
              <div className="space-y-1.5">
                <label
                  htmlFor="signup-email"
                  className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300 flex items-center gap-1.5"
                >
                  <Mail className="w-3.5 h-3.5 text-zinc-500" />
                  이메일 주소 (아이디 / 로그인용) *
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    id="signup-email"
                    type="email"
                    required
                    value={signupEmail}
                    onChange={(e) => setSignupEmail(e.target.value)}
                    placeholder="example@maeum.io"
                    className="w-full pl-10 pr-3.5 py-2 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                  />
                </div>
              </div>

              {/* Phone Number & SMS Verification Field (Dedicated Primary Verification Module) */}
              <div className="space-y-2.5 p-4 rounded-xl border transition-all bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800/80 ring-1 ring-emerald-500/20">
                <div className="flex items-center justify-between flex-wrap gap-1">
                  <label
                    htmlFor="signup-phone"
                    className="block text-xs font-bold text-zinc-800 dark:text-zinc-200 flex items-center gap-1.5"
                  >
                    <Phone className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    휴대폰 본인인증 (SMS 문자 6자리 인증) * [필수]
                  </label>
                  {isPhoneVerified ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-100/90 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800">
                      <CheckCircle className="w-3.5 h-3.5" />
                      본인인증 & DB 승인완료
                    </span>
                  ) : (
                    <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 bg-emerald-100/60 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full">
                      <Smartphone className="w-3 h-3" />
                      SMS 문자 6자리 필수
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="relative w-full">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                      <Phone className="w-4 h-4" />
                    </div>
                    <input
                      id="signup-phone"
                      type="tel"
                      required={signupAuthConfig?.verificationMethod === 'sms' || signupAuthConfig?.verificationMethod === 'both'}
                      disabled={isPhoneVerified}
                      value={signupPhone}
                      onChange={(e) => {
                        const formatted = formatPhoneNumber(e.target.value);
                        setSignupPhone(formatted);
                        if (isPhoneVerified) setIsPhoneVerified(false);
                        if (smsCodeSent) setSmsCodeSent(false);
                      }}
                      placeholder="010-1234-5678"
                      className={`w-full pl-10 pr-3.5 py-2.5 bg-white dark:bg-zinc-800 border rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all ${
                        isPhoneVerified
                          ? 'border-emerald-500 bg-emerald-50/20 text-emerald-800 dark:text-emerald-300'
                          : 'border-zinc-300 dark:border-zinc-700'
                      }`}
                    />
                  </div>
                  <button
                    id="signup-send-sms-btn"
                    type="button"
                    disabled={isSendingSms || isPhoneVerified || !signupPhone.trim()}
                    onClick={handleSendSmsCode}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs sm:text-sm font-semibold rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer"
                  >
                    {isSendingSms ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <MessageSquare className="w-4 h-4" />
                    )}
                    {smsCodeSent ? '인증문자 재전송' : '문자메시지 전송'}
                  </button>
                </div>

                {/* SMS Code Input & Confirm Section */}
                {smsCodeSent && !isPhoneVerified && (
                  <div className="mt-2.5 pt-2.5 border-t border-indigo-100/70 dark:border-indigo-900/40 space-y-2.5">
                    <div className="flex items-center justify-between text-xs text-zinc-600 dark:text-zinc-300">
                      <span className="font-medium flex items-center gap-1.5">
                        <MessageSquare className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                        수신된 문자메시지 인증번호 6자리
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded">
                          DB 등록완료
                        </span>
                        <span className="text-rose-500 dark:text-rose-400 font-mono font-bold">
                          {Math.floor(smsCountdown / 60)}:
                          {(smsCountdown % 60).toString().padStart(2, '0')}
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <input
                        id="signup-sms-code"
                        type="text"
                        maxLength={6}
                        value={smsCodeInput}
                        onChange={(e) => setSmsCodeInput(e.target.value.replace(/\D/g, ''))}
                        placeholder="인증번호 6자리 입력"
                        className="flex-1 px-3 py-2 bg-white dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm font-mono tracking-widest text-center text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                      />
                      <button
                        id="signup-verify-sms-btn"
                        type="button"
                        disabled={isVerifyingSms || smsCodeInput.trim().length !== 6 || smsCountdown === 0}
                        onClick={handleVerifySmsCode}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shrink-0 flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                      >
                        {isVerifyingSms ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Check className="w-3.5 h-3.5" />
                        )}
                        인증확인
                      </button>
                    </div>
                  </div>
                )}

                {/* Phone verification feedback alerts */}
                {phoneError && (
                  <p className="text-xs text-rose-500 dark:text-rose-400 flex items-center gap-1 pt-0.5">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    {phoneError}
                  </p>
                )}
                {phoneSuccessMsg && (
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1 pt-0.5">
                    <CheckCircle className="w-3.5 h-3.5 shrink-0" />
                    {phoneSuccessMsg}
                  </p>
                )}
              </div>

              {/* Password & Confirm */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Password */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="signup-password"
                    className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                  >
                    비밀번호 (4자 이상) *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      id="signup-password"
                      type={showSignupPassword ? 'text' : 'password'}
                      required
                      value={signupPassword}
                      onChange={(e) => setSignupPassword(e.target.value)}
                      placeholder="비밀번호 설정"
                      className="w-full pl-10 pr-10 py-2 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowSignupPassword((prev) => !prev)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200"
                    >
                      {showSignupPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* Password Confirm */}
                <div className="space-y-1.5">
                  <label
                    htmlFor="signup-password-confirm"
                    className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                  >
                    비밀번호 확인 *
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <input
                      id="signup-password-confirm"
                      type={showSignupPassword ? 'text' : 'password'}
                      required
                      value={signupPasswordConfirm}
                      onChange={(e) => setSignupPasswordConfirm(e.target.value)}
                      placeholder="비밀번호 재입력"
                      className={`w-full pl-10 pr-3 py-2 bg-zinc-50 dark:bg-zinc-800/80 border rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all ${
                        signupPasswordConfirm && signupPassword === signupPasswordConfirm
                          ? 'border-emerald-500 dark:border-emerald-500 focus:border-emerald-500'
                          : signupPasswordConfirm && signupPassword !== signupPasswordConfirm
                          ? 'border-rose-500 dark:border-rose-500 focus:border-rose-500'
                          : 'border-zinc-300 dark:border-zinc-700 focus:border-indigo-600'
                      }`}
                    />
                  </div>
                </div>
              </div>

              {/* Password strength bar */}
              {signupPassword && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-zinc-500">비밀번호 강도</span>
                    <span className="font-medium text-zinc-700 dark:text-zinc-300">
                      {passwordStrength.text}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-full overflow-hidden flex gap-1">
                    {[1, 2, 3, 4].map((step) => (
                      <div
                        key={step}
                        className={`h-full flex-1 transition-all ${
                          passwordStrength.score >= step
                            ? passwordStrength.color
                            : 'bg-transparent'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Mandatory Address / Location with Auto-detection */}
              <div className="space-y-1.5 pt-1 border-t border-zinc-100 dark:border-zinc-800/80">
                <div className="flex items-center justify-between">
                  <label
                    htmlFor="signup-location"
                    className="flex items-center gap-1.5 text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                  >
                    <MapPin className="w-3.5 h-3.5 text-rose-500" />
                    <span>주거지</span>
                    <span className="text-rose-500 font-bold">* (의무 입력)</span>
                  </label>

                  {/* Auto-detect button */}
                  <button
                    type="button"
                    onClick={detectLocation}
                    disabled={isDetectingLocation}
                    className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 flex items-center gap-1 cursor-pointer font-medium disabled:opacity-50 transition-colors"
                    title="현재 위치 자동 다시 감지"
                  >
                    {isDetectingLocation ? (
                      <>
                        <Loader2 className="w-3 h-3 animate-spin text-indigo-600 dark:text-indigo-400" />
                        <span>위치 감지 중...</span>
                      </>
                    ) : (
                      <>
                        <RotateCw className="w-3 h-3" />
                        <span>현재 위치 다시 감지</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-rose-500">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <input
                    id="signup-location"
                    type="text"
                    required
                    value={signupLocation}
                    onChange={(e) => {
                      setSignupLocation(e.target.value);
                      setLocationSource('manual');
                    }}
                    placeholder={
                      isDetectingLocation
                        ? '현재 위치 정보를 감지하여 주소를 자동 입력하는 중...'
                        : '예: 서울 강남구 역삼동, 부산 해운대구 (위치 정보로 자동 입력됨)'
                    }
                    className={`w-full pl-10 pr-10 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all font-medium ${
                      !signupLocation && signupError
                        ? 'border-rose-400 dark:border-rose-700 focus:border-rose-500 ring-2 ring-rose-500/10'
                        : 'border-zinc-300 dark:border-zinc-700 focus:border-indigo-600'
                    }`}
                  />
                  {signupLocation && (
                    <button
                      type="button"
                      onClick={() => {
                        setSignupLocation('');
                        setLocationSource(null);
                      }}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 cursor-pointer"
                      title="주소 지우기"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Auto Detection Status & Guide */}
                <div className="flex items-center justify-between flex-wrap gap-1 px-0.5 text-[11px]">
                  {isDetectingLocation ? (
                    <span className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-400 font-medium">
                      <Loader2 className="w-3 h-3 animate-spin" />
                      GPS 위치 정보를 확인하여 주소를 자동 입력하고 있습니다...
                    </span>
                  ) : signupLocation ? (
                    <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                      <CheckCircle className="w-3 h-3" />
                      {locationSource === 'gps'
                        ? 'GPS 위치 정보로 자동 입력되었습니다 (필요 시 직접 수정 가능)'
                        : '위치 정보가 입력되었습니다 (직접 수정 가능)'}
                    </span>
                  ) : (
                    <span className="text-rose-500 dark:text-rose-400 font-medium">
                      * 주소는 의무 입력 항목입니다. 위치를 감지하거나 직접 입력해주세요.
                    </span>
                  )}
                </div>
              </div>

              {/* Avatar Selection */}
              <div className="space-y-2 pt-2 border-t border-zinc-100 dark:border-zinc-800">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                    프로필 사진 선택
                  </label>
                  {(selectedAvatar !== DEFAULT_PERSON_AVATAR || customAvatarUrl.trim()) && (
                    <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                      사진 업로드 완료
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-4 p-3 bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-200/80 dark:border-zinc-700/60 rounded-2xl">
                  {/* Leftmost Photo: Human figure silhouette by default / Uploaded photo */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="relative group shrink-0 cursor-pointer"
                    title="클릭하여 프로필 사진 업로드"
                  >
                    <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-zinc-300 dark:border-zinc-600 group-hover:border-indigo-600 transition-all shadow-sm bg-zinc-100 dark:bg-zinc-800">
                      <img
                        src={customAvatarUrl.trim() || selectedAvatar || DEFAULT_PERSON_AVATAR}
                        alt="프로필 사진"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute inset-0 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                      <Camera className="w-5 h-5" />
                    </div>
                    {(selectedAvatar !== DEFAULT_PERSON_AVATAR || customAvatarUrl.trim()) && (
                      <span className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 border-2 border-white dark:border-zinc-900 rounded-full flex items-center justify-center text-white shadow-xs">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </div>

                  {/* Actions & Description */}
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        id="signup-avatar-upload-btn"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 active:scale-[0.98] text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 shadow-sm transition-all cursor-pointer whitespace-nowrap"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>
                          {selectedAvatar !== DEFAULT_PERSON_AVATAR || customAvatarUrl.trim()
                            ? '사진 변경'
                            : '사진 업로드'}
                        </span>
                      </button>

                      {(selectedAvatar !== DEFAULT_PERSON_AVATAR || customAvatarUrl.trim()) && (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedAvatar(DEFAULT_PERSON_AVATAR);
                            setCustomAvatarUrl('');
                            if (fileInputRef.current) fileInputRef.current.value = '';
                          }}
                          className="px-2.5 py-1.5 text-xs text-zinc-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors font-medium cursor-pointer"
                        >
                          기본으로 초기화
                        </button>
                      )}
                    </div>

                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      {selectedAvatar !== DEFAULT_PERSON_AVATAR || customAvatarUrl.trim()
                        ? '업로드한 사진이 프로필에 등록되었습니다.'
                        : '기기에서 프로필 사진을 업로드하세요. (JPG, PNG 최대 5MB)'}
                    </p>

                    <div className="pt-0.5">
                      <input
                        type="text"
                        value={customAvatarUrl}
                        onChange={(e) => setCustomAvatarUrl(e.target.value)}
                        placeholder="또는 이미지 URL 직접 입력"
                        className="w-full px-2.5 py-1 text-xs bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-lg text-zinc-800 dark:text-zinc-200 placeholder-zinc-400 focus:outline-none focus:border-indigo-600 transition-colors"
                      />
                    </div>

                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleAvatarFileUpload}
                      className="hidden"
                    />
                  </div>
                </div>
              </div>

              {/* Role / Job Selection */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                  직업 / 전문 분야
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {POPULAR_ROLES.map((role) => (
                    <button
                      key={role}
                      type="button"
                      onClick={() => setSignupRole(role)}
                      className={`px-2.5 py-1 rounded-full text-xs font-medium transition-all ${
                        signupRole === role
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-700'
                      }`}
                    >
                      {role}
                    </button>
                  ))}
                </div>
              </div>

              {/* Interests Tags */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                    관심사 태그 (피드 추천에 반영됩니다)
                  </label>
                  <span className="text-[11px] text-zinc-500 dark:text-zinc-400">
                    {selectedInterests.length}개 선택됨
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-1.5 bg-zinc-50 dark:bg-zinc-800/40 rounded-xl border border-zinc-200/60 dark:border-zinc-800">
                  {POPULAR_INTERESTS.map((interest) => {
                    const isSelected = selectedInterests.includes(interest);
                    return (
                      <button
                        key={interest}
                        type="button"
                        onClick={() => toggleInterest(interest)}
                        className={`px-2.5 py-0.5 rounded-lg text-xs transition-all flex items-center gap-1 ${
                          isSelected
                            ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300 font-semibold'
                            : 'bg-white dark:bg-zinc-800 text-zinc-600 dark:text-zinc-400 border border-zinc-200 dark:border-zinc-700 hover:border-zinc-400'
                        }`}
                      >
                        {isSelected && <Check className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />}
                        {interest}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Bio Field */}
              <div className="space-y-1.5">
                <label
                  htmlFor="signup-bio"
                  className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300"
                >
                  한 줄 소개 (Bio)
                </label>
                <textarea
                  id="signup-bio"
                  rows={2}
                  value={signupBio}
                  onChange={(e) => setSignupBio(e.target.value)}
                  placeholder="예: 안녕하세요! 새로운 테크와 일상을 기록하고 공유합니다 ✨"
                  className="w-full p-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-xs text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all resize-none"
                />
              </div>

              {/* Age 14+ Verification Card (개인정보 보호법 제22조의2) */}
              <div className="p-3.5 bg-gradient-to-br from-indigo-50/70 to-purple-50/60 dark:from-indigo-950/40 dark:to-purple-950/30 border border-indigo-200/80 dark:border-indigo-800/60 rounded-xl space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-900 dark:text-indigo-200">
                    <ShieldCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span>만 14세 이상 이용 연령 확인 *</span>
                  </div>
                  {calculateAge(signupBirthdate) !== null && (
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${
                        (calculateAge(signupBirthdate) ?? 0) >= 14
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border-rose-300 dark:border-rose-800 animate-pulse'
                      }`}
                    >
                      {(calculateAge(signupBirthdate) ?? 0) >= 14 ? (
                        <>
                          <CheckCircle className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                          <span>만 {calculateAge(signupBirthdate)}세 (가입 가능 ✅)</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-3 h-3 text-rose-600 dark:text-rose-400" />
                          <span>만 {calculateAge(signupBirthdate)}세 (만 14세 미만 가입 불가 ❌)</span>
                        </>
                      )}
                    </span>
                  )}
                </div>

                {/* Birthdate Input */}
                <div className="space-y-1">
                  <label
                    htmlFor="signup-birthdate"
                    className="block text-xs font-medium text-zinc-700 dark:text-zinc-300 flex items-center justify-between"
                  >
                    <span>생년월일 선택</span>
                    <span className="text-[11px] text-zinc-500 dark:text-zinc-400">
                      정확한 만 나이 자동 계산
                    </span>
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-400">
                      <Calendar className="w-4 h-4 text-indigo-500" />
                    </div>
                    <input
                      id="signup-birthdate"
                      type="date"
                      required
                      value={signupBirthdate}
                      max={new Date().toISOString().split('T')[0]}
                      onChange={(e) => setSignupBirthdate(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 bg-white dark:bg-zinc-800 border border-indigo-200 dark:border-indigo-900/60 rounded-lg text-xs text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    />
                  </div>
                </div>

                {/* Mandatory Checkbox */}
                <label className="flex items-start gap-2.5 cursor-pointer pt-1 border-t border-indigo-100 dark:border-indigo-900/40">
                  <input
                    id="signup-over14-checkbox"
                    type="checkbox"
                    required
                    checked={isOver14Confirmed}
                    onChange={(e) => setIsOver14Confirmed(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-zinc-300 dark:border-zinc-700 cursor-pointer"
                  />
                  <div className="text-xs select-none">
                    <span className="font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-1">
                      [필수] 만 14세 이상입니다.
                    </span>
                    <p className="text-[11px] text-zinc-500 dark:text-zinc-400 mt-0.5 leading-relaxed">
                      개인정보 보호법 제22조의2 및 정보통신망법에 의거하여 만 14세 미만 아동은 법정대리인의 동의가 필요하며, 본 서비스는 만 14세 이상만 가입이 허용됩니다.
                    </p>
                  </div>
                </label>
              </div>

              {/* Submit Signup Button */}
              <button
                id="signup-submit-btn"
                type="submit"
                disabled={isSigningUp}
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 text-white font-semibold text-sm rounded-xl shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
              >
                {isSigningUp ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    회원가입 완료 및 시작하기
                  </>
                )}
              </button>

              {/* Switch to Login */}
              <div className="pt-2 text-center">
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  이미 계정이 있으신가요?{' '}
                  <button
                    type="button"
                    onClick={() => handleTabSwitch('login')}
                    className="font-bold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                  >
                    로그인하기
                  </button>
                </p>
              </div>
            </form>
          )}

          {/* ======================= FIND ID VIEW ======================= */}
          {mode === 'find-id' && (
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                    <Search className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                    아이디 찾기
                  </h3>
                  <button
                    type="button"
                    onClick={() => handleTabSwitch('login')}
                    className="text-xs text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200 flex items-center gap-1 cursor-pointer"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    로그인으로 돌아가기
                  </button>
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  가입 시 등록하신 회원 정보로 아이디(핸들)를 안전하게 확인하실 수 있습니다.
                </p>
              </div>

              {findIdError && (
                <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 rounded-xl flex items-start gap-2.5 text-rose-700 dark:text-rose-300 text-xs animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{findIdError}</span>
                </div>
              )}

              {/* If ID is found */}
              {foundUser ? (
                <div className="p-5 bg-gradient-to-br from-indigo-50/80 via-purple-50/60 to-slate-50 dark:from-indigo-950/40 dark:via-purple-950/30 dark:to-zinc-900 border-2 border-indigo-300/80 dark:border-indigo-700/60 rounded-2xl space-y-4 animate-in fade-in zoom-in-95">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
                      <CheckCircle className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-zinc-900 dark:text-white">
                        회원님의 아이디를 찾았습니다!
                      </h4>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400">
                        {foundUser.name}님의 계정 정보입니다.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-white/90 dark:bg-zinc-800/90 rounded-xl border border-indigo-100 dark:border-zinc-700 space-y-2.5 shadow-sm">
                    <div className="flex items-center justify-between py-1 border-b border-zinc-100 dark:border-zinc-700/60">
                      <span className="text-xs text-zinc-500 dark:text-zinc-400">아이디 (핸들)</span>
                      <span className="font-black text-base text-indigo-600 dark:text-indigo-400 select-all">
                        @{foundUser.handle}
                      </span>
                    </div>
                    <div className="flex items-center justify-between py-1 border-b border-zinc-100 dark:border-zinc-700/60">
                      <span className="text-xs text-zinc-500 dark:text-zinc-400">등록 이메일</span>
                      <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">
                        {foundUser.email ? (
                          foundUser.email.replace(/(^.{2})(.*)(@.*)/, '$1***$3')
                        ) : '미등록'}
                      </span>
                    </div>
                    {foundUser.phoneNumber && (
                      <div className="flex items-center justify-between py-1 border-b border-zinc-100 dark:border-zinc-700/60">
                        <span className="text-xs text-zinc-500 dark:text-zinc-400">등록 휴대폰</span>
                        <span className="text-xs font-semibold text-zinc-800 dark:text-zinc-200">
                          {foundUser.phoneNumber.replace(/(\d{3})-\d{3,4}-(\d{4})/, '$1-****-$2')}
                        </span>
                      </div>
                    )}
                    <div className="flex items-center justify-between py-1">
                      <span className="text-xs text-zinc-500 dark:text-zinc-400">가입 일자</span>
                      <span className="text-xs text-zinc-600 dark:text-zinc-300">
                        {foundUser.joinedDate || (foundUser.createdAt ? new Date(foundUser.createdAt).toLocaleDateString('ko-KR') : '정보 없음')}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="space-y-2 pt-1">
                    <button
                      type="button"
                      id="btn-login-with-found-id"
                      onClick={() => {
                        setLoginIdentifier(foundUser.handle);
                        setAuthModalMode('login');
                      }}
                      className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <LogIn className="w-4 h-4" />
                      이 아이디로 로그인하기
                    </button>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        id="btn-reset-pw-for-found-id"
                        onClick={() => {
                          setResetIdentifier(foundUser.handle);
                          setResetStep(1);
                          setAuthModalMode('reset-password');
                        }}
                        className="flex-1 py-2 bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/40 dark:hover:bg-purple-900/50 text-purple-700 dark:text-purple-300 font-semibold text-xs rounded-xl border border-purple-200 dark:border-purple-800 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <KeyRound className="w-3.5 h-3.5" />
                        비밀번호 찾기
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setFoundUser(null);
                          setFindIdCodeInput('');
                          setIsFindIdCodeSent(false);
                          setIsFindIdCodeVerified(false);
                        }}
                        className="px-4 py-2 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
                      >
                        다시 찾기
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                /* Find ID Form */
                <div className="space-y-4">
                  {/* Method Toggle: Phone vs Email */}
                  <div className="grid grid-cols-2 gap-2 p-1 bg-zinc-100 dark:bg-zinc-800 rounded-xl">
                    <button
                      type="button"
                      onClick={() => {
                        setFindIdMethod('phone');
                        setFindIdError(null);
                        setIsFindIdCodeSent(false);
                      }}
                      className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        findIdMethod === 'phone'
                          ? 'bg-white dark:bg-zinc-700 text-indigo-600 dark:text-indigo-400 shadow-sm'
                          : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
                      }`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      휴대폰 번호로 찾기
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setFindIdMethod('email');
                        setFindIdError(null);
                        setIsFindIdCodeSent(false);
                      }}
                      className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                        findIdMethod === 'email'
                          ? 'bg-white dark:bg-zinc-700 text-indigo-600 dark:text-indigo-400 shadow-sm'
                          : 'text-zinc-500 hover:text-zinc-800 dark:text-zinc-400 dark:hover:text-zinc-200'
                      }`}
                    >
                      <Mail className="w-3.5 h-3.5" />
                      이메일 주소로 찾기
                    </button>
                  </div>

                  <form onSubmit={handleDirectFindId} className="space-y-3.5">
                    {/* Name input */}
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                        이름 (실명 또는 닉네임) *
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                          <User className="w-4 h-4" />
                        </div>
                        <input
                          type="text"
                          required
                          value={findIdName}
                          onChange={(e) => setFindIdName(e.target.value)}
                          placeholder="가입 시 등록한 이름을 입력하세요"
                          className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                        />
                      </div>
                    </div>

                    {/* Contact input */}
                    {findIdMethod === 'phone' ? (
                      <div className="space-y-1.5">
                        <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                          등록 휴대폰 번호 *
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                            <Phone className="w-4 h-4" />
                          </div>
                          <input
                            type="tel"
                            required
                            value={findIdPhone}
                            onChange={(e) => setFindIdPhone(formatPhoneNumber(e.target.value))}
                            placeholder="010-0000-0000"
                            className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                          등록 이메일 주소 *
                        </label>
                        <div className="relative">
                          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                            <Mail className="w-4 h-4" />
                          </div>
                          <input
                            type="email"
                            required
                            value={findIdEmail}
                            onChange={(e) => setFindIdEmail(e.target.value)}
                            placeholder="user@example.com"
                            className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                          />
                        </div>
                      </div>
                    )}

                    {/* Verification option (optional SMS code verification for enhanced privacy) */}
                    {isFindIdCodeSent && (
                      <div className="p-3.5 bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200/80 dark:border-indigo-800/50 rounded-xl space-y-2 animate-in fade-in">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-indigo-900 dark:text-indigo-200">
                            {findIdMethod === 'phone' ? '📱 SMS 인증번호' : '✉️ 이메일 인증번호'}
                          </span>
                          <span className="text-indigo-600 dark:text-indigo-400 font-mono font-bold">
                            {Math.floor(findIdCountdown / 60)}:
                            {String(findIdCountdown % 60).padStart(2, '0')}
                          </span>
                        </div>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            maxLength={6}
                            value={findIdCodeInput}
                            onChange={(e) => setFindIdCodeInput(e.target.value.replace(/\D/g, ''))}
                            placeholder="6자리 숫자 입력"
                            className="flex-1 px-3 py-2 bg-white dark:bg-zinc-900 border border-indigo-300 dark:border-indigo-700 rounded-lg text-sm text-center font-mono font-bold tracking-widest text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                          />
                          <button
                            type="button"
                            onClick={handleVerifyFindIdCode}
                            disabled={isVerifyingFindIdCode || findIdCodeInput.length < 6}
                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs rounded-lg shadow-sm transition-all cursor-pointer"
                          >
                            {isVerifyingFindIdCode ? '확인 중...' : '인증 확인'}
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Find ID Buttons */}
                    <div className="space-y-2 pt-2">
                      <button
                        type="submit"
                        id="btn-direct-find-id"
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-xl shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all active:scale-[0.99] cursor-pointer"
                      >
                        <Search className="w-4 h-4" />
                        아이디 조회하기
                      </button>

                      <div className="flex items-center justify-between text-xs text-zinc-500 pt-1">
                        <span>본인인증 문자를 발송받아 확인하시겠습니까?</span>
                        <button
                          type="button"
                          onClick={handleSendFindIdCode}
                          disabled={isSendingFindIdCode}
                          className="font-bold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                        >
                          {isSendingFindIdCode ? '발송 중...' : isFindIdCodeSent ? '인증번호 재전송' : '인증번호 발송'}
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              )}
            </div>
          )}

          {/* ======================= RESET PASSWORD VIEW ======================= */}
          {mode === 'reset-password' && (
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                    <KeyRound className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                    비밀번호 찾기 / 재설정
                  </h3>
                </div>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  등록된 회원님의 휴대폰 SMS 본인인증을 통해 새 비밀번호를 안전하게 재설정합니다.
                </p>
              </div>

              {/* Step indicator */}
              <div className="flex items-center justify-between px-2 pt-1 pb-2">
                {[
                  { step: 1, label: '계정 확인' },
                  { step: 2, label: '본인 인증' },
                  { step: 3, label: '새 비밀번호' },
                  { step: 4, label: '완료' },
                ].map((s) => (
                  <div key={s.step} className="flex items-center gap-1.5">
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        resetStep === s.step
                          ? 'bg-indigo-600 text-white shadow-md'
                          : resetStep > s.step
                          ? 'bg-emerald-500 text-white'
                          : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-500'
                      }`}
                    >
                      {resetStep > s.step ? <Check className="w-3.5 h-3.5" /> : s.step}
                    </div>
                    <span
                      className={`text-xs ${
                        resetStep === s.step
                          ? 'font-bold text-indigo-600 dark:text-indigo-400'
                          : 'text-zinc-400'
                      }`}
                    >
                      {s.label}
                    </span>
                  </div>
                ))}
              </div>

              {resetError && (
                <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 rounded-xl flex items-start gap-2.5 text-rose-700 dark:text-rose-300 text-xs animate-in fade-in">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{resetError}</span>
                </div>
              )}

              {/* STEP 1: Enter ID & Mobile Phone Verification */}
              {resetStep === 1 && (
                <form onSubmit={handleSendResetPasswordCode} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                      비밀번호를 재설정할 계정 아이디를 입력해주세요*
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                        <AtSign className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        required
                        value={resetIdentifier}
                        onChange={(e) => setResetIdentifier(e.target.value)}
                        placeholder="아이디 (@handle)"
                        className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                      />
                    </div>
                  </div>

                  {/* SMS Verification Notice Card (단일 본인인증) */}
                  <div className="p-3.5 bg-gradient-to-br from-indigo-50/90 to-purple-50/70 dark:from-indigo-950/40 dark:to-purple-950/30 border border-indigo-200/80 dark:border-indigo-800/60 rounded-xl space-y-1.5 shadow-xs">
                    <div className="flex items-center gap-2 font-bold text-xs text-indigo-900 dark:text-indigo-200">
                      <Smartphone className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                      <span>본인확인: 등록 휴대폰 SMS 문자 인증</span>
                    </div>
                    <p className="text-[11px] text-zinc-600 dark:text-zinc-400 leading-relaxed">
                      계정 보안 강화를 위해 가입 시 등록·인증된 회원님의 휴대폰 번호로 6자리 SMS 보안 인증문자가 발송됩니다.
                    </p>
                  </div>

                  <button
                    type="submit"
                    id="btn-send-reset-code"
                    disabled={isSendingResetCode || !resetIdentifier.trim()}
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-semibold text-sm rounded-xl shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all active:scale-[0.99] cursor-pointer"
                  >
                    {isSendingResetCode ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        휴대폰 SMS 인증번호 발송하기
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* STEP 2: Verify Code */}
              {resetStep === 2 && (
                <form onSubmit={handleVerifyResetCode} className="space-y-4 animate-in fade-in">
                  <div className="p-3.5 bg-indigo-50/70 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/50 rounded-xl space-y-1">
                    <p className="text-xs font-semibold text-indigo-950 dark:text-indigo-200">
                      인증번호가 발송되었습니다 📨
                    </p>
                    <p className="text-[11px] text-zinc-600 dark:text-zinc-300">
                      <strong>{resetTargetContact}</strong>(으)로 발송된 6자리 인증번호를 3분 이내에 입력해주세요.
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <label className="font-semibold text-zinc-700 dark:text-zinc-300">
                        인증번호 6자리
                      </label>
                      <span className="text-indigo-600 dark:text-indigo-400 font-mono font-bold">
                        {Math.floor(resetCountdown / 60)}:
                        {String(resetCountdown % 60).padStart(2, '0')}
                      </span>
                    </div>
                    <input
                      type="text"
                      maxLength={6}
                      required
                      value={resetCodeInput}
                      onChange={(e) => setResetCodeInput(e.target.value.replace(/\D/g, ''))}
                      placeholder="6자리 숫자 입력"
                      className="w-full px-4 py-3 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-xl text-center text-lg font-mono font-bold tracking-widest text-zinc-900 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    />
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setResetStep(1)}
                      className="px-4 py-2.5 bg-zinc-100 hover:bg-zinc-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-zinc-700 dark:text-zinc-300 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
                    >
                      이전으로
                    </button>
                    <button
                      type="submit"
                      id="btn-verify-reset-code"
                      disabled={isVerifyingResetCode || resetCodeInput.length < 6}
                      className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-semibold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      {isVerifyingResetCode ? '인증 확인 중...' : '인증 확인 완료'}
                    </button>
                  </div>
                </form>
              )}

              {/* STEP 3: Set New Password */}
              {resetStep === 3 && (
                <form onSubmit={handleResetPasswordSubmit} className="space-y-4 animate-in fade-in">
                  <div className="p-3.5 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 rounded-xl space-y-1">
                    <p className="text-xs font-bold text-emerald-800 dark:text-emerald-200 flex items-center gap-1.5">
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      본인 인증 완료
                    </p>
                    <p className="text-[11px] text-zinc-600 dark:text-zinc-300">
                      <strong>{resetTargetUser?.name || '회원'}</strong>(@{resetTargetUser?.handle})님의 계정 비밀번호를 새로 설정합니다.
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                      새 비밀번호 *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                        <Lock className="w-4 h-4" />
                      </div>
                      <input
                        type={showNewPassword ? 'text' : 'password'}
                        required
                        minLength={4}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="새 비밀번호 (4자 이상)"
                        className="w-full pl-10 pr-10 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPassword((p) => !p)}
                        className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 cursor-pointer"
                      >
                        {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-semibold text-zinc-700 dark:text-zinc-300">
                      새 비밀번호 확인 *
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                        <Lock className="w-4 h-4" />
                      </div>
                      <input
                        type={showNewPassword ? 'text' : 'password'}
                        required
                        minLength={4}
                        value={newPasswordConfirm}
                        onChange={(e) => setNewPasswordConfirm(e.target.value)}
                        placeholder="새 비밀번호 다시 입력"
                        className="w-full pl-10 pr-4 py-2.5 bg-zinc-50 dark:bg-zinc-800/80 border border-zinc-300 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    id="btn-submit-new-password"
                    disabled={isResettingPassword || !newPassword || newPassword.length < 4}
                    className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 text-white font-semibold text-sm rounded-xl shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all active:scale-[0.99] cursor-pointer"
                  >
                    {isResettingPassword ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <KeyRound className="w-4 h-4" />
                        비밀번호 변경 완료하기
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* STEP 4: Success View */}
              {resetStep === 4 && (
                <div className="p-6 bg-slate-50 dark:bg-zinc-800/70 border border-slate-200 dark:border-zinc-700/80 rounded-2xl text-center space-y-4 animate-in fade-in zoom-in-95">
                  <div className="mx-auto w-14 h-14 rounded-full bg-emerald-100 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-zinc-900 dark:text-white">
                      비밀번호가 성공적으로 변경되었습니다! 🎉
                    </h4>
                    <p className="text-xs text-zinc-600 dark:text-zinc-300 mt-1">
                      {resetTargetUser?.name}님의 새 비밀번호가 안전하게 저장되었습니다.
                    </p>
                  </div>
                  <div className="pt-2">
                    <button
                      type="button"
                      id="btn-login-after-reset"
                      onClick={() => {
                        if (resetTargetUser) {
                          login(resetTargetUser.handle, newPassword);
                        } else {
                          setAuthModalMode('login');
                        }
                      }}
                      className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-xl shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <LogIn className="w-4 h-4" />
                      새 비밀번호로 바로 로그인하기
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ======================= QUICK DEMO ACCOUNTS VIEW ======================= */}
          {mode === 'demo' && (
            <div className="space-y-4">
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-amber-500" />
                  준비된 데모 계정으로 즉시 체험하기
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  가입 절차 없이 아래 프로필 중 하나를 클릭하면 즉시 해당 계정으로 로그인됩니다.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-3">
                {users.filter((u) => !u.isAdmin && u.handle !== 'admin' && !u.name.includes('관리자')).map((demoUser) => (
                  <div
                    key={demoUser.id}
                    className="p-3.5 bg-zinc-50 dark:bg-zinc-800/60 hover:bg-zinc-100/80 dark:hover:bg-zinc-800 border border-zinc-200/80 dark:border-zinc-700/60 rounded-xl transition-all flex items-center justify-between gap-3 group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={demoUser.avatar}
                        alt={demoUser.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-zinc-200 dark:border-zinc-700 group-hover:border-indigo-500 transition-colors"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-sm text-zinc-900 dark:text-white truncate">
                            {demoUser.name}
                          </span>
                          {demoUser.isVerified && (
                            <CheckCircle className="w-3.5 h-3.5 text-indigo-600 fill-indigo-600 dark:text-indigo-400 dark:fill-indigo-400 shrink-0" />
                          )}
                          <span className="text-xs text-zinc-400 truncate">
                            @{demoUser.handle}
                          </span>
                        </div>
                        <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium">
                          {demoUser.role || '소셜 크리에이터'}
                        </p>
                        <p className="text-[11px] text-zinc-500 dark:text-zinc-400 line-clamp-1 mt-0.5">
                          {demoUser.bio}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleQuickDemoLogin(demoUser)}
                      className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shrink-0 shadow-sm flex items-center gap-1.5 transition-all group-hover:scale-105"
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      {demoUser.name}
                    </button>
                  </div>
                ))}
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 rounded-xl text-amber-800 dark:text-amber-300 text-xs">
                💡 새로운 계정을 직접 만들어보고 싶으신가요?{' '}
                <button
                  type="button"
                  onClick={() => handleTabSwitch('signup')}
                  className="font-bold underline ml-1 cursor-pointer"
                >
                  회원가입 탭
                </button>
                으로 이동하세요.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
